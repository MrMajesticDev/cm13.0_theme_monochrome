package com.android.keyguard;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import com.android.settingslib.animation.AppearAnimationUtils;
import com.android.settingslib.animation.DisappearAnimationUtils;

public class KeyguardPINView extends KeyguardPinBasedInputView {
    private final AppearAnimationUtils mAppearAnimationUtils;
    private ViewGroup mContainer;
    private final DisappearAnimationUtils mDisappearAnimationUtils;
    private int mDisappearYTranslation;
    private View mDivider;
    private ViewGroup mRow0;
    private ViewGroup mRow1;
    private ViewGroup mRow2;
    private ViewGroup mRow3;
    private View[][] mViews;

    /* renamed from: com.android.keyguard.KeyguardPINView.1 */
    class C00141 implements Runnable {
        C00141() {
        }

        public void run() {
            KeyguardPINView.this.enableClipping(true);
        }
    }

    /* renamed from: com.android.keyguard.KeyguardPINView.2 */
    class C00152 implements Runnable {
        final /* synthetic */ Runnable val$finishRunnable;

        C00152(Runnable runnable) {
            this.val$finishRunnable = runnable;
        }

        public void run() {
            KeyguardPINView.this.enableClipping(true);
            if (this.val$finishRunnable != null) {
                this.val$finishRunnable.run();
            }
        }
    }

    public KeyguardPINView(Context context) {
        this(context, null);
    }

    public KeyguardPINView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mAppearAnimationUtils = new AppearAnimationUtils(context);
        this.mDisappearAnimationUtils = new DisappearAnimationUtils(context, 125, 0.6f, 0.45f, AnimationUtils.loadInterpolator(this.mContext, 17563663));
        this.mDisappearYTranslation = getResources().getDimensionPixelSize(C0065R.dimen.disappear_y_translation);
    }

    protected void resetState() {
        super.resetState();
        this.mSecurityMessageDisplay.setMessage(getMsgWithCnt(C0065R.string.kg_pin_instructions), false);
    }

    protected int getPasswordTextViewId() {
        return C0065R.id.pinEntry;
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mContainer = (ViewGroup) findViewById(C0065R.id.container);
        this.mRow0 = (ViewGroup) findViewById(C0065R.id.row0);
        this.mRow1 = (ViewGroup) findViewById(C0065R.id.row1);
        this.mRow2 = (ViewGroup) findViewById(C0065R.id.row2);
        this.mRow3 = (ViewGroup) findViewById(C0065R.id.row3);
        this.mDivider = findViewById(C0065R.id.divider);
        View[][] viewArr = new View[6][];
        viewArr[0] = new View[]{this.mRow0, null, null};
        viewArr[1] = new View[]{findViewById(C0065R.id.key1), findViewById(C0065R.id.key2), findViewById(C0065R.id.key3)};
        viewArr[2] = new View[]{findViewById(C0065R.id.key4), findViewById(C0065R.id.key5), findViewById(C0065R.id.key6)};
        viewArr[3] = new View[]{findViewById(C0065R.id.key7), findViewById(C0065R.id.key8), findViewById(C0065R.id.key9)};
        viewArr[4] = new View[]{null, findViewById(C0065R.id.key0), findViewById(C0065R.id.key_enter)};
        viewArr[5] = new View[]{null, this.mEcaView, null};
        this.mViews = viewArr;
    }

    public int getWrongPasswordStringId() {
        return C0065R.string.kg_wrong_pin;
    }

    public void startAppearAnimation() {
        enableClipping(false);
        setAlpha(1.0f);
        setTranslationY(this.mAppearAnimationUtils.getStartTranslation());
        AppearAnimationUtils.startTranslationYAnimation(this, 0, 500, 0.0f, this.mAppearAnimationUtils.getInterpolator());
        this.mAppearAnimationUtils.startAnimation2d(this.mViews, new C00141());
    }

    public boolean startDisappearAnimation(Runnable finishRunnable) {
        enableClipping(false);
        setTranslationY(0.0f);
        AppearAnimationUtils.startTranslationYAnimation(this, 0, 280, (float) this.mDisappearYTranslation, this.mDisappearAnimationUtils.getInterpolator());
        this.mDisappearAnimationUtils.startAnimation2d(this.mViews, new C00152(finishRunnable));
        return true;
    }

    private void enableClipping(boolean enable) {
        this.mContainer.setClipToPadding(enable);
        this.mContainer.setClipChildren(enable);
        this.mRow1.setClipToPadding(enable);
        this.mRow2.setClipToPadding(enable);
        this.mRow3.setClipToPadding(enable);
        setClipChildren(enable);
    }

    public boolean hasOverlappingRendering() {
        return false;
    }
}
