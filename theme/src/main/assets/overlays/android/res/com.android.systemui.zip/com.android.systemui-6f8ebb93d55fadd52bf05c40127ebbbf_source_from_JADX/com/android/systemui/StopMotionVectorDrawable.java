package com.android.systemui;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableWrapper;
import java.util.Iterator;

public class StopMotionVectorDrawable extends DrawableWrapper {
    private static final String TAG;
    private AnimatorSet mAnimatorSet;
    private AnimatedVectorDrawable mDrawable;

    static {
        TAG = StopMotionVectorDrawable.class.getSimpleName();
    }

    public StopMotionVectorDrawable(Drawable dr) {
        super(dr);
        setDrawable(dr);
    }

    public void setDrawable(Drawable dr) {
        if (dr == null || (dr instanceof AnimatedVectorDrawable)) {
            super.setDrawable(dr);
            this.mDrawable = (AnimatedVectorDrawable) dr;
            if (this.mDrawable != null) {
                this.mDrawable.reset();
                getAnimatorSetViaReflection();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Drawable must be an AnimatedVectorDrawable");
    }

    public void setCurrentFraction(float fraction) {
        if (this.mDrawable != null && this.mAnimatorSet != null) {
            Iterator i$ = this.mAnimatorSet.getChildAnimations().iterator();
            while (i$.hasNext()) {
                Animator animator = (Animator) i$.next();
                if (animator instanceof ValueAnimator) {
                    ((ValueAnimator) animator).setCurrentFraction(fraction);
                }
            }
            this.mDrawable.invalidateSelf();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void getAnimatorSetViaReflection() {
        /*
        r4 = this;
        r2 = android.graphics.drawable.AnimatedVectorDrawable.class;
        r3 = "mAnimatorSet";
        r0 = r2.getDeclaredField(r3);	 Catch:{ NoSuchFieldException -> 0x0017, IllegalAccessException -> 0x0020 }
        r2 = 1;
        r0.setAccessible(r2);	 Catch:{ NoSuchFieldException -> 0x0017, IllegalAccessException -> 0x0020 }
        r2 = r4.mDrawable;	 Catch:{ NoSuchFieldException -> 0x0017, IllegalAccessException -> 0x0020 }
        r2 = r0.get(r2);	 Catch:{ NoSuchFieldException -> 0x0017, IllegalAccessException -> 0x0020 }
        r2 = (android.animation.AnimatorSet) r2;	 Catch:{ NoSuchFieldException -> 0x0017, IllegalAccessException -> 0x0020 }
        r4.mAnimatorSet = r2;	 Catch:{ NoSuchFieldException -> 0x0017, IllegalAccessException -> 0x0020 }
    L_0x0016:
        return;
    L_0x0017:
        r1 = move-exception;
    L_0x0018:
        r2 = TAG;
        r3 = "Could not get mAnimatorSet via reflection";
        android.util.Log.e(r2, r3, r1);
        goto L_0x0016;
    L_0x0020:
        r1 = move-exception;
        goto L_0x0018;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.StopMotionVectorDrawable.getAnimatorSetViaReflection():void");
    }
}
