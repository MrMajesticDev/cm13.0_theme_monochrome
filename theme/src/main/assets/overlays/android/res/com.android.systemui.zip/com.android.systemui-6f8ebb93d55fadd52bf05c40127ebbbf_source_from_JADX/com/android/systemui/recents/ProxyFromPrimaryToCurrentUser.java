package com.android.systemui.recents;

/* compiled from: Recents */
@interface ProxyFromPrimaryToCurrentUser {
}
