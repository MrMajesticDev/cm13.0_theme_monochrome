package com.android.keyguard;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AlarmManager.AlarmClockInfo;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.provider.Settings.System;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.widget.GridLayout;
import android.widget.TextClock;
import android.widget.TextView;
import com.android.internal.widget.LockPatternUtils;
import java.util.Locale;

public class KeyguardStatusView extends GridLayout {
    private final AlarmManager mAlarmManager;
    private TextView mAlarmStatusView;
    private TextClock mClockView;
    private TextClock mDateView;
    private boolean mEnableRefresh;
    private KeyguardUpdateMonitorCallback mInfoCallback;
    private final LockPatternUtils mLockPatternUtils;
    private TextView mOwnerInfo;

    /* renamed from: com.android.keyguard.KeyguardStatusView.1 */
    class C00441 extends KeyguardUpdateMonitorCallback {
        C00441() {
        }

        public void onTimeChanged() {
            if (KeyguardStatusView.this.mEnableRefresh) {
                KeyguardStatusView.this.refresh();
            }
        }

        public void onKeyguardVisibilityChanged(boolean showing) {
            if (showing) {
                KeyguardStatusView.this.refresh();
                KeyguardStatusView.this.updateOwnerInfo();
            }
        }

        public void onStartedWakingUp() {
            KeyguardStatusView.this.setEnableMarquee(true);
            KeyguardStatusView.this.mEnableRefresh = true;
            KeyguardStatusView.this.refresh();
        }

        public void onFinishedGoingToSleep(int why) {
            KeyguardStatusView.this.setEnableMarquee(false);
            KeyguardStatusView.this.mEnableRefresh = false;
        }

        public void onUserSwitchComplete(int userId) {
            KeyguardStatusView.this.refresh();
            KeyguardStatusView.this.updateOwnerInfo();
        }
    }

    private static final class Patterns {
        static String cacheKey;
        static String clockView12;
        static String clockView24;
        static String dateView;

        static void update(Context context, boolean hasAlarm) {
            Locale locale = Locale.getDefault();
            Resources res = context.getResources();
            String dateViewSkel = res.getString(hasAlarm ? C0065R.string.abbrev_wday_month_day_no_year_alarm : C0065R.string.abbrev_wday_month_day_no_year);
            String clockView12Skel = res.getString(C0065R.string.clock_12hr_format);
            String clockView24Skel = res.getString(C0065R.string.clock_24hr_format);
            if (res.getBoolean(17957048)) {
                String dateformat = System.getString(context.getContentResolver(), "date_format");
                if (dateformat.equals(dateView)) {
                    dateformat = dateView;
                }
                dateView = dateformat;
            } else {
                String key = locale.toString() + dateViewSkel + clockView12Skel + clockView24Skel;
                if (!key.equals(cacheKey)) {
                    dateView = DateFormat.getBestDateTimePattern(locale, dateViewSkel);
                    cacheKey = key;
                } else {
                    return;
                }
            }
            clockView12 = DateFormat.getBestDateTimePattern(locale, clockView12Skel);
            if (!clockView12Skel.contains("a")) {
                clockView12 = clockView12.replaceAll("a", "").trim();
            }
            clockView24 = DateFormat.getBestDateTimePattern(locale, clockView24Skel);
            clockView24 = clockView24.replace(':', '\uee01');
            clockView12 = clockView12.replace(':', '\uee01');
        }
    }

    public KeyguardStatusView(Context context) {
        this(context, null, 0);
    }

    public KeyguardStatusView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public KeyguardStatusView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mEnableRefresh = false;
        this.mInfoCallback = new C00441();
        this.mAlarmManager = (AlarmManager) context.getSystemService("alarm");
        this.mLockPatternUtils = new LockPatternUtils(getContext());
    }

    private void setEnableMarquee(boolean enabled) {
        if (this.mAlarmStatusView != null) {
            this.mAlarmStatusView.setSelected(enabled);
        }
        if (this.mOwnerInfo != null) {
            this.mOwnerInfo.setSelected(enabled);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mAlarmStatusView = (TextView) findViewById(C0065R.id.alarm_status);
        this.mDateView = (TextClock) findViewById(C0065R.id.date_view);
        this.mClockView = (TextClock) findViewById(C0065R.id.clock_view);
        this.mDateView.setShowCurrentUserTime(true);
        this.mClockView.setShowCurrentUserTime(true);
        this.mOwnerInfo = (TextView) findViewById(C0065R.id.owner_info);
        setEnableMarquee(KeyguardUpdateMonitor.getInstance(this.mContext).isDeviceInteractive());
        refresh();
        updateOwnerInfo();
        this.mClockView.setElegantTextHeight(false);
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.mClockView.setTextSize(0, (float) getResources().getDimensionPixelSize(C0065R.dimen.widget_big_font_size));
        this.mDateView.setTextSize(0, (float) getResources().getDimensionPixelSize(C0065R.dimen.widget_label_font_size));
        this.mOwnerInfo.setTextSize(0, (float) getResources().getDimensionPixelSize(C0065R.dimen.widget_label_font_size));
    }

    public void refreshTime() {
        this.mDateView.setFormat24Hour(Patterns.dateView);
        this.mDateView.setFormat12Hour(Patterns.dateView);
        this.mClockView.setFormat12Hour(Patterns.clockView12);
        this.mClockView.setFormat24Hour(Patterns.clockView24);
    }

    private void refresh() {
        AlarmClockInfo nextAlarm = this.mAlarmManager.getNextAlarmClock(-2);
        Patterns.update(this.mContext, nextAlarm != null);
        refreshTime();
        refreshAlarmStatus(nextAlarm);
    }

    void refreshAlarmStatus(AlarmClockInfo nextAlarm) {
        if (nextAlarm != null) {
            this.mAlarmStatusView.setText(formatNextAlarm(this.mContext, nextAlarm));
            this.mAlarmStatusView.setContentDescription(getResources().getString(C0065R.string.keyguard_accessibility_next_alarm, new Object[]{alarm}));
            this.mAlarmStatusView.setVisibility(0);
            return;
        }
        this.mAlarmStatusView.setVisibility(8);
    }

    public static String formatNextAlarm(Context context, AlarmClockInfo info) {
        if (info == null) {
            return "";
        }
        return DateFormat.format(DateFormat.getBestDateTimePattern(Locale.getDefault(), DateFormat.is24HourFormat(context, ActivityManager.getCurrentUser()) ? "EHm" : "Ehma"), info.getTriggerTime()).toString();
    }

    private void updateOwnerInfo() {
        if (this.mOwnerInfo != null) {
            String ownerInfo = getOwnerInfo();
            if (TextUtils.isEmpty(ownerInfo)) {
                this.mOwnerInfo.setVisibility(8);
                return;
            }
            this.mOwnerInfo.setVisibility(0);
            this.mOwnerInfo.setText(ownerInfo);
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        KeyguardUpdateMonitor.getInstance(this.mContext).registerCallback(this.mInfoCallback);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        KeyguardUpdateMonitor.getInstance(this.mContext).removeCallback(this.mInfoCallback);
    }

    private String getOwnerInfo() {
        ContentResolver res = getContext().getContentResolver();
        if (this.mLockPatternUtils.isOwnerInfoEnabled(KeyguardUpdateMonitor.getCurrentUser())) {
            return this.mLockPatternUtils.getOwnerInfo(KeyguardUpdateMonitor.getCurrentUser());
        }
        return null;
    }

    public boolean hasOverlappingRendering() {
        return false;
    }
}
