package com.android.systemui.statusbar.policy;

import android.app.ActivityManager;
import android.content.Context;
import com.android.keyguard.KeyguardUpdateMonitor;
import com.android.keyguard.KeyguardUpdateMonitorCallback;
import com.android.systemui.settings.CurrentUserTracker;
import java.util.ArrayList;
import java.util.Iterator;

public final class KeyguardMonitor extends KeyguardUpdateMonitorCallback {
    private final ArrayList<Callback> mCallbacks;
    private boolean mCanSkipBouncer;
    private final Context mContext;
    private int mCurrentUser;
    private final KeyguardUpdateMonitor mKeyguardUpdateMonitor;
    private boolean mListening;
    private boolean mSecure;
    private boolean mShowing;
    private final CurrentUserTracker mUserTracker;

    public interface Callback {
        void onKeyguardChanged();
    }

    /* renamed from: com.android.systemui.statusbar.policy.KeyguardMonitor.1 */
    class C04771 extends CurrentUserTracker {
        C04771(Context x0) {
            super(x0);
        }

        public void onUserSwitched(int newUserId) {
            KeyguardMonitor.this.mCurrentUser = newUserId;
            KeyguardMonitor.this.updateCanSkipBouncerState();
        }
    }

    public KeyguardMonitor(Context context) {
        this.mCallbacks = new ArrayList();
        this.mContext = context;
        this.mKeyguardUpdateMonitor = KeyguardUpdateMonitor.getInstance(this.mContext);
        this.mUserTracker = new C04771(this.mContext);
    }

    public void addCallback(Callback callback) {
        this.mCallbacks.add(callback);
        if (this.mCallbacks.size() != 0 && !this.mListening) {
            this.mListening = true;
            this.mCurrentUser = ActivityManager.getCurrentUser();
            updateCanSkipBouncerState();
            this.mKeyguardUpdateMonitor.registerCallback(this);
            this.mUserTracker.startTracking();
        }
    }

    public void removeCallback(Callback callback) {
        if (this.mCallbacks.remove(callback) && this.mCallbacks.size() == 0 && this.mListening) {
            this.mListening = false;
            this.mKeyguardUpdateMonitor.removeCallback(this);
            this.mUserTracker.stopTracking();
        }
    }

    public boolean isShowing() {
        return this.mShowing;
    }

    public boolean isSecure() {
        return this.mSecure;
    }

    public boolean canSkipBouncer() {
        return this.mCanSkipBouncer;
    }

    public void notifyKeyguardState(boolean showing, boolean secure) {
        if (this.mShowing != showing || this.mSecure != secure) {
            this.mShowing = showing;
            this.mSecure = secure;
            notifyKeyguardChanged();
        }
    }

    public void onTrustChanged(int userId) {
        updateCanSkipBouncerState();
        notifyKeyguardChanged();
    }

    private void updateCanSkipBouncerState() {
        this.mCanSkipBouncer = this.mKeyguardUpdateMonitor.getUserCanSkipBouncer(this.mCurrentUser);
    }

    private void notifyKeyguardChanged() {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onKeyguardChanged();
        }
    }
}
