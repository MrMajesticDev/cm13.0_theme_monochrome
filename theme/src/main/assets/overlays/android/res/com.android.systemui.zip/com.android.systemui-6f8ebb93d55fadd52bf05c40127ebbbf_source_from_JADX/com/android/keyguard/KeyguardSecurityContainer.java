package com.android.keyguard;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Slog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import com.android.internal.widget.LockPatternUtils;
import com.android.keyguard.KeyguardSecurityModel.SecurityMode;

public class KeyguardSecurityContainer extends FrameLayout implements KeyguardSecurityView {
    private KeyguardSecurityCallback mCallback;
    private SecurityMode mCurrentSecuritySelection;
    private LockPatternUtils mLockPatternUtils;
    private KeyguardSecurityCallback mNullCallback;
    private SecurityCallback mSecurityCallback;
    private KeyguardSecurityModel mSecurityModel;
    private KeyguardSecurityViewFlipper mSecurityViewFlipper;
    private final KeyguardUpdateMonitor mUpdateMonitor;
    private WipeConfirmListener mWipeConfirmListener;

    public interface SecurityCallback {
        boolean dismiss(boolean z);

        void finish(boolean z);

        void onSecurityModeChanged(SecurityMode securityMode, boolean z);

        void reset();

        void userActivity();
    }

    /* renamed from: com.android.keyguard.KeyguardSecurityContainer.1 */
    class C00281 implements OnClickListener {
        C00281() {
        }

        public void onClick(DialogInterface dialog, int which) {
            KeyguardSecurityContainer.this.showWipeConfirmDialog();
        }
    }

    /* renamed from: com.android.keyguard.KeyguardSecurityContainer.2 */
    class C00292 implements KeyguardSecurityCallback {
        C00292() {
        }

        public void userActivity() {
            if (KeyguardSecurityContainer.this.mSecurityCallback != null) {
                KeyguardSecurityContainer.this.mSecurityCallback.userActivity();
            }
        }

        public void dismiss(boolean authenticated) {
            KeyguardSecurityContainer.this.mSecurityCallback.dismiss(authenticated);
        }

        public void reportUnlockAttempt(boolean success, int timeoutMs) {
            KeyguardUpdateMonitor monitor = KeyguardUpdateMonitor.getInstance(KeyguardSecurityContainer.this.mContext);
            if (success) {
                monitor.clearFailedUnlockAttempts();
                KeyguardSecurityContainer.this.mLockPatternUtils.reportSuccessfulPasswordAttempt(KeyguardUpdateMonitor.getCurrentUser());
                return;
            }
            KeyguardSecurityContainer.this.reportFailedUnlockAttempt(timeoutMs);
        }

        public void reset() {
            KeyguardSecurityContainer.this.mSecurityCallback.reset();
        }
    }

    /* renamed from: com.android.keyguard.KeyguardSecurityContainer.3 */
    class C00303 implements KeyguardSecurityCallback {
        C00303() {
        }

        public void userActivity() {
        }

        public void reportUnlockAttempt(boolean success, int timeoutMs) {
        }

        public void dismiss(boolean securityVerified) {
        }

        public void reset() {
        }
    }

    /* renamed from: com.android.keyguard.KeyguardSecurityContainer.4 */
    static /* synthetic */ class C00314 {
        static final /* synthetic */ int[] f0xdc0e830a;

        static {
            f0xdc0e830a = new int[SecurityMode.values().length];
            try {
                f0xdc0e830a[SecurityMode.Pattern.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                f0xdc0e830a[SecurityMode.PIN.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                f0xdc0e830a[SecurityMode.Password.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                f0xdc0e830a[SecurityMode.Invalid.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                f0xdc0e830a[SecurityMode.None.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                f0xdc0e830a[SecurityMode.SimPin.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                f0xdc0e830a[SecurityMode.SimPuk.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
        }
    }

    private class WipeConfirmListener implements OnClickListener {
        private WipeConfirmListener() {
        }

        public void onClick(DialogInterface dialog, int which) {
            if (-1 == which) {
                KeyguardUpdateMonitor.getInstance(KeyguardSecurityContainer.this.mContext).clearFailedUnlockAttempts();
            } else if (!ActivityManager.isUserAMonkey()) {
                KeyguardSecurityContainer.this.mContext.sendBroadcast(new Intent("android.intent.action.MASTER_CLEAR"));
            }
        }
    }

    public KeyguardSecurityContainer(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public KeyguardSecurityContainer(Context context) {
        this(context, null, 0);
    }

    public KeyguardSecurityContainer(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mCurrentSecuritySelection = SecurityMode.Invalid;
        this.mWipeConfirmListener = null;
        this.mCallback = new C00292();
        this.mNullCallback = new C00303();
        this.mSecurityModel = new KeyguardSecurityModel(context);
        this.mLockPatternUtils = new LockPatternUtils(context);
        this.mUpdateMonitor = KeyguardUpdateMonitor.getInstance(this.mContext);
    }

    public void setSecurityCallback(SecurityCallback callback) {
        this.mSecurityCallback = callback;
    }

    public void onResume(int reason) {
        if (this.mCurrentSecuritySelection != SecurityMode.None) {
            getSecurityView(this.mCurrentSecuritySelection).onResume(reason);
        }
    }

    public void onPause() {
        if (this.mCurrentSecuritySelection != SecurityMode.None) {
            getSecurityView(this.mCurrentSecuritySelection).onPause();
        }
    }

    public void startAppearAnimation() {
        if (this.mCurrentSecuritySelection != SecurityMode.None) {
            getSecurityView(this.mCurrentSecuritySelection).startAppearAnimation();
        }
    }

    public boolean startDisappearAnimation(Runnable onFinishRunnable) {
        if (this.mCurrentSecuritySelection != SecurityMode.None) {
            return getSecurityView(this.mCurrentSecuritySelection).startDisappearAnimation(onFinishRunnable);
        }
        return false;
    }

    public CharSequence getCurrentSecurityModeContentDescription() {
        View v = (View) getSecurityView(this.mCurrentSecuritySelection);
        if (v != null) {
            return v.getContentDescription();
        }
        return "";
    }

    private KeyguardSecurityView getSecurityView(SecurityMode securityMode) {
        int securityViewIdForMode = getSecurityViewIdForMode(securityMode);
        KeyguardSecurityView view = null;
        int children = this.mSecurityViewFlipper.getChildCount();
        for (int child = 0; child < children; child++) {
            if (this.mSecurityViewFlipper.getChildAt(child).getId() == securityViewIdForMode) {
                view = (KeyguardSecurityView) this.mSecurityViewFlipper.getChildAt(child);
                break;
            }
        }
        int layoutId = getLayoutIdFor(securityMode);
        if (view != null || layoutId == 0) {
            return view;
        }
        View v = LayoutInflater.from(this.mContext).inflate(layoutId, this.mSecurityViewFlipper, false);
        this.mSecurityViewFlipper.addView(v);
        updateSecurityView(v);
        return (KeyguardSecurityView) v;
    }

    private void updateSecurityView(View view) {
        if (view instanceof KeyguardSecurityView) {
            KeyguardSecurityView ksv = (KeyguardSecurityView) view;
            ksv.setKeyguardCallback(this.mCallback);
            ksv.setLockPatternUtils(this.mLockPatternUtils);
            return;
        }
        Log.w("KeyguardSecurityView", "View " + view + " is not a KeyguardSecurityView");
    }

    protected void onFinishInflate() {
        this.mSecurityViewFlipper = (KeyguardSecurityViewFlipper) findViewById(C0065R.id.view_flipper);
        this.mSecurityViewFlipper.setLockPatternUtils(this.mLockPatternUtils);
    }

    public void setLockPatternUtils(LockPatternUtils utils) {
        this.mLockPatternUtils = utils;
        this.mSecurityModel.setLockPatternUtils(utils);
        this.mSecurityViewFlipper.setLockPatternUtils(this.mLockPatternUtils);
    }

    private void showDialog(String title, String message) {
        AlertDialog dialog = new Builder(this.mContext).setTitle(title).setMessage(message).setNeutralButton(C0065R.string.ok, null).create();
        if (!(this.mContext instanceof Activity)) {
            dialog.getWindow().setType(2009);
        }
        dialog.show();
    }

    private void showTimeoutDialog(int timeoutMs) {
        int timeoutInSeconds = timeoutMs / 1000;
        int messageId = 0;
        switch (C00314.f0xdc0e830a[this.mSecurityModel.getSecurityMode().ordinal()]) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                messageId = C0065R.string.kg_too_many_failed_pattern_attempts_dialog_message;
                break;
            case 2:
                messageId = C0065R.string.kg_too_many_failed_pin_attempts_dialog_message;
                break;
            case 3:
                messageId = C0065R.string.kg_too_many_failed_password_attempts_dialog_message;
                break;
        }
        if (messageId != 0) {
            showDialog(null, this.mContext.getString(messageId, new Object[]{Integer.valueOf(KeyguardUpdateMonitor.getInstance(this.mContext).getFailedUnlockAttempts()), Integer.valueOf(timeoutInSeconds)}));
        }
    }

    private void showAlmostAtWipeDialog(int attempts, int remaining, int userType) {
        String message = null;
        switch (userType) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                message = this.mContext.getString(C0065R.string.kg_failed_attempts_almost_at_wipe, new Object[]{Integer.valueOf(attempts), Integer.valueOf(remaining)});
                break;
            case 2:
                message = this.mContext.getString(C0065R.string.kg_failed_attempts_almost_at_erase_profile, new Object[]{Integer.valueOf(attempts), Integer.valueOf(remaining)});
                break;
            case 3:
                message = this.mContext.getString(C0065R.string.kg_failed_attempts_almost_at_erase_user, new Object[]{Integer.valueOf(attempts), Integer.valueOf(remaining)});
                break;
        }
        showDialog(null, message);
    }

    private void showWipeDialog(int attempts, int userType) {
        String message = null;
        switch (userType) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                message = this.mContext.getString(C0065R.string.kg_failed_attempts_now_wiping, new Object[]{Integer.valueOf(attempts)});
                break;
            case 2:
                message = this.mContext.getString(C0065R.string.kg_failed_attempts_now_erasing_profile, new Object[]{Integer.valueOf(attempts)});
                break;
            case 3:
                message = this.mContext.getString(C0065R.string.kg_failed_attempts_now_erasing_user, new Object[]{Integer.valueOf(attempts)});
                break;
        }
        showDialog(null, message);
    }

    private void showCountdownWipeDialog(int attempts) {
        int msgId = C0065R.string.kg_failed_attempts_now_wiping;
        switch (C00314.f0xdc0e830a[this.mSecurityModel.getSecurityMode().ordinal()]) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                msgId = C0065R.string.kg_failed_pattern_attempts_now_wiping;
                break;
            case 2:
                msgId = C0065R.string.kg_failed_pin_attempts_now_wiping;
                break;
            case 3:
                msgId = C0065R.string.kg_failed_password_attempts_now_wiping;
                break;
        }
        if (this.mWipeConfirmListener == null) {
            this.mWipeConfirmListener = new WipeConfirmListener();
        }
        AlertDialog dialog = new Builder(this.mContext).setMessage(this.mContext.getString(msgId, new Object[]{Integer.valueOf(attempts)})).setNegativeButton(17040501, new C00281()).setPositiveButton(17040502, this.mWipeConfirmListener).setCancelable(false).create();
        if (!(this.mContext instanceof Activity)) {
            dialog.getWindow().setType(2009);
        }
        dialog.show();
    }

    private void showWipeConfirmDialog() {
        AlertDialog dialog = new Builder(this.mContext).setMessage(C0065R.string.kg_failed_attempts_now_wiping_confirm).setNegativeButton(17040501, this.mWipeConfirmListener).setPositiveButton(17040502, this.mWipeConfirmListener).setCancelable(false).create();
        if (!(this.mContext instanceof Activity)) {
            dialog.getWindow().setType(2009);
        }
        dialog.show();
    }

    private void reportFailedUnlockAttempt(int timeoutMs) {
        KeyguardUpdateMonitor monitor = KeyguardUpdateMonitor.getInstance(this.mContext);
        int failedAttempts = monitor.getFailedUnlockAttempts() + 1;
        SecurityMode mode = this.mSecurityModel.getSecurityMode();
        int currentUser = KeyguardUpdateMonitor.getCurrentUser();
        DevicePolicyManager dpm = this.mLockPatternUtils.getDevicePolicyManager();
        int failedAttemptsBeforeWipe = dpm.getMaximumFailedPasswordsForWipe(null, currentUser);
        boolean usingPattern = mode == SecurityMode.Pattern;
        boolean usingPIN = mode == SecurityMode.PIN;
        boolean usingPassword = mode == SecurityMode.Password;
        int maxCountdownTimes = this.mContext.getResources().getInteger(C0065R.integer.config_max_unlock_countdown_times);
        boolean enableTimesCounter = maxCountdownTimes > 0 && (usingPattern || usingPIN || usingPassword);
        int remainingBeforeWipe = failedAttemptsBeforeWipe > 0 ? failedAttemptsBeforeWipe - failedAttempts : Integer.MAX_VALUE;
        if (enableTimesCounter && failedAttempts >= maxCountdownTimes) {
            showCountdownWipeDialog(failedAttempts);
        } else if (remainingBeforeWipe < 5) {
            int expiringUser = dpm.getProfileWithMinimumFailedPasswordsForWipe(currentUser);
            int userType = 1;
            if (expiringUser == currentUser) {
                if (expiringUser != 0) {
                    userType = 3;
                }
            } else if (expiringUser != -10000) {
                userType = 2;
            }
            if (remainingBeforeWipe > 0) {
                showAlmostAtWipeDialog(failedAttempts, remainingBeforeWipe, userType);
            } else {
                Slog.i("KeyguardSecurityView", "Too many unlock attempts; user " + expiringUser + " will be wiped!");
                showWipeDialog(failedAttempts, userType);
            }
        }
        monitor.reportFailedStrongAuthUnlockAttempt();
        this.mLockPatternUtils.reportFailedPasswordAttempt(KeyguardUpdateMonitor.getCurrentUser());
        if (!enableTimesCounter && timeoutMs > 0) {
            showTimeoutDialog(timeoutMs);
        }
    }

    void showPrimarySecurityScreen(boolean turningOff) {
        showSecurityScreen(this.mSecurityModel.getSecurityMode());
    }

    boolean showNextSecurityScreenOrFinish(boolean authenticated) {
        boolean finish = false;
        boolean strongAuth = false;
        if (!this.mUpdateMonitor.getUserCanSkipBouncer(KeyguardUpdateMonitor.getCurrentUser())) {
            SecurityMode securityMode;
            if (SecurityMode.None != this.mCurrentSecuritySelection) {
                if (authenticated) {
                    switch (C00314.f0xdc0e830a[this.mCurrentSecuritySelection.ordinal()]) {
                        case C0065R.styleable.NumPadKey_textView /*1*/:
                        case 2:
                        case 3:
                            strongAuth = true;
                            finish = true;
                            break;
                        case 6:
                        case 7:
                            securityMode = this.mSecurityModel.getSecurityMode();
                            if (securityMode != SecurityMode.None || !this.mLockPatternUtils.isLockScreenDisabled(KeyguardUpdateMonitor.getCurrentUser())) {
                                showSecurityScreen(securityMode);
                                break;
                            }
                            finish = true;
                            break;
                            break;
                        default:
                            Log.v("KeyguardSecurityView", "Bad security screen " + this.mCurrentSecuritySelection + ", fail safe");
                            showPrimarySecurityScreen(false);
                            break;
                    }
                }
            }
            securityMode = this.mSecurityModel.getSecurityMode();
            if (SecurityMode.None == securityMode) {
                finish = true;
            } else {
                showSecurityScreen(securityMode);
            }
        } else {
            finish = true;
        }
        if (finish) {
            this.mSecurityCallback.finish(strongAuth);
        }
        return finish;
    }

    private void showSecurityScreen(SecurityMode securityMode) {
        if (securityMode != this.mCurrentSecuritySelection) {
            boolean z;
            KeyguardSecurityView oldView = getSecurityView(this.mCurrentSecuritySelection);
            KeyguardSecurityView newView = getSecurityView(securityMode);
            if (oldView != null) {
                oldView.onPause();
                oldView.setKeyguardCallback(this.mNullCallback);
            }
            if (securityMode != SecurityMode.None) {
                newView.onResume(2);
                newView.setKeyguardCallback(this.mCallback);
            }
            int childCount = this.mSecurityViewFlipper.getChildCount();
            int securityViewIdForMode = getSecurityViewIdForMode(securityMode);
            for (int i = 0; i < childCount; i++) {
                if (this.mSecurityViewFlipper.getChildAt(i).getId() == securityViewIdForMode) {
                    this.mSecurityViewFlipper.setDisplayedChild(i);
                    break;
                }
            }
            this.mCurrentSecuritySelection = securityMode;
            SecurityCallback securityCallback = this.mSecurityCallback;
            if (securityMode == SecurityMode.None || !newView.needsInput()) {
                z = false;
            } else {
                z = true;
            }
            securityCallback.onSecurityModeChanged(securityMode, z);
        }
    }

    private int getSecurityViewIdForMode(SecurityMode securityMode) {
        switch (C00314.f0xdc0e830a[securityMode.ordinal()]) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return C0065R.id.keyguard_pattern_view;
            case 2:
                return C0065R.id.keyguard_pin_view;
            case 3:
                return C0065R.id.keyguard_password_view;
            case 6:
                return C0065R.id.keyguard_sim_pin_view;
            case 7:
                return C0065R.id.keyguard_sim_puk_view;
            default:
                return 0;
        }
    }

    private int getLayoutIdFor(SecurityMode securityMode) {
        switch (C00314.f0xdc0e830a[securityMode.ordinal()]) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return C0065R.layout.keyguard_pattern_view;
            case 2:
                return C0065R.layout.keyguard_pin_view;
            case 3:
                return C0065R.layout.keyguard_password_view;
            case 6:
                return C0065R.layout.keyguard_sim_pin_view;
            case 7:
                return C0065R.layout.keyguard_sim_puk_view;
            default:
                return 0;
        }
    }

    public SecurityMode getSecurityMode() {
        return this.mSecurityModel.getSecurityMode();
    }

    public SecurityMode getCurrentSecurityMode() {
        return this.mCurrentSecuritySelection;
    }

    public boolean needsInput() {
        return this.mSecurityViewFlipper.needsInput();
    }

    public void setKeyguardCallback(KeyguardSecurityCallback callback) {
        this.mSecurityViewFlipper.setKeyguardCallback(callback);
    }

    public void showPromptReason(int reason) {
        if (this.mCurrentSecuritySelection != SecurityMode.None) {
            getSecurityView(this.mCurrentSecuritySelection).showPromptReason(reason);
        }
    }

    public void showMessage(String message, int color) {
        if (this.mCurrentSecuritySelection != SecurityMode.None) {
            getSecurityView(this.mCurrentSecuritySelection).showMessage(message, color);
        }
    }
}
