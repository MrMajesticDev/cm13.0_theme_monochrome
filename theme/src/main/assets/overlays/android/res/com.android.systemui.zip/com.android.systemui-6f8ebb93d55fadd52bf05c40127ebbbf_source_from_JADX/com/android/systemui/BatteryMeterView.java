package com.android.systemui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.ThemeConfig;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.PorterDuff;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.MeasureSpec;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.policy.BatteryController;
import com.android.systemui.statusbar.policy.BatteryController.BatteryStateChangeCallback;

public class BatteryMeterView extends View implements DemoMode, BatteryStateChangeCallback {
    public static final String TAG;
    private boolean mAnimationsEnabled;
    protected boolean mAttached;
    private BatteryController mBatteryController;
    private BatteryMeterDrawable mBatteryMeterDrawable;
    private boolean mChargingAnimationsEnabled;
    private final int[] mColors;
    private final int mCriticalLevel;
    private int mCurrentBackgroundColor;
    private int mCurrentFillColor;
    private int mDarkModeBackgroundColor;
    private int mDarkModeFillColor;
    private boolean mDemoMode;
    protected BatteryTracker mDemoTracker;
    private int mHeight;
    private int mIconTint;
    private int mLightModeBackgroundColor;
    private int mLightModeFillColor;
    protected BatteryMeterMode mMeterMode;
    private boolean mPowerSaveEnabled;
    protected boolean mShowPercent;
    protected BatteryTracker mTracker;
    private String mWarningString;
    private int mWidth;

    protected interface BatteryMeterDrawable {
        void onBatteryLevelChanged(int i, boolean z, boolean z2);

        void onDispose();

        void onDraw(Canvas canvas, BatteryTracker batteryTracker);

        void onSizeChanged(int i, int i2, int i3, int i4);

        void setDarkIntensity(int i, int i2);
    }

    protected class AllInOneBatteryMeterDrawable implements BatteryMeterDrawable {
        private ValueAnimator mAnimator;
        private LayerDrawable mBatteryDrawable;
        private Drawable mBoltDrawable;
        private Paint mClearPaint;
        private boolean mDisposed;
        private Drawable mFrameDrawable;
        private boolean mInitialized;
        private int mLevel;
        private int mLevelAlpha;
        private StopMotionVectorDrawable mLevelDrawable;
        private BatteryMeterMode mMode;
        private Paint mTextAndBoltPaint;
        private int mTextGravity;
        private float mTextX;
        private float mTextY;
        private boolean mThemeApplied;
        private Paint mWarningTextPaint;

        /* renamed from: com.android.systemui.BatteryMeterView.AllInOneBatteryMeterDrawable.1 */
        class C00811 implements AnimatorUpdateListener {
            C00811() {
            }

            public void onAnimationUpdate(ValueAnimator animation) {
                AllInOneBatteryMeterDrawable.this.mLevelDrawable.setAlpha(((Integer) animation.getAnimatedValue()).intValue());
                BatteryMeterView.this.invalidate();
            }
        }

        /* renamed from: com.android.systemui.BatteryMeterView.AllInOneBatteryMeterDrawable.2 */
        class C00822 extends AnimatorListenerAdapter {
            final /* synthetic */ int val$defaultAlpha;
            final /* synthetic */ boolean val$invalidate;

            C00822(int i, boolean z) {
                this.val$defaultAlpha = i;
                this.val$invalidate = z;
            }

            public void onAnimationCancel(Animator animation) {
                AllInOneBatteryMeterDrawable.this.mLevelDrawable.setAlpha(this.val$defaultAlpha);
                AllInOneBatteryMeterDrawable.this.mAnimator = null;
            }

            public void onAnimationEnd(Animator animation) {
                AllInOneBatteryMeterDrawable.this.mLevelDrawable.setAlpha(this.val$defaultAlpha);
                AllInOneBatteryMeterDrawable.this.mAnimator = null;
                if (this.val$invalidate) {
                    BatteryMeterView.this.invalidate();
                }
            }
        }

        private class BatteryMeterDrawableException extends RuntimeException {
            public BatteryMeterDrawableException(String detailMessage) {
                super(detailMessage);
            }

            public BatteryMeterDrawableException(String detailMessage, Throwable throwable) {
                super(detailMessage, throwable);
            }
        }

        public AllInOneBatteryMeterDrawable(Resources res, BatteryMeterMode mode) {
            int access$100;
            this.mThemeApplied = isThemeApplied();
            loadBatteryDrawables(res, mode);
            this.mMode = mode;
            this.mDisposed = false;
            int[] attrs = new int[]{16842927, 2130771995};
            int resId = getBatteryDrawableStyleResourceForMode(mode);
            Mode xferMode = Mode.XOR;
            if (resId != 0) {
                TypedArray a = BatteryMeterView.this.getContext().obtainStyledAttributes(getBatteryDrawableStyleResourceForMode(mode), attrs);
                this.mTextGravity = a.getInt(0, 17);
                xferMode = PorterDuff.intToMode(a.getInt(1, PorterDuff.modeToInt(Mode.XOR)));
            } else {
                this.mTextGravity = 17;
            }
            Log.d(BatteryMeterView.TAG, "mTextGravity=" + this.mTextGravity);
            this.mTextAndBoltPaint = new Paint(1);
            this.mTextAndBoltPaint.setTypeface(Typeface.create("sans-serif-condensed", 1));
            this.mTextAndBoltPaint.setTextAlign(getPaintAlignmentFromGravity(this.mTextGravity));
            this.mTextAndBoltPaint.setXfermode(new PorterDuffXfermode(xferMode));
            Paint paint = this.mTextAndBoltPaint;
            if (BatteryMeterView.this.mCurrentFillColor != 0) {
                access$100 = BatteryMeterView.this.mCurrentFillColor;
            } else {
                access$100 = res.getColor(2131427354);
            }
            paint.setColor(access$100);
            this.mWarningTextPaint = new Paint(1);
            this.mWarningTextPaint.setColor(BatteryMeterView.this.mColors[1]);
            this.mWarningTextPaint.setTypeface(Typeface.create("sans-serif", 1));
            this.mWarningTextPaint.setTextAlign(getPaintAlignmentFromGravity(this.mTextGravity));
            this.mClearPaint = new Paint();
            this.mClearPaint.setColor(0);
        }

        public void onDraw(Canvas c, BatteryTracker tracker) {
            if (!this.mDisposed) {
                if (!this.mInitialized) {
                    init();
                }
                drawBattery(c, tracker);
                if (BatteryMeterView.this.mAnimationsEnabled) {
                }
                if (BatteryMeterView.this.mChargingAnimationsEnabled && !this.mThemeApplied) {
                    if (tracker.level >= 100 || !tracker.plugged) {
                        cancelChargingAnimation();
                    } else {
                        startChargingAnimation(true);
                    }
                }
            }
        }

        public void onBatteryLevelChanged(int level, boolean pluggedIn, boolean charging) {
            if (!charging || this.mThemeApplied || BatteryMeterView.this.mChargingAnimationsEnabled || this.mLevel == level) {
                this.mLevel = 0;
                return;
            }
            startChargingAnimation(false);
            this.mLevel = level;
        }

        private void startChargingAnimation(boolean invalidate) {
            if (this.mLevelAlpha != 0 && this.mAnimator == null && BatteryMeterView.this.mMeterMode == BatteryMeterMode.BATTERY_METER_CIRCLE) {
                this.mAnimator = ValueAnimator.ofInt(new int[]{defaultAlpha, 0, this.mLevelAlpha});
                this.mAnimator.addUpdateListener(new C00811());
                this.mAnimator.addListener(new C00822(defaultAlpha, invalidate));
                this.mAnimator.setDuration(2000);
                if (invalidate) {
                    this.mAnimator.setStartDelay(500);
                }
                this.mAnimator.start();
            }
        }

        private void cancelChargingAnimation() {
            if (this.mAnimator != null) {
                this.mAnimator.cancel();
                this.mAnimator = null;
            }
        }

        public void onDispose() {
            this.mDisposed = true;
        }

        public void setDarkIntensity(int backgroundColor, int fillColor) {
            BatteryMeterView.this.mIconTint = fillColor;
            this.mFrameDrawable.setTint(backgroundColor);
            if (this.mBoltDrawable != null) {
                this.mBoltDrawable.setTint(-16777216 | fillColor);
                updateBoltDrawableLayer(this.mBatteryDrawable, this.mBoltDrawable);
            }
            BatteryMeterView.this.invalidate();
        }

        public void onSizeChanged(int w, int h, int oldw, int oldh) {
            init();
        }

        private boolean isThemeApplied() {
            ThemeConfig themeConfig = ThemeConfig.getBootTheme(BatteryMeterView.this.getContext().getContentResolver());
            return (themeConfig == null || "system".equals(themeConfig.getOverlayForStatusBar())) ? false : true;
        }

        private void checkBatteryMeterDrawableValid(Resources res, BatteryMeterMode mode) {
            int resId = getBatteryDrawableResourceForMode(mode);
            try {
                Drawable batteryDrawable = res.getDrawable(resId);
                if (batteryDrawable instanceof LayerDrawable) {
                    LayerDrawable layerDrawable = (LayerDrawable) batteryDrawable;
                    Drawable frame = layerDrawable.findDrawableByLayerId(2131755357);
                    Drawable level = layerDrawable.findDrawableByLayerId(2131755358);
                    if (frame == null) {
                        throw new BatteryMeterDrawableException("Missing battery_frame drawble");
                    } else if (level == null) {
                        throw new BatteryMeterDrawableException("Missing battery_fill drawable");
                    } else if (level instanceof AnimatedVectorDrawable) {
                        try {
                            new StopMotionVectorDrawable(level).setCurrentFraction(0.5f);
                            return;
                        } catch (Exception e) {
                            throw new BatteryMeterDrawableException("Unable to perform stop motion on battery_fill drawable", e);
                        }
                    } else {
                        throw new BatteryMeterDrawableException("Expected a AnimatedVectorDrawable but received a " + level.getClass().getSimpleName());
                    }
                }
                throw new BatteryMeterDrawableException("Expected a LayerDrawable but received a " + batteryDrawable.getClass().getSimpleName());
            } catch (NotFoundException e2) {
                throw new BatteryMeterDrawableException(res.getResourceName(resId) + " is an " + "invalid drawable", e2);
            }
        }

        private void loadBatteryDrawables(Resources res, BatteryMeterMode mode) {
            int access$800;
            if (this.mThemeApplied) {
                try {
                    checkBatteryMeterDrawableValid(res, mode);
                } catch (BatteryMeterDrawableException e) {
                    Log.w(BatteryMeterView.TAG, "Invalid themed battery meter drawable, falling back to system", e);
                    Context context = BatteryMeterView.this.getContext();
                    try {
                        res = BatteryMeterView.this.getContext().getPackageManager().getThemedResourcesForApplication(context.getPackageName(), "system");
                    } catch (NameNotFoundException e2) {
                    }
                }
            }
            this.mBatteryDrawable = (LayerDrawable) res.getDrawable(getBatteryDrawableResourceForMode(mode));
            this.mFrameDrawable = this.mBatteryDrawable.findDrawableByLayerId(2131755357);
            Drawable drawable = this.mFrameDrawable;
            if (BatteryMeterView.this.mCurrentBackgroundColor != 0) {
                access$800 = BatteryMeterView.this.mCurrentBackgroundColor;
            } else {
                access$800 = res.getColor(2131427352);
            }
            drawable.setTint(access$800);
            this.mLevelDrawable = new StopMotionVectorDrawable(this.mBatteryDrawable.findDrawableByLayerId(2131755358));
            this.mBoltDrawable = this.mBatteryDrawable.findDrawableByLayerId(2131755359);
        }

        private void drawBattery(Canvas canvas, BatteryTracker tracker) {
            boolean unknownStatus = true;
            int i = 0;
            if (tracker.status != 1) {
                unknownStatus = false;
            }
            int level = tracker.level;
            if (unknownStatus || tracker.status == 5) {
                level = 100;
            }
            this.mTextAndBoltPaint.setColor(BatteryMeterView.this.getColorForLevel(level));
            Drawable d = this.mBatteryDrawable.findDrawableByLayerId(2131755359);
            if (d != null) {
                if (d instanceof BitmapDrawable) {
                    ((BitmapDrawable) d).getPaint().set(tracker.plugged ? this.mTextAndBoltPaint : this.mClearPaint);
                } else {
                    if (tracker.plugged) {
                        i = 255;
                    }
                    d.setAlpha(i);
                }
            }
            int levelColor = BatteryMeterView.this.getColorForLevel(level);
            this.mLevelAlpha = Color.alpha(levelColor);
            this.mLevelDrawable.setCurrentFraction(((float) level) / 100.0f);
            this.mLevelDrawable.setTint(levelColor);
            this.mBatteryDrawable.draw(canvas);
            if (unknownStatus) {
                this.mTextAndBoltPaint.setColor(BatteryMeterView.this.getContext().getColor(2131427352));
                canvas.drawText("?", this.mTextX, this.mTextY, this.mTextAndBoltPaint);
            } else if (!tracker.plugged) {
                drawPercentageText(canvas, tracker);
            }
        }

        private void drawPercentageText(Canvas canvas, BatteryTracker tracker) {
            int level = tracker.level;
            if (level > BatteryMeterView.this.mCriticalLevel && BatteryMeterView.this.mShowPercent && level != 100) {
                String pctText = String.valueOf(level);
                this.mTextAndBoltPaint.setColor(BatteryMeterView.this.getColorForLevel(level));
                canvas.drawText(pctText, this.mTextX, this.mTextY, this.mTextAndBoltPaint);
            } else if (level <= BatteryMeterView.this.mCriticalLevel) {
                canvas.drawText(BatteryMeterView.this.mWarningString, this.mTextX, this.mTextY, this.mWarningTextPaint);
            }
        }

        private void init() {
            float f = 0.0f;
            if (BatteryMeterView.this.mWidth > 0 && BatteryMeterView.this.mHeight > 0) {
                float widthDiv2 = ((float) BatteryMeterView.this.mWidth) / 2.0f;
                float textSize = widthDiv2 - (BatteryMeterView.this.getResources().getDisplayMetrics().density * 2.0f);
                this.mTextAndBoltPaint.setTextSize(textSize);
                this.mWarningTextPaint.setTextSize(textSize);
                int pLeft = BatteryMeterView.this.getPaddingLeft();
                this.mBatteryDrawable.setBounds(new Rect(pLeft, 0, BatteryMeterView.this.mWidth + pLeft, BatteryMeterView.this.mHeight));
                Rect bounds = new Rect();
                this.mTextAndBoltPaint.getTextBounds("99", 0, "99".length(), bounds);
                boolean isRtl = BatteryMeterView.this.isLayoutRtl();
                if ((this.mTextGravity & 8388611) == 8388611) {
                    if (isRtl) {
                        f = (float) BatteryMeterView.this.mWidth;
                    }
                    this.mTextX = f;
                } else if ((this.mTextGravity & 8388613) == 8388613) {
                    if (!isRtl) {
                        f = (float) BatteryMeterView.this.mWidth;
                    }
                    this.mTextX = f;
                } else if ((this.mTextGravity & 3) == 3) {
                    this.mTextX = 0.0f;
                } else if ((this.mTextGravity & 5) == 5) {
                    this.mTextX = (float) BatteryMeterView.this.mWidth;
                } else {
                    this.mTextX = ((float) pLeft) + widthDiv2;
                }
                if ((this.mTextGravity & 48) == 48) {
                    this.mTextY = (float) bounds.height();
                } else if ((this.mTextGravity & 80) == 80) {
                    this.mTextY = (float) BatteryMeterView.this.mHeight;
                } else {
                    this.mTextY = (((float) bounds.height()) / 2.0f) + widthDiv2;
                }
                if (this.mBoltDrawable != null) {
                    updateBoltDrawableLayer(this.mBatteryDrawable, this.mBoltDrawable);
                }
                this.mInitialized = true;
            }
        }

        private int getBatteryDrawableResourceForMode(BatteryMeterMode mode) {
            switch (mode) {
                case BATTERY_METER_CIRCLE:
                    return 2130837544;
                case BATTERY_METER_ICON_PORTRAIT:
                    return 2130837547;
                default:
                    return 0;
            }
        }

        private int getBatteryDrawableStyleResourceForMode(BatteryMeterMode mode) {
            switch (mode) {
                case BATTERY_METER_CIRCLE:
                    return 2131492866;
                case BATTERY_METER_ICON_PORTRAIT:
                    return 2131492865;
                default:
                    return 2131492864;
            }
        }

        private Align getPaintAlignmentFromGravity(int gravity) {
            boolean isRtl = BatteryMeterView.this.isLayoutRtl();
            if ((gravity & 8388611) == 8388611) {
                return isRtl ? Align.RIGHT : Align.LEFT;
            } else {
                if ((gravity & 8388613) == 8388613) {
                    return isRtl ? Align.LEFT : Align.RIGHT;
                } else {
                    if ((gravity & 3) == 3) {
                        return Align.LEFT;
                    }
                    if ((gravity & 5) == 5) {
                        return Align.RIGHT;
                    }
                    return Align.CENTER;
                }
            }
        }

        private void updateBoltDrawableLayer(LayerDrawable batteryDrawable, Drawable boltDrawable) {
            BitmapDrawable newBoltDrawable;
            if (boltDrawable instanceof BitmapDrawable) {
                newBoltDrawable = (BitmapDrawable) boltDrawable.mutate();
            } else {
                Bitmap boltBitmap = createBoltBitmap(boltDrawable);
                if (boltBitmap != null) {
                    Rect bounds = boltDrawable.getBounds();
                    newBoltDrawable = new BitmapDrawable(BatteryMeterView.this.getResources(), boltBitmap);
                    newBoltDrawable.setBounds(bounds);
                } else {
                    return;
                }
            }
            newBoltDrawable.getPaint().set(this.mTextAndBoltPaint);
            batteryDrawable.setDrawableByLayerId(2131755359, newBoltDrawable);
        }

        private Bitmap createBoltBitmap(Drawable boltDrawable) {
            if (BatteryMeterView.this.mWidth <= 0 || BatteryMeterView.this.mHeight <= 0) {
                return null;
            }
            if (boltDrawable instanceof BitmapDrawable) {
                return ((BitmapDrawable) boltDrawable).getBitmap();
            }
            int pLeft = BatteryMeterView.this.getPaddingLeft();
            Rect iconBounds = new Rect(pLeft, 0, BatteryMeterView.this.mWidth + pLeft, BatteryMeterView.this.mHeight);
            Bitmap bolt = Bitmap.createBitmap(iconBounds.width(), iconBounds.height(), Config.ARGB_8888);
            if (bolt == null) {
                return bolt;
            }
            Canvas c = new Canvas(bolt);
            c.drawColor(-1, Mode.CLEAR);
            boltDrawable.draw(c);
            return bolt;
        }
    }

    public enum BatteryMeterMode {
        BATTERY_METER_GONE,
        BATTERY_METER_ICON_PORTRAIT,
        BATTERY_METER_CIRCLE,
        BATTERY_METER_TEXT
    }

    protected class BatteryTracker extends BroadcastReceiver {
        int health;
        int level;
        int plugType;
        boolean plugged;
        boolean present;
        int status;
        String technology;
        int temperature;
        boolean testmode;
        int voltage;

        /* renamed from: com.android.systemui.BatteryMeterView.BatteryTracker.1 */
        class C00831 implements Runnable {
            int curLevel;
            Intent dummy;
            int incr;
            int saveLevel;
            int savePlugged;

            C00831() {
                this.curLevel = 0;
                this.incr = 1;
                this.saveLevel = BatteryTracker.this.level;
                this.savePlugged = BatteryTracker.this.plugType;
                this.dummy = new Intent("android.intent.action.BATTERY_CHANGED");
            }

            public void run() {
                int i = 0;
                if (this.curLevel < 0) {
                    BatteryTracker.this.testmode = false;
                    this.dummy.putExtra("level", this.saveLevel);
                    this.dummy.putExtra("plugged", this.savePlugged);
                    this.dummy.putExtra("testmode", false);
                } else {
                    this.dummy.putExtra("level", this.curLevel);
                    Intent intent = this.dummy;
                    String str = "plugged";
                    if (this.incr > 0) {
                        i = 1;
                    }
                    intent.putExtra(str, i);
                    this.dummy.putExtra("testmode", true);
                }
                BatteryMeterView.this.getContext().sendBroadcast(this.dummy);
                if (BatteryTracker.this.testmode) {
                    this.curLevel += this.incr;
                    if (this.curLevel == 100) {
                        this.incr *= -1;
                    }
                    BatteryMeterView.this.postDelayed(this, 200);
                }
            }
        }

        protected BatteryTracker() {
            this.present = true;
            this.level = -1;
            this.testmode = false;
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals("android.intent.action.BATTERY_CHANGED")) {
                if (!this.testmode || intent.getBooleanExtra("testmode", false)) {
                    this.level = (int) ((100.0f * ((float) intent.getIntExtra("level", 0))) / ((float) intent.getIntExtra("scale", 100)));
                    this.present = intent.getBooleanExtra("present", true);
                    this.plugType = intent.getIntExtra("plugged", 0);
                    this.plugged = this.plugType != 0;
                    this.health = intent.getIntExtra("health", 1);
                    this.status = intent.getIntExtra("status", 1);
                    this.technology = intent.getStringExtra("technology");
                    this.voltage = intent.getIntExtra("voltage", 0);
                    this.temperature = intent.getIntExtra("temperature", 0);
                    BatteryMeterView.this.setContentDescription(context.getString(2131362081, new Object[]{Integer.valueOf(this.level)}));
                    if (BatteryMeterView.this.mBatteryMeterDrawable != null) {
                        BatteryMeterView.this.setVisibility(0);
                        BatteryMeterView.this.invalidate();
                    }
                }
            } else if (action.equals("com.android.systemui.BATTERY_LEVEL_TEST")) {
                this.testmode = true;
                BatteryMeterView.this.post(new C00831());
            }
        }
    }

    static {
        TAG = BatteryMeterView.class.getSimpleName();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.BATTERY_CHANGED");
        filter.addAction("com.android.systemui.BATTERY_LEVEL_TEST");
        Intent sticky = getContext().registerReceiver(this.mTracker, filter);
        if (sticky != null) {
            this.mTracker.onReceive(getContext(), sticky);
        }
        this.mBatteryController.addStateChangedCallback(this);
        this.mAttached = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mAttached = false;
        getContext().unregisterReceiver(this.mTracker);
        this.mBatteryController.removeStateChangedCallback(this);
    }

    public BatteryMeterView(Context context) {
        this(context, null, 0);
    }

    public BatteryMeterView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BatteryMeterView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mShowPercent = true;
        this.mMeterMode = null;
        this.mDemoTracker = new BatteryTracker();
        this.mTracker = new BatteryTracker();
        this.mIconTint = -1;
        this.mCurrentBackgroundColor = 0;
        this.mCurrentFillColor = 0;
        Resources res = context.getResources();
        TypedArray atts = context.obtainStyledAttributes(attrs, C0095R.styleable.BatteryMeterView, defStyle, 0);
        TypedArray levels = res.obtainTypedArray(2131230722);
        TypedArray colors = res.obtainTypedArray(2131230723);
        int N = levels.length();
        this.mColors = new int[(N * 2)];
        for (int i = 0; i < N; i++) {
            this.mColors[i * 2] = levels.getInt(i, 0);
            this.mColors[(i * 2) + 1] = colors.getColor(i, 0);
        }
        levels.recycle();
        colors.recycle();
        atts.recycle();
        this.mWarningString = context.getString(2131362234);
        this.mCriticalLevel = getContext().getResources().getInteger(17694799);
        this.mDarkModeBackgroundColor = context.getColor(2131427411);
        this.mDarkModeFillColor = context.getColor(2131427412);
        this.mLightModeBackgroundColor = context.getColor(2131427414);
        this.mLightModeFillColor = context.getColor(2131427415);
        setAnimationsEnabled(true);
    }

    protected BatteryMeterDrawable createBatteryMeterDrawable(BatteryMeterMode mode) {
        Resources res = getResources();
        switch (C00801.f9x4f1d1e19[mode.ordinal()]) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 2:
                return null;
            default:
                return new AllInOneBatteryMeterDrawable(res, mode);
        }
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        if (this.mMeterMode == BatteryMeterMode.BATTERY_METER_TEXT) {
            onSizeChanged(width, height, 0, 0);
        }
        setMeasuredDimension(width, height);
    }

    public void setBatteryController(BatteryController batteryController) {
        this.mBatteryController = batteryController;
        this.mPowerSaveEnabled = this.mBatteryController.isPowerSave();
    }

    public void onBatteryLevelChanged(int level, boolean pluggedIn, boolean charging) {
        if (this.mBatteryMeterDrawable != null) {
            this.mBatteryMeterDrawable.onBatteryLevelChanged(level, pluggedIn, charging);
        }
    }

    public void onPowerSaveChanged() {
        this.mPowerSaveEnabled = this.mBatteryController.isPowerSave();
        invalidate();
    }

    public void setAnimationsEnabled(boolean enabled) {
        if (this.mAnimationsEnabled != enabled) {
            this.mAnimationsEnabled = enabled;
            int i = (this.mAnimationsEnabled || this.mChargingAnimationsEnabled) ? 2 : 0;
            setLayerType(i, null);
            invalidate();
        }
    }

    public void setChargingAnimationsEnabled(boolean enabled) {
        if (this.mChargingAnimationsEnabled != enabled) {
            this.mChargingAnimationsEnabled = enabled;
            int i = (this.mAnimationsEnabled || this.mChargingAnimationsEnabled) ? 2 : 0;
            setLayerType(i, null);
            invalidate();
        }
    }

    public void onBatteryStyleChanged(int style, int percentMode) {
        boolean showInsidePercent = true;
        if (percentMode != 1) {
            showInsidePercent = false;
        }
        BatteryMeterMode meterMode = BatteryMeterMode.BATTERY_METER_ICON_PORTRAIT;
        switch (style) {
            case 2:
                meterMode = BatteryMeterMode.BATTERY_METER_CIRCLE;
                break;
            case 4:
                meterMode = BatteryMeterMode.BATTERY_METER_GONE;
                showInsidePercent = false;
                break;
            case 6:
                meterMode = BatteryMeterMode.BATTERY_METER_TEXT;
                showInsidePercent = false;
                break;
        }
        setMode(meterMode);
        this.mShowPercent = showInsidePercent;
        invalidate();
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.mHeight = h;
        this.mWidth = w;
        if (this.mBatteryMeterDrawable != null) {
            this.mBatteryMeterDrawable.onSizeChanged(w, h, oldw, oldh);
        }
    }

    public void setMode(BatteryMeterMode mode) {
        if (this.mMeterMode != mode) {
            this.mMeterMode = mode;
            BatteryTracker tracker = this.mDemoMode ? this.mDemoTracker : this.mTracker;
            if (mode == BatteryMeterMode.BATTERY_METER_GONE || mode == BatteryMeterMode.BATTERY_METER_TEXT) {
                setVisibility(8);
                this.mBatteryMeterDrawable = null;
                return;
            }
            if (this.mBatteryMeterDrawable != null) {
                this.mBatteryMeterDrawable.onDispose();
            }
            this.mBatteryMeterDrawable = createBatteryMeterDrawable(mode);
            if (tracker.present) {
                setVisibility(0);
                requestLayout();
                invalidate();
                return;
            }
            setVisibility(8);
        }
    }

    public int getColorForLevel(int percent) {
        if (this.mPowerSaveEnabled) {
            return this.mColors[this.mColors.length - 1];
        }
        int color = 0;
        int i = 0;
        while (i < this.mColors.length) {
            int thresh = this.mColors[i];
            color = this.mColors[i + 1];
            if (percent > thresh) {
                i += 2;
            } else if (i == this.mColors.length - 2) {
                return this.mIconTint;
            } else {
                return color;
            }
        }
        return color;
    }

    public void setDarkIntensity(float darkIntensity) {
        if (this.mBatteryMeterDrawable != null) {
            this.mCurrentBackgroundColor = getBackgroundColor(darkIntensity);
            this.mCurrentFillColor = getFillColor(darkIntensity);
            this.mBatteryMeterDrawable.setDarkIntensity(this.mCurrentBackgroundColor, this.mCurrentFillColor);
        }
    }

    private int getBackgroundColor(float darkIntensity) {
        return getColorForDarkIntensity(darkIntensity, this.mLightModeBackgroundColor, this.mDarkModeBackgroundColor);
    }

    private int getFillColor(float darkIntensity) {
        return getColorForDarkIntensity(darkIntensity, this.mLightModeFillColor, this.mDarkModeFillColor);
    }

    private int getColorForDarkIntensity(float darkIntensity, int lightColor, int darkColor) {
        return ((Integer) ArgbEvaluator.getInstance().evaluate(darkIntensity, Integer.valueOf(lightColor), Integer.valueOf(darkColor))).intValue();
    }

    protected void onDraw(Canvas canvas) {
        if (this.mBatteryMeterDrawable != null) {
            this.mBatteryMeterDrawable.onDraw(canvas, this.mDemoMode ? this.mDemoTracker : this.mTracker);
        }
    }

    public boolean hasOverlappingRendering() {
        return false;
    }

    public void dispatchDemoCommand(String command, Bundle args) {
        if (getVisibility() != 0) {
            return;
        }
        if (!this.mDemoMode && command.equals("enter")) {
            this.mDemoMode = true;
            this.mDemoTracker.level = this.mTracker.level;
            this.mDemoTracker.plugged = this.mTracker.plugged;
        } else if (this.mDemoMode && command.equals("exit")) {
            this.mDemoMode = false;
            postInvalidate();
        } else if (this.mDemoMode && command.equals("battery")) {
            String level = args.getString("level");
            String plugged = args.getString("plugged");
            if (level != null) {
                this.mDemoTracker.level = Math.min(Math.max(Integer.parseInt(level), 0), 100);
            }
            if (plugged != null) {
                this.mDemoTracker.plugged = Boolean.parseBoolean(plugged);
            }
            postInvalidate();
        }
    }
}
