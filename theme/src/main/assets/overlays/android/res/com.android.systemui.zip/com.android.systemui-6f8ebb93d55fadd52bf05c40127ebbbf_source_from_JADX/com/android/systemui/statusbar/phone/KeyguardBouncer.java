package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.android.internal.widget.LockPatternUtils;
import com.android.keyguard.KeyguardHostView;
import com.android.keyguard.KeyguardHostView.OnDismissAction;
import com.android.keyguard.KeyguardSecurityModel.SecurityMode;
import com.android.keyguard.KeyguardUpdateMonitor;
import com.android.keyguard.KeyguardUpdateMonitorCallback;
import com.android.keyguard.ViewMediatorCallback;
import com.android.systemui.DejankUtils;

public class KeyguardBouncer {
    private int mBouncerPromptReason;
    private ViewMediatorCallback mCallback;
    private ViewGroup mContainer;
    private Context mContext;
    private KeyguardHostView mKeyguardView;
    private LockPatternUtils mLockPatternUtils;
    private ViewGroup mRoot;
    private final Runnable mShowRunnable;
    private boolean mShowingSoon;
    private KeyguardUpdateMonitorCallback mUpdateMonitorCallback;
    private StatusBarWindowManager mWindowManager;

    /* renamed from: com.android.systemui.statusbar.phone.KeyguardBouncer.1 */
    class C03731 extends KeyguardUpdateMonitorCallback {
        C03731() {
        }

        public void onStrongAuthStateChanged(int userId) {
            KeyguardBouncer.this.mBouncerPromptReason = KeyguardBouncer.this.mCallback.getBouncerPromptReason();
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.KeyguardBouncer.2 */
    class C03742 implements Runnable {
        C03742() {
        }

        public void run() {
            KeyguardBouncer.this.mRoot.setVisibility(0);
            KeyguardBouncer.this.mKeyguardView.onResume();
            KeyguardBouncer.this.showPromptReason(KeyguardBouncer.this.mBouncerPromptReason);
            KeyguardBouncer.this.mKeyguardView.startAppearAnimation();
            KeyguardBouncer.this.mShowingSoon = false;
            KeyguardBouncer.this.mKeyguardView.sendAccessibilityEvent(32);
        }
    }

    public KeyguardBouncer(Context context, ViewMediatorCallback callback, LockPatternUtils lockPatternUtils, StatusBarWindowManager windowManager, ViewGroup container) {
        this.mUpdateMonitorCallback = new C03731();
        this.mShowRunnable = new C03742();
        this.mContext = context;
        this.mCallback = callback;
        this.mLockPatternUtils = lockPatternUtils;
        this.mContainer = container;
        this.mWindowManager = windowManager;
        KeyguardUpdateMonitor.getInstance(this.mContext).registerCallback(this.mUpdateMonitorCallback);
    }

    public void show(boolean resetSecuritySelection) {
        ensureView();
        if (resetSecuritySelection) {
            this.mKeyguardView.showPrimarySecurityScreen();
        }
        if (this.mRoot.getVisibility() != 0 && !this.mShowingSoon && !this.mKeyguardView.dismiss()) {
            this.mShowingSoon = true;
            DejankUtils.postAfterTraversal(this.mShowRunnable);
        }
    }

    public void showPromptReason(int reason) {
        this.mKeyguardView.showPromptReason(reason);
    }

    public void showMessage(String message, int color) {
        this.mKeyguardView.showMessage(message, color);
    }

    private void cancelShowRunnable() {
        DejankUtils.removeCallbacks(this.mShowRunnable);
        this.mShowingSoon = false;
    }

    public void showWithDismissAction(OnDismissAction r, Runnable cancelAction) {
        ensureView();
        this.mKeyguardView.setOnDismissAction(r, cancelAction);
        show(false);
    }

    public void hide(boolean destroyView) {
        cancelShowRunnable();
        if (this.mKeyguardView != null) {
            this.mKeyguardView.cancelDismissAction();
            this.mKeyguardView.cleanUp();
        }
        if (destroyView) {
            removeView();
        } else if (this.mRoot != null) {
            this.mRoot.setVisibility(4);
        }
    }

    public void startPreHideAnimation(Runnable runnable) {
        if (this.mKeyguardView != null) {
            this.mKeyguardView.startDisappearAnimation(runnable);
        } else if (runnable != null) {
            runnable.run();
        }
    }

    public void onScreenTurnedOff() {
        if (this.mKeyguardView != null && this.mRoot != null && this.mRoot.getVisibility() == 0) {
            this.mKeyguardView.onPause();
        }
    }

    public boolean isShowing() {
        return this.mShowingSoon || (this.mRoot != null && this.mRoot.getVisibility() == 0);
    }

    public void prepare() {
        boolean wasInitialized = this.mRoot != null;
        ensureView();
        if (wasInitialized) {
            this.mKeyguardView.showPrimarySecurityScreen();
        }
        this.mBouncerPromptReason = this.mCallback.getBouncerPromptReason();
    }

    private void ensureView() {
        if (this.mRoot == null) {
            inflateView();
        }
    }

    private void inflateView() {
        removeView();
        this.mRoot = (ViewGroup) LayoutInflater.from(this.mContext).inflate(2130968583, null);
        this.mKeyguardView = (KeyguardHostView) this.mRoot.findViewById(2131755093);
        this.mKeyguardView.setLockPatternUtils(this.mLockPatternUtils);
        this.mKeyguardView.setViewMediatorCallback(this.mCallback);
        this.mContainer.addView(this.mRoot, this.mContainer.getChildCount());
        this.mRoot.setVisibility(4);
        this.mRoot.setSystemUiVisibility(2097152);
    }

    void removeView() {
        if (this.mRoot != null && this.mRoot.getParent() == this.mContainer) {
            this.mContainer.removeView(this.mRoot);
            this.mRoot = null;
        }
    }

    public boolean needsFullscreenBouncer() {
        ensureView();
        if (this.mKeyguardView == null) {
            return false;
        }
        SecurityMode mode = this.mKeyguardView.getSecurityMode();
        if (mode == SecurityMode.SimPin || mode == SecurityMode.SimPuk) {
            return true;
        }
        return false;
    }

    public boolean isFullscreenBouncer() {
        if (this.mKeyguardView == null) {
            return false;
        }
        SecurityMode mode = this.mKeyguardView.getCurrentSecurityMode();
        if (mode == SecurityMode.SimPin || mode == SecurityMode.SimPuk) {
            return true;
        }
        return false;
    }

    public boolean isSecure() {
        return this.mKeyguardView == null || this.mKeyguardView.getSecurityMode() != SecurityMode.None;
    }

    public boolean onMenuPressed() {
        ensureView();
        if (!this.mKeyguardView.handleMenuKey()) {
            return false;
        }
        this.mRoot.setVisibility(0);
        this.mKeyguardView.requestFocus();
        this.mKeyguardView.onResume();
        return true;
    }

    public boolean interceptMediaKey(KeyEvent event) {
        ensureView();
        return this.mKeyguardView.interceptMediaKey(event);
    }

    public void notifyKeyguardAuthenticated(boolean strongAuth) {
        ensureView();
        this.mKeyguardView.finish(strongAuth);
    }
}
