package com.android.keyguard;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;
import com.android.internal.telephony.ITelephony.Stub;
import com.android.internal.telephony.IccCardConstants.State;

public class KeyguardSimPukView extends KeyguardPinBasedInputView {
    private CheckSimPuk mCheckSimPukThread;
    private String mPinText;
    private String mPukText;
    private int mRemainingAttempts;
    private AlertDialog mRemainingAttemptsDialog;
    private boolean mShowDefaultMessage;
    private ImageView mSimImageView;
    private ProgressDialog mSimUnlockProgressDialog;
    private StateMachine mStateMachine;
    private int mSubId;
    KeyguardUpdateMonitorCallback mUpdateMonitorCallback;

    /* renamed from: com.android.keyguard.KeyguardSimPukView.1 */
    class C00381 extends KeyguardUpdateMonitorCallback {
        C00381() {
        }

        public void onSimStateChanged(int subId, int slotId, State simState) {
            KeyguardSimPukView.this.resetState();
        }
    }

    private abstract class CheckSimPuk extends Thread {
        private final String mPin;
        private final String mPuk;
        private final int mSubId;

        /* renamed from: com.android.keyguard.KeyguardSimPukView.CheckSimPuk.1 */
        class C00421 implements Runnable {
            final /* synthetic */ int[] val$result;

            C00421(int[] iArr) {
                this.val$result = iArr;
            }

            public void run() {
                CheckSimPuk.this.onSimLockChangedResponse(this.val$result[0], this.val$result[1]);
            }
        }

        /* renamed from: com.android.keyguard.KeyguardSimPukView.CheckSimPuk.2 */
        class C00432 implements Runnable {
            C00432() {
            }

            public void run() {
                CheckSimPuk.this.onSimLockChangedResponse(2, -1);
            }
        }

        abstract void onSimLockChangedResponse(int i, int i2);

        protected CheckSimPuk(String puk, String pin, int subId) {
            this.mPuk = puk;
            this.mPin = pin;
            this.mSubId = subId;
        }

        public void run() {
            try {
                KeyguardSimPukView.this.post(new C00421(Stub.asInterface(ServiceManager.checkService("phone")).supplyPukReportResultForSubscriber(this.mSubId, this.mPuk, this.mPin)));
            } catch (RemoteException e) {
                Log.e("KeyguardSimPukView", "RemoteException for supplyPukReportResult:", e);
                KeyguardSimPukView.this.post(new C00432());
            }
        }
    }

    /* renamed from: com.android.keyguard.KeyguardSimPukView.2 */
    class C00402 extends CheckSimPuk {

        /* renamed from: com.android.keyguard.KeyguardSimPukView.2.1 */
        class C00391 implements Runnable {
            final /* synthetic */ int val$attemptsRemaining;
            final /* synthetic */ int val$result;

            C00391(int i, int i2) {
                this.val$result = i;
                this.val$attemptsRemaining = i2;
            }

            public void run() {
                if (KeyguardSimPukView.this.mSimUnlockProgressDialog != null) {
                    KeyguardSimPukView.this.mSimUnlockProgressDialog.hide();
                }
                KeyguardSimPukView.this.resetPasswordText(true);
                if (this.val$result == 0) {
                    KeyguardUpdateMonitor.getInstance(KeyguardSimPukView.this.getContext()).reportSimUnlocked(KeyguardSimPukView.this.mSubId);
                    KeyguardSimPukView.this.mRemainingAttempts = -1;
                    KeyguardSimPukView.this.mShowDefaultMessage = true;
                    if (KeyguardSimPukView.this.mCallback != null) {
                        KeyguardSimPukView.this.mCallback.dismiss(true);
                    }
                } else {
                    KeyguardSimPukView.this.mShowDefaultMessage = false;
                    if (this.val$result == 1) {
                        KeyguardSimPukView.this.mSecurityMessageDisplay.setMessage(KeyguardSimPukView.this.getPukPasswordErrorMessage(this.val$attemptsRemaining, false), true);
                        if (this.val$attemptsRemaining <= 2) {
                            KeyguardSimPukView.this.getPukRemainingAttemptsDialog(this.val$attemptsRemaining).show();
                        } else {
                            KeyguardSimPukView.this.mSecurityMessageDisplay.setMessage(KeyguardSimPukView.this.getPukPasswordErrorMessage(this.val$attemptsRemaining, false), true);
                        }
                    } else {
                        KeyguardSimPukView.this.mSecurityMessageDisplay.setMessage(KeyguardSimPukView.this.getContext().getString(C0065R.string.kg_password_puk_failed), true);
                    }
                    KeyguardSimPukView.this.mStateMachine.reset();
                }
                KeyguardSimPukView.this.mCheckSimPukThread = null;
            }
        }

        C00402(String x0, String x1, int x2) {
            super(x0, x1, x2);
        }

        void onSimLockChangedResponse(int result, int attemptsRemaining) {
            KeyguardSimPukView.this.post(new C00391(result, attemptsRemaining));
        }
    }

    /* renamed from: com.android.keyguard.KeyguardSimPukView.3 */
    class C00413 extends CheckSimPuk {
        C00413(String x0, String x1, int x2) {
            super(x0, x1, x2);
        }

        void onSimLockChangedResponse(int result, int attemptsRemaining) {
            Log.d("KeyguardSimPukView", "onSimCheckResponse  dummy One result" + result + " attemptsRemaining=" + attemptsRemaining);
            if (attemptsRemaining >= 0) {
                KeyguardSimPukView.this.mRemainingAttempts = attemptsRemaining;
                KeyguardSimPukView.this.mSecurityMessageDisplay.setMessage(KeyguardSimPukView.this.getPukPasswordErrorMessage(attemptsRemaining, true), true);
            }
        }
    }

    private class StateMachine {
        final int CONFIRM_PIN;
        final int DONE;
        final int ENTER_PIN;
        final int ENTER_PUK;
        private int state;

        private StateMachine() {
            this.ENTER_PUK = 0;
            this.ENTER_PIN = 1;
            this.CONFIRM_PIN = 2;
            this.DONE = 3;
            this.state = 0;
        }

        public void next() {
            int msg = 0;
            if (this.state == 0) {
                if (KeyguardSimPukView.this.checkPuk()) {
                    this.state = 1;
                    msg = C0065R.string.kg_puk_enter_pin_hint;
                } else {
                    msg = C0065R.string.kg_invalid_sim_puk_hint;
                }
            } else if (this.state == 1) {
                if (KeyguardSimPukView.this.checkPin()) {
                    this.state = 2;
                    msg = C0065R.string.kg_enter_confirm_pin_hint;
                } else {
                    msg = C0065R.string.kg_invalid_sim_pin_hint;
                }
            } else if (this.state == 2) {
                if (KeyguardSimPukView.this.confirmPin()) {
                    this.state = 3;
                    msg = C0065R.string.keyguard_sim_unlock_progress_dialog_message;
                    KeyguardSimPukView.this.updateSim();
                } else {
                    this.state = 1;
                    msg = C0065R.string.kg_invalid_confirm_pin_hint;
                }
            }
            KeyguardSimPukView.this.resetPasswordText(true);
            if (msg != 0) {
                KeyguardSimPukView.this.mSecurityMessageDisplay.setMessage(msg, true);
            }
        }

        void reset() {
            KeyguardSimPukView.this.mPinText = "";
            KeyguardSimPukView.this.mPukText = "";
            this.state = 0;
            KeyguardUpdateMonitor monitor = KeyguardUpdateMonitor.getInstance(KeyguardSimPukView.this.mContext);
            KeyguardSimPukView.this.mSubId = monitor.getNextSubIdForState(State.PUK_REQUIRED);
            if (SubscriptionManager.isValidSubscriptionId(KeyguardSimPukView.this.mSubId)) {
                int count = TelephonyManager.getDefault().getSimCount();
                Resources rez = KeyguardSimPukView.this.getResources();
                int color = -1;
                String msg;
                if (count < 2) {
                    msg = rez.getString(C0065R.string.kg_puk_enter_puk_hint);
                } else {
                    SubscriptionInfo info = monitor.getSubscriptionInfoForSubId(KeyguardSimPukView.this.mSubId);
                    CharSequence displayName = info != null ? info.getDisplayName() : "";
                    msg = rez.getString(C0065R.string.kg_puk_enter_puk_hint_multi, new Object[]{displayName});
                    if (info != null) {
                        color = info.getIconTint();
                    }
                }
                if (KeyguardSimPukView.this.mShowDefaultMessage) {
                    KeyguardSimPukView.this.showDefaultMessage();
                }
                KeyguardSimPukView.this.mSimImageView.setImageTintList(ColorStateList.valueOf(color));
            }
            KeyguardSimPukView.this.mPasswordEntry.requestFocus();
        }
    }

    public KeyguardSimPukView(Context context) {
        this(context, null);
    }

    public KeyguardSimPukView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mSimUnlockProgressDialog = null;
        this.mShowDefaultMessage = true;
        this.mRemainingAttempts = -1;
        this.mStateMachine = new StateMachine();
        this.mUpdateMonitorCallback = new C00381();
    }

    protected int getPromtReasonStringRes(int reason) {
        return 0;
    }

    private String getPukPasswordErrorMessage(int attemptsRemaining, boolean isDefault) {
        if (attemptsRemaining == 0) {
            return getContext().getString(C0065R.string.kg_password_wrong_puk_code_dead);
        }
        if (attemptsRemaining > 0) {
            return getContext().getResources().getQuantityString(isDefault ? C0065R.plurals.kg_password_default_puk_message : C0065R.plurals.kg_password_wrong_puk_code, attemptsRemaining, new Object[]{Integer.valueOf(attemptsRemaining)});
        }
        return getContext().getString(isDefault ? C0065R.string.kg_puk_enter_puk_hint : C0065R.string.kg_password_puk_failed);
    }

    public void resetState() {
        super.resetState();
        this.mStateMachine.reset();
    }

    protected boolean shouldLockout(long deadline) {
        return false;
    }

    protected int getPasswordTextViewId() {
        return C0065R.id.pukEntry;
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mSecurityMessageDisplay.setTimeout(0);
        if (this.mEcaView instanceof EmergencyCarrierArea) {
            ((EmergencyCarrierArea) this.mEcaView).setCarrierTextVisible(true);
        }
        this.mSimImageView = (ImageView) findViewById(C0065R.id.keyguard_sim);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.mShowDefaultMessage) {
            showDefaultMessage();
        }
        KeyguardUpdateMonitor.getInstance(this.mContext).registerCallback(this.mUpdateMonitorCallback);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        KeyguardUpdateMonitor.getInstance(this.mContext).removeCallback(this.mUpdateMonitorCallback);
    }

    public void onPause() {
        if (this.mSimUnlockProgressDialog != null) {
            this.mSimUnlockProgressDialog.dismiss();
            this.mSimUnlockProgressDialog = null;
        }
    }

    private Dialog getSimUnlockProgressDialog() {
        if (this.mSimUnlockProgressDialog == null) {
            this.mSimUnlockProgressDialog = new ProgressDialog(this.mContext);
            this.mSimUnlockProgressDialog.setMessage(this.mContext.getString(C0065R.string.kg_sim_unlock_progress_dialog_message));
            this.mSimUnlockProgressDialog.setIndeterminate(true);
            this.mSimUnlockProgressDialog.setCancelable(false);
            if (!(this.mContext instanceof Activity)) {
                this.mSimUnlockProgressDialog.getWindow().setType(2009);
            }
        }
        return this.mSimUnlockProgressDialog;
    }

    private Dialog getPukRemainingAttemptsDialog(int remaining) {
        String msg = getPukPasswordErrorMessage(remaining, false);
        if (this.mRemainingAttemptsDialog == null) {
            Builder builder = new Builder(this.mContext);
            builder.setMessage(msg);
            builder.setCancelable(false);
            builder.setNeutralButton(C0065R.string.ok, null);
            this.mRemainingAttemptsDialog = builder.create();
            this.mRemainingAttemptsDialog.getWindow().setType(2009);
        } else {
            this.mRemainingAttemptsDialog.setMessage(msg);
        }
        return this.mRemainingAttemptsDialog;
    }

    private boolean checkPuk() {
        if (this.mPasswordEntry.getText().length() != 8) {
            return false;
        }
        this.mPukText = this.mPasswordEntry.getText();
        return true;
    }

    private boolean checkPin() {
        int length = this.mPasswordEntry.getText().length();
        if (length < 4 || length > 8) {
            return false;
        }
        this.mPinText = this.mPasswordEntry.getText();
        return true;
    }

    public boolean confirmPin() {
        return this.mPinText.equals(this.mPasswordEntry.getText());
    }

    private void updateSim() {
        getSimUnlockProgressDialog().show();
        if (this.mCheckSimPukThread == null) {
            this.mCheckSimPukThread = new C00402(this.mPukText, this.mPinText, this.mSubId);
            this.mCheckSimPukThread.start();
        }
    }

    protected void verifyPasswordAndUnlock() {
        this.mStateMachine.next();
    }

    public void startAppearAnimation() {
    }

    public boolean startDisappearAnimation(Runnable finishRunnable) {
        return false;
    }

    private void showDefaultMessage() {
        if (this.mRemainingAttempts >= 0) {
            this.mSecurityMessageDisplay.setMessage(getPukPasswordErrorMessage(this.mRemainingAttempts, true), true);
            return;
        }
        this.mSecurityMessageDisplay.setMessage(C0065R.string.kg_sim_pin_instructions, true);
        this.mSubId = KeyguardUpdateMonitor.getInstance(this.mContext).getNextSubIdForState(State.PUK_REQUIRED);
        if (SubscriptionManager.isValidSubscriptionId(this.mSubId)) {
            new C00413("", "", this.mSubId).start();
        }
    }
}
