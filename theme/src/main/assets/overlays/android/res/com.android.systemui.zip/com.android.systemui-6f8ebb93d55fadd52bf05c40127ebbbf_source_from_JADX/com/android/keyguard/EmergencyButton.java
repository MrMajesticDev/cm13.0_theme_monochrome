package com.android.keyguard;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.UserHandle;
import android.telecom.TelecomManager;
import android.telephony.ServiceState;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.android.internal.logging.MetricsLogger;
import com.android.internal.telephony.IccCardConstants.State;
import com.android.internal.widget.LockPatternUtils;

public class EmergencyButton extends Button {
    private static final Intent INTENT_EMERGENCY_DIAL;
    private EmergencyButtonCallback mEmergencyButtonCallback;
    private final boolean mEnableEmergencyCallWhileSimLocked;
    KeyguardUpdateMonitorCallback mInfoCallback;
    private final boolean mIsVoiceCapable;
    private LockPatternUtils mLockPatternUtils;
    private PowerManager mPowerManager;

    /* renamed from: com.android.keyguard.EmergencyButton.1 */
    class C00031 extends KeyguardUpdateMonitorCallback {
        C00031() {
        }

        public void onSimStateChanged(int subId, int slotId, State simState) {
            EmergencyButton.this.updateEmergencyCallButton();
        }

        public void onPhoneStateChanged(int phoneState) {
            EmergencyButton.this.updateEmergencyCallButton();
        }

        public void onServiceStateChanged(int sub, ServiceState state) {
            EmergencyButton.this.updateEmergencyCallButton();
        }
    }

    /* renamed from: com.android.keyguard.EmergencyButton.2 */
    class C00042 implements OnClickListener {
        C00042() {
        }

        public void onClick(View v) {
            EmergencyButton.this.takeEmergencyCallAction();
        }
    }

    public interface EmergencyButtonCallback {
        void onEmergencyButtonClickedWhenInCall();
    }

    static {
        INTENT_EMERGENCY_DIAL = new Intent().setAction("com.android.phone.EmergencyDialer.DIAL").setPackage("com.android.phone").setFlags(343932928);
    }

    public EmergencyButton(Context context) {
        this(context, null);
    }

    public EmergencyButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mInfoCallback = new C00031();
        this.mIsVoiceCapable = context.getResources().getBoolean(17956953);
        this.mEnableEmergencyCallWhileSimLocked = this.mContext.getResources().getBoolean(17956938);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        KeyguardUpdateMonitor.getInstance(this.mContext).registerCallback(this.mInfoCallback);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        KeyguardUpdateMonitor.getInstance(this.mContext).removeCallback(this.mInfoCallback);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mLockPatternUtils = new LockPatternUtils(this.mContext);
        this.mPowerManager = (PowerManager) this.mContext.getSystemService("power");
        setOnClickListener(new C00042());
        updateEmergencyCallButton();
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        updateEmergencyCallButton();
    }

    public void takeEmergencyCallAction() {
        MetricsLogger.action(this.mContext, 200);
        this.mPowerManager.userActivity(SystemClock.uptimeMillis(), true);
        if (isInCall()) {
            resumeCall();
            if (this.mEmergencyButtonCallback != null) {
                this.mEmergencyButtonCallback.onEmergencyButtonClickedWhenInCall();
                return;
            }
            return;
        }
        KeyguardUpdateMonitor.getInstance(this.mContext).reportEmergencyCallAction(true);
        getContext().startActivityAsUser(INTENT_EMERGENCY_DIAL, ActivityOptions.makeCustomAnimation(getContext(), 0, 0).toBundle(), new UserHandle(KeyguardUpdateMonitor.getCurrentUser()));
    }

    private void updateEmergencyCallButton() {
        boolean visible = false;
        if (this.mIsVoiceCapable) {
            if (isInCall()) {
                visible = true;
            } else {
                if (KeyguardUpdateMonitor.getInstance(this.mContext).isSimPinVoiceSecure()) {
                    visible = this.mEnableEmergencyCallWhileSimLocked;
                } else {
                    visible = this.mLockPatternUtils.isSecure(KeyguardUpdateMonitor.getCurrentUser());
                }
                if (this.mContext.getResources().getBoolean(C0065R.bool.kg_hide_emgcy_btn_when_oos)) {
                    visible = visible && !KeyguardUpdateMonitor.getInstance(this.mContext).isOOS();
                }
            }
        }
        if (visible) {
            int textId;
            setVisibility(0);
            if (isInCall()) {
                textId = 17040010;
            } else {
                textId = 17040009;
            }
            setText(textId);
            return;
        }
        setVisibility(8);
    }

    public void setCallback(EmergencyButtonCallback callback) {
        this.mEmergencyButtonCallback = callback;
    }

    private void resumeCall() {
        getTelecommManager().showInCallScreen(false);
    }

    private boolean isInCall() {
        return getTelecommManager().isInCall();
    }

    private TelecomManager getTelecommManager() {
        return (TelecomManager) this.mContext.getSystemService("telecom");
    }
}
