package com.android.systemui.statusbar.policy;

class WifiIcons {
    static final int[][] QS_WIFI_SIGNAL_STRENGTH;
    static final int WIFI_LEVEL_COUNT;
    static final int[][] WIFI_SIGNAL_STRENGTH;

    static {
        WIFI_SIGNAL_STRENGTH = new int[][]{new int[]{2130838143, 2130838145, 2130838147, 2130838149, 2130838151}, new int[]{2130838144, 2130838146, 2130838148, 2130838150, 2130838152}};
        QS_WIFI_SIGNAL_STRENGTH = new int[][]{new int[]{2130837680, 2130837681, 2130837682, 2130837683, 2130837684}, new int[]{2130837687, 2130837688, 2130837689, 2130837690, 2130837691}};
        WIFI_LEVEL_COUNT = WIFI_SIGNAL_STRENGTH[0].length;
    }
}
