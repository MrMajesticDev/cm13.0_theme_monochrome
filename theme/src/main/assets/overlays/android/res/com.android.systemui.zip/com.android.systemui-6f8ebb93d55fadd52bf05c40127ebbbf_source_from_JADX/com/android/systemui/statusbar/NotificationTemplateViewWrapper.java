package com.android.systemui.statusbar;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import com.android.systemui.ViewInvertHelper;

public class NotificationTemplateViewWrapper extends NotificationViewWrapper {
    private final ColorMatrix mGrayscaleColorMatrix;
    private ImageView mIcon;
    private int mIconBackgroundColor;
    private final int mIconBackgroundDarkColor;
    private final PorterDuffColorFilter mIconColorFilter;
    private final int mIconDarkAlpha;
    private boolean mIconForceGraysaleWhenDark;
    private ViewInvertHelper mInvertHelper;
    private final Interpolator mLinearOutSlowInInterpolator;
    protected ImageView mPicture;

    /* renamed from: com.android.systemui.statusbar.NotificationTemplateViewWrapper.1 */
    class C03301 implements AnimatorUpdateListener {
        final /* synthetic */ ImageView val$target;

        C03301(ImageView imageView) {
            this.val$target = imageView;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            NotificationTemplateViewWrapper.this.updateIconColorFilter(this.val$target, ((Float) animation.getAnimatedValue()).floatValue());
        }
    }

    /* renamed from: com.android.systemui.statusbar.NotificationTemplateViewWrapper.2 */
    class C03312 implements AnimatorUpdateListener {
        final /* synthetic */ ImageView val$target;

        C03312(ImageView imageView) {
            this.val$target = imageView;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            float t = ((Float) animation.getAnimatedValue()).floatValue();
            this.val$target.setImageAlpha((int) ((255.0f * (1.0f - t)) + (((float) NotificationTemplateViewWrapper.this.mIconDarkAlpha) * t)));
        }
    }

    /* renamed from: com.android.systemui.statusbar.NotificationTemplateViewWrapper.3 */
    class C03323 implements AnimatorUpdateListener {
        final /* synthetic */ ImageView val$target;

        C03323(ImageView imageView) {
            this.val$target = imageView;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            NotificationTemplateViewWrapper.this.updateGrayscaleMatrix(((Float) animation.getAnimatedValue()).floatValue());
            this.val$target.setColorFilter(new ColorMatrixColorFilter(NotificationTemplateViewWrapper.this.mGrayscaleColorMatrix));
        }
    }

    /* renamed from: com.android.systemui.statusbar.NotificationTemplateViewWrapper.4 */
    class C03334 extends AnimatorListenerAdapter {
        final /* synthetic */ boolean val$dark;
        final /* synthetic */ ImageView val$target;

        C03334(boolean z, ImageView imageView) {
            this.val$dark = z;
            this.val$target = imageView;
        }

        public void onAnimationEnd(Animator animation) {
            if (!this.val$dark) {
                this.val$target.setColorFilter(null);
            }
        }
    }

    protected NotificationTemplateViewWrapper(Context ctx, View view) {
        super(view);
        this.mGrayscaleColorMatrix = new ColorMatrix();
        this.mIconColorFilter = new PorterDuffColorFilter(0, Mode.SRC_ATOP);
        this.mIconDarkAlpha = ctx.getResources().getInteger(2131623982);
        this.mIconBackgroundDarkColor = ctx.getColor(2131427400);
        this.mLinearOutSlowInInterpolator = AnimationUtils.loadInterpolator(ctx, 17563662);
        resolveViews();
    }

    private void resolveViews() {
        ViewInvertHelper viewInvertHelper;
        Drawable iconDrawable;
        View mainColumn = this.mView.findViewById(16909166);
        if (mainColumn != null) {
            viewInvertHelper = new ViewInvertHelper(mainColumn, 700);
        } else {
            viewInvertHelper = null;
        }
        this.mInvertHelper = viewInvertHelper;
        ImageView largeIcon = (ImageView) this.mView.findViewById(16908294);
        this.mIcon = resolveIcon(largeIcon, (ImageView) this.mView.findViewById(16908352));
        this.mPicture = resolvePicture(largeIcon);
        this.mIconBackgroundColor = resolveBackgroundColor(this.mIcon);
        if (this.mIcon != null) {
            iconDrawable = this.mIcon.getDrawable();
        } else {
            iconDrawable = null;
        }
        boolean z = (iconDrawable == null || iconDrawable.getColorFilter() == null) ? false : true;
        this.mIconForceGraysaleWhenDark = z;
    }

    private ImageView resolveIcon(ImageView largeIcon, ImageView rightIcon) {
        if (largeIcon == null || largeIcon.getBackground() == null) {
            return (rightIcon == null || rightIcon.getVisibility() != 0) ? null : rightIcon;
        } else {
            return largeIcon;
        }
    }

    private ImageView resolvePicture(ImageView largeIcon) {
        return (largeIcon == null || largeIcon.getBackground() != null) ? null : largeIcon;
    }

    private int resolveBackgroundColor(ImageView icon) {
        if (!(icon == null || icon.getBackground() == null)) {
            ColorFilter filter = icon.getBackground().getColorFilter();
            if (filter instanceof PorterDuffColorFilter) {
                return ((PorterDuffColorFilter) filter).getColor();
            }
        }
        return 0;
    }

    public void notifyContentUpdated() {
        super.notifyContentUpdated();
        resolveViews();
    }

    public void setDark(boolean dark, boolean fade, long delay) {
        if (this.mInvertHelper != null) {
            if (fade) {
                this.mInvertHelper.fade(dark, delay);
            } else {
                this.mInvertHelper.update(dark);
            }
        }
        if (this.mIcon != null) {
            if (fade) {
                fadeIconColorFilter(this.mIcon, dark, delay);
                fadeIconAlpha(this.mIcon, dark, delay);
                if (!this.mIconForceGraysaleWhenDark) {
                    fadeGrayscale(this.mIcon, dark, delay);
                }
            } else {
                updateIconColorFilter(this.mIcon, dark);
                updateIconAlpha(this.mIcon, dark);
                if (!this.mIconForceGraysaleWhenDark) {
                    updateGrayscale(this.mIcon, dark);
                }
            }
        }
        setPictureGrayscale(dark, fade, delay);
    }

    protected void setPictureGrayscale(boolean grayscale, boolean fade, long delay) {
        if (this.mPicture == null) {
            return;
        }
        if (fade) {
            fadeGrayscale(this.mPicture, grayscale, delay);
        } else {
            updateGrayscale(this.mPicture, grayscale);
        }
    }

    private void startIntensityAnimation(AnimatorUpdateListener updateListener, boolean dark, long delay, AnimatorListener listener) {
        float startIntensity;
        float endIntensity = 1.0f;
        if (dark) {
            startIntensity = 0.0f;
        } else {
            startIntensity = 1.0f;
        }
        if (!dark) {
            endIntensity = 0.0f;
        }
        ValueAnimator animator = ValueAnimator.ofFloat(new float[]{startIntensity, endIntensity});
        animator.addUpdateListener(updateListener);
        animator.setDuration(700);
        animator.setInterpolator(this.mLinearOutSlowInInterpolator);
        animator.setStartDelay(delay);
        if (listener != null) {
            animator.addListener(listener);
        }
        animator.start();
    }

    private void fadeIconColorFilter(ImageView target, boolean dark, long delay) {
        startIntensityAnimation(new C03301(target), dark, delay, null);
    }

    private void fadeIconAlpha(ImageView target, boolean dark, long delay) {
        startIntensityAnimation(new C03312(target), dark, delay, null);
    }

    protected void fadeGrayscale(ImageView target, boolean dark, long delay) {
        startIntensityAnimation(new C03323(target), dark, delay, new C03334(dark, target));
    }

    private void updateIconColorFilter(ImageView target, boolean dark) {
        updateIconColorFilter(target, dark ? 1.0f : 0.0f);
    }

    private void updateIconColorFilter(ImageView target, float intensity) {
        this.mIconColorFilter.setColor(interpolateColor(this.mIconBackgroundColor, this.mIconBackgroundDarkColor, intensity));
        Drawable background = target.getBackground();
        if (background != null) {
            background.mutate().setColorFilter(this.mIconColorFilter);
        }
    }

    private void updateIconAlpha(ImageView target, boolean dark) {
        target.setImageAlpha(dark ? this.mIconDarkAlpha : 255);
    }

    protected void updateGrayscale(ImageView target, boolean dark) {
        if (dark) {
            updateGrayscaleMatrix(1.0f);
            target.setColorFilter(new ColorMatrixColorFilter(this.mGrayscaleColorMatrix));
            return;
        }
        target.setColorFilter(null);
    }

    private void updateGrayscaleMatrix(float intensity) {
        this.mGrayscaleColorMatrix.setSaturation(1.0f - intensity);
    }

    private static int interpolateColor(int source, int target, float t) {
        int aSource = Color.alpha(source);
        int rSource = Color.red(source);
        int gSource = Color.green(source);
        int bSource = Color.blue(source);
        return Color.argb((int) ((((float) aSource) * (1.0f - t)) + (((float) Color.alpha(target)) * t)), (int) ((((float) rSource) * (1.0f - t)) + (((float) Color.red(target)) * t)), (int) ((((float) gSource) * (1.0f - t)) + (((float) Color.green(target)) * t)), (int) ((((float) bSource) * (1.0f - t)) + (((float) Color.blue(target)) * t)));
    }
}
