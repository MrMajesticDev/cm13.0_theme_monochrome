package com.android.keyguard;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings.Secure;
import android.provider.Settings.System;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Stack;

public class PasswordTextView extends View {
    private Interpolator mAppearInterpolator;
    private int mCharPadding;
    private Stack<CharState> mCharPool;
    private Interpolator mDisappearInterpolator;
    private int mDotSize;
    private final Paint mDrawPaint;
    private Interpolator mFastOutSlowInInterpolator;
    private PowerManager mPM;
    private boolean mShowPassword;
    private String mText;
    private ArrayList<CharState> mTextChars;
    private final int mTextHeightRaw;
    private UserActivityListener mUserActivityListener;

    public interface UserActivityListener {
        void onUserActivity();
    }

    private class CharState {
        float currentDotSizeFactor;
        float currentTextSizeFactor;
        float currentTextTranslationY;
        float currentWidthFactor;
        boolean dotAnimationIsGrowing;
        Animator dotAnimator;
        AnimatorListener dotFinishListener;
        private AnimatorUpdateListener dotSizeUpdater;
        private Runnable dotSwapperRunnable;
        boolean isDotSwapPending;
        AnimatorListener removeEndListener;
        boolean textAnimationIsGrowing;
        ValueAnimator textAnimator;
        AnimatorListener textFinishListener;
        private AnimatorUpdateListener textSizeUpdater;
        ValueAnimator textTranslateAnimator;
        AnimatorListener textTranslateFinishListener;
        private AnimatorUpdateListener textTranslationUpdater;
        char whichChar;
        boolean widthAnimationIsGrowing;
        ValueAnimator widthAnimator;
        AnimatorListener widthFinishListener;
        private AnimatorUpdateListener widthUpdater;

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.1 */
        class C00561 extends AnimatorListenerAdapter {
            private boolean mCancelled;

            C00561() {
            }

            public void onAnimationCancel(Animator animation) {
                this.mCancelled = true;
            }

            public void onAnimationEnd(Animator animation) {
                if (!this.mCancelled) {
                    PasswordTextView.this.mTextChars.remove(CharState.this);
                    PasswordTextView.this.mCharPool.push(CharState.this);
                    CharState.this.reset();
                    CharState.this.cancelAnimator(CharState.this.textTranslateAnimator);
                    CharState.this.textTranslateAnimator = null;
                }
            }

            public void onAnimationStart(Animator animation) {
                this.mCancelled = false;
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.2 */
        class C00572 extends AnimatorListenerAdapter {
            C00572() {
            }

            public void onAnimationEnd(Animator animation) {
                CharState.this.dotAnimator = null;
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.3 */
        class C00583 extends AnimatorListenerAdapter {
            C00583() {
            }

            public void onAnimationEnd(Animator animation) {
                CharState.this.textAnimator = null;
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.4 */
        class C00594 extends AnimatorListenerAdapter {
            C00594() {
            }

            public void onAnimationEnd(Animator animation) {
                CharState.this.textTranslateAnimator = null;
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.5 */
        class C00605 extends AnimatorListenerAdapter {
            C00605() {
            }

            public void onAnimationEnd(Animator animation) {
                CharState.this.widthAnimator = null;
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.6 */
        class C00616 implements AnimatorUpdateListener {
            C00616() {
            }

            public void onAnimationUpdate(ValueAnimator animation) {
                CharState.this.currentDotSizeFactor = ((Float) animation.getAnimatedValue()).floatValue();
                PasswordTextView.this.invalidate();
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.7 */
        class C00627 implements AnimatorUpdateListener {
            C00627() {
            }

            public void onAnimationUpdate(ValueAnimator animation) {
                CharState.this.currentTextSizeFactor = ((Float) animation.getAnimatedValue()).floatValue();
                PasswordTextView.this.invalidate();
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.8 */
        class C00638 implements AnimatorUpdateListener {
            C00638() {
            }

            public void onAnimationUpdate(ValueAnimator animation) {
                CharState.this.currentTextTranslationY = ((Float) animation.getAnimatedValue()).floatValue();
                PasswordTextView.this.invalidate();
            }
        }

        /* renamed from: com.android.keyguard.PasswordTextView.CharState.9 */
        class C00649 implements AnimatorUpdateListener {
            C00649() {
            }

            public void onAnimationUpdate(ValueAnimator animation) {
                CharState.this.currentWidthFactor = ((Float) animation.getAnimatedValue()).floatValue();
                PasswordTextView.this.invalidate();
            }
        }

        private CharState() {
            this.currentTextTranslationY = 1.0f;
            this.removeEndListener = new C00561();
            this.dotFinishListener = new C00572();
            this.textFinishListener = new C00583();
            this.textTranslateFinishListener = new C00594();
            this.widthFinishListener = new C00605();
            this.dotSizeUpdater = new C00616();
            this.textSizeUpdater = new C00627();
            this.textTranslationUpdater = new C00638();
            this.widthUpdater = new C00649();
            this.dotSwapperRunnable = new Runnable() {
                public void run() {
                    CharState.this.performSwap();
                    CharState.this.isDotSwapPending = false;
                }
            };
        }

        void reset() {
            this.whichChar = '\u0000';
            this.currentTextSizeFactor = 0.0f;
            this.currentDotSizeFactor = 0.0f;
            this.currentWidthFactor = 0.0f;
            cancelAnimator(this.textAnimator);
            this.textAnimator = null;
            cancelAnimator(this.dotAnimator);
            this.dotAnimator = null;
            cancelAnimator(this.widthAnimator);
            this.widthAnimator = null;
            this.currentTextTranslationY = 1.0f;
            removeDotSwapCallbacks();
        }

        void startRemoveAnimation(long startDelay, long widthDelay) {
            boolean dotNeedsAnimation;
            boolean textNeedsAnimation;
            boolean widthNeedsAnimation;
            if ((this.currentDotSizeFactor <= 0.0f || this.dotAnimator != null) && (this.dotAnimator == null || !this.dotAnimationIsGrowing)) {
                dotNeedsAnimation = false;
            } else {
                dotNeedsAnimation = true;
            }
            if ((this.currentTextSizeFactor <= 0.0f || this.textAnimator != null) && (this.textAnimator == null || !this.textAnimationIsGrowing)) {
                textNeedsAnimation = false;
            } else {
                textNeedsAnimation = true;
            }
            if ((this.currentWidthFactor <= 0.0f || this.widthAnimator != null) && (this.widthAnimator == null || !this.widthAnimationIsGrowing)) {
                widthNeedsAnimation = false;
            } else {
                widthNeedsAnimation = true;
            }
            if (dotNeedsAnimation) {
                startDotDisappearAnimation(startDelay);
            }
            if (textNeedsAnimation) {
                startTextDisappearAnimation(startDelay);
            }
            if (widthNeedsAnimation) {
                startWidthDisappearAnimation(widthDelay);
            }
        }

        void startAppearAnimation() {
            boolean dotNeedsAnimation;
            boolean textNeedsAnimation;
            boolean widthNeedsAnimation;
            if (PasswordTextView.this.mShowPassword || (this.dotAnimator != null && this.dotAnimationIsGrowing)) {
                dotNeedsAnimation = false;
            } else {
                dotNeedsAnimation = true;
            }
            if (!PasswordTextView.this.mShowPassword || (this.textAnimator != null && this.textAnimationIsGrowing)) {
                textNeedsAnimation = false;
            } else {
                textNeedsAnimation = true;
            }
            if (this.widthAnimator == null || !this.widthAnimationIsGrowing) {
                widthNeedsAnimation = true;
            } else {
                widthNeedsAnimation = false;
            }
            if (dotNeedsAnimation) {
                startDotAppearAnimation(0);
            }
            if (textNeedsAnimation) {
                startTextAppearAnimation();
            }
            if (widthNeedsAnimation) {
                startWidthAppearAnimation();
            }
            if (PasswordTextView.this.mShowPassword) {
                postDotSwap(1300);
            }
        }

        private void postDotSwap(long delay) {
            removeDotSwapCallbacks();
            PasswordTextView.this.postDelayed(this.dotSwapperRunnable, delay);
            this.isDotSwapPending = true;
        }

        private void removeDotSwapCallbacks() {
            PasswordTextView.this.removeCallbacks(this.dotSwapperRunnable);
            this.isDotSwapPending = false;
        }

        void swapToDotWhenAppearFinished() {
            removeDotSwapCallbacks();
            if (this.textAnimator != null) {
                postDotSwap(100 + (this.textAnimator.getDuration() - this.textAnimator.getCurrentPlayTime()));
            } else {
                performSwap();
            }
        }

        private void performSwap() {
            startTextDisappearAnimation(0);
            startDotAppearAnimation(30);
        }

        private void startWidthDisappearAnimation(long widthDelay) {
            cancelAnimator(this.widthAnimator);
            this.widthAnimator = ValueAnimator.ofFloat(new float[]{this.currentWidthFactor, 0.0f});
            this.widthAnimator.addUpdateListener(this.widthUpdater);
            this.widthAnimator.addListener(this.widthFinishListener);
            this.widthAnimator.addListener(this.removeEndListener);
            this.widthAnimator.setDuration((long) (160.0f * this.currentWidthFactor));
            this.widthAnimator.setStartDelay(widthDelay);
            this.widthAnimator.start();
            this.widthAnimationIsGrowing = false;
        }

        private void startTextDisappearAnimation(long startDelay) {
            cancelAnimator(this.textAnimator);
            this.textAnimator = ValueAnimator.ofFloat(new float[]{this.currentTextSizeFactor, 0.0f});
            this.textAnimator.addUpdateListener(this.textSizeUpdater);
            this.textAnimator.addListener(this.textFinishListener);
            this.textAnimator.setInterpolator(PasswordTextView.this.mDisappearInterpolator);
            this.textAnimator.setDuration((long) (160.0f * this.currentTextSizeFactor));
            this.textAnimator.setStartDelay(startDelay);
            this.textAnimator.start();
            this.textAnimationIsGrowing = false;
        }

        private void startDotDisappearAnimation(long startDelay) {
            cancelAnimator(this.dotAnimator);
            ValueAnimator animator = ValueAnimator.ofFloat(new float[]{this.currentDotSizeFactor, 0.0f});
            animator.addUpdateListener(this.dotSizeUpdater);
            animator.addListener(this.dotFinishListener);
            animator.setInterpolator(PasswordTextView.this.mDisappearInterpolator);
            animator.setDuration((long) (160.0f * Math.min(this.currentDotSizeFactor, 1.0f)));
            animator.setStartDelay(startDelay);
            animator.start();
            this.dotAnimator = animator;
            this.dotAnimationIsGrowing = false;
        }

        private void startWidthAppearAnimation() {
            cancelAnimator(this.widthAnimator);
            this.widthAnimator = ValueAnimator.ofFloat(new float[]{this.currentWidthFactor, 1.0f});
            this.widthAnimator.addUpdateListener(this.widthUpdater);
            this.widthAnimator.addListener(this.widthFinishListener);
            this.widthAnimator.setDuration((long) (160.0f * (1.0f - this.currentWidthFactor)));
            this.widthAnimator.start();
            this.widthAnimationIsGrowing = true;
        }

        private void startTextAppearAnimation() {
            cancelAnimator(this.textAnimator);
            this.textAnimator = ValueAnimator.ofFloat(new float[]{this.currentTextSizeFactor, 1.0f});
            this.textAnimator.addUpdateListener(this.textSizeUpdater);
            this.textAnimator.addListener(this.textFinishListener);
            this.textAnimator.setInterpolator(PasswordTextView.this.mAppearInterpolator);
            this.textAnimator.setDuration((long) (160.0f * (1.0f - this.currentTextSizeFactor)));
            this.textAnimator.start();
            this.textAnimationIsGrowing = true;
            if (this.textTranslateAnimator == null) {
                this.textTranslateAnimator = ValueAnimator.ofFloat(new float[]{1.0f, 0.0f});
                this.textTranslateAnimator.addUpdateListener(this.textTranslationUpdater);
                this.textTranslateAnimator.addListener(this.textTranslateFinishListener);
                this.textTranslateAnimator.setInterpolator(PasswordTextView.this.mAppearInterpolator);
                this.textTranslateAnimator.setDuration(160);
                this.textTranslateAnimator.start();
            }
        }

        private void startDotAppearAnimation(long delay) {
            cancelAnimator(this.dotAnimator);
            if (PasswordTextView.this.mShowPassword) {
                ValueAnimator growAnimator = ValueAnimator.ofFloat(new float[]{this.currentDotSizeFactor, 1.0f});
                growAnimator.addUpdateListener(this.dotSizeUpdater);
                growAnimator.setDuration((long) (160.0f * (1.0f - this.currentDotSizeFactor)));
                growAnimator.addListener(this.dotFinishListener);
                growAnimator.setStartDelay(delay);
                growAnimator.start();
                this.dotAnimator = growAnimator;
            } else {
                ValueAnimator overShootAnimator = ValueAnimator.ofFloat(new float[]{this.currentDotSizeFactor, 1.5f});
                overShootAnimator.addUpdateListener(this.dotSizeUpdater);
                overShootAnimator.setInterpolator(PasswordTextView.this.mAppearInterpolator);
                overShootAnimator.setDuration(160);
                ValueAnimator settleBackAnimator = ValueAnimator.ofFloat(new float[]{1.5f, 1.0f});
                settleBackAnimator.addUpdateListener(this.dotSizeUpdater);
                settleBackAnimator.setDuration(320 - 160);
                settleBackAnimator.addListener(this.dotFinishListener);
                AnimatorSet animatorSet = new AnimatorSet();
                animatorSet.playSequentially(new Animator[]{overShootAnimator, settleBackAnimator});
                animatorSet.setStartDelay(delay);
                animatorSet.start();
                this.dotAnimator = animatorSet;
            }
            this.dotAnimationIsGrowing = true;
        }

        private void cancelAnimator(Animator animator) {
            if (animator != null) {
                animator.cancel();
            }
        }

        public float draw(Canvas canvas, float currentDrawPosition, int charHeight, float yPosition, float charLength) {
            boolean textVisible;
            boolean dotVisible;
            if (this.currentTextSizeFactor > 0.0f) {
                textVisible = true;
            } else {
                textVisible = false;
            }
            if (this.currentDotSizeFactor > 0.0f) {
                dotVisible = true;
            } else {
                dotVisible = false;
            }
            float charWidth = charLength * this.currentWidthFactor;
            if (textVisible) {
                float currYPosition = (((((float) charHeight) / 2.0f) * this.currentTextSizeFactor) + yPosition) + ((((float) charHeight) * this.currentTextTranslationY) * 0.8f);
                canvas.save();
                canvas.translate(currentDrawPosition + (charWidth / 2.0f), currYPosition);
                canvas.scale(this.currentTextSizeFactor, this.currentTextSizeFactor);
                canvas.drawText(Character.toString(this.whichChar), 0.0f, 0.0f, PasswordTextView.this.mDrawPaint);
                canvas.restore();
            }
            if (dotVisible) {
                canvas.save();
                canvas.translate(currentDrawPosition + (charWidth / 2.0f), yPosition);
                canvas.drawCircle(0.0f, 0.0f, ((float) (PasswordTextView.this.mDotSize / 2)) * this.currentDotSizeFactor, PasswordTextView.this.mDrawPaint);
                canvas.restore();
            }
            return (((float) PasswordTextView.this.mCharPadding) * this.currentWidthFactor) + charWidth;
        }
    }

    public PasswordTextView(Context context) {
        this(context, null);
    }

    public PasswordTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PasswordTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public PasswordTextView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        boolean z = true;
        super(context, attrs, defStyleAttr, defStyleRes);
        this.mTextChars = new ArrayList();
        this.mText = "";
        this.mCharPool = new Stack();
        this.mDrawPaint = new Paint();
        setFocusableInTouchMode(true);
        setFocusable(true);
        TypedArray a = context.obtainStyledAttributes(attrs, C0065R.styleable.PasswordTextView);
        try {
            this.mTextHeightRaw = a.getInt(C0065R.styleable.PasswordTextView_scaledTextSize, 0);
            this.mDrawPaint.setFlags(129);
            this.mDrawPaint.setTextAlign(Align.CENTER);
            this.mDrawPaint.setColor(-1);
            this.mDrawPaint.setTypeface(Typeface.create("sans-serif-light", 0));
            this.mDotSize = getContext().getResources().getDimensionPixelSize(C0065R.dimen.password_dot_size);
            this.mCharPadding = getContext().getResources().getDimensionPixelSize(C0065R.dimen.password_char_padding);
            if (System.getInt(this.mContext.getContentResolver(), "show_password", 1) != 1) {
                z = false;
            }
            this.mShowPassword = z;
            this.mAppearInterpolator = AnimationUtils.loadInterpolator(this.mContext, 17563662);
            this.mDisappearInterpolator = AnimationUtils.loadInterpolator(this.mContext, 17563663);
            this.mFastOutSlowInInterpolator = AnimationUtils.loadInterpolator(this.mContext, 17563661);
            this.mPM = (PowerManager) this.mContext.getSystemService("power");
        } finally {
            a.recycle();
        }
    }

    protected void onDraw(Canvas canvas) {
        float currentDrawPosition = ((float) (getWidth() / 2)) - (getDrawingWidth() / 2.0f);
        int length = this.mTextChars.size();
        Rect bounds = getCharBounds();
        int charHeight = bounds.bottom - bounds.top;
        float yPosition = (float) (getHeight() / 2);
        float charLength = (float) (bounds.right - bounds.left);
        for (int i = 0; i < length; i++) {
            currentDrawPosition += ((CharState) this.mTextChars.get(i)).draw(canvas, currentDrawPosition, charHeight, yPosition, charLength);
        }
    }

    public boolean hasOverlappingRendering() {
        return false;
    }

    private Rect getCharBounds() {
        this.mDrawPaint.setTextSize(((float) this.mTextHeightRaw) * getResources().getDisplayMetrics().scaledDensity);
        Rect bounds = new Rect();
        this.mDrawPaint.getTextBounds("0", 0, 1, bounds);
        return bounds;
    }

    private float getDrawingWidth() {
        int width = 0;
        int length = this.mTextChars.size();
        Rect bounds = getCharBounds();
        int charLength = bounds.right - bounds.left;
        for (int i = 0; i < length; i++) {
            CharState charState = (CharState) this.mTextChars.get(i);
            if (i != 0) {
                width = (int) (((float) width) + (((float) this.mCharPadding) * charState.currentWidthFactor));
            }
            width = (int) (((float) width) + (((float) charLength) * charState.currentWidthFactor));
        }
        return (float) width;
    }

    public void append(char c) {
        CharState charState;
        int visibleChars = this.mTextChars.size();
        String textbefore = this.mText;
        this.mText += c;
        int newLength = this.mText.length();
        if (newLength > visibleChars) {
            charState = obtainCharState(c);
            this.mTextChars.add(charState);
        } else {
            charState = (CharState) this.mTextChars.get(newLength - 1);
            charState.whichChar = c;
        }
        charState.startAppearAnimation();
        if (newLength > 1) {
            CharState previousState = (CharState) this.mTextChars.get(newLength - 2);
            if (previousState.isDotSwapPending) {
                previousState.swapToDotWhenAppearFinished();
            }
        }
        userActivity();
        sendAccessibilityEventTypeViewTextChanged(textbefore, textbefore.length(), 0, 1);
    }

    public void setUserActivityListener(UserActivityListener userActivitiListener) {
        this.mUserActivityListener = userActivitiListener;
    }

    private void userActivity() {
        this.mPM.userActivity(SystemClock.uptimeMillis(), false);
        if (this.mUserActivityListener != null) {
            this.mUserActivityListener.onUserActivity();
        }
    }

    public void deleteLastChar() {
        int length = this.mText.length();
        String textbefore = this.mText;
        if (length > 0) {
            this.mText = this.mText.substring(0, length - 1);
            ((CharState) this.mTextChars.get(length - 1)).startRemoveAnimation(0, 0);
        }
        userActivity();
        sendAccessibilityEventTypeViewTextChanged(textbefore, textbefore.length() - 1, 1, 0);
    }

    public String getText() {
        return this.mText;
    }

    private CharState obtainCharState(char c) {
        CharState charState;
        if (this.mCharPool.isEmpty()) {
            charState = new CharState();
        } else {
            charState = (CharState) this.mCharPool.pop();
            charState.reset();
        }
        charState.whichChar = c;
        return charState;
    }

    public void reset(boolean animated) {
        String textbefore = this.mText;
        this.mText = "";
        int length = this.mTextChars.size();
        int middleIndex = (length - 1) / 2;
        for (int i = 0; i < length; i++) {
            CharState charState = (CharState) this.mTextChars.get(i);
            if (animated) {
                int delayIndex;
                if (i <= middleIndex) {
                    delayIndex = i * 2;
                } else {
                    delayIndex = (length - 1) - (((i - middleIndex) - 1) * 2);
                }
                long min = Math.min(((long) delayIndex) * 40, 200);
                charState.startRemoveAnimation(min, Math.min(40 * ((long) (length - 1)), 200) + 160);
                charState.removeDotSwapCallbacks();
            } else {
                this.mCharPool.push(charState);
            }
        }
        if (!animated) {
            this.mTextChars.clear();
        }
        sendAccessibilityEventTypeViewTextChanged(textbefore, 0, textbefore.length(), 0);
    }

    void sendAccessibilityEventTypeViewTextChanged(String beforeText, int fromIndex, int removedCount, int addedCount) {
        if (!AccessibilityManager.getInstance(this.mContext).isEnabled()) {
            return;
        }
        if (isFocused() || (isSelected() && isShown())) {
            if (!shouldSpeakPasswordsForAccessibility()) {
                beforeText = null;
            }
            AccessibilityEvent event = AccessibilityEvent.obtain(16);
            event.setFromIndex(fromIndex);
            event.setRemovedCount(removedCount);
            event.setAddedCount(addedCount);
            event.setBeforeText(beforeText);
            event.setPassword(true);
            sendAccessibilityEventUnchecked(event);
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent event) {
        super.onInitializeAccessibilityEvent(event);
        event.setClassName(PasswordTextView.class.getName());
        event.setPassword(true);
    }

    public void onPopulateAccessibilityEvent(AccessibilityEvent event) {
        super.onPopulateAccessibilityEvent(event);
        if (shouldSpeakPasswordsForAccessibility()) {
            CharSequence text = this.mText;
            if (!TextUtils.isEmpty(text)) {
                event.getText().add(text);
            }
        }
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        info.setClassName(PasswordTextView.class.getName());
        info.setPassword(true);
        if (shouldSpeakPasswordsForAccessibility()) {
            info.setText(this.mText);
        }
        info.setEditable(true);
        info.setInputType(16);
    }

    private boolean shouldSpeakPasswordsForAccessibility() {
        return Secure.getIntForUser(this.mContext.getContentResolver(), "speak_password", 0, -3) == 1;
    }
}
