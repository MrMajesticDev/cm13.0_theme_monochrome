package com.android.systemui.qs.tiles;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Handler;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import com.android.systemui.qs.GlobalSetting;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.Host;

public class AirplaneModeTile extends QSTile<BooleanState> {
    private final AnimationIcon mDisable;
    private final AnimationIcon mEnable;
    private boolean mListening;
    private final BroadcastReceiver mReceiver;
    private final GlobalSetting mSetting;

    /* renamed from: com.android.systemui.qs.tiles.AirplaneModeTile.1 */
    class C01761 extends GlobalSetting {
        C01761(Context x0, Handler x1, String x2) {
            super(x0, x1, x2);
        }

        protected void handleValueChanged(int value) {
            AirplaneModeTile.this.handleRefreshState(Integer.valueOf(value));
        }
    }

    /* renamed from: com.android.systemui.qs.tiles.AirplaneModeTile.2 */
    class C01772 extends BroadcastReceiver {
        C01772() {
        }

        public void onReceive(Context context, Intent intent) {
            if ("android.intent.action.AIRPLANE_MODE".equals(intent.getAction())) {
                AirplaneModeTile.this.refreshState();
            }
        }
    }

    public AirplaneModeTile(Host host) {
        super(host, "airplane");
        this.mEnable = new AnimationIcon(2130837701);
        this.mDisable = new AnimationIcon(2130837699);
        this.mReceiver = new C01772();
        this.mSetting = new C01761(this.mContext, this.mHandler, "airplane_mode_on");
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    protected void handleToggleClick() {
        boolean z;
        boolean z2 = false;
        Context context = this.mContext;
        int metricsCategory = getMetricsCategory();
        if (((BooleanState) this.mState).value) {
            z = false;
        } else {
            z = true;
        }
        MetricsLogger.action(context, metricsCategory, z);
        if (!((BooleanState) this.mState).value) {
            z2 = true;
        }
        setEnabled(z2);
        this.mEnable.setAllowAnimation(true);
        this.mDisable.setAllowAnimation(true);
    }

    protected void handleDetailClick() {
        handleToggleClick();
    }

    private void setEnabled(boolean enabled) {
        ((ConnectivityManager) this.mContext.getSystemService("connectivity")).setAirplaneMode(enabled);
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        boolean airplaneMode = (arg instanceof Integer ? ((Integer) arg).intValue() : this.mSetting.getValue()) != 0;
        state.value = airplaneMode;
        state.visible = true;
        state.label = this.mContext.getString(C0065R.string.airplane_mode);
        if (airplaneMode) {
            state.icon = this.mEnable;
            state.contentDescription = this.mContext.getString(2131362111);
            return;
        }
        state.icon = this.mDisable;
        state.contentDescription = this.mContext.getString(2131362110);
    }

    public int getMetricsCategory() {
        return 112;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131362113);
        }
        return this.mContext.getString(2131362112);
    }

    public void setListening(boolean listening) {
        if (this.mListening != listening) {
            this.mListening = listening;
            if (listening) {
                IntentFilter filter = new IntentFilter();
                filter.addAction("android.intent.action.AIRPLANE_MODE");
                this.mContext.registerReceiver(this.mReceiver, filter);
            } else {
                this.mContext.unregisterReceiver(this.mReceiver);
            }
            this.mSetting.setListening(listening);
        }
    }
}
