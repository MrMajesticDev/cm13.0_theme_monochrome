package com.android.systemui.statusbar.phone;

import android.app.Notification;
import android.service.notification.StatusBarNotification;
import com.android.systemui.statusbar.ExpandableNotificationRow;
import com.android.systemui.statusbar.NotificationData.Entry;
import java.util.HashMap;
import java.util.HashSet;

public class NotificationGroupManager {
    private int mBarState;
    private final HashMap<String, NotificationGroup> mGroupMap;
    private OnGroupChangeListener mListener;

    /* renamed from: com.android.systemui.statusbar.phone.NotificationGroupManager.1 */
    class C03841 implements Runnable {
        final /* synthetic */ NotificationGroup val$group;
        final /* synthetic */ StatusBarNotification val$sbn;

        C03841(NotificationGroup notificationGroup, StatusBarNotification statusBarNotification) {
            this.val$group = notificationGroup;
            this.val$sbn = statusBarNotification;
        }

        public void run() {
            if (this.val$group.children.isEmpty()) {
                NotificationGroupManager.this.setGroupExpanded(this.val$sbn, false);
            }
        }
    }

    public static class NotificationGroup {
        public final HashSet<Entry> children;
        public boolean expanded;
        public Entry summary;

        public NotificationGroup() {
            this.children = new HashSet();
        }
    }

    public interface OnGroupChangeListener {
        void onGroupCreatedFromChildren(NotificationGroup notificationGroup);

        void onGroupExpansionChanged(ExpandableNotificationRow expandableNotificationRow, boolean z);

        void onGroupsProhibitedChanged();
    }

    public NotificationGroupManager() {
        this.mGroupMap = new HashMap();
        this.mBarState = -1;
    }

    public void setOnGroupChangeListener(OnGroupChangeListener listener) {
        this.mListener = listener;
    }

    public void setGroupExpanded(StatusBarNotification sbn, boolean expanded) {
        NotificationGroup group = (NotificationGroup) this.mGroupMap.get(sbn.getGroupKey());
        if (group != null) {
            setGroupExpanded(group, expanded);
        }
    }

    private void setGroupExpanded(NotificationGroup group, boolean expanded) {
        group.expanded = expanded;
        if (group.summary != null) {
            this.mListener.onGroupExpansionChanged(group.summary.row, expanded);
        }
    }

    public void onEntryRemoved(Entry removed) {
        onEntryRemovedInternal(removed, removed.notification);
    }

    private void onEntryRemovedInternal(Entry removed, StatusBarNotification sbn) {
        Notification notif = sbn.getNotification();
        String groupKey = sbn.getGroupKey();
        NotificationGroup group = (NotificationGroup) this.mGroupMap.get(groupKey);
        if (group != null) {
            if (notif.isGroupSummary()) {
                group.summary = null;
            } else {
                group.children.remove(removed);
            }
            if (!group.children.isEmpty()) {
                return;
            }
            if (group.summary == null) {
                this.mGroupMap.remove(groupKey);
            } else if (group.expanded) {
                removed.row.post(new C03841(group, sbn));
            } else {
                group.summary.row.updateExpandButton();
            }
        }
    }

    public void onEntryAdded(Entry added) {
        StatusBarNotification sbn = added.notification;
        Notification notif = sbn.getNotification();
        String groupKey = sbn.getGroupKey();
        NotificationGroup group = (NotificationGroup) this.mGroupMap.get(groupKey);
        if (group == null) {
            group = new NotificationGroup();
            this.mGroupMap.put(groupKey, group);
        }
        if (notif.isGroupSummary()) {
            group.summary = added;
            group.expanded = added.row.areChildrenExpanded();
            if (!group.children.isEmpty()) {
                this.mListener.onGroupCreatedFromChildren(group);
                return;
            }
            return;
        }
        group.children.add(added);
        if (group.summary != null && group.children.size() == 1 && !group.expanded) {
            group.summary.row.updateExpandButton();
        }
    }

    public void onEntryUpdated(Entry entry, StatusBarNotification oldNotification) {
        if (this.mGroupMap.get(oldNotification.getGroupKey()) != null) {
            onEntryRemovedInternal(entry, oldNotification);
        }
        onEntryAdded(entry);
    }

    public boolean isVisible(StatusBarNotification sbn) {
        if (!sbn.getNotification().isGroupChild()) {
            return true;
        }
        NotificationGroup group = (NotificationGroup) this.mGroupMap.get(sbn.getGroupKey());
        if (group == null || (!group.expanded && group.summary != null)) {
            return false;
        }
        return true;
    }

    public boolean hasGroupChildren(StatusBarNotification sbn) {
        if (areGroupsProhibited() || !sbn.getNotification().isGroupSummary()) {
            return false;
        }
        NotificationGroup group = (NotificationGroup) this.mGroupMap.get(sbn.getGroupKey());
        if (group == null || group.children.isEmpty()) {
            return false;
        }
        return true;
    }

    public void setStatusBarState(int newState) {
        if (this.mBarState != newState) {
            boolean prohibitedBefore = areGroupsProhibited();
            this.mBarState = newState;
            boolean nowProhibited = areGroupsProhibited();
            if (nowProhibited != prohibitedBefore) {
                if (nowProhibited) {
                    for (NotificationGroup group : this.mGroupMap.values()) {
                        if (group.expanded) {
                            setGroupExpanded(group, false);
                        }
                    }
                }
                this.mListener.onGroupsProhibitedChanged();
            }
        }
    }

    private boolean areGroupsProhibited() {
        return this.mBarState == 1;
    }

    public boolean isChildInGroupWithSummary(StatusBarNotification sbn) {
        if (!sbn.getNotification().isGroupChild()) {
            return false;
        }
        NotificationGroup group = (NotificationGroup) this.mGroupMap.get(sbn.getGroupKey());
        if (group == null || group.summary == null) {
            return false;
        }
        return true;
    }

    public ExpandableNotificationRow getGroupSummary(StatusBarNotification sbn) {
        NotificationGroup group = (NotificationGroup) this.mGroupMap.get(sbn.getGroupKey());
        if (group == null || group.summary == null) {
            return null;
        }
        return group.summary.row;
    }
}
