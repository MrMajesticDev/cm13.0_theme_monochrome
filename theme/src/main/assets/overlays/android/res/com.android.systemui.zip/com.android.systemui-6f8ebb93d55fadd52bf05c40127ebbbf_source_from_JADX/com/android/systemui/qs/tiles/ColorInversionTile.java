package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.SecureSetting;
import com.android.systemui.qs.UsageTracker;

public class ColorInversionTile extends QSTile<BooleanState> {
    private static final Intent ACCESSIBILITY_SETTINGS;
    private final AnimationIcon mDisable;
    private final AnimationIcon mEnable;
    private boolean mListening;
    private final SecureSetting mSetting;
    private final UsageTracker mUsageTracker;

    /* renamed from: com.android.systemui.qs.tiles.ColorInversionTile.1 */
    class C01851 extends SecureSetting {
        C01851(Context x0, Handler x1, String x2) {
            super(x0, x1, x2);
        }

        protected void handleValueChanged(int value, boolean observedChange) {
            if (value != 0 || observedChange) {
                ColorInversionTile.this.mUsageTracker.trackUsage();
            }
            if (ColorInversionTile.this.mListening) {
                ColorInversionTile.this.handleRefreshState(Integer.valueOf(value));
            }
        }
    }

    /* renamed from: com.android.systemui.qs.tiles.ColorInversionTile.2 */
    class C01862 implements Runnable {
        C01862() {
        }

        public void run() {
            ColorInversionTile.this.refreshState();
        }
    }

    static {
        ACCESSIBILITY_SETTINGS = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
    }

    public ColorInversionTile(Host host) {
        super(host, "inversion");
        this.mEnable = new AnimationIcon(2130837593);
        this.mDisable = new AnimationIcon(2130837591);
        this.mSetting = new C01851(this.mContext, this.mHandler, "accessibility_display_inversion_enabled");
        this.mUsageTracker = new UsageTracker(host.getContext(), "ColorInversionTileLastUsed", ColorInversionTile.class, 2131623984);
        if (!(this.mSetting.getValue() == 0 || this.mUsageTracker.isRecentlyUsed())) {
            this.mUsageTracker.trackUsage();
        }
        this.mUsageTracker.setListening(true);
        this.mSetting.setListening(true);
    }

    protected void handleDestroy() {
        super.handleDestroy();
        this.mUsageTracker.setListening(false);
        this.mSetting.setListening(false);
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void setListening(boolean listening) {
        this.mListening = listening;
    }

    protected void handleUserSwitch(int newUserId) {
        this.mSetting.setUserId(newUserId);
        handleRefreshState(Integer.valueOf(this.mSetting.getValue()));
    }

    protected void handleToggleClick() {
        boolean z;
        int i = 0;
        Context context = this.mContext;
        int metricsCategory = getMetricsCategory();
        if (((BooleanState) this.mState).value) {
            z = false;
        } else {
            z = true;
        }
        MetricsLogger.action(context, metricsCategory, z);
        SecureSetting secureSetting = this.mSetting;
        if (!((BooleanState) this.mState).value) {
            i = 1;
        }
        secureSetting.setValue(i);
        this.mEnable.setAllowAnimation(true);
        this.mDisable.setAllowAnimation(true);
    }

    protected void handleLongClick() {
        if (!((BooleanState) this.mState).value) {
            this.mUsageTracker.showResetConfirmation(this.mContext.getString(2131362324, new Object[]{((BooleanState) this.mState).label}), new C01862());
        }
    }

    protected void handleDetailClick() {
        handleToggleClick();
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        boolean enabled;
        boolean z = false;
        if ((arg instanceof Integer ? ((Integer) arg).intValue() : this.mSetting.getValue()) != 0) {
            enabled = true;
        } else {
            enabled = false;
        }
        if (enabled || this.mUsageTracker.isRecentlyUsed()) {
            z = true;
        }
        state.visible = z;
        state.value = enabled;
        state.label = this.mContext.getString(2131362203);
        state.icon = enabled ? this.mEnable : this.mDisable;
    }

    public int getMetricsCategory() {
        return 116;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131362139);
        }
        return this.mContext.getString(2131362138);
    }
}
