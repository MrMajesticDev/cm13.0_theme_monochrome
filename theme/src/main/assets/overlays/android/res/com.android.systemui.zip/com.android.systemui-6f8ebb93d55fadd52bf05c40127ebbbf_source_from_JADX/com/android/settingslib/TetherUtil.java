package com.android.settingslib;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.SystemProperties;
import android.telephony.CarrierConfigManager;

public class TetherUtil {
    public static ComponentName TETHER_SERVICE;

    static {
        TETHER_SERVICE = ComponentName.unflattenFromString(Resources.getSystem().getString(17039388));
    }

    public static boolean setWifiTethering(boolean enable, Context context) {
        return ((WifiManager) context.getSystemService("wifi")).setWifiApEnabled(null, enable);
    }

    private static boolean isEntitlementCheckRequired(Context context) {
        return ((CarrierConfigManager) context.getSystemService("carrier_config")).getConfig().getBoolean("require_entitlement_checks_bool");
    }

    public static boolean isProvisioningNeeded(Context context) {
        String[] provisionApp = context.getResources().getStringArray(17235989);
        if (SystemProperties.getBoolean("net.tethering.noprovisioning", false) || provisionApp == null || !isEntitlementCheckRequired(context) || provisionApp.length != 2) {
            return false;
        }
        return true;
    }

    public static boolean isTetheringSupported(Context context) {
        boolean isSecondaryUser;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService("connectivity");
        if (ActivityManager.getCurrentUser() != 0) {
            isSecondaryUser = true;
        } else {
            isSecondaryUser = false;
        }
        if (isSecondaryUser || !cm.isTetheringSupported()) {
            return false;
        }
        return true;
    }
}
