package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction;
import com.android.keyguard.C0065R;
import com.android.keyguard.KeyguardUpdateMonitor;
import com.android.systemui.statusbar.KeyguardAffordanceView;
import com.android.systemui.statusbar.policy.AccessibilityController;

public class LockIcon extends KeyguardAffordanceView {
    private AccessibilityController mAccessibilityController;
    private boolean mDeviceInteractive;
    private boolean mHasFingerPrintIcon;
    private boolean mLastDeviceInteractive;
    private boolean mLastScreenOn;
    private int mLastState;
    private boolean mScreenOn;
    private boolean mTransientFpError;
    private final TrustDrawable mTrustDrawable;
    private final UnlockMethodCache mUnlockMethodCache;

    private static class IntrinsicSizeDrawable extends InsetDrawable {
        private final int mIntrinsicHeight;
        private final int mIntrinsicWidth;

        public IntrinsicSizeDrawable(Drawable drawable, int intrinsicWidth, int intrinsicHeight) {
            super(drawable, 0);
            this.mIntrinsicWidth = intrinsicWidth;
            this.mIntrinsicHeight = intrinsicHeight;
        }

        public int getIntrinsicWidth() {
            return this.mIntrinsicWidth;
        }

        public int getIntrinsicHeight() {
            return this.mIntrinsicHeight;
        }
    }

    public LockIcon(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mLastState = 0;
        this.mTrustDrawable = new TrustDrawable(context);
        setBackground(this.mTrustDrawable);
        this.mUnlockMethodCache = UnlockMethodCache.getInstance(context);
    }

    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (isShown()) {
            this.mTrustDrawable.start();
        } else {
            this.mTrustDrawable.stop();
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mTrustDrawable.stop();
    }

    public void setTransientFpError(boolean transientFpError) {
        this.mTransientFpError = transientFpError;
        update();
    }

    public void setDeviceInteractive(boolean deviceInteractive) {
        this.mDeviceInteractive = deviceInteractive;
        update();
    }

    public void setScreenOn(boolean screenOn) {
        this.mScreenOn = screenOn;
        update();
    }

    public void update() {
        boolean visible = isShown() && KeyguardUpdateMonitor.getInstance(this.mContext).isDeviceInteractive();
        if (visible) {
            this.mTrustDrawable.start();
        } else {
            this.mTrustDrawable.stop();
        }
        int state = getState();
        boolean anyFingerprintIcon = state == 3 || state == 4;
        boolean useAdditionalPadding = anyFingerprintIcon;
        boolean trustHidden = anyFingerprintIcon;
        if (!(state == this.mLastState && this.mDeviceInteractive == this.mLastDeviceInteractive && this.mScreenOn == this.mLastScreenOn)) {
            boolean isAnim = true;
            int iconRes = getAnimationResForTransition(this.mLastState, state, this.mLastDeviceInteractive, this.mDeviceInteractive, this.mLastScreenOn, this.mScreenOn);
            if (iconRes == 2130837750) {
                anyFingerprintIcon = true;
                useAdditionalPadding = true;
                trustHidden = true;
            } else if (iconRes == 2130838160) {
                anyFingerprintIcon = true;
                useAdditionalPadding = false;
                trustHidden = true;
            } else if (iconRes == 2130837536) {
                anyFingerprintIcon = true;
                useAdditionalPadding = false;
                trustHidden = false;
            }
            if (iconRes == -1) {
                iconRes = getIconForState(state, this.mScreenOn, this.mDeviceInteractive);
                isAnim = false;
            }
            Drawable icon = this.mContext.getDrawable(iconRes);
            AnimatedVectorDrawable animation = icon instanceof AnimatedVectorDrawable ? (AnimatedVectorDrawable) icon : null;
            int iconHeight = getResources().getDimensionPixelSize(2131296433);
            int iconWidth = getResources().getDimensionPixelSize(2131296434);
            if (!(anyFingerprintIcon || (icon.getIntrinsicHeight() == iconHeight && icon.getIntrinsicWidth() == iconWidth))) {
                icon = new IntrinsicSizeDrawable(icon, iconWidth, iconHeight);
            }
            setPaddingRelative(0, 0, 0, useAdditionalPadding ? getResources().getDimensionPixelSize(2131296461) : 0);
            setRestingAlpha(anyFingerprintIcon ? 1.0f : 0.5f);
            setImageDrawable(icon);
            setContentDescription(getResources().getString(anyFingerprintIcon ? 2131362013 : 2131362012));
            this.mHasFingerPrintIcon = anyFingerprintIcon;
            if (animation != null && isAnim) {
                animation.start();
            }
            this.mLastState = state;
            this.mLastDeviceInteractive = this.mDeviceInteractive;
            this.mLastScreenOn = this.mScreenOn;
        }
        boolean trustManaged = this.mUnlockMethodCache.isTrustManaged() && !trustHidden;
        this.mTrustDrawable.setTrustManaged(trustManaged);
        updateClickability();
    }

    private void updateClickability() {
        boolean z = false;
        if (this.mAccessibilityController != null) {
            boolean clickToForceLock;
            boolean longClickToForceLock;
            boolean clickToUnlock = this.mAccessibilityController.isTouchExplorationEnabled();
            if (!this.mUnlockMethodCache.isTrustManaged() || this.mAccessibilityController.isAccessibilityEnabled()) {
                clickToForceLock = false;
            } else {
                clickToForceLock = true;
            }
            if (!this.mUnlockMethodCache.isTrustManaged() || clickToForceLock) {
                longClickToForceLock = false;
            } else {
                longClickToForceLock = true;
            }
            if (clickToForceLock || clickToUnlock) {
                z = true;
            }
            setClickable(z);
            setLongClickable(longClickToForceLock);
            setFocusable(this.mAccessibilityController.isAccessibilityEnabled());
        }
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        if (this.mHasFingerPrintIcon) {
            info.setClassName(LockIcon.class.getName());
            info.addAction(new AccessibilityAction(16, getContext().getString(2131362014)));
        }
    }

    public void setAccessibilityController(AccessibilityController accessibilityController) {
        this.mAccessibilityController = accessibilityController;
    }

    private int getIconForState(int state, boolean screenOn, boolean deviceInteractive) {
        switch (state) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                return 2130837598;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return 2130837599;
            case 2:
                return 17302258;
            case 3:
                return (screenOn && deviceInteractive) ? 2130837573 : 2130837752;
            case 4:
                return 2130837574;
            default:
                throw new IllegalArgumentException();
        }
    }

    private int getAnimationResForTransition(int oldState, int newState, boolean oldDeviceInteractive, boolean deviceInteractive, boolean oldScreenOn, boolean screenOn) {
        if (oldState == 3 && newState == 4) {
            return 2130837756;
        }
        if (oldState == 1 && newState == 4) {
            return 2130838160;
        }
        if (oldState == 4 && newState == 1) {
            return 2130837536;
        }
        if (oldState == 4 && newState == 3) {
            return 2130837754;
        }
        if (oldState == 3 && newState == 1 && !this.mUnlockMethodCache.isTrusted()) {
            return 2130837750;
        }
        if (newState == 3 && ((!oldScreenOn && screenOn && deviceInteractive) || (screenOn && !oldDeviceInteractive && deviceInteractive))) {
            return 2130837752;
        }
        return -1;
    }

    private int getState() {
        KeyguardUpdateMonitor updateMonitor = KeyguardUpdateMonitor.getInstance(this.mContext);
        boolean fingerprintRunning = updateMonitor.isFingerprintDetectionRunning();
        boolean unlockingAllowed = updateMonitor.isUnlockingWithFingerprintAllowed();
        if (this.mTransientFpError) {
            return 4;
        }
        if (this.mUnlockMethodCache.canSkipBouncer()) {
            return 1;
        }
        if (this.mUnlockMethodCache.isFaceUnlockRunning()) {
            return 2;
        }
        if (fingerprintRunning && unlockingAllowed) {
            return 3;
        }
        return 0;
    }
}
