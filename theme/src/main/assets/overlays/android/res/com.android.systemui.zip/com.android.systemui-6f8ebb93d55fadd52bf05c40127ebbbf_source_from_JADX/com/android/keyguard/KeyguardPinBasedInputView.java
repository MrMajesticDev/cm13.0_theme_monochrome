package com.android.keyguard;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.View.OnLongClickListener;
import com.android.keyguard.PasswordTextView.UserActivityListener;

public abstract class KeyguardPinBasedInputView extends KeyguardAbsKeyInputView implements OnKeyListener {
    private View mButton0;
    private View mButton1;
    private View mButton2;
    private View mButton3;
    private View mButton4;
    private View mButton5;
    private View mButton6;
    private View mButton7;
    private View mButton8;
    private View mButton9;
    private View mDeleteButton;
    private View mOkButton;
    protected PasswordTextView mPasswordEntry;

    /* renamed from: com.android.keyguard.KeyguardPinBasedInputView.1 */
    class C00241 implements UserActivityListener {
        C00241() {
        }

        public void onUserActivity() {
            KeyguardPinBasedInputView.this.onUserInput();
        }
    }

    /* renamed from: com.android.keyguard.KeyguardPinBasedInputView.2 */
    class C00252 implements OnClickListener {
        C00252() {
        }

        public void onClick(View v) {
            KeyguardPinBasedInputView.this.doHapticKeyClick();
            if (KeyguardPinBasedInputView.this.mPasswordEntry.isEnabled()) {
                KeyguardPinBasedInputView.this.verifyPasswordAndUnlock();
            }
        }
    }

    /* renamed from: com.android.keyguard.KeyguardPinBasedInputView.3 */
    class C00263 implements OnClickListener {
        C00263() {
        }

        public void onClick(View v) {
            if (KeyguardPinBasedInputView.this.mPasswordEntry.isEnabled()) {
                KeyguardPinBasedInputView.this.mPasswordEntry.deleteLastChar();
            }
            KeyguardPinBasedInputView.this.doHapticKeyClick();
        }
    }

    /* renamed from: com.android.keyguard.KeyguardPinBasedInputView.4 */
    class C00274 implements OnLongClickListener {
        C00274() {
        }

        public boolean onLongClick(View v) {
            if (KeyguardPinBasedInputView.this.mPasswordEntry.isEnabled()) {
                KeyguardPinBasedInputView.this.resetPasswordText(true);
            }
            KeyguardPinBasedInputView.this.doHapticKeyClick();
            return true;
        }
    }

    public KeyguardPinBasedInputView(Context context) {
        this(context, null);
    }

    public KeyguardPinBasedInputView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void reset() {
        this.mPasswordEntry.requestFocus();
        super.reset();
    }

    protected boolean onRequestFocusInDescendants(int direction, Rect previouslyFocusedRect) {
        return this.mPasswordEntry.requestFocus(direction, previouslyFocusedRect);
    }

    protected void resetState() {
        setPasswordEntryEnabled(true);
    }

    protected void setPasswordEntryEnabled(boolean enabled) {
        this.mPasswordEntry.setEnabled(enabled);
        this.mOkButton.setEnabled(enabled);
    }

    protected void setPasswordEntryInputEnabled(boolean enabled) {
        this.mPasswordEntry.setEnabled(enabled);
        this.mOkButton.setEnabled(enabled);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (KeyEvent.isConfirmKey(keyCode)) {
            performClick(this.mOkButton);
            return true;
        } else if (keyCode == 67) {
            performClick(this.mDeleteButton);
            return true;
        } else if (keyCode < 7 || keyCode > 16) {
            return super.onKeyDown(keyCode, event);
        } else {
            performNumberClick(keyCode - 7);
            return true;
        }
    }

    protected int getPromtReasonStringRes(int reason) {
        switch (reason) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return C0065R.string.kg_prompt_reason_restart_pin;
            case 2:
                return C0065R.string.kg_prompt_reason_timeout_pin;
            default:
                return 0;
        }
    }

    private void performClick(View view) {
        view.performClick();
    }

    private void performNumberClick(int number) {
        switch (number) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                performClick(this.mButton0);
            case C0065R.styleable.NumPadKey_textView /*1*/:
                performClick(this.mButton1);
            case 2:
                performClick(this.mButton2);
            case 3:
                performClick(this.mButton3);
            case 4:
                performClick(this.mButton4);
            case 5:
                performClick(this.mButton5);
            case 6:
                performClick(this.mButton6);
            case 7:
                performClick(this.mButton7);
            case 8:
                performClick(this.mButton8);
            case 9:
                performClick(this.mButton9);
            default:
        }
    }

    protected void resetPasswordText(boolean animate) {
        this.mPasswordEntry.reset(animate);
    }

    protected String getPasswordText() {
        return this.mPasswordEntry.getText();
    }

    protected void onFinishInflate() {
        this.mPasswordEntry = (PasswordTextView) findViewById(getPasswordTextViewId());
        this.mPasswordEntry.setOnKeyListener(this);
        this.mPasswordEntry.setSelected(true);
        this.mPasswordEntry.setUserActivityListener(new C00241());
        this.mOkButton = findViewById(C0065R.id.key_enter);
        if (this.mOkButton != null) {
            this.mOkButton.setOnClickListener(new C00252());
            this.mOkButton.setOnHoverListener(new LiftToActivateListener(getContext()));
        }
        this.mDeleteButton = findViewById(C0065R.id.delete_button);
        this.mDeleteButton.setVisibility(0);
        this.mDeleteButton.setOnClickListener(new C00263());
        this.mDeleteButton.setOnLongClickListener(new C00274());
        this.mButton0 = findViewById(C0065R.id.key0);
        this.mButton1 = findViewById(C0065R.id.key1);
        this.mButton2 = findViewById(C0065R.id.key2);
        this.mButton3 = findViewById(C0065R.id.key3);
        this.mButton4 = findViewById(C0065R.id.key4);
        this.mButton5 = findViewById(C0065R.id.key5);
        this.mButton6 = findViewById(C0065R.id.key6);
        this.mButton7 = findViewById(C0065R.id.key7);
        this.mButton8 = findViewById(C0065R.id.key8);
        this.mButton9 = findViewById(C0065R.id.key9);
        this.mPasswordEntry.requestFocus();
        super.onFinishInflate();
    }

    public boolean onKey(View v, int keyCode, KeyEvent event) {
        if (event.getAction() != 0) {
            return false;
        }
        onKeyDown(keyCode, event);
        return true;
    }
}
