package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.os.SystemProperties;
import android.text.TextUtils;
import android.util.Log;
import android.util.MathUtils;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DozeParameters {
    private static final boolean DEBUG;
    private static PulseSchedule sPulseSchedule;
    private final Context mContext;

    public static class PulseSchedule {
        private static final Pattern PATTERN;
        private int[] mSchedule;
        private String mSpec;

        static {
            PATTERN = Pattern.compile("(\\d+?)s", 0);
        }

        public static PulseSchedule parse(String spec) {
            if (TextUtils.isEmpty(spec)) {
                return null;
            }
            try {
                PulseSchedule rt = new PulseSchedule();
                rt.mSpec = spec;
                String[] tokens = spec.split(",");
                rt.mSchedule = new int[tokens.length];
                int i = 0;
                while (i < tokens.length) {
                    Matcher m = PATTERN.matcher(tokens[i]);
                    if (m.matches()) {
                        rt.mSchedule[i] = Integer.parseInt(m.group(1));
                        i++;
                    } else {
                        throw new IllegalArgumentException("Bad token: " + tokens[i]);
                    }
                }
                if (!DozeParameters.DEBUG) {
                    return rt;
                }
                Log.d("DozeParameters", "Parsed spec [" + spec + "] as: " + rt);
                return rt;
            } catch (RuntimeException e) {
                Log.w("DozeParameters", "Error parsing spec: " + spec, e);
                return null;
            }
        }

        public String toString() {
            return Arrays.toString(this.mSchedule);
        }

        public long getNextTime(long now, long notificationTime) {
            for (int i : this.mSchedule) {
                long time = notificationTime + ((long) (i * 1000));
                if (time > now) {
                    return time;
                }
            }
            return 0;
        }
    }

    static {
        DEBUG = Log.isLoggable("DozeParameters", 3);
    }

    public DozeParameters(Context context) {
        this.mContext = context;
    }

    public void dump(PrintWriter pw) {
        pw.println("  DozeParameters:");
        pw.print("    getDisplayStateSupported(): ");
        pw.println(getDisplayStateSupported());
        pw.print("    getPulseDuration(pickup=false): ");
        pw.println(getPulseDuration(false));
        pw.print("    getPulseDuration(pickup=true): ");
        pw.println(getPulseDuration(true));
        pw.print("    getPulseInDuration(pickup=false): ");
        pw.println(getPulseInDuration(false));
        pw.print("    getPulseInDuration(pickup=true): ");
        pw.println(getPulseInDuration(true));
        pw.print("    getPulseInVisibleDuration(): ");
        pw.println(getPulseVisibleDuration());
        pw.print("    getPulseOutDuration(): ");
        pw.println(getPulseOutDuration());
        pw.print("    getPulseOnSigMotion(): ");
        pw.println(getPulseOnSigMotion());
        pw.print("    getVibrateOnSigMotion(): ");
        pw.println(getVibrateOnSigMotion());
        pw.print("    getPulseOnPickup(): ");
        pw.println(getPulseOnPickup());
        pw.print("    getVibrateOnPickup(): ");
        pw.println(getVibrateOnPickup());
        pw.print("    getProxCheckBeforePulse(): ");
        pw.println(getProxCheckBeforePulse());
        pw.print("    getPulseOnNotifications(): ");
        pw.println(getPulseOnNotifications());
        pw.print("    getPulseSchedule(): ");
        pw.println(getPulseSchedule());
        pw.print("    getPulseScheduleResets(): ");
        pw.println(getPulseScheduleResets());
        pw.print("    getPickupVibrationThreshold(): ");
        pw.println(getPickupVibrationThreshold());
        pw.print("    getPickupPerformsProxCheck(): ");
        pw.println(getPickupPerformsProxCheck());
    }

    public boolean getDisplayStateSupported() {
        return getBoolean("doze.display.supported", 2131558424);
    }

    public int getPulseDuration(boolean pickup) {
        return (getPulseInDuration(pickup) + getPulseVisibleDuration()) + getPulseOutDuration();
    }

    public int getPulseInDuration(boolean pickup) {
        return pickup ? getInt("doze.pulse.duration.in.pickup", 2131623979) : getInt("doze.pulse.duration.in", 2131623978);
    }

    public int getPulseVisibleDuration() {
        return getInt("doze.pulse.duration.visible", 2131623980);
    }

    public int getPulseOutDuration() {
        return getInt("doze.pulse.duration.out", 2131623981);
    }

    public boolean getPulseOnSigMotion() {
        return getBoolean("doze.pulse.sigmotion", 2131558425);
    }

    public boolean getVibrateOnSigMotion() {
        return SystemProperties.getBoolean("doze.vibrate.sigmotion", false);
    }

    public boolean getPulseOnPickup() {
        return getBoolean("doze.pulse.pickup", 2131558426);
    }

    public boolean getVibrateOnPickup() {
        return SystemProperties.getBoolean("doze.vibrate.pickup", false);
    }

    public boolean getProxCheckBeforePulse() {
        return getBoolean("doze.pulse.proxcheck", 2131558427);
    }

    public boolean getPickupPerformsProxCheck() {
        return getBoolean("doze.pickup.proxcheck", 2131558429);
    }

    public boolean getPulseOnNotifications() {
        return getBoolean("doze.pulse.notifications", 2131558428);
    }

    public PulseSchedule getPulseSchedule() {
        String spec = getString("doze.pulse.schedule", 2131361881);
        if (sPulseSchedule == null || !sPulseSchedule.mSpec.equals(spec)) {
            sPulseSchedule = PulseSchedule.parse(spec);
        }
        return sPulseSchedule;
    }

    public int getPulseScheduleResets() {
        return getInt("doze.pulse.schedule.resets", 2131623976);
    }

    public int getPickupVibrationThreshold() {
        return getInt("doze.pickup.vibration.threshold", 2131623977);
    }

    private boolean getBoolean(String propName, int resId) {
        return SystemProperties.getBoolean(propName, this.mContext.getResources().getBoolean(resId));
    }

    private int getInt(String propName, int resId) {
        return MathUtils.constrain(SystemProperties.getInt(propName, this.mContext.getResources().getInteger(resId)), 0, 60000);
    }

    private String getString(String propName, int resId) {
        return SystemProperties.get(propName, this.mContext.getString(resId));
    }
}
