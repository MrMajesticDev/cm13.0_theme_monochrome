package com.android.systemui.statusbar;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import com.android.systemui.ViewInvertHelper;

public class NotificationOverflowContainer extends ActivatableNotificationView {
    private View mContent;
    private boolean mDark;
    private NotificationOverflowIconsView mIconsView;
    private ViewInvertHelper mViewInvertHelper;

    public NotificationOverflowContainer(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mIconsView = (NotificationOverflowIconsView) findViewById(2131755309);
        this.mIconsView.setMoreText((TextView) findViewById(2131755307));
        this.mIconsView.setOverflowIndicator(findViewById(2131755308));
        this.mContent = findViewById(2131755306);
        this.mViewInvertHelper = new ViewInvertHelper(this.mContent, 700);
    }

    public void setDark(boolean dark, boolean fade, long delay) {
        super.setDark(dark, fade, delay);
        if (this.mDark != dark) {
            this.mDark = dark;
            if (fade) {
                this.mViewInvertHelper.fade(dark, delay);
            } else {
                this.mViewInvertHelper.update(dark);
            }
        }
    }

    protected View getContentView() {
        return this.mContent;
    }

    public NotificationOverflowIconsView getIconsView() {
        return this.mIconsView;
    }
}
