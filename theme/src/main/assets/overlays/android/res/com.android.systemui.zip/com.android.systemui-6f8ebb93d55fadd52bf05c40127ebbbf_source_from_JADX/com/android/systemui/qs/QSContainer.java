package com.android.systemui.qs;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class QSContainer extends FrameLayout {
    private int mHeightOverride;
    private QSPanel mQSPanel;

    public QSContainer(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mHeightOverride = -1;
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mQSPanel = (QSPanel) findViewById(2131755204);
    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        updateBottom();
    }

    public void setHeightOverride(int heightOverride) {
        this.mHeightOverride = heightOverride;
        updateBottom();
    }

    public int getDesiredHeight() {
        if (this.mQSPanel.isClosingDetail()) {
            return (this.mQSPanel.getGridHeight() + getPaddingTop()) + getPaddingBottom();
        }
        return getMeasuredHeight();
    }

    private void updateBottom() {
        setBottom(getTop() + (this.mHeightOverride != -1 ? this.mHeightOverride : getMeasuredHeight()));
    }
}
