package com.android.systemui.qs;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.graphics.drawable.TransitionDrawable;
import android.view.View;
import android.view.ViewAnimationUtils;

public class QSDetailClipper {
    private Animator mAnimator;
    private final TransitionDrawable mBackground;
    private final View mDetail;
    private final AnimatorListenerAdapter mGoneOnEnd;
    private final Runnable mReverseBackground;
    private final AnimatorListenerAdapter mVisibleOnStart;

    /* renamed from: com.android.systemui.qs.QSDetailClipper.1 */
    class C01471 implements Runnable {
        C01471() {
        }

        public void run() {
            if (QSDetailClipper.this.mAnimator != null) {
                QSDetailClipper.this.mBackground.reverseTransition((int) (((double) QSDetailClipper.this.mAnimator.getDuration()) * 0.35d));
            }
        }
    }

    /* renamed from: com.android.systemui.qs.QSDetailClipper.2 */
    class C01482 extends AnimatorListenerAdapter {
        C01482() {
        }

        public void onAnimationStart(Animator animation) {
            QSDetailClipper.this.mDetail.setVisibility(0);
        }

        public void onAnimationEnd(Animator animation) {
            QSDetailClipper.this.mAnimator = null;
        }
    }

    /* renamed from: com.android.systemui.qs.QSDetailClipper.3 */
    class C01493 extends AnimatorListenerAdapter {
        C01493() {
        }

        public void onAnimationEnd(Animator animation) {
            QSDetailClipper.this.mDetail.setVisibility(8);
            QSDetailClipper.this.mBackground.resetTransition();
            QSDetailClipper.this.mAnimator = null;
        }
    }

    public QSDetailClipper(View detail) {
        this.mReverseBackground = new C01471();
        this.mVisibleOnStart = new C01482();
        this.mGoneOnEnd = new C01493();
        this.mDetail = detail;
        this.mBackground = (TransitionDrawable) detail.getBackground();
    }

    public void animateCircularClip(int x, int y, boolean in, AnimatorListener listener) {
        if (this.mAnimator != null) {
            this.mAnimator.cancel();
        }
        int w = this.mDetail.getWidth() - x;
        int h = this.mDetail.getHeight() - y;
        int innerR = 0;
        if (x < 0 || w < 0 || y < 0 || h < 0) {
            innerR = Math.min(Math.min(Math.min(Math.abs(x), Math.abs(y)), Math.abs(w)), Math.abs(h));
        }
        int r = (int) Math.max((double) ((int) Math.max((double) ((int) Math.max((double) ((int) Math.ceil(Math.sqrt((double) ((x * x) + (y * y))))), Math.ceil(Math.sqrt((double) ((w * w) + (y * y)))))), Math.ceil(Math.sqrt((double) ((w * w) + (h * h)))))), Math.ceil(Math.sqrt((double) ((x * x) + (h * h)))));
        if (in) {
            this.mAnimator = ViewAnimationUtils.createCircularReveal(this.mDetail, x, y, (float) innerR, (float) r);
        } else {
            this.mAnimator = ViewAnimationUtils.createCircularReveal(this.mDetail, x, y, (float) r, (float) innerR);
        }
        this.mAnimator.setDuration((long) (((double) this.mAnimator.getDuration()) * 1.5d));
        if (listener != null) {
            this.mAnimator.addListener(listener);
        }
        if (in) {
            this.mBackground.startTransition((int) (((double) this.mAnimator.getDuration()) * 0.6d));
            this.mAnimator.addListener(this.mVisibleOnStart);
        } else {
            this.mDetail.postDelayed(this.mReverseBackground, (long) (((double) this.mAnimator.getDuration()) * 0.65d));
            this.mAnimator.addListener(this.mGoneOnEnd);
        }
        this.mAnimator.start();
    }
}
