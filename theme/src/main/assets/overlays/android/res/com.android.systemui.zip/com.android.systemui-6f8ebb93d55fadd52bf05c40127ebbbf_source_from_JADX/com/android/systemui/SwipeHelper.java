package com.android.systemui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.graphics.RectF;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import com.android.keyguard.C0065R;

public class SwipeHelper {
    public static float SWIPE_PROGRESS_FADE_START;
    private static LinearInterpolator sLinearInterpolator;
    private int DEFAULT_ESCAPE_ANIMATION_DURATION;
    private int MAX_DISMISS_VELOCITY;
    private int MAX_ESCAPE_ANIMATION_DURATION;
    private float SWIPE_ESCAPE_VELOCITY;
    private Callback mCallback;
    private boolean mCanCurrViewBeDimissed;
    private View mCurrAnimView;
    private View mCurrView;
    private float mDensityScale;
    private boolean mDragging;
    private int mFalsingThreshold;
    private final Interpolator mFastOutLinearInInterpolator;
    private Handler mHandler;
    private float mInitialTouchPos;
    private LongPressListener mLongPressListener;
    private boolean mLongPressSent;
    private long mLongPressTimeout;
    private float mMaxSwipeProgress;
    private float mMinSwipeProgress;
    private float mPagingTouchSlop;
    private int mSwipeDirection;
    private final int[] mTmpPos;
    private boolean mTouchAboveFalsingThreshold;
    private VelocityTracker mVelocityTracker;
    private Runnable mWatchLongPress;

    /* renamed from: com.android.systemui.SwipeHelper.1 */
    class C00961 implements Runnable {
        final /* synthetic */ MotionEvent val$ev;

        C00961(MotionEvent motionEvent) {
            this.val$ev = motionEvent;
        }

        public void run() {
            if (SwipeHelper.this.mCurrView != null && !SwipeHelper.this.mLongPressSent) {
                SwipeHelper.this.mLongPressSent = true;
                SwipeHelper.this.mCurrView.sendAccessibilityEvent(2);
                SwipeHelper.this.mCurrView.getLocationOnScreen(SwipeHelper.this.mTmpPos);
                SwipeHelper.this.mLongPressListener.onLongPress(SwipeHelper.this.mCurrView, ((int) this.val$ev.getRawX()) - SwipeHelper.this.mTmpPos[0], ((int) this.val$ev.getRawY()) - SwipeHelper.this.mTmpPos[1]);
            }
        }
    }

    /* renamed from: com.android.systemui.SwipeHelper.2 */
    class C00972 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$animView;
        final /* synthetic */ Runnable val$endAction;
        final /* synthetic */ View val$view;

        C00972(View view, Runnable runnable, View view2) {
            this.val$view = view;
            this.val$endAction = runnable;
            this.val$animView = view2;
        }

        public void onAnimationEnd(Animator animation) {
            SwipeHelper.this.mCallback.onChildDismissed(this.val$view);
            if (this.val$endAction != null) {
                this.val$endAction.run();
            }
            this.val$animView.setLayerType(0, null);
        }
    }

    /* renamed from: com.android.systemui.SwipeHelper.3 */
    class C00983 implements AnimatorUpdateListener {
        final /* synthetic */ View val$animView;
        final /* synthetic */ boolean val$canAnimViewBeDismissed;

        C00983(View view, boolean z) {
            this.val$animView = view;
            this.val$canAnimViewBeDismissed = z;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            SwipeHelper.this.updateSwipeProgressFromOffset(this.val$animView, this.val$canAnimViewBeDismissed);
        }
    }

    /* renamed from: com.android.systemui.SwipeHelper.4 */
    class C00994 implements AnimatorUpdateListener {
        final /* synthetic */ View val$animView;
        final /* synthetic */ boolean val$canAnimViewBeDismissed;

        C00994(View view, boolean z) {
            this.val$animView = view;
            this.val$canAnimViewBeDismissed = z;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            SwipeHelper.this.updateSwipeProgressFromOffset(this.val$animView, this.val$canAnimViewBeDismissed);
        }
    }

    /* renamed from: com.android.systemui.SwipeHelper.5 */
    class C01005 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$animView;
        final /* synthetic */ boolean val$canAnimViewBeDismissed;

        C01005(View view, boolean z) {
            this.val$animView = view;
            this.val$canAnimViewBeDismissed = z;
        }

        public void onAnimationEnd(Animator animator) {
            SwipeHelper.this.updateSwipeProgressFromOffset(this.val$animView, this.val$canAnimViewBeDismissed);
            SwipeHelper.this.mCallback.onChildSnappedBack(this.val$animView);
        }
    }

    public interface Callback {
        boolean canChildBeDismissed(View view);

        View getChildAtPosition(MotionEvent motionEvent);

        View getChildContentView(View view);

        float getFalsingThresholdFactor();

        boolean isAntiFalsingNeeded();

        void onBeginDrag(View view);

        void onChildDismissed(View view);

        void onChildSnappedBack(View view);

        void onDragCancelled(View view);

        boolean updateSwipeProgress(View view, boolean z, float f);
    }

    public interface LongPressListener {
        boolean onLongPress(View view, int i, int i2);
    }

    static {
        sLinearInterpolator = new LinearInterpolator();
        SWIPE_PROGRESS_FADE_START = 0.0f;
    }

    public SwipeHelper(int swipeDirection, Callback callback, Context context) {
        this.SWIPE_ESCAPE_VELOCITY = 100.0f;
        this.DEFAULT_ESCAPE_ANIMATION_DURATION = 200;
        this.MAX_ESCAPE_ANIMATION_DURATION = 400;
        this.MAX_DISMISS_VELOCITY = 2000;
        this.mMinSwipeProgress = 0.0f;
        this.mMaxSwipeProgress = 1.0f;
        this.mTmpPos = new int[2];
        this.mCallback = callback;
        this.mHandler = new Handler();
        this.mSwipeDirection = swipeDirection;
        this.mVelocityTracker = VelocityTracker.obtain();
        this.mDensityScale = context.getResources().getDisplayMetrics().density;
        this.mPagingTouchSlop = (float) ViewConfiguration.get(context).getScaledPagingTouchSlop();
        this.mLongPressTimeout = (long) (((float) ViewConfiguration.getLongPressTimeout()) * 1.5f);
        this.mFastOutLinearInInterpolator = AnimationUtils.loadInterpolator(context, 17563663);
        this.mFalsingThreshold = context.getResources().getDimensionPixelSize(2131296377);
    }

    public void setLongPressListener(LongPressListener listener) {
        this.mLongPressListener = listener;
    }

    public void setDensityScale(float densityScale) {
        this.mDensityScale = densityScale;
    }

    public void setPagingTouchSlop(float pagingTouchSlop) {
        this.mPagingTouchSlop = pagingTouchSlop;
    }

    private float getPos(MotionEvent ev) {
        return this.mSwipeDirection == 0 ? ev.getX() : ev.getY();
    }

    private float getTranslation(View v) {
        return this.mSwipeDirection == 0 ? v.getTranslationX() : v.getTranslationY();
    }

    private float getVelocity(VelocityTracker vt) {
        return this.mSwipeDirection == 0 ? vt.getXVelocity() : vt.getYVelocity();
    }

    private ObjectAnimator createTranslationAnimation(View v, float newPos) {
        return ObjectAnimator.ofFloat(v, this.mSwipeDirection == 0 ? "translationX" : "translationY", new float[]{newPos});
    }

    private float getPerpendicularVelocity(VelocityTracker vt) {
        return this.mSwipeDirection == 0 ? vt.getYVelocity() : vt.getXVelocity();
    }

    private void setTranslation(View v, float translate) {
        if (this.mSwipeDirection == 0) {
            v.setTranslationX(translate);
        } else {
            v.setTranslationY(translate);
        }
    }

    private float getSize(View v) {
        return this.mSwipeDirection == 0 ? (float) v.getMeasuredWidth() : (float) v.getMeasuredHeight();
    }

    private float getSwipeProgressForOffset(View view) {
        float viewSize = getSize(view);
        float fadeSize = 0.5f * viewSize;
        float result = 1.0f;
        float pos = getTranslation(view);
        if (pos >= SWIPE_PROGRESS_FADE_START * viewSize) {
            result = 1.0f - ((pos - (SWIPE_PROGRESS_FADE_START * viewSize)) / fadeSize);
        } else if (pos < (1.0f - SWIPE_PROGRESS_FADE_START) * viewSize) {
            result = 1.0f + (((SWIPE_PROGRESS_FADE_START * viewSize) + pos) / fadeSize);
        }
        return Math.min(Math.max(this.mMinSwipeProgress, result), this.mMaxSwipeProgress);
    }

    private void updateSwipeProgressFromOffset(View animView, boolean dismissable) {
        float swipeProgress = getSwipeProgressForOffset(animView);
        if (!this.mCallback.updateSwipeProgress(animView, dismissable, swipeProgress) && dismissable) {
            float alpha = swipeProgress;
            if (alpha == 0.0f || alpha == 1.0f) {
                animView.setLayerType(0, null);
            } else {
                animView.setLayerType(2, null);
            }
            animView.setAlpha(getSwipeProgressForOffset(animView));
        }
        invalidateGlobalRegion(animView);
    }

    public static void invalidateGlobalRegion(View view) {
        invalidateGlobalRegion(view, new RectF((float) view.getLeft(), (float) view.getTop(), (float) view.getRight(), (float) view.getBottom()));
    }

    public static void invalidateGlobalRegion(View view, RectF childBounds) {
        while (view.getParent() != null && (view.getParent() instanceof View)) {
            view = (View) view.getParent();
            view.getMatrix().mapRect(childBounds);
            view.invalidate((int) Math.floor((double) childBounds.left), (int) Math.floor((double) childBounds.top), (int) Math.ceil((double) childBounds.right), (int) Math.ceil((double) childBounds.bottom));
        }
    }

    public void removeLongPressCallback() {
        if (this.mWatchLongPress != null) {
            this.mHandler.removeCallbacks(this.mWatchLongPress);
            this.mWatchLongPress = null;
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        boolean z = false;
        switch (ev.getAction()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                this.mTouchAboveFalsingThreshold = false;
                this.mDragging = false;
                this.mLongPressSent = false;
                this.mCurrView = this.mCallback.getChildAtPosition(ev);
                this.mVelocityTracker.clear();
                if (this.mCurrView != null) {
                    this.mCurrAnimView = this.mCallback.getChildContentView(this.mCurrView);
                    this.mCanCurrViewBeDimissed = this.mCallback.canChildBeDismissed(this.mCurrView);
                    this.mVelocityTracker.addMovement(ev);
                    this.mInitialTouchPos = getPos(ev);
                    if (this.mLongPressListener != null) {
                        if (this.mWatchLongPress == null) {
                            this.mWatchLongPress = new C00961(ev);
                        }
                        this.mHandler.postDelayed(this.mWatchLongPress, this.mLongPressTimeout);
                        break;
                    }
                }
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 3:
                boolean captured;
                if (this.mDragging || this.mLongPressSent) {
                    captured = true;
                } else {
                    captured = false;
                }
                this.mDragging = false;
                this.mCurrView = null;
                this.mCurrAnimView = null;
                this.mLongPressSent = false;
                removeLongPressCallback();
                if (captured) {
                    return true;
                }
                break;
            case 2:
                if (!(this.mCurrView == null || this.mLongPressSent)) {
                    this.mVelocityTracker.addMovement(ev);
                    if (Math.abs(getPos(ev) - this.mInitialTouchPos) > this.mPagingTouchSlop) {
                        this.mCallback.onBeginDrag(this.mCurrView);
                        this.mDragging = true;
                        this.mInitialTouchPos = getPos(ev) - getTranslation(this.mCurrAnimView);
                        removeLongPressCallback();
                        break;
                    }
                }
                break;
        }
        if (this.mDragging || this.mLongPressSent) {
            z = true;
        }
        return z;
    }

    public void dismissChild(View view, float velocity) {
        dismissChild(view, velocity, null, 0, false, 0);
    }

    public void dismissChild(View view, float velocity, Runnable endAction, long delay, boolean useAccelerateInterpolator, long fixedDuration) {
        float newPos;
        long duration;
        View animView = this.mCallback.getChildContentView(view);
        boolean canAnimViewBeDismissed = this.mCallback.canChildBeDismissed(view);
        boolean isLayoutRtl = view.getLayoutDirection() == 1;
        if (velocity < 0.0f || ((velocity == 0.0f && getTranslation(animView) < 0.0f) || ((velocity == 0.0f && getTranslation(animView) == 0.0f && this.mSwipeDirection == 1) || (velocity == 0.0f && getTranslation(animView) == 0.0f && isLayoutRtl)))) {
            newPos = -getSize(animView);
        } else {
            newPos = getSize(animView);
        }
        if (fixedDuration == 0) {
            duration = (long) this.MAX_ESCAPE_ANIMATION_DURATION;
            if (velocity != 0.0f) {
                duration = Math.min(duration, (long) ((int) ((Math.abs(newPos - getTranslation(animView)) * 1000.0f) / Math.abs(velocity))));
            } else {
                duration = (long) this.DEFAULT_ESCAPE_ANIMATION_DURATION;
            }
        } else {
            duration = fixedDuration;
        }
        animView.setLayerType(2, null);
        ObjectAnimator anim = createTranslationAnimation(animView, newPos);
        if (useAccelerateInterpolator) {
            anim.setInterpolator(this.mFastOutLinearInInterpolator);
        } else {
            anim.setInterpolator(sLinearInterpolator);
        }
        anim.setDuration(duration);
        if (delay > 0) {
            anim.setStartDelay(delay);
        }
        anim.addListener(new C00972(view, endAction, animView));
        anim.addUpdateListener(new C00983(animView, canAnimViewBeDismissed));
        anim.start();
    }

    public void snapChild(View view, float velocity) {
        View animView = this.mCallback.getChildContentView(view);
        boolean canAnimViewBeDismissed = this.mCallback.canChildBeDismissed(animView);
        ObjectAnimator anim = createTranslationAnimation(animView, 0.0f);
        anim.setDuration((long) 150);
        anim.addUpdateListener(new C00994(animView, canAnimViewBeDismissed));
        anim.addListener(new C01005(animView, canAnimViewBeDismissed));
        anim.start();
    }

    public boolean onTouchEvent(MotionEvent ev) {
        if (this.mLongPressSent) {
            return true;
        }
        if (this.mDragging) {
            this.mVelocityTracker.addMovement(ev);
            switch (ev.getAction()) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                case 3:
                    if (this.mCurrView != null) {
                        boolean childSwipedFastEnough;
                        boolean falsingDetected;
                        boolean dismissChild;
                        View view;
                        this.mVelocityTracker.computeCurrentVelocity(1000, ((float) this.MAX_DISMISS_VELOCITY) * this.mDensityScale);
                        float escapeVelocity = this.SWIPE_ESCAPE_VELOCITY * this.mDensityScale;
                        float velocity = getVelocity(this.mVelocityTracker);
                        float perpendicularVelocity = getPerpendicularVelocity(this.mVelocityTracker);
                        boolean childSwipedFarEnough = ((double) Math.abs(getTranslation(this.mCurrAnimView))) > 0.4d * ((double) getSize(this.mCurrAnimView));
                        if (Math.abs(velocity) > escapeVelocity && Math.abs(velocity) > Math.abs(perpendicularVelocity)) {
                            if ((velocity > 0.0f ? 1 : null) == (getTranslation(this.mCurrAnimView) > 0.0f ? 1 : null)) {
                                childSwipedFastEnough = true;
                                falsingDetected = this.mCallback.isAntiFalsingNeeded() && !this.mTouchAboveFalsingThreshold;
                                dismissChild = this.mCallback.canChildBeDismissed(this.mCurrView) && !falsingDetected && ((childSwipedFastEnough || childSwipedFarEnough) && ev.getActionMasked() == 1);
                                if (dismissChild) {
                                    view = this.mCurrView;
                                    if (!childSwipedFastEnough) {
                                        velocity = 0.0f;
                                    }
                                    dismissChild(view, velocity);
                                    break;
                                }
                                this.mCallback.onDragCancelled(this.mCurrView);
                                snapChild(this.mCurrView, velocity);
                                break;
                            }
                        }
                        childSwipedFastEnough = false;
                        if (!this.mCallback.isAntiFalsingNeeded()) {
                            break;
                        }
                        if (!this.mCallback.canChildBeDismissed(this.mCurrView)) {
                        }
                        if (dismissChild) {
                            view = this.mCurrView;
                            if (childSwipedFastEnough) {
                                velocity = 0.0f;
                            }
                            dismissChild(view, velocity);
                        } else {
                            this.mCallback.onDragCancelled(this.mCurrView);
                            snapChild(this.mCurrView, velocity);
                        }
                    }
                    break;
                case 2:
                case 4:
                    if (this.mCurrView != null) {
                        float delta = getPos(ev) - this.mInitialTouchPos;
                        float absDelta = Math.abs(delta);
                        if (absDelta >= ((float) getFalsingThreshold())) {
                            this.mTouchAboveFalsingThreshold = true;
                        }
                        if (!this.mCallback.canChildBeDismissed(this.mCurrView)) {
                            float size = getSize(this.mCurrAnimView);
                            float maxScrollDistance = 0.15f * size;
                            delta = absDelta >= size ? delta > 0.0f ? maxScrollDistance : -maxScrollDistance : maxScrollDistance * ((float) Math.sin(((double) (delta / size)) * 1.5707963267948966d));
                        }
                        setTranslation(this.mCurrAnimView, delta);
                        updateSwipeProgressFromOffset(this.mCurrAnimView, this.mCanCurrViewBeDimissed);
                        break;
                    }
                    break;
            }
            return true;
        } else if (this.mCallback.getChildAtPosition(ev) != null) {
            onInterceptTouchEvent(ev);
            return true;
        } else {
            removeLongPressCallback();
            return false;
        }
    }

    private int getFalsingThreshold() {
        return (int) (((float) this.mFalsingThreshold) * this.mCallback.getFalsingThresholdFactor());
    }
}
