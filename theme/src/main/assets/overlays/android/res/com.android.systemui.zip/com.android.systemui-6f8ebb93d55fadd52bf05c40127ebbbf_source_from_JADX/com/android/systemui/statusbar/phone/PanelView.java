package com.android.systemui.statusbar.phone;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import com.android.keyguard.C0065R;
import com.android.systemui.EventLogTags;
import com.android.systemui.doze.DozeLog;
import com.android.systemui.statusbar.FlingAnimationUtils;
import com.android.systemui.statusbar.policy.HeadsUpManager;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class PanelView extends FrameLayout {
    public static final String TAG;
    private boolean mAnimatingOnDown;
    PanelBar mBar;
    private Interpolator mBounceInterpolator;
    private boolean mClosing;
    private boolean mCollapseAfterPeek;
    private boolean mCollapsedAndHeadsUpOnDown;
    private int mEdgeTapAreaWidth;
    private float mExpandedFraction;
    protected float mExpandedHeight;
    protected boolean mExpanding;
    private Interpolator mFastOutSlowInInterpolator;
    private FlingAnimationUtils mFlingAnimationUtils;
    private final Runnable mFlingCollapseRunnable;
    private boolean mGestureWaitForTouchSlop;
    private boolean mHasLayoutedSinceDown;
    protected HeadsUpManager mHeadsUpManager;
    private ValueAnimator mHeightAnimator;
    protected boolean mHintAnimationRunning;
    private float mHintDistance;
    private boolean mIgnoreXTouchSlop;
    private float mInitialOffsetOnTouch;
    private float mInitialTouchX;
    private float mInitialTouchY;
    private boolean mInstantExpanding;
    private boolean mJustPeeked;
    protected KeyguardBottomAreaView mKeyguardBottomArea;
    private Interpolator mLinearOutSlowInInterpolator;
    private boolean mMotionAborted;
    private float mNextCollapseSpeedUpFactor;
    private boolean mOverExpandedBeforeFling;
    private boolean mPanelClosedOnDown;
    private ObjectAnimator mPeekAnimator;
    private float mPeekHeight;
    private boolean mPeekPending;
    private Runnable mPeekRunnable;
    private boolean mPeekTouching;
    protected final Runnable mPostCollapseRunnable;
    protected PhoneStatusBar mStatusBar;
    private boolean mTouchAboveFalsingThreshold;
    private boolean mTouchDisabled;
    protected int mTouchSlop;
    private boolean mTouchSlopExceeded;
    private boolean mTouchStartedInEmptyArea;
    protected boolean mTracking;
    private int mTrackingPointer;
    private int mUnlockFalsingThreshold;
    private boolean mUpdateFlingOnLayout;
    private float mUpdateFlingVelocity;
    private boolean mUpwardsWhenTresholdReached;
    private VelocityTrackerInterface mVelocityTracker;
    private String mViewName;

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.1 */
    class C03951 implements Runnable {
        C03951() {
        }

        public void run() {
            PanelView.this.mPeekPending = false;
            PanelView.this.runPeekAnimation();
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.2 */
    class C03962 extends AnimatorListenerAdapter {
        private boolean mCancelled;

        C03962() {
        }

        public void onAnimationCancel(Animator animation) {
            this.mCancelled = true;
        }

        public void onAnimationEnd(Animator animation) {
            PanelView.this.mPeekAnimator = null;
            if (PanelView.this.mCollapseAfterPeek && !this.mCancelled) {
                PanelView.this.postOnAnimation(PanelView.this.mPostCollapseRunnable);
            }
            PanelView.this.mCollapseAfterPeek = false;
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.3 */
    class C03973 extends AnimatorListenerAdapter {
        private boolean mCancelled;
        final /* synthetic */ boolean val$clearAllExpandHack;

        C03973(boolean z) {
            this.val$clearAllExpandHack = z;
        }

        public void onAnimationCancel(Animator animation) {
            this.mCancelled = true;
        }

        public void onAnimationEnd(Animator animation) {
            if (this.val$clearAllExpandHack && !this.mCancelled) {
                PanelView.this.setExpandedHeightInternal((float) PanelView.this.getMaxPanelHeight());
            }
            PanelView.this.mHeightAnimator = null;
            if (!this.mCancelled) {
                PanelView.this.notifyExpandingFinished();
            }
            PanelView.this.notifyBarPanelExpansionChanged();
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.4 */
    class C03984 implements Runnable {
        C03984() {
        }

        public void run() {
            PanelView.this.fling(0.0f, false, PanelView.this.mNextCollapseSpeedUpFactor, false);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.5 */
    class C03995 implements OnGlobalLayoutListener {
        C03995() {
        }

        public void onGlobalLayout() {
            if (PanelView.this.mStatusBar.getStatusBarWindow().getHeight() != PanelView.this.mStatusBar.getStatusBarHeight()) {
                PanelView.this.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                PanelView.this.setExpandedFraction(1.0f);
                PanelView.this.mInstantExpanding = false;
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.6 */
    class C04006 implements Runnable {
        C04006() {
        }

        public void run() {
            PanelView.this.notifyExpandingFinished();
            PanelView.this.mStatusBar.onHintFinished();
            PanelView.this.mHintAnimationRunning = false;
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.7 */
    class C04017 extends AnimatorListenerAdapter {
        private boolean mCancelled;
        final /* synthetic */ Runnable val$onAnimationFinished;

        C04017(Runnable runnable) {
            this.val$onAnimationFinished = runnable;
        }

        public void onAnimationCancel(Animator animation) {
            this.mCancelled = true;
        }

        public void onAnimationEnd(Animator animation) {
            if (this.mCancelled) {
                PanelView.this.mHeightAnimator = null;
                this.val$onAnimationFinished.run();
                return;
            }
            PanelView.this.startUnlockHintAnimationPhase2(this.val$onAnimationFinished);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.8 */
    class C04028 implements Runnable {
        C04028() {
        }

        public void run() {
            PanelView.this.mKeyguardBottomArea.getIndicationView().animate().translationY(0.0f).setDuration(450).setInterpolator(PanelView.this.mBounceInterpolator).start();
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PanelView.9 */
    class C04039 extends AnimatorListenerAdapter {
        final /* synthetic */ Runnable val$onAnimationFinished;

        C04039(Runnable runnable) {
            this.val$onAnimationFinished = runnable;
        }

        public void onAnimationEnd(Animator animation) {
            PanelView.this.mHeightAnimator = null;
            this.val$onAnimationFinished.run();
            PanelView.this.notifyBarPanelExpansionChanged();
        }
    }

    protected abstract boolean fullyExpandedClearAllVisible();

    protected abstract float getCannedFlingDurationFactor();

    protected abstract int getClearAllHeight();

    protected abstract int getMaxPanelHeight();

    protected abstract float getOverExpansionAmount();

    protected abstract float getOverExpansionPixels();

    protected abstract float getPeekHeight();

    protected abstract boolean hasConflictingGestures();

    protected abstract boolean isClearAllVisible();

    protected abstract boolean isInContentBounds(float f, float f2);

    protected abstract boolean isPanelVisibleBecauseOfHeadsUp();

    protected abstract boolean isTrackingBlocked();

    protected abstract void onHeightUpdated(float f);

    protected abstract boolean onMiddleClicked();

    public abstract void resetViews();

    protected abstract void setOverExpansion(float f, boolean z);

    protected abstract boolean shouldGestureIgnoreXTouchSlop(float f, float f2);

    static {
        TAG = PanelView.class.getSimpleName();
    }

    protected void onExpandingFinished() {
        this.mBar.onExpandingFinished();
    }

    protected void onExpandingStarted() {
    }

    private void notifyExpandingStarted() {
        if (!this.mExpanding) {
            this.mExpanding = true;
            onExpandingStarted();
        }
    }

    protected final void notifyExpandingFinished() {
        endClosing();
        if (this.mExpanding) {
            this.mExpanding = false;
            onExpandingFinished();
        }
    }

    private void schedulePeek() {
        this.mPeekPending = true;
        postOnAnimationDelayed(this.mPeekRunnable, (long) ViewConfiguration.getTapTimeout());
        notifyBarPanelExpansionChanged();
    }

    private void runPeekAnimation() {
        this.mPeekHeight = getPeekHeight();
        if (this.mHeightAnimator == null) {
            this.mPeekAnimator = ObjectAnimator.ofFloat(this, "expandedHeight", new float[]{this.mPeekHeight}).setDuration(250);
            this.mPeekAnimator.setInterpolator(this.mLinearOutSlowInInterpolator);
            this.mPeekAnimator.addListener(new C03962());
            notifyExpandingStarted();
            this.mPeekAnimator.start();
            this.mJustPeeked = true;
        }
    }

    public PanelView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mExpandedFraction = 0.0f;
        this.mExpandedHeight = 0.0f;
        this.mNextCollapseSpeedUpFactor = 1.0f;
        this.mPeekRunnable = new C03951();
        this.mFlingCollapseRunnable = new C03984();
        this.mPostCollapseRunnable = new Runnable() {
            public void run() {
                PanelView.this.collapse(false, 1.0f);
            }
        };
        this.mFlingAnimationUtils = new FlingAnimationUtils(context, 0.6f);
        this.mFastOutSlowInInterpolator = AnimationUtils.loadInterpolator(context, 17563661);
        this.mLinearOutSlowInInterpolator = AnimationUtils.loadInterpolator(context, 17563662);
        this.mBounceInterpolator = new BounceInterpolator();
    }

    protected void loadDimens() {
        Resources res = getContext().getResources();
        this.mTouchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        this.mHintDistance = res.getDimension(2131296390);
        this.mEdgeTapAreaWidth = res.getDimensionPixelSize(2131296391);
        this.mUnlockFalsingThreshold = res.getDimensionPixelSize(2131296375);
    }

    private void trackMovement(MotionEvent event) {
        float deltaX = event.getRawX() - event.getX();
        float deltaY = event.getRawY() - event.getY();
        event.offsetLocation(deltaX, deltaY);
        if (this.mVelocityTracker != null) {
            this.mVelocityTracker.addMovement(event);
        }
        event.offsetLocation(-deltaX, -deltaY);
    }

    public void setTouchDisabled(boolean disabled) {
        this.mTouchDisabled = disabled;
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.mInstantExpanding || this.mTouchDisabled) {
            return false;
        }
        if (this.mMotionAborted && event.getActionMasked() != 0) {
            return false;
        }
        boolean z;
        int pointerIndex = event.findPointerIndex(this.mTrackingPointer);
        if (pointerIndex < 0) {
            pointerIndex = 0;
            this.mTrackingPointer = event.getPointerId(0);
        }
        float x = event.getX(pointerIndex);
        float y = event.getY(pointerIndex);
        if (event.getActionMasked() == 0) {
            z = isFullyCollapsed() || hasConflictingGestures();
            this.mGestureWaitForTouchSlop = z;
            if (isFullyCollapsed() || shouldGestureIgnoreXTouchSlop(x, y)) {
                z = true;
            } else {
                z = false;
            }
            this.mIgnoreXTouchSlop = z;
        }
        switch (event.getActionMasked()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                startExpandMotion(x, y, false, this.mExpandedHeight);
                this.mJustPeeked = false;
                this.mPanelClosedOnDown = isFullyCollapsed();
                this.mHasLayoutedSinceDown = false;
                this.mUpdateFlingOnLayout = false;
                this.mMotionAborted = false;
                this.mPeekTouching = this.mPanelClosedOnDown;
                this.mTouchAboveFalsingThreshold = false;
                z = isFullyCollapsed() && this.mHeadsUpManager.hasPinnedHeadsUp();
                this.mCollapsedAndHeadsUpOnDown = z;
                if (this.mVelocityTracker == null) {
                    initVelocityTracker();
                }
                trackMovement(event);
                if (!(this.mGestureWaitForTouchSlop && ((this.mHeightAnimator == null || this.mHintAnimationRunning) && !this.mPeekPending && this.mPeekAnimator == null))) {
                    cancelHeightAnimator();
                    cancelPeek();
                    if ((this.mHeightAnimator == null || this.mHintAnimationRunning) && !this.mPeekPending && this.mPeekAnimator == null) {
                        z = false;
                    } else {
                        z = true;
                    }
                    this.mTouchSlopExceeded = z;
                    onTrackingStarted();
                }
                if (isFullyCollapsed() && !this.mHeadsUpManager.hasPinnedHeadsUp()) {
                    schedulePeek();
                    break;
                }
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 3:
                trackMovement(event);
                endMotionEvent(event, x, y, false);
                break;
            case 2:
                float h = y - this.mInitialTouchY;
                if (Math.abs(h) > ((float) this.mTouchSlop) && (Math.abs(h) > Math.abs(x - this.mInitialTouchX) || this.mIgnoreXTouchSlop)) {
                    this.mTouchSlopExceeded = true;
                    if (!(!this.mGestureWaitForTouchSlop || this.mTracking || this.mCollapsedAndHeadsUpOnDown)) {
                        if (!(this.mJustPeeked || this.mInitialOffsetOnTouch == 0.0f)) {
                            startExpandMotion(x, y, false, this.mExpandedHeight);
                            h = 0.0f;
                        }
                        cancelHeightAnimator();
                        removeCallbacks(this.mPeekRunnable);
                        this.mPeekPending = false;
                        onTrackingStarted();
                    }
                }
                float newHeight = Math.max(0.0f, this.mInitialOffsetOnTouch + h);
                if (newHeight > this.mPeekHeight) {
                    if (this.mPeekAnimator != null) {
                        this.mPeekAnimator.cancel();
                    }
                    this.mJustPeeked = false;
                }
                if ((-h) >= ((float) getFalsingThreshold())) {
                    this.mTouchAboveFalsingThreshold = true;
                    this.mUpwardsWhenTresholdReached = isDirectionUpwards(x, y);
                }
                if (!this.mJustPeeked && ((!this.mGestureWaitForTouchSlop || this.mTracking) && !isTrackingBlocked())) {
                    setExpandedHeightInternal(newHeight);
                }
                trackMovement(event);
                break;
            case 5:
                if (this.mStatusBar.getBarState() == 1) {
                    this.mMotionAborted = true;
                    endMotionEvent(event, x, y, true);
                    return false;
                }
                break;
            case 6:
                int upPointer = event.getPointerId(event.getActionIndex());
                if (this.mTrackingPointer == upPointer) {
                    int newIndex;
                    if (event.getPointerId(0) != upPointer) {
                        newIndex = 0;
                    } else {
                        newIndex = 1;
                    }
                    float newY = event.getY(newIndex);
                    float newX = event.getX(newIndex);
                    this.mTrackingPointer = event.getPointerId(newIndex);
                    startExpandMotion(newX, newY, true, this.mExpandedHeight);
                    break;
                }
                break;
        }
        if (!this.mGestureWaitForTouchSlop || this.mTracking) {
            return true;
        }
        return false;
    }

    private boolean isDirectionUpwards(float x, float y) {
        float xDiff = x - this.mInitialTouchX;
        float yDiff = y - this.mInitialTouchY;
        if (yDiff < 0.0f && Math.abs(yDiff) >= Math.abs(xDiff)) {
            return true;
        }
        return false;
    }

    protected void startExpandMotion(float newX, float newY, boolean startTracking, float expandedHeight) {
        this.mInitialOffsetOnTouch = expandedHeight;
        this.mInitialTouchY = newY;
        this.mInitialTouchX = newX;
        if (startTracking) {
            this.mTouchSlopExceeded = true;
            onTrackingStarted();
        }
    }

    private void endMotionEvent(MotionEvent event, float x, float y, boolean forceCancel) {
        this.mTrackingPointer = -1;
        if ((this.mTracking && this.mTouchSlopExceeded) || Math.abs(x - this.mInitialTouchX) > ((float) this.mTouchSlop) || Math.abs(y - this.mInitialTouchY) > ((float) this.mTouchSlop) || event.getActionMasked() == 3 || forceCancel) {
            float vel = 0.0f;
            float vectorVel = 0.0f;
            if (this.mVelocityTracker != null) {
                this.mVelocityTracker.computeCurrentVelocity(1000);
                vel = this.mVelocityTracker.getYVelocity();
                vectorVel = (float) Math.hypot((double) this.mVelocityTracker.getXVelocity(), (double) this.mVelocityTracker.getYVelocity());
            }
            boolean expand = flingExpands(vel, vectorVel, x, y) || event.getActionMasked() == 3 || forceCancel;
            DozeLog.traceFling(expand, this.mTouchAboveFalsingThreshold, this.mStatusBar.isFalsingThresholdNeeded(), this.mStatusBar.isWakeUpComingFromTouch());
            if (!expand && this.mStatusBar.getBarState() == 1) {
                float displayDensity = this.mStatusBar.getDisplayDensity();
                EventLogTags.writeSysuiLockscreenGesture(1, (int) Math.abs((y - this.mInitialTouchY) / displayDensity), (int) Math.abs(vel / displayDensity));
            }
            fling(vel, expand, isFalseTouch(x, y));
            onTrackingStopped(expand);
            boolean z = expand && this.mPanelClosedOnDown && !this.mHasLayoutedSinceDown;
            this.mUpdateFlingOnLayout = z;
            if (this.mUpdateFlingOnLayout) {
                this.mUpdateFlingVelocity = vel;
            }
        } else {
            onTrackingStopped(onEmptySpaceClick(this.mInitialTouchX));
        }
        if (this.mVelocityTracker != null) {
            this.mVelocityTracker.recycle();
            this.mVelocityTracker = null;
        }
        this.mPeekTouching = false;
    }

    private int getFalsingThreshold() {
        return (int) (((float) this.mUnlockFalsingThreshold) * (this.mStatusBar.isWakeUpComingFromTouch() ? 1.5f : 1.0f));
    }

    protected void onTrackingStopped(boolean expand) {
        this.mTracking = false;
        this.mBar.onTrackingStopped(this, expand);
        notifyBarPanelExpansionChanged();
    }

    protected void onTrackingStarted() {
        endClosing();
        this.mTracking = true;
        this.mCollapseAfterPeek = false;
        this.mBar.onTrackingStarted(this);
        notifyExpandingStarted();
        notifyBarPanelExpansionChanged();
    }

    public boolean onInterceptTouchEvent(MotionEvent event) {
        boolean z = true;
        if (this.mInstantExpanding || (this.mMotionAborted && event.getActionMasked() != 0)) {
            return false;
        }
        int pointerIndex = event.findPointerIndex(this.mTrackingPointer);
        if (pointerIndex < 0) {
            pointerIndex = 0;
            this.mTrackingPointer = event.getPointerId(0);
        }
        float x = event.getX(pointerIndex);
        float y = event.getY(pointerIndex);
        boolean scrolledToBottom = isScrolledToBottom();
        switch (event.getActionMasked()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                boolean z2;
                this.mStatusBar.userActivity();
                if (this.mHeightAnimator != null) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                this.mAnimatingOnDown = z2;
                if ((!this.mAnimatingOnDown || !this.mClosing || this.mHintAnimationRunning) && !this.mPeekPending && this.mPeekAnimator == null) {
                    this.mInitialTouchY = y;
                    this.mInitialTouchX = x;
                    if (isInContentBounds(x, y)) {
                        z = false;
                    }
                    this.mTouchStartedInEmptyArea = z;
                    this.mTouchSlopExceeded = false;
                    this.mJustPeeked = false;
                    this.mMotionAborted = false;
                    this.mPanelClosedOnDown = isFullyCollapsed();
                    this.mCollapsedAndHeadsUpOnDown = false;
                    this.mHasLayoutedSinceDown = false;
                    this.mUpdateFlingOnLayout = false;
                    this.mTouchAboveFalsingThreshold = false;
                    initVelocityTracker();
                    trackMovement(event);
                    break;
                }
                cancelHeightAnimator();
                cancelPeek();
                this.mTouchSlopExceeded = true;
                return true;
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 3:
                if (this.mVelocityTracker != null) {
                    this.mVelocityTracker.recycle();
                    this.mVelocityTracker = null;
                    break;
                }
                break;
            case 2:
                float h = y - this.mInitialTouchY;
                trackMovement(event);
                if (scrolledToBottom || this.mTouchStartedInEmptyArea || this.mAnimatingOnDown) {
                    float hAbs = Math.abs(h);
                    if ((h < ((float) (-this.mTouchSlop)) || (this.mAnimatingOnDown && hAbs > ((float) this.mTouchSlop))) && hAbs > Math.abs(x - this.mInitialTouchX)) {
                        cancelHeightAnimator();
                        startExpandMotion(x, y, true, this.mExpandedHeight);
                        return true;
                    }
                }
            case 5:
                if (this.mStatusBar.getBarState() == 1) {
                    this.mMotionAborted = true;
                    if (this.mVelocityTracker != null) {
                        this.mVelocityTracker.recycle();
                        this.mVelocityTracker = null;
                        break;
                    }
                }
                break;
            case 6:
                int upPointer = event.getPointerId(event.getActionIndex());
                if (this.mTrackingPointer == upPointer) {
                    int newIndex;
                    if (event.getPointerId(0) != upPointer) {
                        newIndex = 0;
                    } else {
                        newIndex = 1;
                    }
                    this.mTrackingPointer = event.getPointerId(newIndex);
                    this.mInitialTouchX = event.getX(newIndex);
                    this.mInitialTouchY = event.getY(newIndex);
                    break;
                }
                break;
        }
        return false;
    }

    protected void cancelHeightAnimator() {
        if (this.mHeightAnimator != null) {
            this.mHeightAnimator.cancel();
        }
        endClosing();
    }

    private void endClosing() {
        if (this.mClosing) {
            this.mClosing = false;
            onClosingFinished();
        }
    }

    private void initVelocityTracker() {
        if (this.mVelocityTracker != null) {
            this.mVelocityTracker.recycle();
        }
        this.mVelocityTracker = VelocityTrackerFactory.obtain(getContext());
    }

    protected boolean isScrolledToBottom() {
        return true;
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        loadDimens();
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        loadDimens();
    }

    protected boolean flingExpands(float vel, float vectorVel, float x, float y) {
        if (isFalseTouch(x, y)) {
            return true;
        }
        if (Math.abs(vectorVel) < this.mFlingAnimationUtils.getMinVelocityPxPerSecond()) {
            if (getExpandedFraction() <= 0.5f) {
                return false;
            }
            return true;
        } else if (vel <= 0.0f) {
            return false;
        } else {
            return true;
        }
    }

    private boolean isFalseTouch(float x, float y) {
        boolean z = true;
        if (!this.mStatusBar.isFalsingThresholdNeeded()) {
            return false;
        }
        if (!this.mTouchAboveFalsingThreshold) {
            return true;
        }
        if (this.mUpwardsWhenTresholdReached) {
            return false;
        }
        if (isDirectionUpwards(x, y)) {
            z = false;
        }
        return z;
    }

    protected void fling(float vel, boolean expand) {
        fling(vel, expand, 1.0f, false);
    }

    protected void fling(float vel, boolean expand, boolean expandBecauseOfFalsing) {
        fling(vel, expand, 1.0f, expandBecauseOfFalsing);
    }

    protected void fling(float vel, boolean expand, float collapseSpeedUpFactor, boolean expandBecauseOfFalsing) {
        cancelPeek();
        float target = expand ? (float) getMaxPanelHeight() : 0.0f;
        if (!expand) {
            this.mClosing = true;
        }
        flingToHeight(vel, expand, target, collapseSpeedUpFactor, expandBecauseOfFalsing);
    }

    protected void flingToHeight(float vel, boolean expand, float target, float collapseSpeedUpFactor, boolean expandBecauseOfFalsing) {
        boolean clearAllExpandHack;
        boolean z = true;
        if (!expand || !fullyExpandedClearAllVisible() || this.mExpandedHeight >= ((float) (getMaxPanelHeight() - getClearAllHeight())) || isClearAllVisible()) {
            clearAllExpandHack = false;
        } else {
            clearAllExpandHack = true;
        }
        if (clearAllExpandHack) {
            target = (float) (getMaxPanelHeight() - getClearAllHeight());
        }
        if (target == this.mExpandedHeight || (getOverExpansionAmount() > 0.0f && expand)) {
            notifyExpandingFinished();
            return;
        }
        if (getOverExpansionAmount() <= 0.0f) {
            z = false;
        }
        this.mOverExpandedBeforeFling = z;
        ValueAnimator animator = createHeightAnimator(target);
        if (expand) {
            if (expandBecauseOfFalsing) {
                vel = 0.0f;
            }
            this.mFlingAnimationUtils.apply(animator, this.mExpandedHeight, target, vel, (float) getHeight());
            if (expandBecauseOfFalsing) {
                animator.setDuration(350);
            }
        } else {
            this.mFlingAnimationUtils.applyDismissing(animator, this.mExpandedHeight, target, vel, (float) getHeight());
            if (vel == 0.0f) {
                animator.setDuration((long) ((((float) animator.getDuration()) * getCannedFlingDurationFactor()) / collapseSpeedUpFactor));
            }
        }
        animator.addListener(new C03973(clearAllExpandHack));
        this.mHeightAnimator = animator;
        animator.start();
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mViewName = getResources().getResourceName(getId());
    }

    public void setExpandedHeight(float height) {
        setExpandedHeightInternal(getOverExpansionPixels() + height);
    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        requestPanelHeightUpdate();
        this.mHasLayoutedSinceDown = true;
        if (this.mUpdateFlingOnLayout) {
            abortAnimations();
            fling(this.mUpdateFlingVelocity, true);
            this.mUpdateFlingOnLayout = false;
        }
    }

    protected void requestPanelHeightUpdate() {
        float currentMaxPanelHeight = (float) getMaxPanelHeight();
        if ((!this.mTracking || isTrackingBlocked()) && this.mHeightAnimator == null && !isFullyCollapsed() && currentMaxPanelHeight != this.mExpandedHeight && !this.mPeekPending && this.mPeekAnimator == null && !this.mPeekTouching) {
            setExpandedHeight(currentMaxPanelHeight);
        }
    }

    public void setExpandedHeightInternal(float h) {
        float f = 0.0f;
        float fhWithoutOverExpansion = ((float) getMaxPanelHeight()) - getOverExpansionAmount();
        if (this.mHeightAnimator == null) {
            float overExpansionPixels = Math.max(0.0f, h - fhWithoutOverExpansion);
            if (getOverExpansionPixels() != overExpansionPixels && this.mTracking) {
                setOverExpansion(overExpansionPixels, true);
            }
            this.mExpandedHeight = Math.min(h, fhWithoutOverExpansion) + getOverExpansionAmount();
        } else {
            this.mExpandedHeight = h;
            if (this.mOverExpandedBeforeFling) {
                setOverExpansion(Math.max(0.0f, h - fhWithoutOverExpansion), false);
            }
        }
        this.mExpandedHeight = Math.max(0.0f, this.mExpandedHeight);
        if (fhWithoutOverExpansion != 0.0f) {
            f = this.mExpandedHeight / fhWithoutOverExpansion;
        }
        this.mExpandedFraction = Math.min(1.0f, f);
        onHeightUpdated(this.mExpandedHeight);
        notifyBarPanelExpansionChanged();
    }

    public void setExpandedFraction(float frac) {
        setExpandedHeight(((float) getMaxPanelHeight()) * frac);
    }

    public float getExpandedHeight() {
        return this.mExpandedHeight;
    }

    public float getExpandedFraction() {
        return this.mExpandedFraction;
    }

    public boolean isFullyExpanded() {
        return this.mExpandedHeight >= ((float) getMaxPanelHeight());
    }

    public boolean isFullyCollapsed() {
        return this.mExpandedHeight <= 0.0f;
    }

    public boolean isCollapsing() {
        return this.mClosing;
    }

    public boolean isTracking() {
        return this.mTracking;
    }

    public void setBar(PanelBar panelBar) {
        this.mBar = panelBar;
    }

    public void collapse(boolean delayed, float speedUpFactor) {
        if (this.mPeekPending || this.mPeekAnimator != null) {
            this.mCollapseAfterPeek = true;
            if (this.mPeekPending) {
                removeCallbacks(this.mPeekRunnable);
                this.mPeekRunnable.run();
            }
        } else if (!isFullyCollapsed() && !this.mTracking && !this.mClosing) {
            cancelHeightAnimator();
            notifyExpandingStarted();
            this.mClosing = true;
            if (delayed) {
                this.mNextCollapseSpeedUpFactor = speedUpFactor;
                postDelayed(this.mFlingCollapseRunnable, 120);
                return;
            }
            fling(0.0f, false, speedUpFactor, false);
        }
    }

    public void expand() {
        if (isFullyCollapsed()) {
            this.mBar.startOpeningPanel(this);
            notifyExpandingStarted();
            fling(0.0f, true);
        }
    }

    public void cancelPeek() {
        if (this.mPeekAnimator != null) {
            this.mPeekAnimator.cancel();
        }
        removeCallbacks(this.mPeekRunnable);
        this.mPeekPending = false;
        notifyBarPanelExpansionChanged();
    }

    public void instantExpand() {
        this.mInstantExpanding = true;
        this.mUpdateFlingOnLayout = false;
        abortAnimations();
        cancelPeek();
        if (this.mTracking) {
            onTrackingStopped(true);
        }
        if (this.mExpanding) {
            notifyExpandingFinished();
        }
        notifyBarPanelExpansionChanged();
        getViewTreeObserver().addOnGlobalLayoutListener(new C03995());
        requestLayout();
    }

    public void instantCollapse() {
        abortAnimations();
        setExpandedFraction(0.0f);
        if (this.mExpanding) {
            notifyExpandingFinished();
        }
    }

    private void abortAnimations() {
        cancelPeek();
        cancelHeightAnimator();
        removeCallbacks(this.mPostCollapseRunnable);
        removeCallbacks(this.mFlingCollapseRunnable);
    }

    protected void onClosingFinished() {
        this.mBar.onClosingFinished();
    }

    protected void startUnlockHintAnimation() {
        if (this.mHeightAnimator == null && !this.mTracking) {
            cancelPeek();
            notifyExpandingStarted();
            startUnlockHintAnimationPhase1(new C04006());
            this.mStatusBar.onUnlockHintStarted();
            this.mHintAnimationRunning = true;
        }
    }

    private void startUnlockHintAnimationPhase1(Runnable onAnimationFinished) {
        ValueAnimator animator = createHeightAnimator(Math.max(0.0f, ((float) getMaxPanelHeight()) - this.mHintDistance));
        animator.setDuration(250);
        animator.setInterpolator(this.mFastOutSlowInInterpolator);
        animator.addListener(new C04017(onAnimationFinished));
        animator.start();
        this.mHeightAnimator = animator;
        this.mKeyguardBottomArea.getIndicationView().animate().translationY(-this.mHintDistance).setDuration(250).setInterpolator(this.mFastOutSlowInInterpolator).withEndAction(new C04028()).start();
    }

    private void startUnlockHintAnimationPhase2(Runnable onAnimationFinished) {
        ValueAnimator animator = createHeightAnimator((float) getMaxPanelHeight());
        animator.setDuration(450);
        animator.setInterpolator(this.mBounceInterpolator);
        animator.addListener(new C04039(onAnimationFinished));
        animator.start();
        this.mHeightAnimator = animator;
    }

    private ValueAnimator createHeightAnimator(float targetHeight) {
        ValueAnimator animator = ValueAnimator.ofFloat(new float[]{this.mExpandedHeight, targetHeight});
        animator.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                PanelView.this.setExpandedHeightInternal(((Float) animation.getAnimatedValue()).floatValue());
            }
        });
        return animator;
    }

    protected void notifyBarPanelExpansionChanged() {
        PanelBar panelBar = this.mBar;
        float f = this.mExpandedFraction;
        boolean z = this.mExpandedFraction > 0.0f || this.mPeekPending || this.mPeekAnimator != null || this.mInstantExpanding || isPanelVisibleBecauseOfHeadsUp() || this.mTracking || this.mHeightAnimator != null;
        panelBar.panelExpansionChanged(this, f, z);
    }

    protected boolean onEmptySpaceClick(float x) {
        if (this.mHintAnimationRunning) {
            return true;
        }
        return onMiddleClicked();
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        String str;
        String str2 = "[PanelView(%s): expandedHeight=%f maxPanelHeight=%d closing=%s tracking=%s justPeeked=%s peekAnim=%s%s timeAnim=%s%s touchDisabled=%s]";
        Object[] objArr = new Object[11];
        objArr[0] = getClass().getSimpleName();
        objArr[1] = Float.valueOf(getExpandedHeight());
        objArr[2] = Integer.valueOf(getMaxPanelHeight());
        if (this.mClosing) {
            str = "T";
        } else {
            str = "f";
        }
        objArr[3] = str;
        if (this.mTracking) {
            str = "T";
        } else {
            str = "f";
        }
        objArr[4] = str;
        if (this.mJustPeeked) {
            str = "T";
        } else {
            str = "f";
        }
        objArr[5] = str;
        objArr[6] = this.mPeekAnimator;
        if (this.mPeekAnimator == null || !this.mPeekAnimator.isStarted()) {
            str = "";
        } else {
            str = " (started)";
        }
        objArr[7] = str;
        objArr[8] = this.mHeightAnimator;
        if (this.mHeightAnimator == null || !this.mHeightAnimator.isStarted()) {
            str = "";
        } else {
            str = " (started)";
        }
        objArr[9] = str;
        if (this.mTouchDisabled) {
            str = "T";
        } else {
            str = "f";
        }
        objArr[10] = str;
        pw.println(String.format(str2, objArr));
    }

    public void setHeadsUpManager(HeadsUpManager headsUpManager) {
        this.mHeadsUpManager = headsUpManager;
    }
}
