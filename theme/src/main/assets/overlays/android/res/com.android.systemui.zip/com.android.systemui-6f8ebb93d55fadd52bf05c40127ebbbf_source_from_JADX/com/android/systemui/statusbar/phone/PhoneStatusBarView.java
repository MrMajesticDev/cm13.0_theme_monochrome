package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import com.android.systemui.DejankUtils;

public class PhoneStatusBarView extends PanelBar {
    private static final boolean DEBUG;
    PhoneStatusBar mBar;
    private final PhoneStatusBarTransitions mBarTransitions;
    private Runnable mHideExpandedRunnable;
    PanelView mLastFullyOpenedPanel;
    private float mMinFraction;
    PanelView mNotificationPanel;
    private float mPanelFraction;
    private ScrimController mScrimController;

    /* renamed from: com.android.systemui.statusbar.phone.PhoneStatusBarView.1 */
    class C04221 implements Runnable {
        C04221() {
        }

        public void run() {
            PhoneStatusBarView.this.mBar.makeExpandedInvisible();
        }
    }

    static {
        DEBUG = PhoneStatusBar.DEBUG;
    }

    public PhoneStatusBarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mLastFullyOpenedPanel = null;
        this.mHideExpandedRunnable = new C04221();
        Resources res = getContext().getResources();
        this.mBarTransitions = new PhoneStatusBarTransitions(this);
    }

    public BarTransitions getBarTransitions() {
        return this.mBarTransitions;
    }

    public void setBar(PhoneStatusBar bar) {
        this.mBar = bar;
    }

    public void setScrimController(ScrimController scrimController) {
        this.mScrimController = scrimController;
    }

    public void onFinishInflate() {
        this.mBarTransitions.init();
    }

    public void addPanel(PanelView pv) {
        super.addPanel(pv);
        if (pv.getId() == 2131755282) {
            this.mNotificationPanel = pv;
        }
    }

    public boolean panelsEnabled() {
        return this.mBar.panelsEnabled();
    }

    public boolean onRequestSendAccessibilityEventInternal(View child, AccessibilityEvent event) {
        if (!super.onRequestSendAccessibilityEventInternal(child, event)) {
            return false;
        }
        AccessibilityEvent record = AccessibilityEvent.obtain();
        onInitializeAccessibilityEvent(record);
        dispatchPopulateAccessibilityEvent(record);
        event.appendRecord(record);
        return true;
    }

    public PanelView selectPanelForTouch(MotionEvent touch) {
        return this.mNotificationPanel.getExpandedHeight() > 0.0f ? null : this.mNotificationPanel;
    }

    public void onPanelPeeked() {
        super.onPanelPeeked();
        removePendingHideExpandedRunnables();
        this.mBar.makeExpandedVisible(false);
    }

    public void onAllPanelsCollapsed() {
        super.onAllPanelsCollapsed();
        DejankUtils.postAfterTraversal(this.mHideExpandedRunnable);
        this.mLastFullyOpenedPanel = null;
    }

    public void removePendingHideExpandedRunnables() {
        DejankUtils.removeCallbacks(this.mHideExpandedRunnable);
    }

    public void onPanelFullyOpened(PanelView openPanel) {
        super.onPanelFullyOpened(openPanel);
        if (openPanel != this.mLastFullyOpenedPanel) {
            openPanel.sendAccessibilityEvent(32);
        }
        this.mLastFullyOpenedPanel = openPanel;
    }

    public boolean onTouchEvent(MotionEvent event) {
        return this.mBar.interceptTouchEvent(event) || super.onTouchEvent(event);
    }

    public void onTrackingStarted(PanelView panel) {
        super.onTrackingStarted(panel);
        this.mBar.onTrackingStarted();
        this.mScrimController.onTrackingStarted();
    }

    public void onClosingFinished() {
        super.onClosingFinished();
        this.mBar.onClosingFinished();
    }

    public void onTrackingStopped(PanelView panel, boolean expand) {
        super.onTrackingStopped(panel, expand);
        this.mBar.onTrackingStopped(expand);
    }

    public void onExpandingFinished() {
        super.onExpandingFinished();
        this.mScrimController.onExpandingFinished();
    }

    public boolean onInterceptTouchEvent(MotionEvent event) {
        return this.mBar.interceptTouchEvent(event) || super.onInterceptTouchEvent(event);
    }

    public void panelScrimMinFractionChanged(float minFraction) {
        if (this.mMinFraction != minFraction) {
            this.mMinFraction = minFraction;
            updateScrimFraction();
        }
    }

    public void panelExpansionChanged(PanelView panel, float frac, boolean expanded) {
        super.panelExpansionChanged(panel, frac, expanded);
        this.mPanelFraction = frac;
        updateScrimFraction();
    }

    private void updateScrimFraction() {
        this.mScrimController.setPanelExpansion(Math.max(this.mPanelFraction - (this.mMinFraction / (1.0f - this.mMinFraction)), 0.0f));
    }
}
