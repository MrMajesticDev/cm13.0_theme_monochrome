package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.provider.Settings.Secure;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.SecureSetting;
import com.android.systemui.volume.SegmentedButtons;
import com.android.systemui.volume.SegmentedButtons.Callback;

public class ImmersiveTile extends QSTile<BooleanState> {
    private final ImmersiveDetailAdapter mDetailAdapter;
    private final AnimationIcon mDisableFull;
    private final AnimationIcon mDisableNavBar;
    private final AnimationIcon mDisableStatusBar;
    private final AnimationIcon mEnableFull;
    private final AnimationIcon mEnableNavBar;
    private final AnimationIcon mEnableStatusBar;
    private int mLastState;
    private boolean mListening;
    private final SecureSetting mSetting;

    /* renamed from: com.android.systemui.qs.tiles.ImmersiveTile.1 */
    class C01931 extends SecureSetting {
        C01931(Context x0, Handler x1, String x2) {
            super(x0, x1, x2);
        }

        protected void handleValueChanged(int value, boolean observedChange) {
            ImmersiveTile.this.handleRefreshState(Integer.valueOf(value));
        }
    }

    private final class ImmersiveDetailAdapter implements DetailAdapter {
        private SegmentedButtons mButtons;
        private final Callback mButtonsCallback;
        private ViewGroup mMessageContainer;
        private TextView mMessageText;

        /* renamed from: com.android.systemui.qs.tiles.ImmersiveTile.ImmersiveDetailAdapter.1 */
        class C01941 implements Callback {
            C01941() {
            }

            public void onSelected(Object value, boolean fromClick) {
                if (value != null && ImmersiveDetailAdapter.this.mButtons.isShown()) {
                    ImmersiveTile.this.mLastState = ((Integer) value).intValue();
                    if (fromClick) {
                        MetricsLogger.action(ImmersiveTile.this.mContext, 259, ImmersiveTile.this.mLastState);
                        ImmersiveDetailAdapter.this.setToggleState(true);
                    }
                    ImmersiveTile.this.fireToggleStateChanged(true);
                    ImmersiveTile.this.mSetting.setValue(ImmersiveTile.this.mLastState);
                    Secure.putIntForUser(ImmersiveTile.this.mContext.getContentResolver(), "last_system_design_flags", ImmersiveTile.this.mLastState, -2);
                }
            }

            public void onInteraction() {
            }
        }

        private ImmersiveDetailAdapter() {
            this.mButtonsCallback = new C01941();
        }

        public int getTitle() {
            return 2131361894;
        }

        public Boolean getToggleState() {
            return Boolean.valueOf(((BooleanState) ImmersiveTile.this.mState).value);
        }

        public Intent getSettingsIntent() {
            return null;
        }

        public void setToggleState(boolean state) {
            MetricsLogger.action(ImmersiveTile.this.mContext, 259, state);
            if (!state) {
                ImmersiveTile.this.showDetail(false);
            }
            ImmersiveTile.this.setEnabled(state);
            ImmersiveTile.this.fireToggleStateChanged(state);
            switch (ImmersiveTile.this.mLastState) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    this.mMessageText.setText(ImmersiveTile.this.mContext.getString(2131361906));
                    this.mMessageContainer.setVisibility(0);
                case 2:
                    this.mMessageText.setText(ImmersiveTile.this.mContext.getString(2131361905));
                    this.mMessageContainer.setVisibility(0);
                case 3:
                    this.mMessageText.setText(ImmersiveTile.this.mContext.getString(2131361904));
                    this.mMessageContainer.setVisibility(0);
                default:
                    this.mMessageContainer.setVisibility(8);
            }
        }

        public int getMetricsCategory() {
            return 258;
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            LinearLayout mDetails = convertView != null ? (LinearLayout) convertView : (LinearLayout) LayoutInflater.from(context).inflate(2130968581, parent, false);
            if (convertView == null) {
                this.mButtons = (SegmentedButtons) mDetails.findViewById(2131755082);
                this.mButtons.addButton(2131361896, 2131361901, Integer.valueOf(3));
                this.mButtons.addButton(2131361898, 2131361902, Integer.valueOf(2));
                this.mButtons.addButton(2131361900, 2131361903, Integer.valueOf(1));
                this.mButtons.setCallback(this.mButtonsCallback);
                this.mMessageContainer = (ViewGroup) mDetails.findViewById(2131755083);
                this.mMessageText = (TextView) mDetails.findViewById(2131755084);
                this.mButtons.setSelectedValue(Integer.valueOf(ImmersiveTile.this.mLastState), false);
            }
            setToggleState(true);
            return mDetails;
        }
    }

    public ImmersiveTile(Host host) {
        super(host, "immersive");
        this.mEnableFull = new AnimationIcon(2130837584);
        this.mEnableStatusBar = new AnimationIcon(2130837588);
        this.mEnableNavBar = new AnimationIcon(2130837586);
        this.mDisableFull = new AnimationIcon(2130837583);
        this.mDisableStatusBar = new AnimationIcon(2130837587);
        this.mDisableNavBar = new AnimationIcon(2130837585);
        this.mSetting = new C01931(this.mContext, this.mHandler, "system_design_flags");
        this.mDetailAdapter = new ImmersiveDetailAdapter();
        this.mLastState = Secure.getIntForUser(this.mContext.getContentResolver(), "last_system_design_flags", 3, -2);
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    protected void handleUserSwitch(int newUserId) {
        this.mSetting.setUserId(newUserId);
        handleRefreshState(Integer.valueOf(this.mSetting.getValue()));
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void handleToggleClick() {
        boolean z;
        boolean z2 = true;
        this.mEnableFull.setAllowAnimation(true);
        this.mEnableStatusBar.setAllowAnimation(true);
        this.mEnableNavBar.setAllowAnimation(true);
        this.mDisableFull.setAllowAnimation(true);
        this.mDisableStatusBar.setAllowAnimation(true);
        this.mDisableNavBar.setAllowAnimation(true);
        Context context = this.mContext;
        int metricsCategory = getMetricsCategory();
        if (((BooleanState) this.mState).value) {
            z = false;
        } else {
            z = true;
        }
        MetricsLogger.action(context, metricsCategory, z);
        if (((BooleanState) this.mState).value) {
            z2 = false;
        }
        setEnabled(z2);
    }

    public void handleDetailClick() {
        showDetail(true);
        handleToggleClick();
    }

    private void setEnabled(boolean enabled) {
        this.mSetting.setValue(enabled ? this.mLastState : 0);
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        int value = this.mSetting.getValue();
        state.value = value != 0;
        state.visible = true;
        switch (value) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                state.icon = this.mEnableNavBar;
                state.label = this.mContext.getString(2131361899);
                state.contentDescription = this.mContext.getString(2131361890);
            case 2:
                state.icon = this.mEnableStatusBar;
                state.label = this.mContext.getString(2131361897);
                state.contentDescription = this.mContext.getString(2131361891);
            case 3:
                state.icon = this.mEnableFull;
                state.label = this.mContext.getString(2131361895);
                state.contentDescription = this.mContext.getString(2131361889);
            default:
                if (state.icon == this.mEnableStatusBar) {
                    state.icon = this.mDisableStatusBar;
                } else if (state.icon == this.mEnableNavBar) {
                    state.icon = this.mDisableNavBar;
                } else {
                    state.icon = this.mDisableFull;
                }
                state.label = this.mContext.getString(2131361894);
                state.contentDescription = this.mContext.getString(2131361888);
        }
    }

    public int getMetricsCategory() {
        return 257;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131361892);
        }
        return this.mContext.getString(2131361893);
    }

    public void setListening(boolean listening) {
        if (this.mListening != listening) {
            this.mListening = listening;
            this.mSetting.setListening(listening);
        }
    }
}
