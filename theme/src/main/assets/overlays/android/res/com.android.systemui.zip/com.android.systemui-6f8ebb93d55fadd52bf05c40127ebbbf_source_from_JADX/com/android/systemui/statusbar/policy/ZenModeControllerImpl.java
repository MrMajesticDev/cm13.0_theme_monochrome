package com.android.systemui.statusbar.policy;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AlarmManager.AlarmClockInfo;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.UserHandle;
import android.os.UserManager;
import android.provider.Settings.Global;
import android.provider.Settings.Secure;
import android.service.notification.Condition;
import android.service.notification.IConditionListener;
import android.service.notification.IConditionListener.Stub;
import android.service.notification.ZenModeConfig;
import android.service.notification.ZenModeConfig.ZenRule;
import android.util.Log;
import android.util.Slog;
import com.android.systemui.qs.GlobalSetting;
import com.android.systemui.statusbar.policy.ZenModeController.Callback;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Objects;

public class ZenModeControllerImpl implements ZenModeController {
    private static final boolean DEBUG;
    private final AlarmManager mAlarmManager;
    private final ArrayList<Callback> mCallbacks;
    private final LinkedHashMap<Uri, Condition> mConditions;
    private ZenModeConfig mConfig;
    private final GlobalSetting mConfigSetting;
    private final Context mContext;
    private final IConditionListener mListener;
    private final GlobalSetting mModeSetting;
    private final NotificationManager mNoMan;
    private final BroadcastReceiver mReceiver;
    private boolean mRegistered;
    private boolean mRequesting;
    private final SetupObserver mSetupObserver;
    private int mUserId;
    private final UserManager mUserManager;

    /* renamed from: com.android.systemui.statusbar.policy.ZenModeControllerImpl.1 */
    class C05051 extends GlobalSetting {
        C05051(Context x0, Handler x1, String x2) {
            super(x0, x1, x2);
        }

        protected void handleValueChanged(int value) {
            ZenModeControllerImpl.this.fireZenChanged(value);
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.ZenModeControllerImpl.2 */
    class C05062 extends GlobalSetting {
        C05062(Context x0, Handler x1, String x2) {
            super(x0, x1, x2);
        }

        protected void handleValueChanged(int value) {
            ZenModeControllerImpl.this.updateZenModeConfig();
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.ZenModeControllerImpl.3 */
    class C05073 extends Stub {
        C05073() {
        }

        public void onConditionsReceived(Condition[] conditions) {
            if (ZenModeControllerImpl.DEBUG) {
                Slog.d("ZenModeController", "onConditionsReceived " + (conditions == null ? 0 : conditions.length) + " mRequesting=" + ZenModeControllerImpl.this.mRequesting);
            }
            if (ZenModeControllerImpl.this.mRequesting) {
                ZenModeControllerImpl.this.updateConditions(conditions);
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.ZenModeControllerImpl.4 */
    class C05084 extends BroadcastReceiver {
        C05084() {
        }

        public void onReceive(Context context, Intent intent) {
            if ("android.app.action.NEXT_ALARM_CLOCK_CHANGED".equals(intent.getAction())) {
                ZenModeControllerImpl.this.fireNextAlarmChanged();
            }
            if ("android.os.action.ACTION_EFFECTS_SUPPRESSOR_CHANGED".equals(intent.getAction())) {
                ZenModeControllerImpl.this.fireEffectsSuppressorChanged();
            }
        }
    }

    private final class SetupObserver extends ContentObserver {
        private boolean mRegistered;
        private final ContentResolver mResolver;

        public SetupObserver(Handler handler) {
            super(handler);
            this.mResolver = ZenModeControllerImpl.this.mContext.getContentResolver();
        }

        public boolean isUserSetup() {
            return Secure.getIntForUser(this.mResolver, "user_setup_complete", 0, ZenModeControllerImpl.this.mUserId) != 0;
        }

        public boolean isDeviceProvisioned() {
            return Global.getInt(this.mResolver, "device_provisioned", 0) != 0;
        }

        public void register() {
            if (this.mRegistered) {
                this.mResolver.unregisterContentObserver(this);
            }
            this.mResolver.registerContentObserver(Global.getUriFor("device_provisioned"), false, this);
            this.mResolver.registerContentObserver(Secure.getUriFor("user_setup_complete"), false, this, ZenModeControllerImpl.this.mUserId);
            ZenModeControllerImpl.this.fireZenAvailableChanged(ZenModeControllerImpl.this.isZenAvailable());
        }

        public void onChange(boolean selfChange, Uri uri) {
            if (Global.getUriFor("device_provisioned").equals(uri) || Secure.getUriFor("user_setup_complete").equals(uri)) {
                ZenModeControllerImpl.this.fireZenAvailableChanged(ZenModeControllerImpl.this.isZenAvailable());
            }
        }
    }

    static {
        DEBUG = Log.isLoggable("ZenModeController", 3);
    }

    public ZenModeControllerImpl(Context context, Handler handler) {
        this.mCallbacks = new ArrayList();
        this.mConditions = new LinkedHashMap();
        this.mListener = new C05073();
        this.mReceiver = new C05084();
        this.mContext = context;
        this.mModeSetting = new C05051(this.mContext, handler, "zen_mode");
        this.mConfigSetting = new C05062(this.mContext, handler, "zen_mode_config_etag");
        this.mNoMan = (NotificationManager) context.getSystemService("notification");
        this.mConfig = this.mNoMan.getZenModeConfig();
        this.mModeSetting.setListening(true);
        this.mConfigSetting.setListening(true);
        this.mAlarmManager = (AlarmManager) context.getSystemService("alarm");
        this.mSetupObserver = new SetupObserver(handler);
        this.mSetupObserver.register();
        this.mUserManager = (UserManager) context.getSystemService(UserManager.class);
    }

    public boolean isVolumeRestricted() {
        return this.mUserManager.hasUserRestriction("no_adjust_volume", new UserHandle(this.mUserId));
    }

    public void addCallback(Callback callback) {
        this.mCallbacks.add(callback);
    }

    public void removeCallback(Callback callback) {
        this.mCallbacks.remove(callback);
    }

    public int getZen() {
        return this.mModeSetting.getValue();
    }

    public void setZen(int zen, Uri conditionId, String reason) {
        this.mNoMan.setZenMode(zen, conditionId, reason);
    }

    public boolean isZenAvailable() {
        return this.mSetupObserver.isDeviceProvisioned() && this.mSetupObserver.isUserSetup();
    }

    public ZenRule getManualRule() {
        return this.mConfig == null ? null : this.mConfig.manualRule;
    }

    public ZenModeConfig getConfig() {
        return this.mConfig;
    }

    public long getNextAlarm() {
        AlarmClockInfo info = this.mAlarmManager.getNextAlarmClock(this.mUserId);
        return info != null ? info.getTriggerTime() : 0;
    }

    public void setUserId(int userId) {
        this.mUserId = userId;
        if (this.mRegistered) {
            this.mContext.unregisterReceiver(this.mReceiver);
        }
        IntentFilter filter = new IntentFilter("android.app.action.NEXT_ALARM_CLOCK_CHANGED");
        filter.addAction("android.os.action.ACTION_EFFECTS_SUPPRESSOR_CHANGED");
        this.mContext.registerReceiverAsUser(this.mReceiver, new UserHandle(this.mUserId), filter, null, null);
        this.mRegistered = true;
        this.mSetupObserver.register();
    }

    public boolean isCountdownConditionSupported() {
        return NotificationManager.from(this.mContext).isSystemConditionProviderEnabled("countdown");
    }

    public int getCurrentUser() {
        return ActivityManager.getCurrentUser();
    }

    private void fireNextAlarmChanged() {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onNextAlarmChanged();
        }
    }

    private void fireEffectsSuppressorChanged() {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onEffectsSupressorChanged();
        }
    }

    private void fireZenChanged(int zen) {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onZenChanged(zen);
        }
    }

    private void fireZenAvailableChanged(boolean available) {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onZenAvailableChanged(available);
        }
    }

    private void fireConditionsChanged(Condition[] conditions) {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onConditionsChanged(conditions);
        }
    }

    private void fireManualRuleChanged(ZenRule rule) {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onManualRuleChanged(rule);
        }
    }

    private void fireConfigChanged(ZenModeConfig config) {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((Callback) i$.next()).onConfigChanged(config);
        }
    }

    private void updateConditions(Condition[] conditions) {
        if (conditions != null && conditions.length != 0) {
            for (Condition c : conditions) {
                if ((c.flags & 1) != 0) {
                    this.mConditions.put(c.id, c);
                }
            }
            fireConditionsChanged((Condition[]) this.mConditions.values().toArray(new Condition[this.mConditions.values().size()]));
        }
    }

    private void updateZenModeConfig() {
        ZenModeConfig config = this.mNoMan.getZenModeConfig();
        if (!Objects.equals(config, this.mConfig)) {
            ZenRule oldRule;
            ZenRule newRule;
            if (this.mConfig != null) {
                oldRule = this.mConfig.manualRule;
            } else {
                oldRule = null;
            }
            this.mConfig = config;
            fireConfigChanged(config);
            if (config != null) {
                newRule = config.manualRule;
            } else {
                newRule = null;
            }
            if (!Objects.equals(oldRule, newRule)) {
                fireManualRuleChanged(newRule);
            }
        }
    }
}
