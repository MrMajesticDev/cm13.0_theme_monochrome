package com.android.systemui.qs.tiles;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings.Global;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.Icon;
import com.android.systemui.qs.UsageTracker;
import com.android.systemui.statusbar.phone.SystemUIDialog;
import com.android.systemui.statusbar.policy.HotspotController;

public class HotspotTile extends QSTile<BooleanState> {
    private final Callback mCallback;
    private final HotspotController mController;
    private final AnimationIcon mDisable;
    private final AnimationIcon mEnable;
    private final UsageTracker mUsageTracker;

    public static class APChangedReceiver extends BroadcastReceiver {
        private UsageTracker mUsageTracker;

        public void onReceive(Context context, Intent intent) {
            if (this.mUsageTracker == null) {
                this.mUsageTracker = HotspotTile.newUsageTracker(context);
            }
            this.mUsageTracker.trackUsage();
        }
    }

    private final class Callback implements com.android.systemui.statusbar.policy.HotspotController.Callback {
        private Callback() {
        }

        public void onHotspotChanged(boolean enabled) {
            HotspotTile.this.refreshState(Boolean.valueOf(enabled));
        }
    }

    public HotspotTile(Host host) {
        super(host, "hotspot");
        this.mEnable = new AnimationIcon(2130837579);
        this.mDisable = new AnimationIcon(2130837577);
        this.mCallback = new Callback();
        this.mController = host.getHotspotController();
        this.mUsageTracker = newUsageTracker(host.getContext());
        this.mUsageTracker.setListening(true);
    }

    protected void handleDestroy() {
        super.handleDestroy();
        this.mUsageTracker.setListening(false);
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void setListening(boolean listening) {
        if (listening) {
            this.mController.addCallback(this.mCallback);
        } else {
            this.mController.removeCallback(this.mCallback);
        }
    }

    protected void handleToggleClick() {
        boolean airplaneMode;
        boolean z = false;
        if (Global.getInt(this.mContext.getContentResolver(), "airplane_mode_on", 0) == 1) {
            airplaneMode = true;
        } else {
            airplaneMode = false;
        }
        if (airplaneMode) {
            SystemUIDialog d = new SystemUIDialog(this.mContext);
            d.setTitle(2131362210);
            d.setMessage(2131362371);
            d.setPositiveButton(17039370, null);
            d.setShowForAllUsers(true);
            d.show();
            return;
        }
        boolean z2;
        boolean isEnabled = ((BooleanState) this.mState).value;
        Context context = this.mContext;
        int metricsCategory = getMetricsCategory();
        if (isEnabled) {
            z2 = false;
        } else {
            z2 = true;
        }
        MetricsLogger.action(context, metricsCategory, z2);
        HotspotController hotspotController = this.mController;
        if (!isEnabled) {
            z = true;
        }
        hotspotController.setHotspotEnabled(z);
        this.mEnable.setAllowAnimation(true);
        this.mDisable.setAllowAnimation(true);
    }

    protected void handleDetailClick() {
        handleToggleClick();
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        boolean z = this.mController.isHotspotSupported() && this.mUsageTracker.isRecentlyUsed();
        state.visible = z;
        state.label = this.mContext.getString(2131362210);
        if (arg instanceof Boolean) {
            state.value = ((Boolean) arg).booleanValue();
        } else {
            state.value = this.mController.isHotspotEnabled();
        }
        Icon icon = (state.visible && state.value) ? this.mEnable : this.mDisable;
        state.icon = icon;
    }

    public int getMetricsCategory() {
        return 120;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131362141);
        }
        return this.mContext.getString(2131362140);
    }

    private static UsageTracker newUsageTracker(Context context) {
        return new UsageTracker(context, "HotspotTileLastUsed", HotspotTile.class, 2131623983);
    }
}
