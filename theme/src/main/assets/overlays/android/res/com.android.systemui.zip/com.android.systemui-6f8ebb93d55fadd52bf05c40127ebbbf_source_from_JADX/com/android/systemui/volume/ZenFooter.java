package com.android.systemui.volume;

import android.animation.LayoutTransition;
import android.animation.ValueAnimator;
import android.content.Context;
import android.service.notification.ZenModeConfig;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.policy.ZenModeController;
import com.android.systemui.statusbar.policy.ZenModeController.Callback;
import java.util.Objects;

public class ZenFooter extends LinearLayout {
    private static final String TAG;
    private ZenModeConfig mConfig;
    private final Context mContext;
    private ZenModeController mController;
    private TextView mEndNowButton;
    private ImageView mIcon;
    private final SpTexts mSpTexts;
    private TextView mSummaryLine1;
    private TextView mSummaryLine2;
    private final VolumeDialogController mVolumeDialogController;
    private int mZen;
    private Callback mZenModeCallback;

    /* renamed from: com.android.systemui.volume.ZenFooter.1 */
    class C05891 extends Callback {
        C05891() {
        }

        public void onZenChanged(int zen) {
            ZenFooter.this.setZen(zen);
        }

        public void onConfigChanged(ZenModeConfig config) {
            ZenFooter.this.setConfig(config);
        }
    }

    /* renamed from: com.android.systemui.volume.ZenFooter.2 */
    class C05902 implements OnClickListener {
        final /* synthetic */ ZenModeController val$controller;

        C05902(ZenModeController zenModeController) {
            this.val$controller = zenModeController;
        }

        public void onClick(View v) {
            this.val$controller.setZen(0, null, ZenFooter.TAG);
        }
    }

    static {
        TAG = Util.logTag(ZenFooter.class);
    }

    public ZenFooter(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mZen = -1;
        this.mZenModeCallback = new C05891();
        this.mContext = context;
        this.mSpTexts = new SpTexts(this.mContext);
        LayoutTransition layoutTransition = new LayoutTransition();
        layoutTransition.setDuration(new ValueAnimator().getDuration() / 2);
        setLayoutTransition(layoutTransition);
        this.mVolumeDialogController = new VolumeDialogController(context, null);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mIcon = (ImageView) findViewById(2131755345);
        this.mSummaryLine1 = (TextView) findViewById(2131755346);
        this.mSummaryLine2 = (TextView) findViewById(2131755347);
        this.mEndNowButton = (TextView) findViewById(2131755348);
        this.mSpTexts.add(this.mSummaryLine1);
        this.mSpTexts.add(this.mSummaryLine2);
        this.mSpTexts.add(this.mEndNowButton);
    }

    public void init(ZenModeController controller) {
        controller.addCallback(this.mZenModeCallback);
        this.mEndNowButton.setOnClickListener(new C05902(controller));
        this.mZen = controller.getZen();
        this.mConfig = controller.getConfig();
        this.mController = controller;
        update();
    }

    private void setZen(int zen) {
        if (this.mZen != zen) {
            this.mZen = zen;
            update();
        }
    }

    private void setConfig(ZenModeConfig config) {
        if (!Objects.equals(this.mConfig, config)) {
            this.mConfig = config;
            update();
        }
    }

    public boolean isZen() {
        return isZenPriority() || isZenAlarms() || isZenNone();
    }

    private boolean isZenPriority() {
        return this.mZen == 1;
    }

    private boolean isZenAlarms() {
        return this.mZen == 3;
    }

    private boolean isZenNone() {
        return this.mZen == 2;
    }

    public void update() {
        boolean isForever;
        int i = 0;
        boolean hasAlertSlider = ZenModeConfig.hasAlertSlider(this.mContext);
        ImageView imageView = this.mIcon;
        int i2 = isZenNone() ? 2130837566 : !isZen() ? 0 : 2130837563;
        imageView.setImageResource(i2);
        String line1 = isZenPriority() ? this.mContext.getString(2131362252) : isZenAlarms() ? this.mContext.getString(2131362253) : isZenNone() ? this.mContext.getString(2131362251) : null;
        Util.setText(this.mSummaryLine1, line1);
        if (this.mConfig == null || this.mConfig.manualRule == null || this.mConfig.manualRule.conditionId != null) {
            isForever = false;
        } else {
            isForever = true;
        }
        String line2 = isForever ? this.mContext.getString(17040793) : ZenModeConfig.getConditionSummary(this.mContext, this.mConfig, this.mController.getCurrentUser(), true);
        if (hasAlertSlider) {
            switch (this.mZen) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    line2 = this.mContext.getString(2131361940);
                    break;
                case 2:
                    line2 = this.mContext.getString(2131361942);
                    break;
                case 3:
                    line2 = this.mContext.getString(2131361941);
                    break;
            }
        }
        Util.setText(this.mSummaryLine2, line2);
        this.mSpTexts.update();
        Util.setText(this.mEndNowButton, this.mContext.getString(2131362316));
        TextView textView = this.mEndNowButton;
        if (hasAlertSlider) {
            i = 8;
        }
        textView.setVisibility(i);
    }

    public void onConfigurationChanged() {
        update();
    }

    public void cleanup() {
        this.mController.removeCallback(this.mZenModeCallback);
    }
}
