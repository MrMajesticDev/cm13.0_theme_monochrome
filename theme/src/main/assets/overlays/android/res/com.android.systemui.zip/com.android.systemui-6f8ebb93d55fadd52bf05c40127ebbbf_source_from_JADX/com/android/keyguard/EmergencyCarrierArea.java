package com.android.keyguard;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public class EmergencyCarrierArea extends AlphaOptimizedLinearLayout {
    private CarrierText mCarrierText;
    private EmergencyButton mEmergencyButton;

    /* renamed from: com.android.keyguard.EmergencyCarrierArea.1 */
    class C00051 implements OnTouchListener {
        C00051() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            if (EmergencyCarrierArea.this.mCarrierText.getVisibility() == 0) {
                switch (event.getAction()) {
                    case C0065R.styleable.NumPadKey_digit /*0*/:
                        EmergencyCarrierArea.this.mCarrierText.animate().alpha(0.0f);
                        break;
                    case C0065R.styleable.NumPadKey_textView /*1*/:
                        EmergencyCarrierArea.this.mCarrierText.animate().alpha(1.0f);
                        break;
                    default:
                        break;
                }
            }
            return false;
        }
    }

    public EmergencyCarrierArea(Context context) {
        super(context);
    }

    public EmergencyCarrierArea(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mCarrierText = (CarrierText) findViewById(C0065R.id.carrier_text);
        this.mEmergencyButton = (EmergencyButton) findViewById(C0065R.id.emergency_call_button);
        this.mEmergencyButton.setOnTouchListener(new C00051());
    }

    public void setCarrierTextVisible(boolean visible) {
        this.mCarrierText.setVisibility(visible ? 0 : 8);
    }
}
