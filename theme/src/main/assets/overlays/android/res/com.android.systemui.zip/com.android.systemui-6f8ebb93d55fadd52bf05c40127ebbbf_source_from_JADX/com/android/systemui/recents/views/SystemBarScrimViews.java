package com.android.systemui.recents.views;

import android.app.Activity;
import android.view.View;
import android.view.ViewPropertyAnimator;
import com.android.systemui.recents.RecentsConfiguration;

public class SystemBarScrimViews {
    RecentsConfiguration mConfig;
    boolean mHasNavBarScrim;
    boolean mHasStatusBarScrim;
    View mNavBarScrimView;
    boolean mShouldAnimateNavBarScrim;
    boolean mShouldAnimateStatusBarScrim;
    View mStatusBarScrimView;

    /* renamed from: com.android.systemui.recents.views.SystemBarScrimViews.1 */
    class C02301 implements Runnable {
        C02301() {
        }

        public void run() {
            SystemBarScrimViews.this.mStatusBarScrimView.setVisibility(0);
        }
    }

    /* renamed from: com.android.systemui.recents.views.SystemBarScrimViews.2 */
    class C02312 implements Runnable {
        C02312() {
        }

        public void run() {
            SystemBarScrimViews.this.mNavBarScrimView.setVisibility(0);
        }
    }

    public SystemBarScrimViews(Activity activity, RecentsConfiguration config) {
        this.mConfig = config;
        this.mStatusBarScrimView = activity.findViewById(2131755209);
        this.mNavBarScrimView = activity.findViewById(2131755213);
    }

    public void prepareEnterRecentsAnimation() {
        int i;
        int i2 = 0;
        this.mHasNavBarScrim = this.mConfig.hasNavBarScrim();
        this.mShouldAnimateNavBarScrim = this.mConfig.shouldAnimateNavBarScrim();
        this.mHasStatusBarScrim = this.mConfig.hasStatusBarScrim();
        this.mShouldAnimateStatusBarScrim = this.mConfig.shouldAnimateStatusBarScrim();
        View view = this.mNavBarScrimView;
        if (!this.mHasNavBarScrim || this.mShouldAnimateNavBarScrim) {
            i = 4;
        } else {
            i = 0;
        }
        view.setVisibility(i);
        View view2 = this.mStatusBarScrimView;
        if (!this.mHasStatusBarScrim || this.mShouldAnimateStatusBarScrim) {
            i2 = 4;
        }
        view2.setVisibility(i2);
    }

    public void startEnterRecentsAnimation() {
        long j;
        if (this.mHasStatusBarScrim && this.mShouldAnimateStatusBarScrim) {
            this.mStatusBarScrimView.setTranslationY((float) (-this.mStatusBarScrimView.getMeasuredHeight()));
            ViewPropertyAnimator translationY = this.mStatusBarScrimView.animate().translationY(0.0f);
            if (this.mConfig.launchedFromHome) {
                j = (long) this.mConfig.transitionEnterFromHomeDelay;
            } else {
                j = (long) this.mConfig.transitionEnterFromAppDelay;
            }
            translationY.setStartDelay(j).setDuration((long) this.mConfig.navBarScrimEnterDuration).setInterpolator(this.mConfig.quintOutInterpolator).withStartAction(new C02301()).start();
        }
        if (this.mHasNavBarScrim && this.mShouldAnimateNavBarScrim) {
            this.mNavBarScrimView.setTranslationY((float) this.mNavBarScrimView.getMeasuredHeight());
            translationY = this.mNavBarScrimView.animate().translationY(0.0f);
            if (this.mConfig.launchedFromHome) {
                j = (long) this.mConfig.transitionEnterFromHomeDelay;
            } else {
                j = (long) this.mConfig.transitionEnterFromAppDelay;
            }
            translationY.setStartDelay(j).setDuration((long) this.mConfig.navBarScrimEnterDuration).setInterpolator(this.mConfig.quintOutInterpolator).withStartAction(new C02312()).start();
        }
    }

    public void startExitRecentsAnimation() {
        if (this.mHasStatusBarScrim && this.mShouldAnimateStatusBarScrim) {
            this.mStatusBarScrimView.animate().translationY((float) (-this.mStatusBarScrimView.getMeasuredHeight())).setStartDelay(0).setDuration((long) this.mConfig.taskViewExitToAppDuration).setInterpolator(this.mConfig.fastOutSlowInInterpolator).start();
        }
        if (this.mHasNavBarScrim && this.mShouldAnimateNavBarScrim) {
            this.mNavBarScrimView.animate().translationY((float) this.mNavBarScrimView.getMeasuredHeight()).setStartDelay(0).setDuration((long) this.mConfig.taskViewExitToAppDuration).setInterpolator(this.mConfig.fastOutSlowInInterpolator).start();
        }
    }
}
