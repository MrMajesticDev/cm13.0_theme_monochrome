package com.android.systemui.usb;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.storage.IMountService;
import android.os.storage.IMountService.Stub;
import android.os.storage.StorageEventListener;
import android.os.storage.StorageManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.android.keyguard.C0065R;
import java.util.List;

public class UsbStorageActivity extends Activity implements OnCancelListener, OnClickListener {
    private Handler mAsyncStorageHandler;
    private TextView mBanner;
    private boolean mDestroyed;
    private ImageView mIcon;
    private TextView mMessage;
    private Button mMountButton;
    private ProgressBar mProgressBar;
    private StorageEventListener mStorageListener;
    private StorageManager mStorageManager;
    private Handler mUIHandler;
    private Button mUnmountButton;
    private BroadcastReceiver mUsbStateReceiver;

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.1 */
    class C05341 extends BroadcastReceiver {
        C05341() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("android.hardware.usb.action.USB_STATE")) {
                UsbStorageActivity.this.handleUsbStateChanged(intent);
            }
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.2 */
    class C05352 extends StorageEventListener {
        C05352() {
        }

        public void onStorageStateChanged(String path, String oldState, String newState) {
            UsbStorageActivity.this.switchDisplay(newState.equals("shared"));
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.3 */
    class C05363 implements Runnable {
        final /* synthetic */ boolean val$usbStorageInUse;

        C05363(boolean z) {
            this.val$usbStorageInUse = z;
        }

        public void run() {
            UsbStorageActivity.this.switchDisplayAsync(this.val$usbStorageInUse);
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.4 */
    class C05374 implements Runnable {
        C05374() {
        }

        public void run() {
            UsbStorageActivity.this.switchDisplay(UsbStorageActivity.this.mStorageManager.isUsbMassStorageEnabled());
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.5 */
    class C05385 implements DialogInterface.OnClickListener {
        C05385() {
        }

        public void onClick(DialogInterface dialog, int which) {
            UsbStorageActivity.this.switchUsbMassStorage(true);
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.6 */
    class C05396 implements Runnable {
        final /* synthetic */ int val$id;

        C05396(int i) {
            this.val$id = i;
        }

        public void run() {
            if (!UsbStorageActivity.this.mDestroyed) {
                UsbStorageActivity.this.removeDialog(this.val$id);
                UsbStorageActivity.this.showDialog(this.val$id);
            }
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.7 */
    class C05407 implements Runnable {
        C05407() {
        }

        public void run() {
            UsbStorageActivity.this.mUnmountButton.setVisibility(8);
            UsbStorageActivity.this.mMountButton.setVisibility(8);
            UsbStorageActivity.this.mProgressBar.setVisibility(0);
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.8 */
    class C05418 implements Runnable {
        final /* synthetic */ boolean val$on;

        C05418(boolean z) {
            this.val$on = z;
        }

        public void run() {
            if (this.val$on) {
                UsbStorageActivity.this.mStorageManager.enableUsbMassStorage();
            } else {
                UsbStorageActivity.this.mStorageManager.disableUsbMassStorage();
            }
        }
    }

    /* renamed from: com.android.systemui.usb.UsbStorageActivity.9 */
    class C05429 implements Runnable {
        C05429() {
        }

        public void run() {
            UsbStorageActivity.this.checkStorageUsersAsync();
        }
    }

    public UsbStorageActivity() {
        this.mStorageManager = null;
        this.mUsbStateReceiver = new C05341();
        this.mStorageListener = new C05352();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (this.mStorageManager == null) {
            this.mStorageManager = (StorageManager) getSystemService("storage");
            if (this.mStorageManager == null) {
                Log.w("UsbStorageActivity", "Failed to get StorageManager");
            }
        }
        this.mUIHandler = new Handler();
        HandlerThread thr = new HandlerThread("SystemUI UsbStorageActivity");
        thr.start();
        this.mAsyncStorageHandler = new Handler(thr.getLooper());
        getWindow().addFlags(4194304);
        if (Environment.isExternalStorageRemovable()) {
            getWindow().addFlags(524288);
        }
        setContentView(17367290);
        this.mIcon = (ImageView) findViewById(16908294);
        this.mBanner = (TextView) findViewById(16909317);
        this.mMessage = (TextView) findViewById(16908299);
        this.mMountButton = (Button) findViewById(16909318);
        this.mMountButton.setOnClickListener(this);
        this.mUnmountButton = (Button) findViewById(16909319);
        this.mUnmountButton.setOnClickListener(this);
        this.mProgressBar = (ProgressBar) findViewById(16908301);
    }

    protected void onDestroy() {
        super.onDestroy();
        this.mDestroyed = true;
    }

    private void switchDisplay(boolean usbStorageInUse) {
        this.mUIHandler.post(new C05363(usbStorageInUse));
    }

    private void switchDisplayAsync(boolean usbStorageInUse) {
        if (usbStorageInUse) {
            this.mProgressBar.setVisibility(8);
            this.mUnmountButton.setVisibility(0);
            this.mMountButton.setVisibility(8);
            this.mIcon.setImageResource(17303354);
            this.mBanner.setText(17040370);
            this.mMessage.setText(17040371);
            return;
        }
        this.mProgressBar.setVisibility(8);
        this.mUnmountButton.setVisibility(8);
        this.mMountButton.setVisibility(0);
        this.mIcon.setImageResource(17303353);
        this.mBanner.setText(17040362);
        this.mMessage.setText(17040363);
    }

    protected void onResume() {
        super.onResume();
        this.mStorageManager.registerListener(this.mStorageListener);
        registerReceiver(this.mUsbStateReceiver, new IntentFilter("android.hardware.usb.action.USB_STATE"));
        try {
            this.mAsyncStorageHandler.post(new C05374());
        } catch (Exception ex) {
            Log.e("UsbStorageActivity", "Failed to read UMS enable state", ex);
        }
    }

    protected void onPause() {
        super.onPause();
        unregisterReceiver(this.mUsbStateReceiver);
        if (this.mStorageManager == null && this.mStorageListener != null) {
            this.mStorageManager.unregisterListener(this.mStorageListener);
        }
    }

    private void handleUsbStateChanged(Intent intent) {
        if (!intent.getExtras().getBoolean("connected")) {
            finish();
        }
    }

    private IMountService getMountService() {
        IBinder service = ServiceManager.getService("mount");
        if (service != null) {
            return Stub.asInterface(service);
        }
        return null;
    }

    public Dialog onCreateDialog(int id, Bundle args) {
        switch (id) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return new Builder(this).setTitle(17040374).setPositiveButton(17040377, new C05385()).setNegativeButton(17039360, null).setMessage(17040375).setOnCancelListener(this).create();
            case 2:
                return new Builder(this).setTitle(17040376).setNeutralButton(17040377, null).setMessage(17040365).setOnCancelListener(this).create();
            default:
                return null;
        }
    }

    private void scheduleShowDialog(int id) {
        this.mUIHandler.post(new C05396(id));
    }

    private void switchUsbMassStorage(boolean on) {
        this.mUIHandler.post(new C05407());
        this.mAsyncStorageHandler.post(new C05418(on));
    }

    private void checkStorageUsers() {
        this.mAsyncStorageHandler.post(new C05429());
    }

    private void checkStorageUsersAsync() {
        IMountService ims = getMountService();
        if (ims == null) {
            scheduleShowDialog(2);
        }
        boolean showDialog = false;
        try {
            int[] stUsers = ims.getStorageUsers(Environment.getExternalStorageDirectory().toString());
            if (stUsers == null || stUsers.length <= 0) {
                List<ApplicationInfo> infoList = ((ActivityManager) getSystemService("activity")).getRunningExternalApplications();
                if (infoList != null && infoList.size() > 0) {
                    showDialog = true;
                }
                if (showDialog) {
                    switchUsbMassStorage(true);
                } else {
                    scheduleShowDialog(1);
                }
            }
            showDialog = true;
            if (showDialog) {
                switchUsbMassStorage(true);
            } else {
                scheduleShowDialog(1);
            }
        } catch (RemoteException e) {
            scheduleShowDialog(2);
        }
    }

    public void onClick(View v) {
        if (v == this.mMountButton) {
            checkStorageUsers();
        } else if (v == this.mUnmountButton) {
            switchUsbMassStorage(false);
        }
    }

    public void onCancel(DialogInterface dialog) {
        finish();
    }
}
