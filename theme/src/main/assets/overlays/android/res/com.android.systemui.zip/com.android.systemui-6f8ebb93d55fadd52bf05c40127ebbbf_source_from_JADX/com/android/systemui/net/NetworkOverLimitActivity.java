package com.android.systemui.net;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.net.INetworkPolicyManager.Stub;
import android.net.NetworkTemplate;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;
import com.android.keyguard.C0065R;

public class NetworkOverLimitActivity extends Activity {

    /* renamed from: com.android.systemui.net.NetworkOverLimitActivity.1 */
    class C01411 implements OnClickListener {
        final /* synthetic */ NetworkTemplate val$template;

        C01411(NetworkTemplate networkTemplate) {
            this.val$template = networkTemplate;
        }

        public void onClick(DialogInterface dialog, int which) {
            NetworkOverLimitActivity.this.snoozePolicy(this.val$template);
        }
    }

    /* renamed from: com.android.systemui.net.NetworkOverLimitActivity.2 */
    class C01422 implements OnDismissListener {
        C01422() {
        }

        public void onDismiss(DialogInterface dialog) {
            NetworkOverLimitActivity.this.finish();
        }
    }

    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        NetworkTemplate template = (NetworkTemplate) getIntent().getParcelableExtra("android.net.NETWORK_TEMPLATE");
        Builder builder = new Builder(this);
        builder.setTitle(getLimitedDialogTitleForTemplate(template));
        builder.setMessage(2131362148);
        builder.setPositiveButton(17039370, null);
        builder.setNegativeButton(2131362149, new C01411(template));
        Dialog dialog = builder.create();
        dialog.getWindow().setType(2003);
        dialog.setOnDismissListener(new C01422());
        dialog.show();
    }

    private void snoozePolicy(NetworkTemplate template) {
        try {
            Stub.asInterface(ServiceManager.getService("netpolicy")).snoozeLimit(template);
        } catch (RemoteException e) {
            Log.w("NetworkOverLimitActivity", "problem snoozing network policy", e);
        }
    }

    private static int getLimitedDialogTitleForTemplate(NetworkTemplate template) {
        switch (template.getMatchRule()) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return 2131362146;
            case 2:
                return 2131362144;
            case 3:
                return 2131362145;
            default:
                return 2131362147;
        }
    }
}
