package com.android.systemui.recents;

public class Constants {

    public static class DebugFlags {

        public static class App {
        }
    }

    public static class Metrics {
    }

    public static class Values {

        public static class App {
            public static int AppWidgetHostId;
            public static String DebugModeVersion;

            static {
                AppWidgetHostId = 1024;
                DebugModeVersion = "A";
            }
        }

        public static class TaskStackView {
        }
    }
}
