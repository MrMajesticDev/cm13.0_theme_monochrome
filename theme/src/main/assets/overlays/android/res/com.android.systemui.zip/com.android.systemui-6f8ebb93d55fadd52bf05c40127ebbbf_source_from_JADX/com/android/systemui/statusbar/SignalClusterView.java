package com.android.systemui.statusbar;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.telephony.SubscriptionInfo;
import android.telephony.TelephonyManager;
import android.util.ArraySet;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.android.systemui.statusbar.phone.StatusBarIconController;
import com.android.systemui.statusbar.policy.NetworkController.IconState;
import com.android.systemui.statusbar.policy.NetworkController.SignalCallback;
import com.android.systemui.statusbar.policy.NetworkControllerImpl;
import com.android.systemui.statusbar.policy.SecurityController;
import com.android.systemui.statusbar.policy.SecurityController.SecurityControllerCallback;
import com.android.systemui.tuner.TunerService;
import com.android.systemui.tuner.TunerService.Tunable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SignalClusterView extends LinearLayout implements SignalCallback, SecurityControllerCallback, Tunable {
    static final boolean DEBUG;
    ImageView mAirplane;
    private String mAirplaneContentDescription;
    private int mAirplaneIconId;
    private boolean mBlockAirplane;
    private boolean mBlockEthernet;
    private boolean mBlockMobile;
    private boolean mBlockWifi;
    private float mDarkIntensity;
    ImageView mEthernet;
    ImageView mEthernetDark;
    private String mEthernetDescription;
    ViewGroup mEthernetGroup;
    private int mEthernetIconId;
    private boolean mEthernetVisible;
    private int mIconTint;
    private boolean mIsAirplaneMode;
    private int mLastAirplaneIconId;
    private int mLastEthernetIconId;
    private int mLastWifiActivityId;
    private int mLastWifiStrengthId;
    LinearLayout mMobileSignalGroup;
    NetworkControllerImpl mNC;
    ImageView mNoSims;
    View mNoSimsCombo;
    ImageView mNoSimsDark;
    private int mNoSimsIcon;
    private boolean mNoSimsVisible;
    private ArrayList<PhoneState> mPhoneStates;
    SecurityController mSC;
    private int mSecondaryTelephonyPadding;
    ImageView mVpn;
    private boolean mVpnVisible;
    private int mWideTypeIconStartPadding;
    ImageView mWifi;
    ImageView mWifiActivity;
    private int mWifiActivityId;
    View mWifiAirplaneSpacer;
    ImageView mWifiDark;
    private String mWifiDescription;
    ViewGroup mWifiGroup;
    View mWifiSignalSpacer;
    private int mWifiStrengthId;
    private boolean mWifiVisible;

    /* renamed from: com.android.systemui.statusbar.SignalClusterView.1 */
    class C03451 implements Runnable {
        C03451() {
        }

        public void run() {
            if (SignalClusterView.this.mSC != null) {
                SignalClusterView.this.mVpnVisible = SignalClusterView.this.mSC.isVpnEnabled();
                SignalClusterView.this.apply();
            }
        }
    }

    private class PhoneState {
        private ImageView mDataActivity;
        private int mDataActivityId;
        private boolean mIsMobileTypeIconWide;
        private ImageView mMobile;
        private ImageView mMobileActivity;
        private int mMobileActivityId;
        private ImageView mMobileDark;
        private String mMobileDescription;
        private ViewGroup mMobileGroup;
        private ViewGroup mMobileSingleGroup;
        private ViewGroup mMobileStackedGroup;
        private int mMobileStrengthId;
        private ImageView mMobileType;
        private String mMobileTypeDescription;
        private int mMobileTypeId;
        private boolean mMobileVisible;
        private ImageView mRoaming;
        private ImageView mStackedData;
        private int mStackedDataId;
        private ImageView mStackedVoice;
        private int mStackedVoiceId;
        private final int mSubId;

        public PhoneState(int subId, Context context) {
            this.mMobileVisible = false;
            this.mMobileStrengthId = 0;
            this.mMobileTypeId = 0;
            this.mDataActivityId = 0;
            this.mMobileActivityId = 0;
            this.mStackedDataId = 0;
            this.mStackedVoiceId = 0;
            setViews((ViewGroup) LayoutInflater.from(context).inflate(2130968603, null));
            this.mSubId = subId;
        }

        public void setViews(ViewGroup root) {
            this.mMobileGroup = root;
            this.mMobile = (ImageView) root.findViewById(2131755166);
            this.mMobileDark = (ImageView) root.findViewById(2131755167);
            this.mMobileType = (ImageView) root.findViewById(2131755168);
            this.mMobileActivity = (ImageView) root.findViewById(2131755170);
            this.mDataActivity = (ImageView) root.findViewById(2131755164);
            this.mStackedData = (ImageView) root.findViewById(2131755172);
            this.mStackedVoice = (ImageView) root.findViewById(2131755173);
            this.mMobileSingleGroup = (ViewGroup) root.findViewById(2131755165);
            this.mMobileStackedGroup = (ViewGroup) root.findViewById(2131755171);
            this.mRoaming = (ImageView) root.findViewById(2131755169);
        }

        public boolean apply(boolean isSecondaryIcon) {
            int access$1800;
            int i = 0;
            if (!this.mMobileVisible || SignalClusterView.this.mIsAirplaneMode) {
                this.mMobileGroup.setVisibility(8);
            } else {
                Animatable ad;
                this.mMobile.setImageResource(this.mMobileStrengthId);
                Drawable mobileDrawable = this.mMobile.getDrawable();
                if (mobileDrawable instanceof Animatable) {
                    ad = (Animatable) mobileDrawable;
                    if (!ad.isRunning()) {
                        ad.start();
                    }
                }
                this.mMobileDark.setImageResource(this.mMobileStrengthId);
                Drawable mobileDarkDrawable = this.mMobileDark.getDrawable();
                if (mobileDarkDrawable instanceof Animatable) {
                    ad = (Animatable) mobileDarkDrawable;
                    if (!ad.isRunning()) {
                        ad.start();
                    }
                }
                this.mMobileType.setImageResource(this.mMobileTypeId);
                this.mDataActivity.setImageResource(this.mDataActivityId);
                Drawable dataActivityDrawable = this.mDataActivity.getDrawable();
                if (dataActivityDrawable instanceof Animatable) {
                    ad = (Animatable) dataActivityDrawable;
                    if (!ad.isRunning()) {
                        ad.start();
                    }
                }
                this.mMobileActivity.setImageResource(this.mMobileActivityId);
                Drawable mobileActivityDrawable = this.mMobileActivity.getDrawable();
                if (mobileActivityDrawable instanceof Animatable) {
                    ad = (Animatable) mobileActivityDrawable;
                    if (!ad.isRunning()) {
                        ad.start();
                    }
                }
                if (this.mStackedDataId == 0 || this.mStackedVoiceId == 0) {
                    this.mStackedData.setImageResource(0);
                    this.mStackedVoice.setImageResource(0);
                    this.mMobileSingleGroup.setVisibility(0);
                    this.mMobileStackedGroup.setVisibility(8);
                } else {
                    this.mStackedData.setImageResource(this.mStackedDataId);
                    this.mStackedVoice.setImageResource(this.mStackedVoiceId);
                    this.mMobileSingleGroup.setVisibility(8);
                    this.mMobileStackedGroup.setVisibility(0);
                }
                TelephonyManager tm = (TelephonyManager) SignalClusterView.this.mContext.getSystemService("phone");
                if (tm == null || !tm.isNetworkRoaming(this.mSubId)) {
                    this.mRoaming.setImageDrawable(null);
                } else {
                    this.mRoaming.setImageDrawable(SignalClusterView.this.getContext().getResources().getDrawable(2130837840));
                }
                this.mMobileGroup.setContentDescription(this.mMobileTypeDescription + " " + this.mMobileDescription);
                this.mMobileGroup.setVisibility(0);
            }
            ViewGroup viewGroup = this.mMobileGroup;
            if (isSecondaryIcon) {
                access$1800 = SignalClusterView.this.mSecondaryTelephonyPadding;
            } else {
                access$1800 = 0;
            }
            viewGroup.setPaddingRelative(access$1800, 0, 0, 0);
            ImageView imageView = this.mMobile;
            if (this.mIsMobileTypeIconWide) {
                access$1800 = SignalClusterView.this.mWideTypeIconStartPadding;
            } else {
                access$1800 = 0;
            }
            imageView.setPaddingRelative(access$1800, 0, 0, 0);
            imageView = this.mMobileDark;
            if (this.mIsMobileTypeIconWide) {
                access$1800 = SignalClusterView.this.mWideTypeIconStartPadding;
            } else {
                access$1800 = 0;
            }
            imageView.setPaddingRelative(access$1800, 0, 0, 0);
            if (SignalClusterView.DEBUG) {
                String str = "SignalClusterView";
                String str2 = "mobile: %s sig=%d typ=%d";
                Object[] objArr = new Object[3];
                objArr[0] = this.mMobileVisible ? "VISIBLE" : "GONE";
                objArr[1] = Integer.valueOf(this.mMobileStrengthId);
                objArr[2] = Integer.valueOf(this.mMobileTypeId);
                Log.d(str, String.format(str2, objArr));
            }
            imageView = this.mMobileType;
            if (this.mMobileTypeId != 0) {
                access$1800 = 0;
            } else {
                access$1800 = 8;
            }
            imageView.setVisibility(access$1800);
            imageView = this.mDataActivity;
            if (this.mDataActivityId != 0) {
                access$1800 = 0;
            } else {
                access$1800 = 8;
            }
            imageView.setVisibility(access$1800);
            ImageView imageView2 = this.mMobileActivity;
            if (this.mMobileActivityId == 0) {
                i = 8;
            }
            imageView2.setVisibility(i);
            return this.mMobileVisible;
        }

        public void populateAccessibilityEvent(AccessibilityEvent event) {
            if (this.mMobileVisible && this.mMobileGroup != null && this.mMobileGroup.getContentDescription() != null) {
                event.getText().add(this.mMobileGroup.getContentDescription());
            }
        }

        public void setIconTint(int tint, float darkIntensity) {
            SignalClusterView.this.applyDarkIntensity(darkIntensity, this.mMobile, this.mMobileDark);
            SignalClusterView.this.setTint(this.mMobileType, tint);
        }
    }

    static {
        DEBUG = Log.isLoggable("SignalClusterView", 3);
    }

    public SignalClusterView(Context context) {
        this(context, null);
    }

    public SignalClusterView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SignalClusterView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mNoSimsVisible = false;
        this.mVpnVisible = false;
        this.mEthernetVisible = false;
        this.mEthernetIconId = 0;
        this.mLastEthernetIconId = -1;
        this.mWifiVisible = false;
        this.mWifiStrengthId = 0;
        this.mWifiActivityId = 0;
        this.mLastWifiStrengthId = -1;
        this.mLastWifiActivityId = -1;
        this.mIsAirplaneMode = false;
        this.mAirplaneIconId = 0;
        this.mLastAirplaneIconId = -1;
        this.mPhoneStates = new ArrayList();
        this.mIconTint = -1;
    }

    public void onTuningChanged(String key, String newValue) {
        if ("icon_blacklist".equals(key)) {
            ArraySet<String> blockList = StatusBarIconController.getIconBlacklist(newValue);
            boolean blockAirplane = blockList.contains("airplane");
            boolean blockMobile = blockList.contains("mobile");
            boolean blockWifi = blockList.contains("wifi");
            boolean blockEthernet = blockList.contains("ethernet");
            if (blockAirplane != this.mBlockAirplane || blockMobile != this.mBlockMobile || blockEthernet != this.mBlockEthernet || blockWifi != this.mBlockWifi) {
                this.mBlockAirplane = blockAirplane;
                this.mBlockMobile = blockMobile;
                this.mBlockEthernet = blockEthernet;
                this.mBlockWifi = blockWifi;
                this.mNC.removeSignalCallback(this);
                this.mNC.addSignalCallback(this);
            }
        }
    }

    public void setNetworkController(NetworkControllerImpl nc) {
        if (DEBUG) {
            Log.d("SignalClusterView", "NetworkController=" + nc);
        }
        this.mNC = nc;
    }

    public void setSecurityController(SecurityController sc) {
        if (DEBUG) {
            Log.d("SignalClusterView", "SecurityController=" + sc);
        }
        if (sc == null && this.mSC != null) {
            this.mSC.removeCallback(this);
        }
        this.mSC = sc;
        if (this.mSC != null) {
            this.mSC.addCallback(this);
            this.mVpnVisible = this.mSC.isVpnEnabled();
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mWideTypeIconStartPadding = getContext().getResources().getDimensionPixelSize(2131296443);
        this.mSecondaryTelephonyPadding = getContext().getResources().getDimensionPixelSize(2131296444);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mVpn = (ImageView) findViewById(2131755254);
        this.mEthernetGroup = (ViewGroup) findViewById(2131755255);
        this.mEthernet = (ImageView) findViewById(2131755256);
        this.mEthernetDark = (ImageView) findViewById(2131755257);
        this.mWifiGroup = (ViewGroup) findViewById(2131755258);
        this.mWifi = (ImageView) findViewById(2131755259);
        this.mWifiDark = (ImageView) findViewById(2131755260);
        this.mWifiActivity = (ImageView) findViewById(2131755261);
        this.mAirplane = (ImageView) findViewById(2131755268);
        this.mNoSims = (ImageView) findViewById(2131755265);
        this.mNoSimsDark = (ImageView) findViewById(2131755266);
        this.mNoSimsCombo = findViewById(2131755264);
        this.mWifiAirplaneSpacer = findViewById(2131755267);
        this.mWifiSignalSpacer = findViewById(2131755262);
        this.mMobileSignalGroup = (LinearLayout) findViewById(2131755263);
        Iterator i$ = this.mPhoneStates.iterator();
        while (i$.hasNext()) {
            this.mMobileSignalGroup.addView(((PhoneState) i$.next()).mMobileGroup);
        }
        TunerService.get(this.mContext).addTunable((Tunable) this, "icon_blacklist");
        apply();
        applyIconTint();
    }

    protected void onDetachedFromWindow() {
        this.mVpn = null;
        this.mEthernetGroup = null;
        this.mEthernet = null;
        this.mWifiGroup = null;
        this.mWifi = null;
        this.mWifiActivity = null;
        this.mAirplane = null;
        this.mMobileSignalGroup.removeAllViews();
        this.mMobileSignalGroup = null;
        TunerService.get(this.mContext).removeTunable(this);
        super.onDetachedFromWindow();
    }

    public void onStateChanged() {
        post(new C03451());
    }

    public void setWifiIndicators(boolean enabled, IconState statusIcon, IconState qsIcon, boolean activityIn, boolean activityOut, String description) {
        boolean z = statusIcon.visible && !this.mBlockWifi;
        this.mWifiVisible = z;
        this.mWifiStrengthId = statusIcon.icon;
        this.mWifiActivityId = getWifiActivityId(activityIn, activityOut);
        this.mWifiDescription = statusIcon.contentDescription;
        apply();
    }

    public void setMobileDataIndicators(IconState statusIcon, IconState qsIcon, int statusType, int qsType, boolean activityIn, boolean activityOut, int dataActivityId, int mobileActivityId, int stackedDataId, int stackedVoiceId, String typeContentDescription, String description, boolean isWide, int subId) {
        PhoneState state = getState(subId);
        if (state != null) {
            boolean z = statusIcon.visible && !this.mBlockMobile;
            state.mMobileVisible = z;
            state.mMobileStrengthId = statusIcon.icon;
            state.mMobileTypeId = statusType;
            state.mMobileDescription = statusIcon.contentDescription;
            state.mMobileTypeDescription = typeContentDescription;
            z = statusType != 0 && isWide;
            state.mIsMobileTypeIconWide = z;
            state.mDataActivityId = dataActivityId;
            state.mMobileActivityId = mobileActivityId;
            state.mStackedDataId = stackedDataId;
            state.mStackedVoiceId = stackedVoiceId;
            apply();
        }
    }

    public void setEthernetIndicators(IconState state) {
        boolean z = state.visible && !this.mBlockEthernet;
        this.mEthernetVisible = z;
        this.mEthernetIconId = state.icon;
        this.mEthernetDescription = state.contentDescription;
        apply();
    }

    public void setNoSims(boolean show) {
        boolean z = show && !this.mBlockMobile;
        this.mNoSimsVisible = z;
        apply();
    }

    public void setSubs(List<SubscriptionInfo> subs) {
        if (!hasCorrectSubs(subs)) {
            this.mPhoneStates.clear();
            if (this.mMobileSignalGroup != null) {
                this.mMobileSignalGroup.removeAllViews();
            }
            int n = subs.size();
            for (int i = 0; i < n; i++) {
                inflatePhoneState(((SubscriptionInfo) subs.get(i)).getSubscriptionId());
            }
            if (isAttachedToWindow()) {
                applyIconTint();
            }
        }
    }

    private boolean hasCorrectSubs(List<SubscriptionInfo> subs) {
        int N = subs.size();
        if (N != this.mPhoneStates.size()) {
            return false;
        }
        for (int i = 0; i < N; i++) {
            if (((PhoneState) this.mPhoneStates.get(i)).mSubId != ((SubscriptionInfo) subs.get(i)).getSubscriptionId()) {
                return false;
            }
        }
        return true;
    }

    private PhoneState getState(int subId) {
        Iterator i$ = this.mPhoneStates.iterator();
        while (i$.hasNext()) {
            PhoneState state = (PhoneState) i$.next();
            if (state.mSubId == subId) {
                return state;
            }
        }
        Log.e("SignalClusterView", "Unexpected subscription " + subId);
        return null;
    }

    private int getWifiActivityId(boolean activityIn, boolean activityOut) {
        if (!getContext().getResources().getBoolean(2131558417)) {
            return 0;
        }
        if (activityIn && activityOut) {
            return 2130838141;
        }
        if (activityIn) {
            return 2130838140;
        }
        if (activityOut) {
            return 2130838142;
        }
        return 0;
    }

    private int getNoSimIcon() {
        Resources res = getContext().getResources();
        if (!res.getBoolean(2131558419)) {
            return 0;
        }
        try {
            String[] noSimArray = res.getStringArray(2131230830);
            if (noSimArray == null) {
                return 0;
            }
            String resName = noSimArray[0];
            int resId = res.getIdentifier(resName, null, getContext().getPackageName());
            if (DEBUG) {
                Log.d("SignalClusterView", "getNoSimIcon resId = " + resId + " resName = " + resName);
            }
            return resId;
        } catch (NotFoundException e) {
            return 0;
        }
    }

    private PhoneState inflatePhoneState(int subId) {
        PhoneState state = new PhoneState(subId, this.mContext);
        if (this.mMobileSignalGroup != null) {
            this.mMobileSignalGroup.addView(state.mMobileGroup);
        }
        this.mPhoneStates.add(state);
        return state;
    }

    public void setIsAirplaneMode(IconState icon) {
        boolean z = icon.visible && !this.mBlockAirplane;
        this.mIsAirplaneMode = z;
        this.mAirplaneIconId = icon.icon;
        this.mAirplaneContentDescription = icon.contentDescription;
        apply();
    }

    public void setMobileDataEnabled(boolean enabled) {
    }

    public boolean dispatchPopulateAccessibilityEventInternal(AccessibilityEvent event) {
        if (!(!this.mEthernetVisible || this.mEthernetGroup == null || this.mEthernetGroup.getContentDescription() == null)) {
            event.getText().add(this.mEthernetGroup.getContentDescription());
        }
        if (!(!this.mWifiVisible || this.mWifiGroup == null || this.mWifiGroup.getContentDescription() == null)) {
            event.getText().add(this.mWifiGroup.getContentDescription());
        }
        Iterator i$ = this.mPhoneStates.iterator();
        while (i$.hasNext()) {
            ((PhoneState) i$.next()).populateAccessibilityEvent(event);
        }
        return super.dispatchPopulateAccessibilityEventInternal(event);
    }

    public void onRtlPropertiesChanged(int layoutDirection) {
        super.onRtlPropertiesChanged(layoutDirection);
        if (this.mEthernet != null) {
            this.mEthernet.setImageDrawable(null);
            this.mEthernetDark.setImageDrawable(null);
            this.mLastEthernetIconId = -1;
        }
        if (this.mWifi != null) {
            this.mWifi.setImageDrawable(null);
            this.mWifiDark.setImageDrawable(null);
            this.mLastWifiStrengthId = -1;
        }
        if (this.mWifiActivity != null) {
            this.mWifiActivity.setImageDrawable(null);
            this.mLastWifiActivityId = -1;
        }
        Iterator i$ = this.mPhoneStates.iterator();
        while (i$.hasNext()) {
            PhoneState state = (PhoneState) i$.next();
            if (state.mMobile != null) {
                state.mMobile.setImageDrawable(null);
            }
            if (state.mMobileType != null) {
                state.mMobileType.setImageDrawable(null);
            }
        }
        if (this.mAirplane != null) {
            this.mAirplane.setImageDrawable(null);
            this.mLastAirplaneIconId = -1;
        }
        apply();
    }

    public boolean hasOverlappingRendering() {
        return false;
    }

    private void apply() {
        int i = 0;
        if (this.mWifiGroup != null) {
            int i2;
            String str;
            String str2;
            Object[] objArr;
            ImageView imageView = this.mVpn;
            if (this.mVpnVisible) {
                i2 = 0;
            } else {
                i2 = 8;
            }
            imageView.setVisibility(i2);
            if (DEBUG) {
                str = "SignalClusterView";
                str2 = "vpn: %s";
                objArr = new Object[1];
                objArr[0] = this.mVpnVisible ? "VISIBLE" : "GONE";
                Log.d(str, String.format(str2, objArr));
            }
            if (this.mEthernetVisible) {
                if (this.mLastEthernetIconId != this.mEthernetIconId) {
                    this.mEthernet.setImageResource(this.mEthernetIconId);
                    this.mEthernetDark.setImageResource(this.mEthernetIconId);
                    this.mLastEthernetIconId = this.mEthernetIconId;
                }
                this.mEthernetGroup.setContentDescription(this.mEthernetDescription);
                this.mEthernetGroup.setVisibility(0);
            } else {
                this.mEthernetGroup.setVisibility(8);
            }
            if (DEBUG) {
                str = "SignalClusterView";
                str2 = "ethernet: %s";
                objArr = new Object[1];
                objArr[0] = this.mEthernetVisible ? "VISIBLE" : "GONE";
                Log.d(str, String.format(str2, objArr));
            }
            if (this.mWifiVisible) {
                if (this.mWifiStrengthId != this.mLastWifiStrengthId) {
                    this.mWifi.setImageResource(this.mWifiStrengthId);
                    this.mWifiDark.setImageResource(this.mWifiStrengthId);
                    this.mLastWifiStrengthId = this.mWifiStrengthId;
                }
                if (this.mWifiActivityId != this.mLastWifiActivityId) {
                    this.mWifiActivity.setImageResource(this.mWifiActivityId);
                    this.mLastWifiActivityId = this.mWifiActivityId;
                }
                this.mWifiGroup.setContentDescription(this.mWifiDescription);
                this.mWifiGroup.setVisibility(0);
            } else {
                this.mWifiGroup.setVisibility(8);
            }
            if (DEBUG) {
                str = "SignalClusterView";
                str2 = "wifi: %s sig=%d act=%d";
                objArr = new Object[3];
                objArr[0] = this.mWifiVisible ? "VISIBLE" : "GONE";
                objArr[1] = Integer.valueOf(this.mWifiStrengthId);
                objArr[2] = Integer.valueOf(this.mWifiActivityId);
                Log.d(str, String.format(str2, objArr));
            }
            boolean anyMobileVisible = false;
            int firstMobileTypeId = 0;
            Iterator i$ = this.mPhoneStates.iterator();
            while (i$.hasNext()) {
                PhoneState state = (PhoneState) i$.next();
                if (state.apply(anyMobileVisible) && !anyMobileVisible) {
                    firstMobileTypeId = state.mMobileTypeId;
                    anyMobileVisible = true;
                }
            }
            if (this.mIsAirplaneMode) {
                if (this.mLastAirplaneIconId != this.mAirplaneIconId) {
                    this.mAirplane.setImageResource(this.mAirplaneIconId);
                    this.mLastAirplaneIconId = this.mAirplaneIconId;
                }
                this.mAirplane.setContentDescription(this.mAirplaneContentDescription);
                this.mAirplane.setVisibility(0);
            } else {
                this.mAirplane.setVisibility(8);
            }
            if (this.mIsAirplaneMode && this.mWifiVisible) {
                this.mWifiAirplaneSpacer.setVisibility(0);
            } else {
                this.mWifiAirplaneSpacer.setVisibility(8);
            }
            if (((!anyMobileVisible || firstMobileTypeId == 0) && !this.mNoSimsVisible) || !this.mWifiVisible) {
                this.mWifiSignalSpacer.setVisibility(8);
            } else {
                this.mWifiSignalSpacer.setVisibility(0);
            }
            if (!(!this.mNoSimsVisible || this.mNoSims == null || this.mNoSimsDark == null)) {
                if (this.mNoSimsIcon == 0) {
                    this.mNoSimsIcon = getNoSimIcon();
                }
                if (this.mNoSimsIcon != 0) {
                    this.mNoSims.setImageResource(this.mNoSimsIcon);
                    this.mNoSimsDark.setImageResource(this.mNoSimsIcon);
                }
            }
            View view = this.mNoSimsCombo;
            if (this.mIsAirplaneMode || !this.mNoSimsVisible) {
                i = 8;
            }
            view.setVisibility(i);
        }
    }

    public void setIconTint(int tint, float darkIntensity) {
        boolean changed = (tint == this.mIconTint && darkIntensity == this.mDarkIntensity) ? false : true;
        this.mIconTint = tint;
        this.mDarkIntensity = darkIntensity;
        if (changed && isAttachedToWindow()) {
            applyIconTint();
        }
    }

    private void applyIconTint() {
        setTint(this.mVpn, this.mIconTint);
        setTint(this.mAirplane, this.mIconTint);
        applyDarkIntensity(this.mDarkIntensity, this.mNoSims, this.mNoSimsDark);
        applyDarkIntensity(this.mDarkIntensity, this.mWifi, this.mWifiDark);
        applyDarkIntensity(this.mDarkIntensity, this.mEthernet, this.mEthernetDark);
        for (int i = 0; i < this.mPhoneStates.size(); i++) {
            ((PhoneState) this.mPhoneStates.get(i)).setIconTint(this.mIconTint, this.mDarkIntensity);
        }
    }

    private void applyDarkIntensity(float darkIntensity, View lightIcon, View darkIcon) {
        lightIcon.setAlpha(1.0f - darkIntensity);
        darkIcon.setAlpha(darkIntensity);
    }

    private void setTint(ImageView v, int tint) {
        v.setImageTintList(ColorStateList.valueOf(tint));
    }
}
