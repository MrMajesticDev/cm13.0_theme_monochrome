package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewStub;
import android.view.ViewStub.OnInflateListener;
import android.view.WindowInsets;
import android.widget.FrameLayout;

public class NotificationsQuickSettingsContainer extends FrameLayout implements OnInflateListener {
    private boolean mInflated;
    private View mKeyguardStatusBar;
    private boolean mQsExpanded;
    private View mScrollView;
    private View mStackScroller;
    private View mUserSwitcher;

    public NotificationsQuickSettingsContainer(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mScrollView = findViewById(2131755285);
        this.mStackScroller = findViewById(2131755287);
        this.mKeyguardStatusBar = findViewById(2131755136);
        ViewStub userSwitcher = (ViewStub) findViewById(2131755288);
        userSwitcher.setOnInflateListener(this);
        this.mUserSwitcher = userSwitcher;
    }

    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        setPadding(0, 0, 0, insets.getSystemWindowInsetBottom());
        return insets;
    }

    protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
        boolean userSwitcherVisible;
        boolean statusBarVisible;
        if (this.mInflated && this.mUserSwitcher.getVisibility() == 0) {
            userSwitcherVisible = true;
        } else {
            userSwitcherVisible = false;
        }
        if (this.mKeyguardStatusBar.getVisibility() == 0) {
            statusBarVisible = true;
        } else {
            statusBarVisible = false;
        }
        View stackQsTop = this.mQsExpanded ? this.mStackScroller : this.mScrollView;
        View stackQsBottom = !this.mQsExpanded ? this.mStackScroller : this.mScrollView;
        if (child == this.mScrollView) {
            if (userSwitcherVisible && statusBarVisible) {
                stackQsBottom = this.mUserSwitcher;
            } else if (statusBarVisible) {
                stackQsBottom = this.mKeyguardStatusBar;
            } else if (userSwitcherVisible) {
                stackQsBottom = this.mUserSwitcher;
            }
            return super.drawChild(canvas, stackQsBottom, drawingTime);
        } else if (child == this.mStackScroller) {
            if (userSwitcherVisible && statusBarVisible) {
                stackQsTop = this.mKeyguardStatusBar;
            } else if (statusBarVisible || userSwitcherVisible) {
                stackQsTop = stackQsBottom;
            }
            return super.drawChild(canvas, stackQsTop, drawingTime);
        } else if (child == this.mUserSwitcher) {
            if (!(userSwitcherVisible && statusBarVisible)) {
                stackQsBottom = stackQsTop;
            }
            return super.drawChild(canvas, stackQsBottom, drawingTime);
        } else if (child == this.mKeyguardStatusBar) {
            return super.drawChild(canvas, stackQsTop, drawingTime);
        } else {
            return super.drawChild(canvas, child, drawingTime);
        }
    }

    public void onInflate(ViewStub stub, View inflated) {
        if (stub == this.mUserSwitcher) {
            this.mUserSwitcher = inflated;
            this.mInflated = true;
        }
    }

    public void setQsExpanded(boolean expanded) {
        if (this.mQsExpanded != expanded) {
            this.mQsExpanded = expanded;
            invalidate();
        }
    }
}
