package com.android.systemui.statusbar.policy;

import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;
import com.android.internal.util.AsyncChannel;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.policy.NetworkController.IconState;
import java.util.List;
import java.util.Objects;

public class WifiSignalController extends SignalController<WifiState, IconGroup> {
    private final boolean mHasMobileData;
    private final AsyncChannel mWifiChannel;
    private final WifiManager mWifiManager;

    private class WifiHandler extends Handler {
        private WifiHandler() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    WifiSignalController.this.setActivity(msg.arg1);
                case 69632:
                    if (msg.arg1 == 0) {
                        WifiSignalController.this.mWifiChannel.sendMessage(Message.obtain(this, 69633));
                    } else {
                        Log.e(WifiSignalController.this.mTag, "Failed to connect to wifi");
                    }
                default:
            }
        }
    }

    static class WifiState extends State {
        String ssid;

        WifiState() {
        }

        public void copyFrom(State s) {
            super.copyFrom(s);
            this.ssid = ((WifiState) s).ssid;
        }

        protected void toString(StringBuilder builder) {
            super.toString(builder);
            builder.append(',').append("ssid=").append(this.ssid);
        }

        public boolean equals(Object o) {
            return super.equals(o) && Objects.equals(((WifiState) o).ssid, this.ssid);
        }
    }

    public WifiSignalController(Context context, boolean hasMobileData, CallbackHandler callbackHandler, NetworkControllerImpl networkController) {
        super("WifiSignalController", context, 1, callbackHandler, networkController);
        this.mWifiManager = (WifiManager) context.getSystemService("wifi");
        this.mHasMobileData = hasMobileData;
        Handler handler = new WifiHandler();
        this.mWifiChannel = new AsyncChannel();
        Messenger wifiMessenger = this.mWifiManager.getWifiServiceMessenger();
        if (wifiMessenger != null) {
            this.mWifiChannel.connect(context, handler, wifiMessenger);
        }
        WifiState wifiState = (WifiState) this.mCurrentState;
        WifiState wifiState2 = (WifiState) this.mLastState;
        IconGroup iconGroup = new IconGroup("Wi-Fi Icons", WifiIcons.WIFI_SIGNAL_STRENGTH, WifiIcons.QS_WIFI_SIGNAL_STRENGTH, AccessibilityContentDescriptions.WIFI_CONNECTION_STRENGTH, 2130838153, 2130837692, 2130838153, 2130837692, 2131361868);
        wifiState2.iconGroup = iconGroup;
        wifiState.iconGroup = iconGroup;
    }

    protected WifiState cleanState() {
        return new WifiState();
    }

    public void notifyListeners() {
        boolean wifiVisible;
        boolean ssidPresent;
        boolean z;
        boolean visibleWhenEnabled = this.mContext.getResources().getBoolean(2131558418);
        if (((WifiState) this.mCurrentState).enabled && (((WifiState) this.mCurrentState).connected || !this.mHasMobileData || visibleWhenEnabled)) {
            wifiVisible = true;
        } else {
            wifiVisible = false;
        }
        String wifiDesc = wifiVisible ? ((WifiState) this.mCurrentState).ssid : null;
        if (!wifiVisible || ((WifiState) this.mCurrentState).ssid == null) {
            ssidPresent = false;
        } else {
            ssidPresent = true;
        }
        String contentDescription = getStringIfExists(getContentDescription());
        IconState statusIcon = new IconState(wifiVisible, getCurrentIconId(), contentDescription);
        IconState qsIcon = new IconState(((WifiState) this.mCurrentState).connected, getQsCurrentIconId(), contentDescription);
        CallbackHandler callbackHandler = this.mCallbackHandler;
        boolean z2 = ((WifiState) this.mCurrentState).enabled;
        if (ssidPresent && ((WifiState) this.mCurrentState).activityIn) {
            z = true;
        } else {
            z = false;
        }
        boolean z3 = ssidPresent && ((WifiState) this.mCurrentState).activityOut;
        callbackHandler.setWifiIndicators(z2, statusIcon, qsIcon, z, z3, wifiDesc);
    }

    public void handleBroadcast(Intent intent) {
        boolean z = true;
        String action = intent.getAction();
        WifiState wifiState;
        if (action.equals("android.net.wifi.WIFI_STATE_CHANGED")) {
            wifiState = (WifiState) this.mCurrentState;
            if (intent.getIntExtra("wifi_state", 4) != 3) {
                z = false;
            }
            wifiState.enabled = z;
        } else if (action.equals("android.net.wifi.STATE_CHANGE")) {
            NetworkInfo networkInfo = (NetworkInfo) intent.getParcelableExtra("networkInfo");
            wifiState = (WifiState) this.mCurrentState;
            if (networkInfo == null || !networkInfo.isConnected()) {
                z = false;
            }
            wifiState.connected = z;
            if (((WifiState) this.mCurrentState).connected) {
                WifiInfo info = intent.getParcelableExtra("wifiInfo") != null ? (WifiInfo) intent.getParcelableExtra("wifiInfo") : this.mWifiManager.getConnectionInfo();
                if (info != null) {
                    ((WifiState) this.mCurrentState).ssid = getSsid(info);
                } else {
                    ((WifiState) this.mCurrentState).ssid = null;
                }
            } else if (!((WifiState) this.mCurrentState).connected) {
                ((WifiState) this.mCurrentState).ssid = null;
            }
        } else if (action.equals("android.net.wifi.RSSI_CHANGED")) {
            ((WifiState) this.mCurrentState).rssi = intent.getIntExtra("newRssi", -200);
            ((WifiState) this.mCurrentState).level = WifiManager.calculateSignalLevel(((WifiState) this.mCurrentState).rssi, WifiIcons.WIFI_LEVEL_COUNT);
        }
        notifyListenersIfNecessary();
    }

    private String getSsid(WifiInfo info) {
        String ssid = info.getSSID();
        if (ssid != null) {
            return ssid;
        }
        List<WifiConfiguration> networks = this.mWifiManager.getConfiguredNetworks();
        int length = networks.size();
        for (int i = 0; i < length; i++) {
            if (((WifiConfiguration) networks.get(i)).networkId == info.getNetworkId()) {
                return ((WifiConfiguration) networks.get(i)).SSID;
            }
        }
        return null;
    }

    void setActivity(int wifiActivity) {
        boolean z = false;
        WifiState wifiState = (WifiState) this.mCurrentState;
        boolean z2 = wifiActivity == 3 || wifiActivity == 1;
        wifiState.activityIn = z2;
        wifiState = (WifiState) this.mCurrentState;
        if (wifiActivity == 3 || wifiActivity == 2) {
            z = true;
        }
        wifiState.activityOut = z;
        notifyListenersIfNecessary();
    }
}
