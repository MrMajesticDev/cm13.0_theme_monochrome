package com.android.keyguard;

import android.app.ActivityManager;
import android.app.ActivityManagerNative;
import android.app.AlarmManager;
import android.app.IUserSwitchObserver.Stub;
import android.app.PendingIntent;
import android.app.admin.DevicePolicyManager;
import android.app.trust.TrustManager;
import android.app.trust.TrustManager.TrustListener;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.AuthenticationCallback;
import android.hardware.fingerprint.FingerprintManager.AuthenticationResult;
import android.hardware.fingerprint.FingerprintManager.LockoutResetCallback;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.IRemoteCallback;
import android.os.Message;
import android.os.RemoteException;
import android.os.SystemClock;
import android.os.UserHandle;
import android.provider.Settings.Global;
import android.telephony.ServiceState;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.SubscriptionManager.OnSubscriptionsChangedListener;
import android.telephony.TelephonyManager;
import android.util.ArraySet;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import com.android.internal.telephony.IccCardConstants.State;
import com.android.internal.widget.LockPatternUtils;
import com.google.android.collect.Lists;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class KeyguardUpdateMonitor implements TrustListener {
    private static int sCurrentUser;
    private static KeyguardUpdateMonitor sInstance;
    private AlarmManager mAlarmManager;
    private AuthenticationCallback mAuthenticationCallback;
    private BatteryStatus mBatteryStatus;
    private boolean mBootCompleted;
    private boolean mBouncer;
    private final BroadcastReceiver mBroadcastAllReceiver;
    private final BroadcastReceiver mBroadcastReceiver;
    private final ArrayList<WeakReference<KeyguardUpdateMonitorCallback>> mCallbacks;
    private final Context mContext;
    private boolean mDeviceInteractive;
    private boolean mDeviceProvisioned;
    private ContentObserver mDeviceProvisionedObserver;
    private DisplayClientState mDisplayClientState;
    private SparseIntArray mFailedAttempts;
    private boolean mFingerprintAlreadyAuthenticated;
    private CancellationSignal mFingerprintCancelSignal;
    private int mFingerprintRunningState;
    private FingerprintManager mFpm;
    private boolean mGoingToSleep;
    private final Handler mHandler;
    private boolean mKeyguardIsVisible;
    private final LockoutResetCallback mLockoutResetCallback;
    private int mPhoneState;
    private int mRingMode;
    private boolean mScreenOn;
    HashMap<Integer, ServiceState> mServiceStates;
    HashMap<Integer, SimData> mSimDatas;
    private ArraySet<Integer> mStrongAuthNotTimedOut;
    private final BroadcastReceiver mStrongAuthTimeoutReceiver;
    private final StrongAuthTracker mStrongAuthTracker;
    private List<SubscriptionInfo> mSubscriptionInfo;
    private OnSubscriptionsChangedListener mSubscriptionListener;
    private SubscriptionManager mSubscriptionManager;
    private boolean mSwitchingUser;
    private TrustManager mTrustManager;
    private SparseBooleanArray mUserFaceUnlockRunning;
    private SparseBooleanArray mUserFingerprintAuthenticated;
    private SparseBooleanArray mUserHasTrust;
    private SparseBooleanArray mUserTrustIsManaged;

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.1 */
    class C00451 extends Handler {
        C00451() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 301:
                    KeyguardUpdateMonitor.this.handleTimeUpdate();
                case 302:
                    KeyguardUpdateMonitor.this.handleBatteryUpdate((BatteryStatus) msg.obj);
                case 304:
                    KeyguardUpdateMonitor.this.handleSimStateChange(msg.arg1, msg.arg2, (State) msg.obj);
                case 305:
                    KeyguardUpdateMonitor.this.handleRingerModeChange(msg.arg1);
                case 306:
                    KeyguardUpdateMonitor.this.handlePhoneStateChanged((String) msg.obj);
                case 308:
                    KeyguardUpdateMonitor.this.handleDeviceProvisioned();
                case 309:
                    KeyguardUpdateMonitor.this.handleDevicePolicyManagerStateChanged();
                case 310:
                    KeyguardUpdateMonitor.this.handleUserSwitching(msg.arg1, (IRemoteCallback) msg.obj);
                case 312:
                    KeyguardUpdateMonitor.this.handleKeyguardReset();
                case 313:
                    KeyguardUpdateMonitor.this.handleBootCompleted();
                case 314:
                    KeyguardUpdateMonitor.this.handleUserSwitchComplete(msg.arg1);
                case 317:
                    KeyguardUpdateMonitor.this.handleUserInfoChanged(msg.arg1);
                case 318:
                    KeyguardUpdateMonitor.this.handleReportEmergencyCallAction();
                case 319:
                    KeyguardUpdateMonitor.this.handleStartedWakingUp();
                case 320:
                    KeyguardUpdateMonitor.this.handleFinishedGoingToSleep(msg.arg1);
                case 321:
                    KeyguardUpdateMonitor.this.handleStartedGoingToSleep(msg.arg1);
                case 322:
                    KeyguardUpdateMonitor.this.handleKeyguardBouncerChanged(msg.arg1);
                case 327:
                    KeyguardUpdateMonitor.this.handleFaceUnlockStateChanged(msg.arg1 != 0, msg.arg2);
                case 328:
                    KeyguardUpdateMonitor.this.handleSimSubscriptionInfoChanged();
                case 329:
                    KeyguardUpdateMonitor.this.handleAirplaneModeChanged();
                case 330:
                    KeyguardUpdateMonitor.this.handleServiceStateChange(msg.arg1, (ServiceState) msg.obj);
                case 331:
                    KeyguardUpdateMonitor.this.handleScreenTurnedOn();
                case 332:
                    KeyguardUpdateMonitor.this.handleScreenTurnedOff();
                case 500:
                    KeyguardUpdateMonitor.this.handleLocaleChanged();
                default:
            }
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.2 */
    class C00462 extends OnSubscriptionsChangedListener {
        C00462() {
        }

        public void onSubscriptionsChanged() {
            KeyguardUpdateMonitor.this.mHandler.sendEmptyMessage(328);
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.3 */
    class C00473 extends BroadcastReceiver {
        C00473() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.TIME_TICK".equals(action) || "android.intent.action.TIME_SET".equals(action) || "android.intent.action.TIMEZONE_CHANGED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendEmptyMessage(301);
            } else if ("android.intent.action.BATTERY_CHANGED".equals(action)) {
                int status = intent.getIntExtra("status", 1);
                int plugged = intent.getIntExtra("plugged", 0);
                int level = intent.getIntExtra("level", 0);
                int health = intent.getIntExtra("health", 1);
                int maxChargingCurrent = intent.getIntExtra("max_charging_current", -1);
                KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(302, new BatteryStatus(status, level, plugged, health, maxChargingCurrent)));
            } else if ("android.intent.action.SIM_STATE_CHANGED".equals(action)) {
                SimData args = SimData.fromIntent(intent);
                KeyguardUpdateMonitor.this.mHandler.obtainMessage(304, args.subId, args.slotId, args.simState).sendToTarget();
            } else if ("android.media.RINGER_MODE_CHANGED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(305, intent.getIntExtra("android.media.EXTRA_RINGER_MODE", -1), 0));
            } else if ("android.intent.action.PHONE_STATE".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(306, intent.getStringExtra("state")));
            } else if ("android.intent.action.AIRPLANE_MODE".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendEmptyMessage(329);
            } else if ("android.intent.action.BOOT_COMPLETED".equals(action)) {
                KeyguardUpdateMonitor.this.dispatchBootCompleted();
            } else if ("android.intent.action.SERVICE_STATE".equals(action)) {
                ServiceState serviceState = ServiceState.newFromBundle(intent.getExtras());
                KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(330, intent.getIntExtra("subscription", -1), 0, serviceState));
            } else if ("android.intent.action.LOCALE_CHANGED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendEmptyMessage(500);
            }
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.4 */
    class C00484 extends BroadcastReceiver {
        C00484() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.app.action.NEXT_ALARM_CLOCK_CHANGED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendEmptyMessage(301);
            } else if ("android.intent.action.USER_INFO_CHANGED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(317, intent.getIntExtra("android.intent.extra.user_handle", getSendingUserId()), 0));
            } else if ("com.android.facelock.FACE_UNLOCK_STARTED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(327, 1, getSendingUserId()));
            } else if ("com.android.facelock.FACE_UNLOCK_STOPPED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(327, 0, getSendingUserId()));
            } else if ("android.app.action.DEVICE_POLICY_MANAGER_STATE_CHANGED".equals(action)) {
                KeyguardUpdateMonitor.this.mHandler.sendEmptyMessage(309);
            }
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.5 */
    class C00495 extends BroadcastReceiver {
        C00495() {
        }

        public void onReceive(Context context, Intent intent) {
            if ("com.android.systemui.ACTION_STRONG_AUTH_TIMEOUT".equals(intent.getAction())) {
                int userId = intent.getIntExtra("com.android.systemui.USER_ID", -1);
                KeyguardUpdateMonitor.this.mStrongAuthNotTimedOut.remove(Integer.valueOf(userId));
                KeyguardUpdateMonitor.this.notifyStrongAuthStateChanged(userId);
            }
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.6 */
    class C00506 extends LockoutResetCallback {
        C00506() {
        }

        public void onLockoutReset() {
            KeyguardUpdateMonitor.this.handleFingerprintLockoutReset();
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.7 */
    class C00517 extends AuthenticationCallback {
        C00517() {
        }

        public void onAuthenticationFailed() {
            KeyguardUpdateMonitor.this.handleFingerprintAuthFailed();
        }

        public void onAuthenticationSucceeded(AuthenticationResult result) {
            KeyguardUpdateMonitor.this.handleFingerprintAuthenticated();
        }

        public void onAuthenticationHelp(int helpMsgId, CharSequence helpString) {
            KeyguardUpdateMonitor.this.handleFingerprintHelp(helpMsgId, helpString.toString());
        }

        public void onAuthenticationError(int errMsgId, CharSequence errString) {
            KeyguardUpdateMonitor.this.handleFingerprintError(errMsgId, errString.toString());
        }

        public void onAuthenticationAcquired(int acquireInfo) {
            KeyguardUpdateMonitor.this.handleFingerprintAcquired(acquireInfo);
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.8 */
    class C00528 extends Stub {
        C00528() {
        }

        public void onUserSwitching(int newUserId, IRemoteCallback reply) {
            KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(310, newUserId, 0, reply));
        }

        public void onUserSwitchComplete(int newUserId) throws RemoteException {
            KeyguardUpdateMonitor.this.mHandler.sendMessage(KeyguardUpdateMonitor.this.mHandler.obtainMessage(314, newUserId, 0));
        }

        public void onForegroundProfileSwitch(int newProfileId) {
        }
    }

    /* renamed from: com.android.keyguard.KeyguardUpdateMonitor.9 */
    class C00539 extends ContentObserver {
        C00539(Handler x0) {
            super(x0);
        }

        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            KeyguardUpdateMonitor.this.mDeviceProvisioned = KeyguardUpdateMonitor.this.isDeviceProvisionedInSettingsDb();
            if (KeyguardUpdateMonitor.this.mDeviceProvisioned) {
                KeyguardUpdateMonitor.this.mHandler.sendEmptyMessage(308);
            }
        }
    }

    public static class BatteryStatus {
        public final int health;
        public final int level;
        public final int maxChargingCurrent;
        public final int plugged;
        public final int status;

        public BatteryStatus(int status, int level, int plugged, int health, int maxChargingCurrent) {
            this.status = status;
            this.level = level;
            this.plugged = plugged;
            this.health = health;
            this.maxChargingCurrent = maxChargingCurrent;
        }

        public boolean isPluggedIn() {
            return this.plugged == 1 || this.plugged == 2 || this.plugged == 4;
        }

        public boolean isCharged() {
            return this.status == 5 || this.level >= 100;
        }

        public boolean isBatteryLow() {
            return this.level < 20;
        }

        public final int getChargingSpeed(int slowThreshold, int fastThreshold) {
            if (this.maxChargingCurrent <= 0) {
                return -1;
            }
            if (this.maxChargingCurrent < slowThreshold) {
                return 0;
            }
            return this.maxChargingCurrent > fastThreshold ? 2 : 1;
        }
    }

    static class DisplayClientState {
        DisplayClientState() {
        }
    }

    private static class SimData {
        public State simState;
        public int slotId;
        public int subId;

        SimData(State state, int slot, int id) {
            this.simState = state;
            this.slotId = slot;
            this.subId = id;
        }

        static SimData fromIntent(Intent intent) {
            if ("android.intent.action.SIM_STATE_CHANGED".equals(intent.getAction())) {
                State state;
                String stateExtra = intent.getStringExtra("ss");
                int slotId = intent.getIntExtra("slot", 0);
                int subId = intent.getIntExtra("subscription", -1);
                if ("ABSENT".equals(stateExtra)) {
                    if ("PERM_DISABLED".equals(intent.getStringExtra("reason"))) {
                        state = State.PERM_DISABLED;
                    } else {
                        state = State.ABSENT;
                    }
                } else if ("READY".equals(stateExtra)) {
                    state = State.READY;
                } else if ("LOCKED".equals(stateExtra)) {
                    String lockedReason = intent.getStringExtra("reason");
                    if ("PIN".equals(lockedReason)) {
                        state = State.PIN_REQUIRED;
                    } else if ("PUK".equals(lockedReason)) {
                        state = State.PUK_REQUIRED;
                    } else if ("NETWORK".equals(lockedReason)) {
                        state = State.NETWORK_LOCKED;
                    } else {
                        state = State.UNKNOWN;
                    }
                } else if ("CARD_IO_ERROR".equals(stateExtra)) {
                    state = State.CARD_IO_ERROR;
                } else if ("LOADED".equals(stateExtra) || "IMSI".equals(stateExtra)) {
                    state = State.READY;
                } else if ("NOT_READY".equals(stateExtra) && TelephonyManager.getDefault().isMultiSimEnabled()) {
                    state = State.NOT_READY;
                } else {
                    state = State.UNKNOWN;
                }
                return new SimData(state, slotId, subId);
            }
            throw new IllegalArgumentException("only handles intent ACTION_SIM_STATE_CHANGED");
        }

        public String toString() {
            return "SimData{state=" + this.simState + ",slotId=" + this.slotId + ",subId=" + this.subId + "}";
        }
    }

    public class StrongAuthTracker extends com.android.internal.widget.LockPatternUtils.StrongAuthTracker {
        public boolean isUnlockingWithFingerprintAllowed() {
            return isFingerprintAllowedForUser(KeyguardUpdateMonitor.getCurrentUser());
        }

        public boolean hasUserAuthenticatedSinceBoot() {
            return (getStrongAuthForUser(KeyguardUpdateMonitor.getCurrentUser()) & 1) == 0;
        }

        public void onStrongAuthRequiredChanged(int userId) {
            KeyguardUpdateMonitor.this.notifyStrongAuthStateChanged(userId);
        }
    }

    public static synchronized void setCurrentUser(int currentUser) {
        synchronized (KeyguardUpdateMonitor.class) {
            sCurrentUser = currentUser;
        }
    }

    public static synchronized int getCurrentUser() {
        int i;
        synchronized (KeyguardUpdateMonitor.class) {
            i = sCurrentUser;
        }
        return i;
    }

    public void onTrustChanged(boolean enabled, int userId, int flags) {
        this.mUserHasTrust.put(userId, enabled);
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onTrustChanged(userId);
                if (enabled && flags != 0) {
                    cb.onTrustGrantedWithFlags(flags, userId);
                }
            }
        }
    }

    protected void handleSimSubscriptionInfoChanged() {
        int i;
        List<SubscriptionInfo> subscriptionInfos = getSubscriptionInfo(true);
        ArrayList<SubscriptionInfo> changedSubscriptions = new ArrayList();
        for (i = 0; i < subscriptionInfos.size(); i++) {
            SubscriptionInfo info = (SubscriptionInfo) subscriptionInfos.get(i);
            if (refreshSimState(info.getSubscriptionId(), info.getSimSlotIndex())) {
                changedSubscriptions.add(info);
            }
        }
        for (i = 0; i < changedSubscriptions.size(); i++) {
            int j;
            SimData data = (SimData) this.mSimDatas.get(Integer.valueOf(((SubscriptionInfo) changedSubscriptions.get(i)).getSubscriptionId()));
            for (j = 0; j < this.mCallbacks.size(); j++) {
                KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(j)).get();
                if (cb != null) {
                    cb.onSimStateChanged(data.subId, data.slotId, data.simState);
                }
            }
        }
        for (j = 0; j < this.mCallbacks.size(); j++) {
            cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(j)).get();
            if (cb != null) {
                cb.onRefreshCarrierInfo();
            }
        }
    }

    private void handleAirplaneModeChanged() {
        for (int j = 0; j < this.mCallbacks.size(); j++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(j)).get();
            if (cb != null) {
                cb.onRefreshCarrierInfo();
            }
        }
    }

    List<SubscriptionInfo> getSubscriptionInfo(boolean forceReload) {
        List<SubscriptionInfo> sil = this.mSubscriptionInfo;
        if (sil == null || forceReload) {
            sil = this.mSubscriptionManager.getActiveSubscriptionInfoList();
        }
        if (sil == null) {
            this.mSubscriptionInfo = new ArrayList();
        } else {
            this.mSubscriptionInfo = sil;
        }
        return this.mSubscriptionInfo;
    }

    public boolean isEmergencyOnly() {
        boolean isEmerg = false;
        for (int slotId = 0; slotId < TelephonyManager.getDefault().getPhoneCount(); slotId++) {
            ServiceState state = null;
            SubscriptionManager subscriptionManager = this.mSubscriptionManager;
            int[] subId = SubscriptionManager.getSubId(slotId);
            if (subId != null && subId.length > 0) {
                state = (ServiceState) this.mServiceStates.get(Integer.valueOf(subId[0]));
            }
            if (state != null) {
                if (state.getVoiceRegState() == 0) {
                    return false;
                }
                if (state.isEmergencyOnly()) {
                    isEmerg = true;
                }
            }
        }
        return isEmerg;
    }

    public int getPresentSubId() {
        for (int slotId = 0; slotId < TelephonyManager.getDefault().getPhoneCount(); slotId++) {
            SubscriptionManager subscriptionManager = this.mSubscriptionManager;
            int[] subId = SubscriptionManager.getSubId(slotId);
            if (subId != null && subId.length > 0 && getSimState(subId[0]) != State.ABSENT) {
                return subId[0];
            }
        }
        return -1;
    }

    public void onTrustManagedChanged(boolean managed, int userId) {
        this.mUserTrustIsManaged.put(userId, managed);
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onTrustManagedChanged(userId);
            }
        }
    }

    private void onFingerprintAuthenticated(int userId) {
        this.mUserFingerprintAuthenticated.put(userId, true);
        this.mFingerprintAlreadyAuthenticated = isUnlockingWithFingerprintAllowed();
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onFingerprintAuthenticated(userId);
            }
        }
    }

    private void handleFingerprintAuthFailed() {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onFingerprintAuthFailed();
            }
        }
        handleFingerprintHelp(-1, this.mContext.getString(C0065R.string.fingerprint_not_recognized));
    }

    private void handleFingerprintAcquired(int acquireInfo) {
        if (acquireInfo == 0) {
            for (int i = 0; i < this.mCallbacks.size(); i++) {
                KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
                if (cb != null) {
                    cb.onFingerprintAcquired();
                }
            }
        }
    }

    private void handleFingerprintAuthenticated() {
        try {
            int userId = ActivityManagerNative.getDefault().getCurrentUser().id;
            if (isFingerprintDisabled(userId)) {
                Log.d("KeyguardUpdateMonitor", "Fingerprint disabled by DPM for userId: " + userId);
                return;
            }
            onFingerprintAuthenticated(userId);
            setFingerprintRunningState(0);
        } catch (RemoteException e) {
            Log.e("KeyguardUpdateMonitor", "Failed to get current user id: ", e);
        } finally {
            setFingerprintRunningState(0);
        }
    }

    private void handleFingerprintHelp(int msgId, String helpString) {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onFingerprintHelp(msgId, helpString);
            }
        }
    }

    private void handleFingerprintError(int msgId, String errString) {
        if (msgId == 5 && this.mFingerprintRunningState == 3) {
            setFingerprintRunningState(0);
            startListeningForFingerprint();
        } else {
            setFingerprintRunningState(0);
        }
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onFingerprintError(msgId, errString);
            }
        }
    }

    private void handleFingerprintLockoutReset() {
        updateFingerprintListeningState();
    }

    private void setFingerprintRunningState(int fingerprintRunningState) {
        boolean wasRunning;
        boolean isRunning = true;
        if (this.mFingerprintRunningState == 1) {
            wasRunning = true;
        } else {
            wasRunning = false;
        }
        if (fingerprintRunningState != 1) {
            isRunning = false;
        }
        this.mFingerprintRunningState = fingerprintRunningState;
        if (wasRunning != isRunning) {
            notifyFingerprintRunningStateChanged();
        }
    }

    private void notifyFingerprintRunningStateChanged() {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onFingerprintRunningStateChanged(isFingerprintDetectionRunning());
            }
        }
    }

    private void handleFaceUnlockStateChanged(boolean running, int userId) {
        this.mUserFaceUnlockRunning.put(userId, running);
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onFaceUnlockStateChanged(running, userId);
            }
        }
    }

    public boolean isFaceUnlockRunning(int userId) {
        return this.mUserFaceUnlockRunning.get(userId);
    }

    public boolean isFingerprintDetectionRunning() {
        return this.mFingerprintRunningState == 1;
    }

    private boolean isTrustDisabled(int userId) {
        return isSimPinSecure();
    }

    private boolean isFingerprintDisabled(int userId) {
        DevicePolicyManager dpm = (DevicePolicyManager) this.mContext.getSystemService("device_policy");
        return !(dpm == null || (dpm.getKeyguardDisabledFeatures(null, userId) & 32) == 0) || isSimPinSecure();
    }

    public boolean getUserCanSkipBouncer(int userId) {
        return getUserHasTrust(userId) || (this.mUserFingerprintAuthenticated.get(userId) && isUnlockingWithFingerprintAllowed());
    }

    public boolean getUserHasTrust(int userId) {
        return !isTrustDisabled(userId) && this.mUserHasTrust.get(userId);
    }

    public boolean getUserTrustIsManaged(int userId) {
        return this.mUserTrustIsManaged.get(userId) && !isTrustDisabled(userId);
    }

    public boolean isUnlockingWithFingerprintAllowed() {
        return this.mStrongAuthTracker.isUnlockingWithFingerprintAllowed() && !hasFingerprintUnlockTimedOut(sCurrentUser);
    }

    public StrongAuthTracker getStrongAuthTracker() {
        return this.mStrongAuthTracker;
    }

    public boolean hasFingerprintUnlockTimedOut(int userId) {
        return !this.mStrongAuthNotTimedOut.contains(Integer.valueOf(userId));
    }

    public void reportSuccessfulStrongAuthUnlockAttempt() {
        this.mStrongAuthNotTimedOut.add(Integer.valueOf(sCurrentUser));
        scheduleStrongAuthTimeout();
        if (this.mFpm != null) {
            this.mFpm.resetTimeout(null);
        }
    }

    private void scheduleStrongAuthTimeout() {
        long when = SystemClock.elapsedRealtime() + 259200000;
        Intent intent = new Intent("com.android.systemui.ACTION_STRONG_AUTH_TIMEOUT");
        intent.putExtra("com.android.systemui.USER_ID", sCurrentUser);
        this.mAlarmManager.set(3, when, PendingIntent.getBroadcast(this.mContext, sCurrentUser, intent, 268435456));
        notifyStrongAuthStateChanged(sCurrentUser);
    }

    private void notifyStrongAuthStateChanged(int userId) {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onStrongAuthStateChanged(userId);
            }
        }
    }

    public static KeyguardUpdateMonitor getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new KeyguardUpdateMonitor(context);
        }
        return sInstance;
    }

    protected void handleStartedWakingUp() {
        updateFingerprintListeningState();
        int count = this.mCallbacks.size();
        for (int i = 0; i < count; i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onStartedWakingUp();
            }
        }
    }

    protected void handleStartedGoingToSleep(int arg1) {
        clearFingerprintRecognized();
        int count = this.mCallbacks.size();
        for (int i = 0; i < count; i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onStartedGoingToSleep(arg1);
            }
        }
        this.mGoingToSleep = true;
        this.mFingerprintAlreadyAuthenticated = false;
        updateFingerprintListeningState();
    }

    protected void handleFinishedGoingToSleep(int arg1) {
        this.mGoingToSleep = false;
        int count = this.mCallbacks.size();
        for (int i = 0; i < count; i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onFinishedGoingToSleep(arg1);
            }
        }
        updateFingerprintListeningState();
    }

    private void handleScreenTurnedOn() {
        int count = this.mCallbacks.size();
        for (int i = 0; i < count; i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onScreenTurnedOn();
            }
        }
    }

    private void handleScreenTurnedOff() {
        int count = this.mCallbacks.size();
        for (int i = 0; i < count; i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onScreenTurnedOff();
            }
        }
    }

    private void handleUserInfoChanged(int userId) {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onUserInfoChanged(userId);
            }
        }
    }

    private KeyguardUpdateMonitor(Context context) {
        this.mSimDatas = new HashMap();
        this.mServiceStates = new HashMap();
        this.mFailedAttempts = new SparseIntArray();
        this.mStrongAuthNotTimedOut = new ArraySet();
        this.mStrongAuthTracker = new StrongAuthTracker();
        this.mCallbacks = Lists.newArrayList();
        this.mFingerprintRunningState = 0;
        this.mHandler = new C00451();
        this.mSubscriptionListener = new C00462();
        this.mUserHasTrust = new SparseBooleanArray();
        this.mUserTrustIsManaged = new SparseBooleanArray();
        this.mUserFingerprintAuthenticated = new SparseBooleanArray();
        this.mUserFaceUnlockRunning = new SparseBooleanArray();
        this.mDisplayClientState = new DisplayClientState();
        this.mBroadcastReceiver = new C00473();
        this.mBroadcastAllReceiver = new C00484();
        this.mStrongAuthTimeoutReceiver = new C00495();
        this.mLockoutResetCallback = new C00506();
        this.mAuthenticationCallback = new C00517();
        this.mContext = context;
        this.mSubscriptionManager = SubscriptionManager.from(context);
        this.mAlarmManager = (AlarmManager) context.getSystemService(AlarmManager.class);
        this.mDeviceProvisioned = isDeviceProvisionedInSettingsDb();
        if (!this.mDeviceProvisioned) {
            watchForDeviceProvisioning();
        }
        this.mBatteryStatus = new BatteryStatus(1, 100, 0, 0, 0);
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.TIME_TICK");
        filter.addAction("android.intent.action.TIME_SET");
        filter.addAction("android.intent.action.BATTERY_CHANGED");
        filter.addAction("android.intent.action.TIMEZONE_CHANGED");
        filter.addAction("android.intent.action.AIRPLANE_MODE");
        filter.addAction("android.intent.action.LOCALE_CHANGED");
        filter.addAction("android.intent.action.SIM_STATE_CHANGED");
        filter.addAction("android.intent.action.SERVICE_STATE");
        filter.addAction("android.intent.action.PHONE_STATE");
        filter.addAction("android.media.RINGER_MODE_CHANGED");
        context.registerReceiver(this.mBroadcastReceiver, filter);
        IntentFilter bootCompleteFilter = new IntentFilter();
        bootCompleteFilter.setPriority(1000);
        bootCompleteFilter.addAction("android.intent.action.BOOT_COMPLETED");
        context.registerReceiver(this.mBroadcastReceiver, bootCompleteFilter);
        IntentFilter allUserFilter = new IntentFilter();
        allUserFilter.addAction("android.intent.action.USER_INFO_CHANGED");
        allUserFilter.addAction("android.app.action.NEXT_ALARM_CLOCK_CHANGED");
        allUserFilter.addAction("com.android.facelock.FACE_UNLOCK_STARTED");
        allUserFilter.addAction("com.android.facelock.FACE_UNLOCK_STOPPED");
        allUserFilter.addAction("android.app.action.DEVICE_POLICY_MANAGER_STATE_CHANGED");
        context.registerReceiverAsUser(this.mBroadcastAllReceiver, UserHandle.ALL, allUserFilter, null, null);
        this.mSubscriptionManager.addOnSubscriptionsChangedListener(this.mSubscriptionListener);
        try {
            ActivityManagerNative.getDefault().registerUserSwitchObserver(new C00528());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        IntentFilter strongAuthTimeoutFilter = new IntentFilter();
        strongAuthTimeoutFilter.addAction("com.android.systemui.ACTION_STRONG_AUTH_TIMEOUT");
        context.registerReceiver(this.mStrongAuthTimeoutReceiver, strongAuthTimeoutFilter, "com.android.systemui.permission.SELF", null);
        this.mTrustManager = (TrustManager) context.getSystemService("trust");
        this.mTrustManager.registerTrustListener(this);
        new LockPatternUtils(context).registerStrongAuthTracker(this.mStrongAuthTracker);
        this.mFpm = (FingerprintManager) context.getSystemService("fingerprint");
        updateFingerprintListeningState();
        if (this.mFpm != null) {
            this.mFpm.addLockoutResetCallback(this.mLockoutResetCallback);
        }
    }

    private void updateFingerprintListeningState() {
        boolean shouldListenForFingerprint = shouldListenForFingerprint();
        if (this.mFingerprintRunningState == 1 && !shouldListenForFingerprint) {
            stopListeningForFingerprint();
        } else if (this.mFingerprintRunningState != 1 && shouldListenForFingerprint) {
            startListeningForFingerprint();
        }
    }

    private boolean shouldListenForFingerprint() {
        return ((!this.mKeyguardIsVisible && this.mDeviceInteractive && !this.mBouncer && !this.mGoingToSleep) || this.mSwitchingUser || this.mFingerprintAlreadyAuthenticated || isFingerprintDisabled(getCurrentUser())) ? false : true;
    }

    private void startListeningForFingerprint() {
        if (this.mFingerprintRunningState == 2) {
            setFingerprintRunningState(3);
            return;
        }
        int userId = ActivityManager.getCurrentUser();
        if (isUnlockWithFingerprintPossible(userId)) {
            if (this.mFingerprintCancelSignal != null) {
                this.mFingerprintCancelSignal.cancel();
            }
            this.mFingerprintCancelSignal = new CancellationSignal();
            this.mFpm.authenticate(null, this.mFingerprintCancelSignal, 0, this.mAuthenticationCallback, null, userId);
            setFingerprintRunningState(1);
        }
    }

    public boolean isUnlockWithFingerprintPossible(int userId) {
        return this.mFpm != null && this.mFpm.isHardwareDetected() && !isFingerprintDisabled(userId) && this.mFpm.getEnrolledFingerprints(userId).size() > 0;
    }

    private void stopListeningForFingerprint() {
        if (this.mFingerprintRunningState == 1) {
            this.mFingerprintCancelSignal.cancel();
            this.mFingerprintCancelSignal = null;
            setFingerprintRunningState(2);
        }
        if (this.mFingerprintRunningState == 3) {
            setFingerprintRunningState(2);
        }
    }

    private boolean isDeviceProvisionedInSettingsDb() {
        return Global.getInt(this.mContext.getContentResolver(), "device_provisioned", 0) != 0;
    }

    private void watchForDeviceProvisioning() {
        this.mDeviceProvisionedObserver = new C00539(this.mHandler);
        this.mContext.getContentResolver().registerContentObserver(Global.getUriFor("device_provisioned"), false, this.mDeviceProvisionedObserver);
        boolean provisioned = isDeviceProvisionedInSettingsDb();
        if (provisioned != this.mDeviceProvisioned) {
            this.mDeviceProvisioned = provisioned;
            if (this.mDeviceProvisioned) {
                this.mHandler.sendEmptyMessage(308);
            }
        }
    }

    protected void handleDevicePolicyManagerStateChanged() {
        updateFingerprintListeningState();
        for (int i = this.mCallbacks.size() - 1; i >= 0; i--) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onDevicePolicyManagerStateChanged();
            }
        }
    }

    protected void handleUserSwitching(int userId, IRemoteCallback reply) {
        this.mSwitchingUser = true;
        updateFingerprintListeningState();
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onUserSwitching(userId);
            }
        }
        try {
            reply.sendResult(null);
        } catch (RemoteException e) {
        }
    }

    protected void handleUserSwitchComplete(int userId) {
        this.mSwitchingUser = false;
        updateFingerprintListeningState();
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onUserSwitchComplete(userId);
            }
        }
    }

    public void dispatchBootCompleted() {
        this.mHandler.sendEmptyMessage(313);
    }

    protected void handleBootCompleted() {
        if (!this.mBootCompleted) {
            this.mBootCompleted = true;
            for (int i = 0; i < this.mCallbacks.size(); i++) {
                KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
                if (cb != null) {
                    cb.onBootCompleted();
                }
            }
        }
    }

    protected void handleDeviceProvisioned() {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onDeviceProvisioned();
            }
        }
        if (this.mDeviceProvisionedObserver != null) {
            this.mContext.getContentResolver().unregisterContentObserver(this.mDeviceProvisionedObserver);
            this.mDeviceProvisionedObserver = null;
        }
    }

    protected void handlePhoneStateChanged(String newState) {
        if (TelephonyManager.EXTRA_STATE_IDLE.equals(newState)) {
            this.mPhoneState = 0;
        } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(newState)) {
            this.mPhoneState = 2;
        } else if (TelephonyManager.EXTRA_STATE_RINGING.equals(newState)) {
            this.mPhoneState = 1;
        }
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onPhoneStateChanged(this.mPhoneState);
            }
        }
    }

    protected void handleRingerModeChange(int mode) {
        this.mRingMode = mode;
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onRingerModeChanged(mode);
            }
        }
    }

    private void handleTimeUpdate() {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onTimeChanged();
            }
        }
    }

    private void handleBatteryUpdate(BatteryStatus status) {
        boolean batteryUpdateInteresting = isBatteryUpdateInteresting(this.mBatteryStatus, status);
        this.mBatteryStatus = status;
        if (batteryUpdateInteresting) {
            for (int i = 0; i < this.mCallbacks.size(); i++) {
                KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
                if (cb != null) {
                    cb.onRefreshBatteryInfo(status);
                }
            }
        }
    }

    private void handleSimStateChange(int subId, int slotId, State state) {
        if (SubscriptionManager.isValidSubscriptionId(subId)) {
            boolean changed;
            SimData data = (SimData) this.mSimDatas.get(Integer.valueOf(subId));
            if (data == null) {
                this.mSimDatas.put(Integer.valueOf(subId), new SimData(state, slotId, subId));
                changed = true;
            } else {
                changed = (data.simState == state && data.subId == subId && data.slotId == slotId) ? false : true;
                data.simState = state;
                data.subId = subId;
                data.slotId = slotId;
            }
            if (changed && state != State.UNKNOWN) {
                for (int i = 0; i < this.mCallbacks.size(); i++) {
                    KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
                    if (cb != null) {
                        cb.onSimStateChanged(subId, slotId, state);
                    }
                }
                return;
            }
            return;
        }
        Log.w("KeyguardUpdateMonitor", "invalid subId in handleSimStateChange()");
    }

    private void handleLocaleChanged() {
        for (int j = 0; j < this.mCallbacks.size(); j++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(j)).get();
            if (cb != null) {
                cb.onRefreshCarrierInfo();
            }
        }
    }

    private void handleServiceStateChange(int subId, ServiceState serviceState) {
        if (SubscriptionManager.isValidSubscriptionId(subId)) {
            this.mServiceStates.put(Integer.valueOf(subId), serviceState);
            for (int j = 0; j < this.mCallbacks.size(); j++) {
                KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(j)).get();
                if (cb != null) {
                    cb.onRefreshCarrierInfo();
                    cb.onServiceStateChanged(subId, serviceState);
                }
            }
            return;
        }
        Log.w("KeyguardUpdateMonitor", "invalid subId in handleServiceStateChange()");
    }

    public void onKeyguardVisibilityChanged(boolean showing) {
        this.mKeyguardIsVisible = showing;
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onKeyguardVisibilityChangedRaw(showing);
            }
        }
        if (!showing) {
            this.mFingerprintAlreadyAuthenticated = false;
        }
        updateFingerprintListeningState();
    }

    private void handleKeyguardReset() {
        updateFingerprintListeningState();
    }

    private void handleKeyguardBouncerChanged(int bouncer) {
        boolean isBouncer = true;
        if (bouncer != 1) {
            isBouncer = false;
        }
        this.mBouncer = isBouncer;
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onKeyguardBouncerChanged(isBouncer);
            }
        }
        updateFingerprintListeningState();
    }

    private void handleReportEmergencyCallAction() {
        for (int i = 0; i < this.mCallbacks.size(); i++) {
            KeyguardUpdateMonitorCallback cb = (KeyguardUpdateMonitorCallback) ((WeakReference) this.mCallbacks.get(i)).get();
            if (cb != null) {
                cb.onEmergencyCallAction();
            }
        }
    }

    private static boolean isBatteryUpdateInteresting(BatteryStatus old, BatteryStatus current) {
        boolean nowPluggedIn = current.isPluggedIn();
        boolean wasPluggedIn = old.isPluggedIn();
        boolean stateChangedWhilePluggedIn;
        if (wasPluggedIn && nowPluggedIn && old.status != current.status) {
            stateChangedWhilePluggedIn = true;
        } else {
            stateChangedWhilePluggedIn = false;
        }
        if (wasPluggedIn != nowPluggedIn || stateChangedWhilePluggedIn) {
            return true;
        }
        if (nowPluggedIn && old.level != current.level) {
            return true;
        }
        if (!nowPluggedIn && current.isBatteryLow() && current.level != old.level) {
            return true;
        }
        if (!nowPluggedIn || current.maxChargingCurrent == old.maxChargingCurrent) {
            return false;
        }
        return true;
    }

    public void removeCallback(KeyguardUpdateMonitorCallback callback) {
        for (int i = this.mCallbacks.size() - 1; i >= 0; i--) {
            if (((WeakReference) this.mCallbacks.get(i)).get() == callback) {
                this.mCallbacks.remove(i);
            }
        }
    }

    public void registerCallback(KeyguardUpdateMonitorCallback callback) {
        int i = 0;
        while (i < this.mCallbacks.size()) {
            if (((WeakReference) this.mCallbacks.get(i)).get() != callback) {
                i++;
            } else {
                return;
            }
        }
        this.mCallbacks.add(new WeakReference(callback));
        removeCallback(null);
        sendUpdates(callback);
    }

    private void sendUpdates(KeyguardUpdateMonitorCallback callback) {
        callback.onRefreshBatteryInfo(this.mBatteryStatus);
        callback.onTimeChanged();
        callback.onRingerModeChanged(this.mRingMode);
        callback.onPhoneStateChanged(this.mPhoneState);
        callback.onRefreshCarrierInfo();
        callback.onClockVisibilityChanged();
        for (Entry<Integer, SimData> data : this.mSimDatas.entrySet()) {
            SimData state = (SimData) data.getValue();
            callback.onSimStateChanged(state.subId, state.slotId, state.simState);
        }
    }

    public void sendKeyguardReset() {
        this.mHandler.obtainMessage(312).sendToTarget();
    }

    public void sendKeyguardBouncerChanged(boolean showingBouncer) {
        Message message = this.mHandler.obtainMessage(322);
        message.arg1 = showingBouncer ? 1 : 0;
        message.sendToTarget();
    }

    public void reportSimUnlocked(int subId) {
        handleSimStateChange(subId, SubscriptionManager.getSlotId(subId), State.READY);
    }

    public void reportEmergencyCallAction(boolean bypassHandler) {
        if (bypassHandler) {
            handleReportEmergencyCallAction();
        } else {
            this.mHandler.obtainMessage(318).sendToTarget();
        }
    }

    public boolean isDeviceProvisioned() {
        return this.mDeviceProvisioned;
    }

    public void clearFailedUnlockAttempts() {
        this.mFailedAttempts.delete(sCurrentUser);
    }

    public int getFailedUnlockAttempts() {
        return this.mFailedAttempts.get(sCurrentUser, 0);
    }

    public void reportFailedStrongAuthUnlockAttempt() {
        this.mFailedAttempts.put(sCurrentUser, getFailedUnlockAttempts() + 1);
    }

    public void clearFingerprintRecognized() {
        this.mUserFingerprintAuthenticated.clear();
    }

    public boolean isSimPinVoiceSecure() {
        return isSimPinSecure();
    }

    public boolean isSimPinSecure() {
        for (SubscriptionInfo info : getSubscriptionInfo(false)) {
            if (isSimPinSecure(getSimState(info.getSubscriptionId()))) {
                return true;
            }
        }
        return false;
    }

    public State getSimState(int subId) {
        if (this.mSimDatas.containsKey(Integer.valueOf(subId))) {
            return ((SimData) this.mSimDatas.get(Integer.valueOf(subId))).simState;
        }
        return State.UNKNOWN;
    }

    public boolean isOOS() {
        for (Integer intValue : this.mServiceStates.keySet()) {
            ServiceState state = (ServiceState) this.mServiceStates.get(Integer.valueOf(intValue.intValue()));
            if (state.getVoiceRegState() == 1 || state.getVoiceRegState() == 3) {
                if (state.isEmergencyOnly()) {
                }
            }
            return false;
        }
        return true;
    }

    private boolean refreshSimState(int subId, int slotId) {
        State state;
        int simState = TelephonyManager.from(this.mContext).getSimState(slotId);
        try {
            state = State.intToState(simState);
        } catch (IllegalArgumentException e) {
            Log.w("KeyguardUpdateMonitor", "Unknown sim state: " + simState);
            state = State.UNKNOWN;
        }
        SimData data = (SimData) this.mSimDatas.get(Integer.valueOf(subId));
        if (data == null) {
            this.mSimDatas.put(Integer.valueOf(subId), new SimData(state, slotId, subId));
            return true;
        }
        boolean changed = data.simState != state;
        data.simState = state;
        return changed;
    }

    public static boolean isSimPinSecure(State state) {
        State simState = state;
        return simState == State.PIN_REQUIRED || simState == State.PUK_REQUIRED || simState == State.PERM_DISABLED;
    }

    public void dispatchStartedWakingUp() {
        synchronized (this) {
            this.mDeviceInteractive = true;
        }
        this.mHandler.sendEmptyMessage(319);
    }

    public void dispatchStartedGoingToSleep(int why) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(321, why, 0));
    }

    public void dispatchFinishedGoingToSleep(int why) {
        synchronized (this) {
            this.mDeviceInteractive = false;
        }
        this.mHandler.sendMessage(this.mHandler.obtainMessage(320, why, 0));
    }

    public void dispatchScreenTurnedOn() {
        synchronized (this) {
            this.mScreenOn = true;
        }
        this.mHandler.sendEmptyMessage(331);
    }

    public void dispatchScreenTurnedOff() {
        synchronized (this) {
            this.mScreenOn = false;
        }
        this.mHandler.sendEmptyMessage(332);
    }

    public boolean isDeviceInteractive() {
        return this.mDeviceInteractive;
    }

    public boolean isGoingToSleep() {
        return this.mGoingToSleep;
    }

    public int getNextSubIdForState(State state) {
        List<SubscriptionInfo> list = getSubscriptionInfo(false);
        int resultId = -1;
        int bestSlotId = Integer.MAX_VALUE;
        for (int i = 0; i < list.size(); i++) {
            int id = ((SubscriptionInfo) list.get(i)).getSubscriptionId();
            int slotId = SubscriptionManager.getSlotId(id);
            if (state == getSimState(id) && bestSlotId > slotId) {
                resultId = id;
                bestSlotId = slotId;
            }
        }
        return resultId;
    }

    public SubscriptionInfo getSubscriptionInfoForSubId(int subId) {
        List<SubscriptionInfo> list = getSubscriptionInfo(false);
        for (int i = 0; i < list.size(); i++) {
            SubscriptionInfo info = (SubscriptionInfo) list.get(i);
            if (subId == info.getSubscriptionId()) {
                return info;
            }
        }
        return null;
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        pw.println("KeyguardUpdateMonitor state:");
        pw.println("  SIM States:");
        for (SimData data : this.mSimDatas.values()) {
            pw.println("    " + data.toString());
        }
        pw.println("  Subs:");
        if (this.mSubscriptionInfo != null) {
            for (int i = 0; i < this.mSubscriptionInfo.size(); i++) {
                pw.println("    " + this.mSubscriptionInfo.get(i));
            }
        }
        pw.println("  Service states:");
        for (Integer intValue : this.mServiceStates.keySet()) {
            int subId = intValue.intValue();
            pw.println("    " + subId + "=" + this.mServiceStates.get(Integer.valueOf(subId)));
        }
    }
}
