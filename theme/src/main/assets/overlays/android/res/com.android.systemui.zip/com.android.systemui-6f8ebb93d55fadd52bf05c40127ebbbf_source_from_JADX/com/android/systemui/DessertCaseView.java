package com.android.systemui;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import java.util.HashSet;
import java.util.Set;

public class DessertCaseView extends FrameLayout {
    private static final float[] ALPHA_MASK;
    private static final float[] MASK;
    private static final int NUM_PASTRIES;
    private static final int[] PASTRIES;
    private static final int[] RARE_PASTRIES;
    private static final String TAG;
    private static final float[] WHITE_MASK;
    private static final int[] XRARE_PASTRIES;
    private static final int[] XXRARE_PASTRIES;
    float[] hsv;
    private int mCellSize;
    private View[] mCells;
    private int mColumns;
    private SparseArray<Drawable> mDrawables;
    private final Set<Point> mFreeList;
    private final Handler mHandler;
    private int mHeight;
    private final Runnable mJuggle;
    private int mRows;
    private boolean mStarted;
    private int mWidth;
    private final HashSet<View> tmpSet;

    /* renamed from: com.android.systemui.DessertCaseView.1 */
    class C00871 implements Runnable {
        C00871() {
        }

        public void run() {
            int N = DessertCaseView.this.getChildCount();
            for (int i = 0; i < 1; i++) {
                DessertCaseView.this.place(DessertCaseView.this.getChildAt((int) (Math.random() * ((double) N))), true);
            }
            DessertCaseView.this.fillFreeList();
            if (DessertCaseView.this.mStarted) {
                DessertCaseView.this.mHandler.postDelayed(DessertCaseView.this.mJuggle, 2000);
            }
        }
    }

    /* renamed from: com.android.systemui.DessertCaseView.2 */
    class C00892 implements OnClickListener {
        final /* synthetic */ ImageView val$v;

        /* renamed from: com.android.systemui.DessertCaseView.2.1 */
        class C00881 implements Runnable {
            C00881() {
            }

            public void run() {
                DessertCaseView.this.fillFreeList();
            }
        }

        C00892(ImageView imageView) {
            this.val$v = imageView;
        }

        public void onClick(View view) {
            DessertCaseView.this.place(this.val$v, true);
            DessertCaseView.this.postDelayed(new C00881(), 250);
        }
    }

    /* renamed from: com.android.systemui.DessertCaseView.3 */
    class C00903 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$v;

        C00903(View view) {
            this.val$v = view;
        }

        public void onAnimationStart(Animator animator) {
            this.val$v.setLayerType(2, null);
            this.val$v.buildLayer();
        }

        public void onAnimationEnd(Animator animator) {
            this.val$v.setLayerType(0, null);
        }
    }

    /* renamed from: com.android.systemui.DessertCaseView.4 */
    class C00914 implements AnimatorListener {
        final /* synthetic */ View val$squatter;

        C00914(View view) {
            this.val$squatter = view;
        }

        public void onAnimationStart(Animator animator) {
        }

        public void onAnimationEnd(Animator animator) {
            DessertCaseView.this.removeView(this.val$squatter);
        }

        public void onAnimationCancel(Animator animator) {
        }

        public void onAnimationRepeat(Animator animator) {
        }
    }

    public static class RescalingContainer extends FrameLayout {
        private DessertCaseView mView;

        public RescalingContainer(Context context) {
            super(context);
            setSystemUiVisibility(5638);
        }

        public void setView(DessertCaseView v) {
            addView(v);
            this.mView = v;
        }

        protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
            float w = (float) (right - left);
            float h = (float) (bottom - top);
            DessertCaseView dessertCaseView = this.mView;
            int w2 = (int) ((w / 0.25f) / 2.0f);
            dessertCaseView = this.mView;
            int h2 = (int) ((h / 0.25f) / 2.0f);
            int cx = (int) (((float) left) + (0.5f * w));
            int cy = (int) (((float) top) + (0.5f * h));
            this.mView.layout(cx - w2, cy - h2, cx + w2, cy + h2);
        }
    }

    static {
        TAG = DessertCaseView.class.getSimpleName();
        PASTRIES = new int[]{2130837528, 2130837514};
        RARE_PASTRIES = new int[]{2130837515, 2130837517, 2130837519, 2130837521, 2130837522, 2130837523, 2130837524, 2130837526, 2130837530};
        XRARE_PASTRIES = new int[]{2130837531, 2130837518, 2130837520, 2130837527, 2130837529};
        XXRARE_PASTRIES = new int[]{2130837532, 2130837516, 2130837525};
        NUM_PASTRIES = ((PASTRIES.length + RARE_PASTRIES.length) + XRARE_PASTRIES.length) + XXRARE_PASTRIES.length;
        MASK = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        ALPHA_MASK = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f};
        WHITE_MASK = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 0.0f, 255.0f, 0.0f, 0.0f, 0.0f, 0.0f, 255.0f, -1.0f, 0.0f, 0.0f, 0.0f, 255.0f};
    }

    public DessertCaseView(Context context) {
        this(context, null);
    }

    public DessertCaseView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DessertCaseView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mDrawables = new SparseArray(NUM_PASTRIES);
        this.mFreeList = new HashSet();
        this.mHandler = new Handler();
        this.mJuggle = new C00871();
        this.hsv = new float[]{0.0f, 1.0f, 0.85f};
        this.tmpSet = new HashSet();
        Resources res = getResources();
        this.mStarted = false;
        this.mCellSize = res.getDimensionPixelSize(2131296342);
        Options opts = new Options();
        if (this.mCellSize < 512) {
            opts.inSampleSize = 2;
        }
        opts.inMutable = true;
        Bitmap loaded = null;
        for (int[] arr$ : new int[][]{PASTRIES, RARE_PASTRIES, XRARE_PASTRIES, XXRARE_PASTRIES}) {
            for (int resid : r1[r5]) {
                opts.inBitmap = loaded;
                loaded = BitmapFactory.decodeResource(res, resid, opts);
                BitmapDrawable d = new BitmapDrawable(res, convertToAlphaMask(loaded));
                d.setColorFilter(new ColorMatrixColorFilter(ALPHA_MASK));
                d.setBounds(0, 0, this.mCellSize, this.mCellSize);
                this.mDrawables.append(resid, d);
            }
        }
    }

    private static Bitmap convertToAlphaMask(Bitmap b) {
        Bitmap a = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Config.ALPHA_8);
        Canvas c = new Canvas(a);
        Paint pt = new Paint();
        pt.setColorFilter(new ColorMatrixColorFilter(MASK));
        c.drawBitmap(b, 0.0f, 0.0f, pt);
        return a;
    }

    public void start() {
        if (!this.mStarted) {
            this.mStarted = true;
            fillFreeList(2000);
        }
        this.mHandler.postDelayed(this.mJuggle, 5000);
    }

    public void stop() {
        this.mStarted = false;
        this.mHandler.removeCallbacks(this.mJuggle);
    }

    int pick(int[] a) {
        return a[(int) (Math.random() * ((double) a.length))];
    }

    int random_color() {
        this.hsv[0] = ((float) irand(0, 12)) * 30.0f;
        return Color.HSVToColor(this.hsv);
    }

    protected synchronized void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!(this.mWidth == w && this.mHeight == h)) {
            boolean wasStarted = this.mStarted;
            if (wasStarted) {
                stop();
            }
            this.mWidth = w;
            this.mHeight = h;
            this.mCells = null;
            removeAllViewsInLayout();
            this.mFreeList.clear();
            this.mRows = this.mHeight / this.mCellSize;
            this.mColumns = this.mWidth / this.mCellSize;
            this.mCells = new View[(this.mRows * this.mColumns)];
            setScaleX(0.25f);
            setScaleY(0.25f);
            setTranslationX((((float) (this.mWidth - (this.mCellSize * this.mColumns))) * 0.5f) * 0.25f);
            setTranslationY((((float) (this.mHeight - (this.mCellSize * this.mRows))) * 0.5f) * 0.25f);
            for (int j = 0; j < this.mRows; j++) {
                for (int i = 0; i < this.mColumns; i++) {
                    this.mFreeList.add(new Point(i, j));
                }
            }
            if (wasStarted) {
                start();
            }
        }
    }

    public void fillFreeList() {
        fillFreeList(500);
    }

    public synchronized void fillFreeList(int animationLen) {
        Context ctx = getContext();
        LayoutParams lp = new LayoutParams(this.mCellSize, this.mCellSize);
        while (!this.mFreeList.isEmpty()) {
            Point pt = (Point) this.mFreeList.iterator().next();
            this.mFreeList.remove(pt);
            if (this.mCells[(this.mColumns * pt.y) + pt.x] == null) {
                Drawable d;
                ImageView v = new ImageView(ctx);
                v.setOnClickListener(new C00892(v));
                v.setBackgroundColor(random_color());
                float which = frand();
                if (which < 5.0E-4f) {
                    d = (Drawable) this.mDrawables.get(pick(XXRARE_PASTRIES));
                } else if (which < 0.005f) {
                    d = (Drawable) this.mDrawables.get(pick(XRARE_PASTRIES));
                } else if (which < 0.5f) {
                    d = (Drawable) this.mDrawables.get(pick(RARE_PASTRIES));
                } else if (which < 0.7f) {
                    d = (Drawable) this.mDrawables.get(pick(PASTRIES));
                } else {
                    d = null;
                }
                if (d != null) {
                    v.getOverlay().add(d);
                }
                int i = this.mCellSize;
                lp.height = i;
                lp.width = i;
                addView(v, lp);
                place(v, pt, false);
                if (animationLen > 0) {
                    float s = (float) ((Integer) v.getTag(33554434)).intValue();
                    v.setScaleX(0.5f * s);
                    v.setScaleY(0.5f * s);
                    v.setAlpha(0.0f);
                    v.animate().withLayer().scaleX(s).scaleY(s).alpha(1.0f).setDuration((long) animationLen);
                }
            }
        }
    }

    public void place(View v, boolean animate) {
        place(v, new Point(irand(0, this.mColumns), irand(0, this.mRows)), animate);
    }

    private final AnimatorListener makeHardwareLayerListener(View v) {
        return new C00903(v);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void place(android.view.View r28, android.graphics.Point r29, boolean r30) {
        /*
        r27 = this;
        monitor-enter(r27);
        r0 = r29;
        r5 = r0.x;	 Catch:{ all -> 0x01af }
        r0 = r29;
        r8 = r0.y;	 Catch:{ all -> 0x01af }
        r12 = frand();	 Catch:{ all -> 0x01af }
        r19 = 33554433; // 0x2000001 float:9.403956E-38 double:1.65780926E-316;
        r0 = r28;
        r1 = r19;
        r19 = r0.getTag(r1);	 Catch:{ all -> 0x01af }
        if (r19 == 0) goto L_0x004e;
    L_0x001a:
        r4 = r27.getOccupied(r28);	 Catch:{ all -> 0x01af }
        r9 = r4.length;	 Catch:{ all -> 0x01af }
        r6 = 0;
    L_0x0020:
        if (r6 >= r9) goto L_0x004e;
    L_0x0022:
        r10 = r4[r6];	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mFreeList;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r19;
        r0.add(r10);	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mCells;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r10.y;	 Catch:{ all -> 0x01af }
        r20 = r0;
        r0 = r27;
        r0 = r0.mColumns;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 * r21;
        r0 = r10.x;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 + r21;
        r21 = 0;
        r19[r20] = r21;	 Catch:{ all -> 0x01af }
        r6 = r6 + 1;
        goto L_0x0020;
    L_0x004e:
        r14 = 1;
        r19 = 1008981770; // 0x3c23d70a float:0.01 double:4.9850323E-315;
        r19 = (r12 > r19 ? 1 : (r12 == r19 ? 0 : -1));
        if (r19 >= 0) goto L_0x00cb;
    L_0x0056:
        r0 = r27;
        r0 = r0.mColumns;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 + -3;
        r0 = r19;
        if (r5 >= r0) goto L_0x006f;
    L_0x0062:
        r0 = r27;
        r0 = r0.mRows;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 + -3;
        r0 = r19;
        if (r8 >= r0) goto L_0x006f;
    L_0x006e:
        r14 = 4;
    L_0x006f:
        r19 = 33554433; // 0x2000001 float:9.403956E-38 double:1.65780926E-316;
        r0 = r28;
        r1 = r19;
        r2 = r29;
        r0.setTag(r1, r2);	 Catch:{ all -> 0x01af }
        r19 = 33554434; // 0x2000002 float:9.403957E-38 double:1.6578093E-316;
        r20 = java.lang.Integer.valueOf(r14);	 Catch:{ all -> 0x01af }
        r0 = r28;
        r1 = r19;
        r2 = r20;
        r0.setTag(r1, r2);	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.tmpSet;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19.clear();	 Catch:{ all -> 0x01af }
        r11 = r27.getOccupied(r28);	 Catch:{ all -> 0x01af }
        r4 = r11;
        r9 = r4.length;	 Catch:{ all -> 0x01af }
        r6 = 0;
    L_0x009b:
        if (r6 >= r9) goto L_0x010e;
    L_0x009d:
        r10 = r4[r6];	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mCells;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r10.y;	 Catch:{ all -> 0x01af }
        r20 = r0;
        r0 = r27;
        r0 = r0.mColumns;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 * r21;
        r0 = r10.x;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 + r21;
        r18 = r19[r20];	 Catch:{ all -> 0x01af }
        if (r18 == 0) goto L_0x00c8;
    L_0x00bb:
        r0 = r27;
        r0 = r0.tmpSet;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r19;
        r1 = r18;
        r0.add(r1);	 Catch:{ all -> 0x01af }
    L_0x00c8:
        r6 = r6 + 1;
        goto L_0x009b;
    L_0x00cb:
        r19 = 1036831949; // 0x3dcccccd float:0.1 double:5.122630465E-315;
        r19 = (r12 > r19 ? 1 : (r12 == r19 ? 0 : -1));
        if (r19 >= 0) goto L_0x00ec;
    L_0x00d2:
        r0 = r27;
        r0 = r0.mColumns;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 + -2;
        r0 = r19;
        if (r5 >= r0) goto L_0x006f;
    L_0x00de:
        r0 = r27;
        r0 = r0.mRows;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 + -2;
        r0 = r19;
        if (r8 >= r0) goto L_0x006f;
    L_0x00ea:
        r14 = 3;
        goto L_0x006f;
    L_0x00ec:
        r19 = 1051260355; // 0x3ea8f5c3 float:0.33 double:5.19391626E-315;
        r19 = (r12 > r19 ? 1 : (r12 == r19 ? 0 : -1));
        if (r19 >= 0) goto L_0x006f;
    L_0x00f3:
        r0 = r27;
        r0 = r0.mColumns;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 + -1;
        r0 = r19;
        if (r5 == r0) goto L_0x006f;
    L_0x00ff:
        r0 = r27;
        r0 = r0.mRows;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 + -1;
        r0 = r19;
        if (r8 == r0) goto L_0x006f;
    L_0x010b:
        r14 = 2;
        goto L_0x006f;
    L_0x010e:
        r0 = r27;
        r0 = r0.tmpSet;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r6 = r19.iterator();	 Catch:{ all -> 0x01af }
    L_0x0118:
        r19 = r6.hasNext();	 Catch:{ all -> 0x01af }
        if (r19 == 0) goto L_0x01bb;
    L_0x011e:
        r18 = r6.next();	 Catch:{ all -> 0x01af }
        r18 = (android.view.View) r18;	 Catch:{ all -> 0x01af }
        r0 = r27;
        r1 = r18;
        r4 = r0.getOccupied(r1);	 Catch:{ all -> 0x01af }
        r9 = r4.length;	 Catch:{ all -> 0x01af }
        r7 = 0;
    L_0x012e:
        if (r7 >= r9) goto L_0x0162;
    L_0x0130:
        r17 = r4[r7];	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mFreeList;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r19;
        r1 = r17;
        r0.add(r1);	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mCells;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r17;
        r0 = r0.y;	 Catch:{ all -> 0x01af }
        r20 = r0;
        r0 = r27;
        r0 = r0.mColumns;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 * r21;
        r0 = r17;
        r0 = r0.x;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 + r21;
        r21 = 0;
        r19[r20] = r21;	 Catch:{ all -> 0x01af }
        r7 = r7 + 1;
        goto L_0x012e;
    L_0x0162:
        r0 = r18;
        r1 = r28;
        if (r0 == r1) goto L_0x0118;
    L_0x0168:
        r19 = 33554433; // 0x2000001 float:9.403956E-38 double:1.65780926E-316;
        r20 = 0;
        r18.setTag(r19, r20);	 Catch:{ all -> 0x01af }
        if (r30 == 0) goto L_0x01b2;
    L_0x0172:
        r19 = r18.animate();	 Catch:{ all -> 0x01af }
        r19 = r19.withLayer();	 Catch:{ all -> 0x01af }
        r20 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r19 = r19.scaleX(r20);	 Catch:{ all -> 0x01af }
        r20 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r19 = r19.scaleY(r20);	 Catch:{ all -> 0x01af }
        r20 = 0;
        r19 = r19.alpha(r20);	 Catch:{ all -> 0x01af }
        r20 = 500; // 0x1f4 float:7.0E-43 double:2.47E-321;
        r19 = r19.setDuration(r20);	 Catch:{ all -> 0x01af }
        r20 = new android.view.animation.AccelerateInterpolator;	 Catch:{ all -> 0x01af }
        r20.<init>();	 Catch:{ all -> 0x01af }
        r19 = r19.setInterpolator(r20);	 Catch:{ all -> 0x01af }
        r20 = new com.android.systemui.DessertCaseView$4;	 Catch:{ all -> 0x01af }
        r0 = r20;
        r1 = r27;
        r2 = r18;
        r0.<init>(r2);	 Catch:{ all -> 0x01af }
        r19 = r19.setListener(r20);	 Catch:{ all -> 0x01af }
        r19.start();	 Catch:{ all -> 0x01af }
        goto L_0x0118;
    L_0x01af:
        r19 = move-exception;
        monitor-exit(r27);
        throw r19;
    L_0x01b2:
        r0 = r27;
        r1 = r18;
        r0.removeView(r1);	 Catch:{ all -> 0x01af }
        goto L_0x0118;
    L_0x01bb:
        r4 = r11;
        r9 = r4.length;	 Catch:{ all -> 0x01af }
        r6 = 0;
    L_0x01be:
        if (r6 >= r9) goto L_0x01ea;
    L_0x01c0:
        r10 = r4[r6];	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mCells;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r10.y;	 Catch:{ all -> 0x01af }
        r20 = r0;
        r0 = r27;
        r0 = r0.mColumns;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 * r21;
        r0 = r10.x;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 + r21;
        r19[r20] = r28;	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mFreeList;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r19;
        r0.remove(r10);	 Catch:{ all -> 0x01af }
        r6 = r6 + 1;
        goto L_0x01be;
    L_0x01ea:
        r19 = 0;
        r20 = 4;
        r19 = irand(r19, r20);	 Catch:{ all -> 0x01af }
        r0 = r19;
        r0 = (float) r0;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r20 = 1119092736; // 0x42b40000 float:90.0 double:5.529052754E-315;
        r13 = r19 * r20;
        if (r30 == 0) goto L_0x0325;
    L_0x01fd:
        r28.bringToFront();	 Catch:{ all -> 0x01af }
        r15 = new android.animation.AnimatorSet;	 Catch:{ all -> 0x01af }
        r15.<init>();	 Catch:{ all -> 0x01af }
        r19 = 2;
        r0 = r19;
        r0 = new android.animation.Animator[r0];	 Catch:{ all -> 0x01af }
        r19 = r0;
        r20 = 0;
        r21 = android.view.View.SCALE_X;	 Catch:{ all -> 0x01af }
        r22 = 1;
        r0 = r22;
        r0 = new float[r0];	 Catch:{ all -> 0x01af }
        r22 = r0;
        r23 = 0;
        r0 = (float) r14;	 Catch:{ all -> 0x01af }
        r24 = r0;
        r22[r23] = r24;	 Catch:{ all -> 0x01af }
        r0 = r28;
        r1 = r21;
        r2 = r22;
        r21 = android.animation.ObjectAnimator.ofFloat(r0, r1, r2);	 Catch:{ all -> 0x01af }
        r19[r20] = r21;	 Catch:{ all -> 0x01af }
        r20 = 1;
        r21 = android.view.View.SCALE_Y;	 Catch:{ all -> 0x01af }
        r22 = 1;
        r0 = r22;
        r0 = new float[r0];	 Catch:{ all -> 0x01af }
        r22 = r0;
        r23 = 0;
        r0 = (float) r14;	 Catch:{ all -> 0x01af }
        r24 = r0;
        r22[r23] = r24;	 Catch:{ all -> 0x01af }
        r0 = r28;
        r1 = r21;
        r2 = r22;
        r21 = android.animation.ObjectAnimator.ofFloat(r0, r1, r2);	 Catch:{ all -> 0x01af }
        r19[r20] = r21;	 Catch:{ all -> 0x01af }
        r0 = r19;
        r15.playTogether(r0);	 Catch:{ all -> 0x01af }
        r19 = new android.view.animation.AnticipateOvershootInterpolator;	 Catch:{ all -> 0x01af }
        r19.<init>();	 Catch:{ all -> 0x01af }
        r0 = r19;
        r15.setInterpolator(r0);	 Catch:{ all -> 0x01af }
        r20 = 500; // 0x1f4 float:7.0E-43 double:2.47E-321;
        r0 = r20;
        r15.setDuration(r0);	 Catch:{ all -> 0x01af }
        r16 = new android.animation.AnimatorSet;	 Catch:{ all -> 0x01af }
        r16.<init>();	 Catch:{ all -> 0x01af }
        r19 = 3;
        r0 = r19;
        r0 = new android.animation.Animator[r0];	 Catch:{ all -> 0x01af }
        r19 = r0;
        r20 = 0;
        r21 = android.view.View.ROTATION;	 Catch:{ all -> 0x01af }
        r22 = 1;
        r0 = r22;
        r0 = new float[r0];	 Catch:{ all -> 0x01af }
        r22 = r0;
        r23 = 0;
        r22[r23] = r13;	 Catch:{ all -> 0x01af }
        r0 = r28;
        r1 = r21;
        r2 = r22;
        r21 = android.animation.ObjectAnimator.ofFloat(r0, r1, r2);	 Catch:{ all -> 0x01af }
        r19[r20] = r21;	 Catch:{ all -> 0x01af }
        r20 = 1;
        r21 = android.view.View.X;	 Catch:{ all -> 0x01af }
        r22 = 1;
        r0 = r22;
        r0 = new float[r0];	 Catch:{ all -> 0x01af }
        r22 = r0;
        r23 = 0;
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r24 = r0;
        r24 = r24 * r5;
        r25 = r14 + -1;
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r26 = r0;
        r25 = r25 * r26;
        r25 = r25 / 2;
        r24 = r24 + r25;
        r0 = r24;
        r0 = (float) r0;	 Catch:{ all -> 0x01af }
        r24 = r0;
        r22[r23] = r24;	 Catch:{ all -> 0x01af }
        r0 = r28;
        r1 = r21;
        r2 = r22;
        r21 = android.animation.ObjectAnimator.ofFloat(r0, r1, r2);	 Catch:{ all -> 0x01af }
        r19[r20] = r21;	 Catch:{ all -> 0x01af }
        r20 = 2;
        r21 = android.view.View.Y;	 Catch:{ all -> 0x01af }
        r22 = 1;
        r0 = r22;
        r0 = new float[r0];	 Catch:{ all -> 0x01af }
        r22 = r0;
        r23 = 0;
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r24 = r0;
        r24 = r24 * r8;
        r25 = r14 + -1;
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r26 = r0;
        r25 = r25 * r26;
        r25 = r25 / 2;
        r24 = r24 + r25;
        r0 = r24;
        r0 = (float) r0;	 Catch:{ all -> 0x01af }
        r24 = r0;
        r22[r23] = r24;	 Catch:{ all -> 0x01af }
        r0 = r28;
        r1 = r21;
        r2 = r22;
        r21 = android.animation.ObjectAnimator.ofFloat(r0, r1, r2);	 Catch:{ all -> 0x01af }
        r19[r20] = r21;	 Catch:{ all -> 0x01af }
        r0 = r16;
        r1 = r19;
        r0.playTogether(r1);	 Catch:{ all -> 0x01af }
        r19 = new android.view.animation.DecelerateInterpolator;	 Catch:{ all -> 0x01af }
        r19.<init>();	 Catch:{ all -> 0x01af }
        r0 = r16;
        r1 = r19;
        r0.setInterpolator(r1);	 Catch:{ all -> 0x01af }
        r20 = 500; // 0x1f4 float:7.0E-43 double:2.47E-321;
        r0 = r16;
        r1 = r20;
        r0.setDuration(r1);	 Catch:{ all -> 0x01af }
        r19 = r27.makeHardwareLayerListener(r28);	 Catch:{ all -> 0x01af }
        r0 = r19;
        r15.addListener(r0);	 Catch:{ all -> 0x01af }
        r15.start();	 Catch:{ all -> 0x01af }
        r16.start();	 Catch:{ all -> 0x01af }
    L_0x0323:
        monitor-exit(r27);
        return;
    L_0x0325:
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 * r5;
        r20 = r14 + -1;
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 * r21;
        r20 = r20 / 2;
        r19 = r19 + r20;
        r0 = r19;
        r0 = (float) r0;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r28;
        r1 = r19;
        r0.setX(r1);	 Catch:{ all -> 0x01af }
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r19 = r19 * r8;
        r20 = r14 + -1;
        r0 = r27;
        r0 = r0.mCellSize;	 Catch:{ all -> 0x01af }
        r21 = r0;
        r20 = r20 * r21;
        r20 = r20 / 2;
        r19 = r19 + r20;
        r0 = r19;
        r0 = (float) r0;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r28;
        r1 = r19;
        r0.setY(r1);	 Catch:{ all -> 0x01af }
        r0 = (float) r14;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r28;
        r1 = r19;
        r0.setScaleX(r1);	 Catch:{ all -> 0x01af }
        r0 = (float) r14;	 Catch:{ all -> 0x01af }
        r19 = r0;
        r0 = r28;
        r1 = r19;
        r0.setScaleY(r1);	 Catch:{ all -> 0x01af }
        r0 = r28;
        r0.setRotation(r13);	 Catch:{ all -> 0x01af }
        goto L_0x0323;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.DessertCaseView.place(android.view.View, android.graphics.Point, boolean):void");
    }

    private Point[] getOccupied(View v) {
        int scale = ((Integer) v.getTag(33554434)).intValue();
        Point pt = (Point) v.getTag(33554433);
        if (pt == null || scale == 0) {
            return new Point[0];
        }
        Point[] result = new Point[(scale * scale)];
        int p = 0;
        int i = 0;
        while (i < scale) {
            int j = 0;
            int p2 = p;
            while (j < scale) {
                p = p2 + 1;
                result[p2] = new Point(pt.x + i, pt.y + j);
                j++;
                p2 = p;
            }
            i++;
            p = p2;
        }
        return result;
    }

    static float frand() {
        return (float) Math.random();
    }

    static float frand(float a, float b) {
        return (frand() * (b - a)) + a;
    }

    static int irand(int a, int b) {
        return (int) frand((float) a, (float) b);
    }

    public void onDraw(Canvas c) {
        super.onDraw(c);
    }
}
