package com.android.systemui.recents;

import android.app.ActivityManager;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import com.android.systemui.Prefs;
import com.android.systemui.recents.misc.Console;
import com.android.systemui.recents.misc.SystemServicesProxy;

public class RecentsConfiguration {
    static RecentsConfiguration sInstance;
    static int sPrevConfigurationHashCode;
    public int altTabKeyDelay;
    public boolean debugModeEnabled;
    public boolean developerOptionsEnabled;
    public int dismissAllButtonSizePx;
    public Rect displayRect;
    public boolean fakeShadows;
    public Interpolator fastOutLinearInInterpolator;
    public Interpolator fastOutSlowInInterpolator;
    public int filteringCurrentViewsAnimDuration;
    public int filteringNewViewsAnimDuration;
    boolean hasTransposedNavBar;
    boolean hasTransposedSearchBar;
    boolean isLandscape;
    public boolean launchedFromAppWithThumbnail;
    public boolean launchedFromHome;
    public boolean launchedFromSearchHome;
    public boolean launchedHasConfigurationChanged;
    public int launchedNumVisibleTasks;
    public int launchedNumVisibleThumbnails;
    public boolean launchedReuseTaskStackViews;
    public int launchedToTaskId;
    public boolean launchedWithAltTab;
    public boolean launchedWithNoRecentTasks;
    public Interpolator linearOutSlowInInterpolator;
    public boolean lockToAppEnabled;
    public int maxNumTasksToLoad;
    public boolean multiStackEnabled;
    public int navBarScrimEnterDuration;
    public Interpolator quintOutInterpolator;
    public int searchBarSpaceHeightPx;
    public int svelteLevel;
    public Rect systemInsets;
    public int taskBarDismissDozeDelaySeconds;
    public int taskBarHeight;
    public float taskBarViewAffiliationColorMinAlpha;
    public int taskBarViewDarkTextColor;
    public int taskBarViewDefaultBackgroundColor;
    public int taskBarViewHighlightColor;
    public int taskBarViewLightTextColor;
    public int taskStackMaxDim;
    public float taskStackOverscrollPct;
    public int taskStackScrollDuration;
    public int taskStackTopPaddingPx;
    public float taskStackWidthPaddingPct;
    public int taskViewAffiliateGroupEnterOffsetPx;
    public int taskViewEnterFromAppDuration;
    public int taskViewEnterFromHomeDuration;
    public int taskViewEnterFromHomeStaggerDelay;
    public int taskViewExitToAppDuration;
    public int taskViewExitToHomeDuration;
    public int taskViewHighlightPx;
    public int taskViewRemoveAnimDuration;
    public int taskViewRemoveAnimTranslationXPx;
    public int taskViewRoundedCornerRadiusPx;
    public float taskViewThumbnailAlpha;
    public int taskViewTranslationZMaxPx;
    public int taskViewTranslationZMinPx;
    public int transitionEnterFromAppDelay;
    public int transitionEnterFromHomeDelay;
    public boolean useHardwareLayers;

    private RecentsConfiguration(Context context) {
        this.systemInsets = new Rect();
        this.displayRect = new Rect();
        this.fastOutSlowInInterpolator = AnimationUtils.loadInterpolator(context, 17563661);
        this.fastOutLinearInInterpolator = AnimationUtils.loadInterpolator(context, 17563663);
        this.linearOutSlowInInterpolator = AnimationUtils.loadInterpolator(context, 17563662);
        this.quintOutInterpolator = AnimationUtils.loadInterpolator(context, 17563653);
    }

    public static RecentsConfiguration reinitialize(Context context, SystemServicesProxy ssp) {
        if (sInstance == null) {
            sInstance = new RecentsConfiguration(context);
        }
        int configHashCode = context.getResources().getConfiguration().hashCode();
        if (sPrevConfigurationHashCode != configHashCode) {
            sInstance.update(context);
            sPrevConfigurationHashCode = configHashCode;
        }
        sInstance.updateOnReinitialize(context, ssp);
        return sInstance;
    }

    public static RecentsConfiguration getInstance() {
        return sInstance;
    }

    void update(Context context) {
        boolean z = true;
        Resources res = context.getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        this.debugModeEnabled = Prefs.getBoolean(context, "debugModeEnabled", false);
        if (this.debugModeEnabled) {
            Console.Enabled = true;
        }
        if (res.getConfiguration().orientation != 2) {
            z = false;
        }
        this.isLandscape = z;
        this.hasTransposedSearchBar = res.getBoolean(2131558420);
        this.hasTransposedNavBar = res.getBoolean(2131558421);
        this.displayRect.set(0, 0, dm.widthPixels, dm.heightPixels);
        this.filteringCurrentViewsAnimDuration = res.getInteger(2131623960);
        this.filteringNewViewsAnimDuration = res.getInteger(2131623961);
        this.maxNumTasksToLoad = ActivityManager.getMaxRecentTasksStatic();
        this.searchBarSpaceHeightPx = res.getDimensionPixelSize(2131296354);
        this.taskStackScrollDuration = res.getInteger(2131623971);
        this.taskStackWidthPaddingPct = res.getFloat(2131296356);
        this.taskStackOverscrollPct = res.getFloat(2131296357);
        this.taskStackMaxDim = res.getInteger(2131623972);
        this.taskStackTopPaddingPx = res.getDimensionPixelSize(2131296358);
        this.dismissAllButtonSizePx = res.getDimensionPixelSize(2131296359);
        this.transitionEnterFromAppDelay = res.getInteger(2131623962);
        this.transitionEnterFromHomeDelay = res.getInteger(2131623965);
        this.taskViewEnterFromAppDuration = res.getInteger(2131623963);
        this.taskViewEnterFromHomeDuration = res.getInteger(2131623966);
        this.taskViewEnterFromHomeStaggerDelay = res.getInteger(2131623967);
        this.taskViewExitToAppDuration = res.getInteger(2131623964);
        this.taskViewExitToHomeDuration = res.getInteger(2131623968);
        this.taskViewRemoveAnimDuration = res.getInteger(2131623970);
        this.taskViewRemoveAnimTranslationXPx = res.getDimensionPixelSize(2131296349);
        this.taskViewRoundedCornerRadiusPx = res.getDimensionPixelSize(2131296346);
        this.taskViewHighlightPx = res.getDimensionPixelSize(2131296350);
        this.taskViewTranslationZMinPx = res.getDimensionPixelSize(2131296347);
        this.taskViewTranslationZMaxPx = res.getDimensionPixelSize(2131296348);
        this.taskViewAffiliateGroupEnterOffsetPx = res.getDimensionPixelSize(2131296351);
        this.taskViewThumbnailAlpha = res.getFloat(2131296352);
        this.taskBarViewDefaultBackgroundColor = context.getColor(2131427376);
        this.taskBarViewLightTextColor = context.getColor(2131427377);
        this.taskBarViewDarkTextColor = context.getColor(2131427378);
        this.taskBarViewHighlightColor = context.getColor(2131427381);
        this.taskBarViewAffiliationColorMinAlpha = res.getFloat(2131296360);
        this.taskBarHeight = res.getDimensionPixelSize(2131296353);
        this.taskBarDismissDozeDelaySeconds = res.getInteger(2131623959);
        this.navBarScrimEnterDuration = res.getInteger(2131623969);
        this.useHardwareLayers = res.getBoolean(2131558402);
        this.altTabKeyDelay = res.getInteger(2131623973);
        this.fakeShadows = res.getBoolean(2131558403);
        this.svelteLevel = res.getInteger(2131623974);
    }

    public void updateSystemInsets(Rect insets) {
        this.systemInsets.set(insets);
    }

    void updateOnReinitialize(Context context, SystemServicesProxy ssp) {
        boolean z = true;
        this.developerOptionsEnabled = ssp.getGlobalSetting(context, "development_settings_enabled") != 0;
        if (ssp.getSystemSetting(context, "lock_to_app_enabled") == 0) {
            z = false;
        }
        this.lockToAppEnabled = z;
        this.multiStackEnabled = "true".equals(ssp.getSystemProperty("persist.sys.debug.multi_window"));
    }

    public void updateOnConfigurationChange() {
        this.launchedReuseTaskStackViews = false;
        this.launchedHasConfigurationChanged = true;
    }

    public boolean shouldAnimateStatusBarScrim() {
        return this.launchedFromHome;
    }

    public boolean hasStatusBarScrim() {
        return !this.launchedWithNoRecentTasks;
    }

    public boolean shouldAnimateNavBarScrim() {
        return true;
    }

    public boolean hasNavBarScrim() {
        return (this.launchedWithNoRecentTasks || (this.hasTransposedNavBar && this.isLandscape)) ? false : true;
    }

    public void getAvailableTaskStackBounds(int windowWidth, int windowHeight, int topInset, int rightInset, Rect searchBarBounds, Rect taskStackBounds) {
        if (this.isLandscape && this.hasTransposedSearchBar) {
            taskStackBounds.set(0, topInset, windowWidth - rightInset, windowHeight);
            return;
        }
        int top;
        if (searchBarBounds.isEmpty()) {
            top = topInset;
        } else {
            top = 0;
        }
        taskStackBounds.set(0, searchBarBounds.bottom + top, windowWidth, windowHeight);
    }

    public void getSearchBarBounds(int windowWidth, int windowHeight, int topInset, Rect searchBarSpaceBounds) {
        int searchBarSize = this.searchBarSpaceHeightPx;
        if (this.isLandscape && this.hasTransposedSearchBar) {
            searchBarSpaceBounds.set(0, topInset, searchBarSize, windowHeight);
        } else {
            searchBarSpaceBounds.set(0, topInset, windowWidth, topInset + searchBarSize);
        }
    }
}
