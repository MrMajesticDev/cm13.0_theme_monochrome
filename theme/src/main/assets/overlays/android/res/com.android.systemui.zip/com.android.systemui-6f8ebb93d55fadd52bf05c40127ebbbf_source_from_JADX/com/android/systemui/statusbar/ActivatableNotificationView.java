package com.android.systemui.statusbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewConfiguration;
import android.view.ViewPropertyAnimator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.PathInterpolator;
import com.android.keyguard.C0065R;
import com.android.systemui.ViewInvertHelper;

public abstract class ActivatableNotificationView extends ExpandableOutlineView {
    private static final Interpolator ACTIVATE_INVERSE_ALPHA_INTERPOLATOR;
    private static final Interpolator ACTIVATE_INVERSE_INTERPOLATOR;
    private boolean mActivated;
    private float mAnimationTranslationY;
    private float mAppearAnimationFraction;
    private RectF mAppearAnimationRect;
    private float mAppearAnimationTranslation;
    private ValueAnimator mAppearAnimator;
    private ObjectAnimator mBackgroundAnimator;
    private NotificationBackgroundView mBackgroundDimmed;
    private ViewInvertHelper mBackgroundDimmedInvertHelper;
    private NotificationBackgroundView mBackgroundNormal;
    private ViewInvertHelper mBackgroundNormalInvertHelper;
    private int mBgTint;
    private Interpolator mCurrentAlphaInterpolator;
    private Interpolator mCurrentAppearInterpolator;
    private boolean mDark;
    private boolean mDimmed;
    private float mDownX;
    private float mDownY;
    private boolean mDrawingAppearAnimation;
    protected final Interpolator mFastOutSlowInInterpolator;
    private boolean mIsBelowSpeedBump;
    private final int mLegacyColor;
    private final Interpolator mLinearInterpolator;
    private final Interpolator mLinearOutSlowInInterpolator;
    private final int mLowPriorityColor;
    private final int mLowPriorityRippleColor;
    private final int mNormalColor;
    protected final int mNormalRippleColor;
    private OnActivatedListener mOnActivatedListener;
    private boolean mShowingLegacyBackground;
    private final Interpolator mSlowOutFastInInterpolator;
    private final Interpolator mSlowOutLinearInInterpolator;
    private final Runnable mTapTimeoutRunnable;
    private final int mTintedRippleColor;
    private final float mTouchSlop;

    /* renamed from: com.android.systemui.statusbar.ActivatableNotificationView.1 */
    class C02751 implements Runnable {
        C02751() {
        }

        public void run() {
            ActivatableNotificationView.this.makeInactive(true);
        }
    }

    /* renamed from: com.android.systemui.statusbar.ActivatableNotificationView.2 */
    class C02762 extends AnimatorListenerAdapter {
        C02762() {
        }

        public void onAnimationEnd(Animator animation) {
            if (ActivatableNotificationView.this.mDimmed) {
                ActivatableNotificationView.this.mBackgroundNormal.setVisibility(4);
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.ActivatableNotificationView.3 */
    class C02773 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$background;

        C02773(View view) {
            this.val$background = view;
        }

        public void onAnimationCancel(Animator animation) {
            this.val$background.setAlpha(1.0f);
        }
    }

    /* renamed from: com.android.systemui.statusbar.ActivatableNotificationView.4 */
    class C02784 extends AnimatorListenerAdapter {
        C02784() {
        }

        public void onAnimationEnd(Animator animation) {
            if (ActivatableNotificationView.this.mDimmed) {
                ActivatableNotificationView.this.mBackgroundNormal.setVisibility(4);
            } else {
                ActivatableNotificationView.this.mBackgroundDimmed.setVisibility(4);
            }
            ActivatableNotificationView.this.mBackgroundAnimator = null;
        }
    }

    /* renamed from: com.android.systemui.statusbar.ActivatableNotificationView.5 */
    class C02795 implements AnimatorUpdateListener {
        C02795() {
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            ActivatableNotificationView.this.mAppearAnimationFraction = ((Float) animation.getAnimatedValue()).floatValue();
            ActivatableNotificationView.this.updateAppearAnimationAlpha();
            ActivatableNotificationView.this.updateAppearRect();
            ActivatableNotificationView.this.invalidate();
        }
    }

    /* renamed from: com.android.systemui.statusbar.ActivatableNotificationView.6 */
    class C02806 extends AnimatorListenerAdapter {
        private boolean mWasCancelled;
        final /* synthetic */ Runnable val$onFinishedRunnable;

        C02806(Runnable runnable) {
            this.val$onFinishedRunnable = runnable;
        }

        public void onAnimationEnd(Animator animation) {
            if (this.val$onFinishedRunnable != null) {
                this.val$onFinishedRunnable.run();
            }
            if (!this.mWasCancelled) {
                ActivatableNotificationView.this.mAppearAnimationFraction = -1.0f;
                ActivatableNotificationView.this.setOutlineRect(null);
                ActivatableNotificationView.this.enableAppearDrawing(false);
            }
        }

        public void onAnimationStart(Animator animation) {
            this.mWasCancelled = false;
        }

        public void onAnimationCancel(Animator animation) {
            this.mWasCancelled = true;
        }
    }

    public interface OnActivatedListener {
        void onActivated(ActivatableNotificationView activatableNotificationView);

        void onActivationReset(ActivatableNotificationView activatableNotificationView);
    }

    protected abstract View getContentView();

    static {
        ACTIVATE_INVERSE_INTERPOLATOR = new PathInterpolator(0.6f, 0.0f, 0.5f, 1.0f);
        ACTIVATE_INVERSE_ALPHA_INTERPOLATOR = new PathInterpolator(0.0f, 0.0f, 0.5f, 1.0f);
    }

    public ActivatableNotificationView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mBgTint = 0;
        this.mAppearAnimationRect = new RectF();
        this.mAppearAnimationFraction = -1.0f;
        this.mTapTimeoutRunnable = new C02751();
        this.mTouchSlop = (float) ViewConfiguration.get(context).getScaledTouchSlop();
        this.mFastOutSlowInInterpolator = AnimationUtils.loadInterpolator(context, 17563661);
        this.mSlowOutFastInInterpolator = new PathInterpolator(0.8f, 0.0f, 0.6f, 1.0f);
        this.mLinearOutSlowInInterpolator = AnimationUtils.loadInterpolator(context, 17563662);
        this.mSlowOutLinearInInterpolator = new PathInterpolator(0.8f, 0.0f, 1.0f, 1.0f);
        this.mLinearInterpolator = new LinearInterpolator();
        setClipChildren(false);
        setClipToPadding(false);
        this.mLegacyColor = context.getColor(2131427385);
        this.mNormalColor = context.getColor(2131427386);
        this.mLowPriorityColor = context.getColor(2131427388);
        setRoundCornerRadius((float) getResources().getDimensionPixelSize(2131296392));
        this.mTintedRippleColor = context.getColor(2131427392);
        this.mLowPriorityRippleColor = context.getColor(2131427391);
        this.mNormalRippleColor = context.getColor(2131427390);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mBackgroundNormal = (NotificationBackgroundView) findViewById(2131755304);
        this.mBackgroundDimmed = (NotificationBackgroundView) findViewById(2131755305);
        this.mBackgroundNormal.setCustomBackground(2130837776);
        this.mBackgroundDimmed.setCustomBackground(2130837777);
        this.mBackgroundNormalInvertHelper = new ViewInvertHelper(this.mBackgroundNormal, 170);
        this.mBackgroundDimmedInvertHelper = new ViewInvertHelper(this.mBackgroundDimmed, 170);
        updateBackground();
        updateBackgroundTint();
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.mDimmed) {
            return handleTouchEventDimmed(event);
        }
        return super.onTouchEvent(event);
    }

    public void drawableHotspotChanged(float x, float y) {
        if (!this.mDimmed) {
            this.mBackgroundNormal.drawableHotspotChanged(x, y);
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.mDimmed) {
            this.mBackgroundDimmed.setState(getDrawableState());
        } else {
            this.mBackgroundNormal.setState(getDrawableState());
        }
    }

    private boolean handleTouchEventDimmed(MotionEvent event) {
        switch (event.getActionMasked()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                this.mDownX = event.getX();
                this.mDownY = event.getY();
                if (this.mDownY > ((float) getActualHeight())) {
                    return false;
                }
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                if (isWithinTouchSlop(event)) {
                    if (this.mActivated) {
                        if (performClick()) {
                            removeCallbacks(this.mTapTimeoutRunnable);
                            break;
                        }
                    }
                    makeActive();
                    postDelayed(this.mTapTimeoutRunnable, 1200);
                    break;
                }
                makeInactive(true);
                break;
                break;
            case 2:
                if (!isWithinTouchSlop(event)) {
                    makeInactive(true);
                    return false;
                }
                break;
            case 3:
                makeInactive(true);
                break;
        }
        return true;
    }

    private void makeActive() {
        startActivateAnimation(false);
        this.mActivated = true;
        if (this.mOnActivatedListener != null) {
            this.mOnActivatedListener.onActivated(this);
        }
    }

    private void startActivateAnimation(boolean reverse) {
        float f = 0.0f;
        if (isAttachedToWindow()) {
            Animator animator;
            Interpolator interpolator;
            Interpolator alphaInterpolator;
            int widthHalf = this.mBackgroundNormal.getWidth() / 2;
            int heightHalf = this.mBackgroundNormal.getActualHeight() / 2;
            float radius = (float) Math.sqrt((double) ((widthHalf * widthHalf) + (heightHalf * heightHalf)));
            if (reverse) {
                animator = ViewAnimationUtils.createCircularReveal(this.mBackgroundNormal, widthHalf, heightHalf, radius, 0.0f);
            } else {
                animator = ViewAnimationUtils.createCircularReveal(this.mBackgroundNormal, widthHalf, heightHalf, 0.0f, radius);
            }
            this.mBackgroundNormal.setVisibility(0);
            if (reverse) {
                interpolator = ACTIVATE_INVERSE_INTERPOLATOR;
                alphaInterpolator = ACTIVATE_INVERSE_ALPHA_INTERPOLATOR;
            } else {
                interpolator = this.mLinearOutSlowInInterpolator;
                alphaInterpolator = this.mLinearOutSlowInInterpolator;
            }
            animator.setInterpolator(interpolator);
            animator.setDuration(220);
            if (reverse) {
                this.mBackgroundNormal.setAlpha(1.0f);
                animator.addListener(new C02762());
                animator.start();
            } else {
                this.mBackgroundNormal.setAlpha(0.4f);
                animator.start();
            }
            ViewPropertyAnimator animate = this.mBackgroundNormal.animate();
            if (!reverse) {
                f = 1.0f;
            }
            animate.alpha(f).setInterpolator(alphaInterpolator).setDuration(220);
        }
    }

    public void makeInactive(boolean animate) {
        if (this.mActivated) {
            if (this.mDimmed) {
                if (animate) {
                    startActivateAnimation(true);
                } else {
                    this.mBackgroundNormal.setVisibility(4);
                }
            }
            this.mActivated = false;
        }
        if (this.mOnActivatedListener != null) {
            this.mOnActivatedListener.onActivationReset(this);
        }
        removeCallbacks(this.mTapTimeoutRunnable);
    }

    private boolean isWithinTouchSlop(MotionEvent event) {
        return Math.abs(event.getX() - this.mDownX) < this.mTouchSlop && Math.abs(event.getY() - this.mDownY) < this.mTouchSlop;
    }

    public void setDimmed(boolean dimmed, boolean fade) {
        if (this.mDimmed != dimmed) {
            this.mDimmed = dimmed;
            if (fade) {
                fadeDimmedBackground();
            } else {
                updateBackground();
            }
        }
    }

    public void setDark(boolean dark, boolean fade, long delay) {
        super.setDark(dark, fade, delay);
        if (this.mDark != dark) {
            float f;
            this.mDark = dark;
            if (dark || !fade) {
                updateBackground();
            } else {
                if (this.mActivated) {
                    this.mBackgroundDimmed.setVisibility(0);
                    this.mBackgroundNormal.setVisibility(0);
                } else if (this.mDimmed) {
                    this.mBackgroundDimmed.setVisibility(0);
                    this.mBackgroundNormal.setVisibility(4);
                } else {
                    this.mBackgroundDimmed.setVisibility(4);
                    this.mBackgroundNormal.setVisibility(0);
                }
                fadeInFromDark(delay);
            }
            if (dark) {
                f = 0.0f;
            } else {
                f = 1.0f;
            }
            setOutlineAlpha(f);
        }
    }

    public void setShowingLegacyBackground(boolean showing) {
        this.mShowingLegacyBackground = showing;
        updateBackgroundTint();
    }

    public void setBelowSpeedBump(boolean below) {
        super.setBelowSpeedBump(below);
        if (below != this.mIsBelowSpeedBump) {
            this.mIsBelowSpeedBump = below;
            updateBackgroundTint();
        }
    }

    public void setTintColor(int color) {
        this.mBgTint = color;
        updateBackgroundTint();
    }

    private void updateBackgroundTint() {
        int color = getBgColor();
        int rippleColor = getRippleColor();
        if (color == this.mNormalColor) {
            color = 0;
        }
        this.mBackgroundDimmed.setTint(color);
        this.mBackgroundNormal.setTint(color);
        this.mBackgroundDimmed.setRippleColor(rippleColor);
        this.mBackgroundNormal.setRippleColor(rippleColor);
    }

    private void fadeInFromDark(long delay) {
        View background = this.mDimmed ? this.mBackgroundDimmed : this.mBackgroundNormal;
        if (this.mDimmed) {
            this.mBackgroundDimmedInvertHelper.fade(false, delay);
            this.mBackgroundNormalInvertHelper.update(false);
        } else {
            this.mBackgroundDimmedInvertHelper.update(false);
            this.mBackgroundNormalInvertHelper.fade(false, delay);
        }
        background.animate().alpha(1.0f).setDuration(170).setStartDelay(delay).setInterpolator(this.mLinearOutSlowInInterpolator).setListener(new C02773(background)).start();
    }

    private void fadeDimmedBackground() {
        float startAlpha;
        float endAlpha;
        this.mBackgroundDimmed.animate().cancel();
        this.mBackgroundNormal.animate().cancel();
        if (this.mDimmed) {
            this.mBackgroundDimmed.setVisibility(0);
        } else {
            this.mBackgroundNormal.setVisibility(0);
        }
        if (this.mDimmed) {
            startAlpha = 1.0f;
        } else {
            startAlpha = 0.0f;
        }
        if (this.mDimmed) {
            endAlpha = 0.0f;
        } else {
            endAlpha = 1.0f;
        }
        int duration = 220;
        if (this.mBackgroundAnimator != null) {
            startAlpha = ((Float) this.mBackgroundAnimator.getAnimatedValue()).floatValue();
            duration = (int) this.mBackgroundAnimator.getCurrentPlayTime();
            this.mBackgroundAnimator.removeAllListeners();
            this.mBackgroundAnimator.cancel();
            if (duration <= 0) {
                updateBackground();
                return;
            }
        }
        this.mBackgroundNormal.setAlpha(startAlpha);
        this.mBackgroundAnimator = ObjectAnimator.ofFloat(this.mBackgroundNormal, View.ALPHA, new float[]{startAlpha, endAlpha});
        this.mBackgroundAnimator.setInterpolator(this.mFastOutSlowInInterpolator);
        this.mBackgroundAnimator.setDuration((long) duration);
        this.mBackgroundAnimator.addListener(new C02784());
        this.mBackgroundAnimator.start();
    }

    private void updateBackground() {
        cancelFadeAnimations();
        this.mBackgroundNormalInvertHelper.update(this.mDark);
        this.mBackgroundDimmedInvertHelper.update(this.mDark);
        if (this.mDark) {
            this.mBackgroundDimmed.setVisibility(4);
            this.mBackgroundNormal.setVisibility(0);
        } else if (this.mDimmed) {
            this.mBackgroundDimmed.setVisibility(0);
            this.mBackgroundNormal.setVisibility(4);
        } else {
            this.mBackgroundDimmed.setVisibility(4);
            this.mBackgroundNormal.setVisibility(0);
            this.mBackgroundNormal.setAlpha(1.0f);
            removeCallbacks(this.mTapTimeoutRunnable);
        }
    }

    private void cancelFadeAnimations() {
        if (this.mBackgroundAnimator != null) {
            this.mBackgroundAnimator.cancel();
        }
        this.mBackgroundDimmed.animate().cancel();
        this.mBackgroundNormal.animate().cancel();
    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        setPivotX((float) (getWidth() / 2));
    }

    public void setActualHeight(int actualHeight, boolean notifyListeners) {
        super.setActualHeight(actualHeight, notifyListeners);
        setPivotY((float) (actualHeight / 2));
        this.mBackgroundNormal.setActualHeight(actualHeight);
        this.mBackgroundDimmed.setActualHeight(actualHeight);
    }

    public void setClipTopAmount(int clipTopAmount) {
        super.setClipTopAmount(clipTopAmount);
        this.mBackgroundNormal.setClipTopAmount(clipTopAmount);
        this.mBackgroundDimmed.setClipTopAmount(clipTopAmount);
    }

    public void performRemoveAnimation(long duration, float translationDirection, Runnable onFinishedRunnable) {
        enableAppearDrawing(true);
        if (this.mDrawingAppearAnimation) {
            startAppearAnimation(false, translationDirection, 0, duration, onFinishedRunnable);
        } else if (onFinishedRunnable != null) {
            onFinishedRunnable.run();
        }
    }

    public void performAddAnimation(long delay, long duration) {
        enableAppearDrawing(true);
        if (this.mDrawingAppearAnimation) {
            startAppearAnimation(true, -1.0f, delay, duration, null);
        }
    }

    private void startAppearAnimation(boolean isAppearing, float translationDirection, long delay, long duration, Runnable onFinishedRunnable) {
        float targetValue;
        cancelAppearAnimation();
        this.mAnimationTranslationY = ((float) getActualHeight()) * translationDirection;
        if (this.mAppearAnimationFraction == -1.0f) {
            if (isAppearing) {
                this.mAppearAnimationFraction = 0.0f;
                this.mAppearAnimationTranslation = this.mAnimationTranslationY;
            } else {
                this.mAppearAnimationFraction = 1.0f;
                this.mAppearAnimationTranslation = 0.0f;
            }
        }
        if (isAppearing) {
            this.mCurrentAppearInterpolator = this.mSlowOutFastInInterpolator;
            this.mCurrentAlphaInterpolator = this.mLinearOutSlowInInterpolator;
            targetValue = 1.0f;
        } else {
            this.mCurrentAppearInterpolator = this.mFastOutSlowInInterpolator;
            this.mCurrentAlphaInterpolator = this.mSlowOutLinearInInterpolator;
            targetValue = 0.0f;
        }
        this.mAppearAnimator = ValueAnimator.ofFloat(new float[]{this.mAppearAnimationFraction, targetValue});
        this.mAppearAnimator.setInterpolator(this.mLinearInterpolator);
        this.mAppearAnimator.setDuration((long) (((float) duration) * Math.abs(this.mAppearAnimationFraction - targetValue)));
        this.mAppearAnimator.addUpdateListener(new C02795());
        if (delay > 0) {
            updateAppearAnimationAlpha();
            updateAppearRect();
            this.mAppearAnimator.setStartDelay(delay);
        }
        this.mAppearAnimator.addListener(new C02806(onFinishedRunnable));
        this.mAppearAnimator.start();
    }

    private void cancelAppearAnimation() {
        if (this.mAppearAnimator != null) {
            this.mAppearAnimator.cancel();
        }
    }

    public void cancelAppearDrawing() {
        cancelAppearAnimation();
        enableAppearDrawing(false);
    }

    private void updateAppearRect() {
        float bottom;
        float top;
        float inverseFraction = 1.0f - this.mAppearAnimationFraction;
        float translateYTotalAmount = this.mCurrentAppearInterpolator.getInterpolation(inverseFraction) * this.mAnimationTranslationY;
        this.mAppearAnimationTranslation = translateYTotalAmount;
        float left = (((float) getWidth()) * 0.475f) * this.mCurrentAppearInterpolator.getInterpolation(Math.min(1.0f, Math.max(0.0f, (inverseFraction - 0.0f) / 0.8f)));
        float right = ((float) getWidth()) - left;
        float heightFraction = this.mCurrentAppearInterpolator.getInterpolation(Math.max(0.0f, (inverseFraction - 0.0f) / 1.0f));
        int actualHeight = getActualHeight();
        if (this.mAnimationTranslationY > 0.0f) {
            bottom = (((float) actualHeight) - ((this.mAnimationTranslationY * heightFraction) * 0.1f)) - translateYTotalAmount;
            top = bottom * heightFraction;
        } else {
            top = (((((float) actualHeight) + this.mAnimationTranslationY) * heightFraction) * 0.1f) - translateYTotalAmount;
            bottom = (((float) actualHeight) * (1.0f - heightFraction)) + (top * heightFraction);
        }
        this.mAppearAnimationRect.set(left, top, right, bottom);
        setOutlineRect(left, this.mAppearAnimationTranslation + top, right, this.mAppearAnimationTranslation + bottom);
    }

    private void updateAppearAnimationAlpha() {
        setContentAlpha(this.mCurrentAlphaInterpolator.getInterpolation(Math.min(1.0f, this.mAppearAnimationFraction / 1.0f)));
    }

    private void setContentAlpha(float contentAlpha) {
        View contentView = getContentView();
        if (contentView.hasOverlappingRendering()) {
            int layerType = (contentAlpha == 0.0f || contentAlpha == 1.0f) ? 0 : 2;
            if (contentView.getLayerType() != layerType) {
                contentView.setLayerType(layerType, null);
            }
        }
        contentView.setAlpha(contentAlpha);
    }

    private int getBgColor() {
        if (this.mBgTint != 0) {
            return this.mBgTint;
        }
        if (this.mShowingLegacyBackground) {
            return this.mLegacyColor;
        }
        if (this.mIsBelowSpeedBump) {
            return this.mLowPriorityColor;
        }
        return this.mNormalColor;
    }

    protected int getRippleColor() {
        if (this.mBgTint != 0) {
            return this.mTintedRippleColor;
        }
        if (this.mShowingLegacyBackground) {
            return this.mTintedRippleColor;
        }
        if (this.mIsBelowSpeedBump) {
            return this.mLowPriorityRippleColor;
        }
        return this.mNormalRippleColor;
    }

    private void enableAppearDrawing(boolean enable) {
        if (enable != this.mDrawingAppearAnimation) {
            this.mDrawingAppearAnimation = enable;
            if (!enable) {
                setContentAlpha(1.0f);
            }
            invalidate();
        }
    }

    protected void dispatchDraw(Canvas canvas) {
        if (this.mDrawingAppearAnimation) {
            canvas.save();
            canvas.translate(0.0f, this.mAppearAnimationTranslation);
        }
        super.dispatchDraw(canvas);
        if (this.mDrawingAppearAnimation) {
            canvas.restore();
        }
    }

    public void setOnActivatedListener(OnActivatedListener onActivatedListener) {
        this.mOnActivatedListener = onActivatedListener;
    }

    public void reset() {
        setTintColor(0);
        setShowingLegacyBackground(false);
        setBelowSpeedBump(false);
    }
}
