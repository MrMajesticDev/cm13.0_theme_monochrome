package com.android.systemui.statusbar.policy;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.PowerManager;
import android.provider.Settings.System;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

public class BatteryController extends BroadcastReceiver {
    private static final boolean DEBUG;
    private final ArrayList<BatteryStateChangeCallback> mChangeCallbacks;
    private boolean mCharged;
    private boolean mCharging;
    private int mLevel;
    private SettingsObserver mObserver;
    private int mPercentMode;
    private boolean mPluggedIn;
    private final PowerManager mPowerManager;
    private boolean mPowerSave;
    private int mStyle;
    private int mUserId;

    public interface BatteryStateChangeCallback {
        void onBatteryLevelChanged(int i, boolean z, boolean z2);

        void onBatteryStyleChanged(int i, int i2);

        void onPowerSaveChanged();
    }

    private final class SettingsObserver extends ContentObserver {
        private final Uri PERCENT_URI;
        private final Uri STYLE_URI;
        private boolean mRegistered;
        private ContentResolver mResolver;

        public SettingsObserver(Context context, Handler handler) {
            super(handler);
            this.STYLE_URI = System.getUriFor("status_bar_battery_style");
            this.PERCENT_URI = System.getUriFor("status_bar_show_battery_percent");
            this.mResolver = context.getContentResolver();
        }

        public void observe() {
            if (this.mRegistered) {
                this.mResolver.unregisterContentObserver(this);
            }
            this.mResolver.registerContentObserver(this.STYLE_URI, false, this, BatteryController.this.mUserId);
            this.mResolver.registerContentObserver(this.PERCENT_URI, false, this, BatteryController.this.mUserId);
            this.mRegistered = true;
            update();
        }

        public void onChange(boolean selfChange, Uri uri) {
            update();
        }

        private void update() {
            BatteryController.this.mStyle = System.getIntForUser(this.mResolver, "status_bar_battery_style", 0, BatteryController.this.mUserId);
            BatteryController.this.mPercentMode = System.getIntForUser(this.mResolver, "status_bar_show_battery_percent", 0, BatteryController.this.mUserId);
            BatteryController.this.fireSettingsChanged();
        }
    }

    static {
        DEBUG = Log.isLoggable("BatteryController", 3);
    }

    public BatteryController(Context context, Handler handler) {
        this.mChangeCallbacks = new ArrayList();
        this.mPowerManager = (PowerManager) context.getSystemService("power");
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.BATTERY_CHANGED");
        filter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
        filter.addAction("android.os.action.POWER_SAVE_MODE_CHANGING");
        context.registerReceiver(this, filter);
        updatePowerSave();
        this.mObserver = new SettingsObserver(context, handler);
        this.mObserver.observe();
    }

    public void setUserId(int userId) {
        this.mUserId = userId;
        this.mObserver.observe();
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        pw.println("BatteryController state:");
        pw.print("  mLevel=");
        pw.println(this.mLevel);
        pw.print("  mPluggedIn=");
        pw.println(this.mPluggedIn);
        pw.print("  mCharging=");
        pw.println(this.mCharging);
        pw.print("  mCharged=");
        pw.println(this.mCharged);
        pw.print("  mPowerSave=");
        pw.println(this.mPowerSave);
    }

    public void addStateChangedCallback(BatteryStateChangeCallback cb) {
        this.mChangeCallbacks.add(cb);
        cb.onBatteryLevelChanged(this.mLevel, this.mPluggedIn, this.mCharging);
        cb.onBatteryStyleChanged(this.mStyle, this.mPercentMode);
    }

    public void removeStateChangedCallback(BatteryStateChangeCallback cb) {
        this.mChangeCallbacks.remove(cb);
    }

    public void onReceive(Context context, Intent intent) {
        boolean z = false;
        String action = intent.getAction();
        if (action.equals("android.intent.action.BATTERY_CHANGED")) {
            boolean z2;
            this.mLevel = (int) ((100.0f * ((float) intent.getIntExtra("level", 0))) / ((float) intent.getIntExtra("scale", 100)));
            this.mPluggedIn = intent.getIntExtra("plugged", 0) != 0;
            int status = intent.getIntExtra("status", 1);
            if (status == 5) {
                z2 = true;
            } else {
                z2 = false;
            }
            this.mCharged = z2;
            if (this.mCharged || status == 2) {
                z = true;
            }
            this.mCharging = z;
            fireBatteryLevelChanged();
        } else if (action.equals("android.os.action.POWER_SAVE_MODE_CHANGED")) {
            updatePowerSave();
        } else if (action.equals("android.os.action.POWER_SAVE_MODE_CHANGING")) {
            setPowerSave(intent.getBooleanExtra("mode", false));
        }
    }

    public boolean isPowerSave() {
        return this.mPowerSave;
    }

    private void updatePowerSave() {
        setPowerSave(this.mPowerManager.isPowerSaveMode());
    }

    private void setPowerSave(boolean powerSave) {
        if (powerSave != this.mPowerSave) {
            this.mPowerSave = powerSave;
            if (DEBUG) {
                Log.d("BatteryController", "Power save is " + (this.mPowerSave ? "on" : "off"));
            }
            firePowerSaveChanged();
        }
    }

    private void fireBatteryLevelChanged() {
        int N = this.mChangeCallbacks.size();
        for (int i = 0; i < N; i++) {
            ((BatteryStateChangeCallback) this.mChangeCallbacks.get(i)).onBatteryLevelChanged(this.mLevel, this.mPluggedIn, this.mCharging);
        }
    }

    private void firePowerSaveChanged() {
        int N = this.mChangeCallbacks.size();
        for (int i = 0; i < N; i++) {
            ((BatteryStateChangeCallback) this.mChangeCallbacks.get(i)).onPowerSaveChanged();
        }
    }

    private void fireSettingsChanged() {
        int N = this.mChangeCallbacks.size();
        for (int i = 0; i < N; i++) {
            ((BatteryStateChangeCallback) this.mChangeCallbacks.get(i)).onBatteryStyleChanged(this.mStyle, this.mPercentMode);
        }
    }
}
