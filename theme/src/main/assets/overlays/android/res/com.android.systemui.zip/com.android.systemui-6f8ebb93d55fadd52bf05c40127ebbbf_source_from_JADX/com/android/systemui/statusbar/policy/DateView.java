package com.android.systemui.statusbar.policy;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.TypedArray;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.widget.TextView;
import com.android.systemui.C0095R;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateView extends TextView {
    private final Date mCurrentTime;
    private SimpleDateFormat mDateFormat;
    private String mDatePattern;
    private BroadcastReceiver mIntentReceiver;
    private String mLastText;

    /* renamed from: com.android.systemui.statusbar.policy.DateView.1 */
    class C04671 extends BroadcastReceiver {
        C04671() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.TIME_TICK".equals(action) || "android.intent.action.TIME_SET".equals(action) || "android.intent.action.TIMEZONE_CHANGED".equals(action) || "android.intent.action.LOCALE_CHANGED".equals(action)) {
                if ("android.intent.action.LOCALE_CHANGED".equals(action) || "android.intent.action.TIMEZONE_CHANGED".equals(action)) {
                    DateView.this.mDateFormat = null;
                }
                DateView.this.updateClock();
            }
        }
    }

    public DateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mCurrentTime = new Date();
        this.mIntentReceiver = new C04671();
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, C0095R.styleable.DateView, 0, 0);
        try {
            this.mDatePattern = a.getString(0);
            if (this.mDatePattern == null) {
                this.mDatePattern = getContext().getString(2131361882);
            }
        } finally {
            a.recycle();
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.TIME_TICK");
        filter.addAction("android.intent.action.TIME_SET");
        filter.addAction("android.intent.action.TIMEZONE_CHANGED");
        filter.addAction("android.intent.action.LOCALE_CHANGED");
        getContext().registerReceiver(this.mIntentReceiver, filter, null, null);
        updateClock();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mDateFormat = null;
        getContext().unregisterReceiver(this.mIntentReceiver);
    }

    protected void updateClock() {
        if (this.mDateFormat == null) {
            Locale l = Locale.getDefault();
            this.mDateFormat = new SimpleDateFormat(DateFormat.getBestDateTimePattern(l, this.mDatePattern), l);
        }
        this.mCurrentTime.setTime(System.currentTimeMillis());
        String text = getDateFormat();
        if (!text.equals(this.mLastText)) {
            setText(text);
            this.mLastText = text;
        }
    }

    private String getDateFormat() {
        if (getContext().getResources().getBoolean(17957048)) {
            return DateFormat.getDateFormat(getContext()).format(this.mCurrentTime);
        }
        return this.mDateFormat.format(this.mCurrentTime);
    }
}
