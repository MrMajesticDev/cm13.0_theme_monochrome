package com.android.systemui.statusbar.policy;

import android.app.ActivityManagerNative;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.UserInfo;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.RemoteException;
import android.os.UserHandle;
import android.os.UserManager;
import android.provider.ContactsContract.Profile;
import android.util.Log;
import android.util.Pair;
import com.android.internal.util.UserIcons;
import com.android.systemui.BitmapHelper;
import java.util.ArrayList;
import java.util.Iterator;

public final class UserInfoController {
    private final ArrayList<OnUserInfoChangedListener> mCallbacks;
    private final Context mContext;
    private final BroadcastReceiver mProfileReceiver;
    private final BroadcastReceiver mReceiver;
    private boolean mUseDefaultAvatar;
    private Drawable mUserDrawable;
    private AsyncTask<Void, Void, Pair<String, Drawable>> mUserInfoTask;
    private String mUserName;

    public interface OnUserInfoChangedListener {
        void onUserInfoChanged(String str, Drawable drawable);
    }

    /* renamed from: com.android.systemui.statusbar.policy.UserInfoController.1 */
    class C04951 extends BroadcastReceiver {
        C04951() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.USER_SWITCHED".equals(action)) {
                UserInfoController.this.reloadUserInfo();
            } else if ("android.intent.action.CONFIGURATION_CHANGED".equals(action) && UserInfoController.this.mUseDefaultAvatar) {
                UserInfoController.this.reloadUserInfo();
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.UserInfoController.2 */
    class C04962 extends BroadcastReceiver {
        C04962() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.provider.Contacts.PROFILE_CHANGED".equals(action) || "android.intent.action.USER_INFO_CHANGED".equals(action)) {
                try {
                    if (intent.getIntExtra("android.intent.extra.user_handle", getSendingUserId()) == ActivityManagerNative.getDefault().getCurrentUser().id) {
                        UserInfoController.this.reloadUserInfo();
                    }
                } catch (RemoteException e) {
                    Log.e("UserInfoController", "Couldn't get current user id for profile change", e);
                }
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.UserInfoController.3 */
    class C04973 extends AsyncTask<Void, Void, Pair<String, Drawable>> {
        final /* synthetic */ int val$avatarSize;
        final /* synthetic */ Context val$context;
        final /* synthetic */ boolean val$isGuest;
        final /* synthetic */ int val$userId;
        final /* synthetic */ String val$userName;

        C04973(String str, int i, int i2, boolean z, Context context) {
            this.val$userName = str;
            this.val$userId = i;
            this.val$avatarSize = i2;
            this.val$isGuest = z;
            this.val$context = context;
        }

        protected Pair<String, Drawable> doInBackground(Void... params) {
            Drawable avatar;
            UserManager um = UserManager.get(UserInfoController.this.mContext);
            String name = this.val$userName;
            Bitmap rawAvatar = um.getUserIcon(this.val$userId);
            if (rawAvatar != null) {
                avatar = new BitmapDrawable(UserInfoController.this.mContext.getResources(), BitmapHelper.createCircularClip(rawAvatar, this.val$avatarSize, this.val$avatarSize));
            } else {
                avatar = UserIcons.getDefaultUserIcon(this.val$isGuest ? -10000 : this.val$userId, true);
                UserInfoController.this.mUseDefaultAvatar = true;
            }
            if (um.getUsers().size() <= 1) {
                Cursor cursor = this.val$context.getContentResolver().query(Profile.CONTENT_URI, new String[]{"_id", "display_name"}, null, null, null);
                if (cursor != null) {
                    try {
                        if (cursor.moveToFirst()) {
                            name = cursor.getString(cursor.getColumnIndex("display_name"));
                        }
                        cursor.close();
                    } catch (Throwable th) {
                        cursor.close();
                    }
                }
            }
            return new Pair(name, avatar);
        }

        protected void onPostExecute(Pair<String, Drawable> result) {
            UserInfoController.this.mUserName = (String) result.first;
            UserInfoController.this.mUserDrawable = (Drawable) result.second;
            UserInfoController.this.mUserInfoTask = null;
            UserInfoController.this.notifyChanged();
        }
    }

    public UserInfoController(Context context) {
        this.mCallbacks = new ArrayList();
        this.mReceiver = new C04951();
        this.mProfileReceiver = new C04962();
        this.mContext = context;
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.USER_SWITCHED");
        filter.addAction("android.intent.action.CONFIGURATION_CHANGED");
        this.mContext.registerReceiver(this.mReceiver, filter);
        IntentFilter profileFilter = new IntentFilter();
        profileFilter.addAction("android.provider.Contacts.PROFILE_CHANGED");
        profileFilter.addAction("android.intent.action.USER_INFO_CHANGED");
        this.mContext.registerReceiverAsUser(this.mProfileReceiver, UserHandle.ALL, profileFilter, null, null);
    }

    public void addListener(OnUserInfoChangedListener callback) {
        this.mCallbacks.add(callback);
    }

    public void removeListener(OnUserInfoChangedListener callback) {
        this.mCallbacks.remove(callback);
    }

    public void reloadUserInfo() {
        if (this.mUserInfoTask != null) {
            this.mUserInfoTask.cancel(false);
            this.mUserInfoTask = null;
        }
        queryForUserInformation();
    }

    private void queryForUserInformation() {
        try {
            UserInfo userInfo = ActivityManagerNative.getDefault().getCurrentUser();
            Context currentUserContext = this.mContext.createPackageContextAsUser("android", 0, new UserHandle(userInfo.id));
            int userId = userInfo.id;
            boolean isGuest = userInfo.isGuest();
            String userName = userInfo.name;
            Resources res = this.mContext.getResources();
            this.mUserInfoTask = new C04973(userName, userId, Math.max(res.getDimensionPixelSize(2131296412), res.getDimensionPixelSize(2131296411)), isGuest, currentUserContext);
            this.mUserInfoTask.execute(new Void[0]);
        } catch (NameNotFoundException e) {
            Log.e("UserInfoController", "Couldn't create user context", e);
            throw new RuntimeException(e);
        } catch (RemoteException e2) {
            Log.e("UserInfoController", "Couldn't get user info", e2);
            throw new RuntimeException(e2);
        }
    }

    private void notifyChanged() {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            ((OnUserInfoChangedListener) i$.next()).onUserInfoChanged(this.mUserName, this.mUserDrawable);
        }
    }
}
