package com.android.systemui.statusbar.phone;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AnimationUtils;
import com.android.keyguard.AlphaOptimizedImageButton;
import com.android.keyguard.C0065R;

public class SettingsButton extends AlphaOptimizedImageButton {
    private ObjectAnimator mAnimator;
    private final Runnable mLongPressCallback;
    private float mSlop;
    private boolean mUpToSpeed;

    /* renamed from: com.android.systemui.statusbar.phone.SettingsButton.1 */
    class C04261 implements AnimatorListener {
        C04261() {
        }

        public void onAnimationStart(Animator animation) {
        }

        public void onAnimationRepeat(Animator animation) {
        }

        public void onAnimationEnd(Animator animation) {
            SettingsButton.this.setAlpha(1.0f);
            SettingsButton.this.setTranslationX(0.0f);
            SettingsButton.this.cancelLongClick();
        }

        public void onAnimationCancel(Animator animation) {
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.SettingsButton.2 */
    class C04272 implements AnimatorListener {
        C04272() {
        }

        public void onAnimationStart(Animator animation) {
        }

        public void onAnimationRepeat(Animator animation) {
        }

        public void onAnimationEnd(Animator animation) {
            SettingsButton.this.startContinuousSpin();
        }

        public void onAnimationCancel(Animator animation) {
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.SettingsButton.3 */
    class C04283 implements Runnable {
        C04283() {
        }

        public void run() {
            SettingsButton.this.startAccelSpin();
        }
    }

    public SettingsButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mLongPressCallback = new C04283();
        this.mSlop = (float) ViewConfiguration.get(getContext()).getScaledTouchSlop();
    }

    public boolean isAnimating() {
        return this.mAnimator != null && this.mAnimator.isRunning();
    }

    public boolean isTunerClick() {
        return this.mUpToSpeed;
    }

    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                postDelayed(this.mLongPressCallback, 1000);
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                if (!this.mUpToSpeed) {
                    cancelLongClick();
                    break;
                }
                startExitAnimation();
                break;
            case 2:
                float x = event.getX();
                float y = event.getY();
                if (x < (-this.mSlop) || y < (-this.mSlop) || x > ((float) getWidth()) + this.mSlop || y > ((float) getHeight()) + this.mSlop) {
                    cancelLongClick();
                    break;
                }
            case 3:
                cancelLongClick();
                break;
        }
        return super.onTouchEvent(event);
    }

    private void cancelLongClick() {
        cancelAnimation();
        this.mUpToSpeed = false;
        removeCallbacks(this.mLongPressCallback);
    }

    private void cancelAnimation() {
        if (this.mAnimator != null) {
            this.mAnimator.removeAllListeners();
            this.mAnimator.cancel();
            this.mAnimator = null;
        }
    }

    private void startExitAnimation() {
        animate().translationX(((float) ((View) getParent().getParent()).getWidth()) - getX()).alpha(0.0f).setDuration(350).setInterpolator(AnimationUtils.loadInterpolator(this.mContext, 17563650)).setListener(new C04261()).start();
    }

    protected void startAccelSpin() {
        cancelAnimation();
        this.mAnimator = ObjectAnimator.ofFloat(this, View.ROTATION, new float[]{0.0f, 360.0f});
        this.mAnimator.setInterpolator(AnimationUtils.loadInterpolator(this.mContext, 17563648));
        this.mAnimator.setDuration(750);
        this.mAnimator.addListener(new C04272());
        this.mAnimator.start();
    }

    protected void startContinuousSpin() {
        cancelAnimation();
        this.mUpToSpeed = true;
        this.mAnimator = ObjectAnimator.ofFloat(this, View.ROTATION, new float[]{0.0f, 360.0f});
        this.mAnimator.setInterpolator(AnimationUtils.loadInterpolator(this.mContext, 17563659));
        this.mAnimator.setDuration(375);
        this.mAnimator.setRepeatCount(-1);
        this.mAnimator.start();
    }
}
