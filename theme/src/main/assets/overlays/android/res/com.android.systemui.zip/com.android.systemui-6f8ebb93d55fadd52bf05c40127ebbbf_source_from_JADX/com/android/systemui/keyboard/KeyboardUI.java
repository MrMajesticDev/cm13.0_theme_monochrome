package com.android.systemui.keyboard;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanFilter.Builder;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.Configuration;
import android.hardware.input.InputManager;
import android.hardware.input.InputManager.OnTabletModeChangedListener;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.Settings.Secure;
import android.text.TextUtils;
import com.android.keyguard.C0065R;
import com.android.settingslib.bluetooth.BluetoothCallback;
import com.android.settingslib.bluetooth.CachedBluetoothDevice;
import com.android.settingslib.bluetooth.CachedBluetoothDeviceManager;
import com.android.settingslib.bluetooth.LocalBluetoothAdapter;
import com.android.settingslib.bluetooth.LocalBluetoothManager;
import com.android.settingslib.bluetooth.LocalBluetoothProfileManager;
import com.android.systemui.SystemUI;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

public class KeyboardUI extends SystemUI implements OnTabletModeChangedListener {
    private boolean mBootCompleted;
    private long mBootCompletedTime;
    private CachedBluetoothDeviceManager mCachedDeviceManager;
    protected volatile Context mContext;
    private BluetoothDialog mDialog;
    private boolean mEnabled;
    private volatile KeyboardHandler mHandler;
    private int mInTabletMode;
    private String mKeyboardName;
    private LocalBluetoothAdapter mLocalBluetoothAdapter;
    private LocalBluetoothProfileManager mProfileManager;
    private int mScanAttempt;
    private ScanCallback mScanCallback;
    private int mState;
    private volatile KeyboardUIHandler mUIHandler;

    private final class BluetoothCallbackHandler implements BluetoothCallback {
        private BluetoothCallbackHandler() {
        }

        public void onBluetoothStateChanged(int bluetoothState) {
            KeyboardUI.this.mHandler.obtainMessage(4, bluetoothState, 0).sendToTarget();
        }

        public void onDeviceBondStateChanged(CachedBluetoothDevice cachedDevice, int bondState) {
            KeyboardUI.this.mHandler.obtainMessage(5, bondState, 0, cachedDevice).sendToTarget();
        }

        public void onDeviceAdded(CachedBluetoothDevice cachedDevice) {
        }

        public void onDeviceDeleted(CachedBluetoothDevice cachedDevice) {
        }

        public void onScanningStateChanged(boolean started) {
        }

        public void onConnectionStateChanged(CachedBluetoothDevice cachedDevice, int state) {
        }
    }

    private final class BluetoothDialogClickListener implements OnClickListener {
        private BluetoothDialogClickListener() {
        }

        public void onClick(DialogInterface dialog, int which) {
            int enable;
            if (-1 == which) {
                enable = 1;
            } else {
                enable = 0;
            }
            KeyboardUI.this.mHandler.obtainMessage(3, enable, 0).sendToTarget();
            KeyboardUI.this.mDialog = null;
        }
    }

    private final class KeyboardHandler extends Handler {
        public KeyboardHandler(Looper looper) {
            super(looper, null, true);
        }

        public void handleMessage(Message msg) {
            boolean enable = true;
            switch (msg.what) {
                case C0065R.styleable.NumPadKey_digit /*0*/:
                    KeyboardUI.this.init();
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    KeyboardUI.this.onBootCompletedInternal();
                case 2:
                    KeyboardUI.this.processKeyboardState();
                case 3:
                    if (msg.arg1 != 1) {
                        enable = false;
                    }
                    if (enable) {
                        KeyboardUI.this.mLocalBluetoothAdapter.enable();
                    } else {
                        KeyboardUI.this.mState = 7;
                    }
                case 4:
                    KeyboardUI.this.onBluetoothStateChangedInternal(msg.arg1);
                case 5:
                    KeyboardUI.this.onDeviceBondStateChangedInternal(msg.obj, msg.arg1);
                case 6:
                    KeyboardUI.this.onDeviceAddedInternal(KeyboardUI.this.getCachedBluetoothDevice(msg.obj));
                case 7:
                    KeyboardUI.this.onBleScanFailedInternal();
                case 10:
                    KeyboardUI.this.bleAbortScanInternal(msg.arg1);
                default:
            }
        }
    }

    private final class KeyboardScanCallback extends ScanCallback {
        private KeyboardScanCallback() {
        }

        private boolean isDeviceDiscoverable(ScanResult result) {
            return (result.getScanRecord().getAdvertiseFlags() & 3) != 0;
        }

        public void onBatchScanResults(List<ScanResult> results) {
            BluetoothDevice bestDevice = null;
            int bestRssi = Integer.MIN_VALUE;
            for (ScanResult result : results) {
                if (isDeviceDiscoverable(result) && result.getRssi() > bestRssi) {
                    bestDevice = result.getDevice();
                    bestRssi = result.getRssi();
                }
            }
            if (bestDevice != null) {
                KeyboardUI.this.mHandler.obtainMessage(6, bestDevice).sendToTarget();
            }
        }

        public void onScanFailed(int errorCode) {
            KeyboardUI.this.mHandler.obtainMessage(7).sendToTarget();
        }

        public void onScanResult(int callbackType, ScanResult result) {
            if (isDeviceDiscoverable(result)) {
                KeyboardUI.this.mHandler.obtainMessage(6, result.getDevice()).sendToTarget();
            }
        }
    }

    private final class KeyboardUIHandler extends Handler {
        public KeyboardUIHandler() {
            super(Looper.getMainLooper(), null, true);
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 8:
                    OnClickListener listener = new BluetoothDialogClickListener(null);
                    KeyboardUI.this.mDialog = new BluetoothDialog(KeyboardUI.this.mContext);
                    KeyboardUI.this.mDialog.setTitle(2131362368);
                    KeyboardUI.this.mDialog.setMessage(2131362369);
                    KeyboardUI.this.mDialog.setPositiveButton(2131362370, listener);
                    KeyboardUI.this.mDialog.setNegativeButton(17039360, listener);
                    KeyboardUI.this.mDialog.show();
                case 9:
                    if (KeyboardUI.this.mDialog != null) {
                        KeyboardUI.this.mDialog.dismiss();
                        KeyboardUI.this.mDialog = null;
                    }
                default:
            }
        }
    }

    public KeyboardUI() {
        this.mInTabletMode = -1;
        this.mScanAttempt = 0;
    }

    public void start() {
        this.mContext = this.mContext;
        HandlerThread thread = new HandlerThread("Keyboard", 10);
        thread.start();
        this.mHandler = new KeyboardHandler(thread.getLooper());
        this.mHandler.sendEmptyMessage(0);
    }

    protected void onConfigurationChanged(Configuration newConfig) {
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        pw.println("KeyboardUI:");
        pw.println("  mEnabled=" + this.mEnabled);
        pw.println("  mBootCompleted=" + this.mEnabled);
        pw.println("  mBootCompletedTime=" + this.mBootCompletedTime);
        pw.println("  mKeyboardName=" + this.mKeyboardName);
        pw.println("  mInTabletMode=" + this.mInTabletMode);
        pw.println("  mState=" + stateToString(this.mState));
    }

    protected void onBootCompleted() {
        this.mHandler.sendEmptyMessage(1);
    }

    public void onTabletModeChanged(long whenNanos, boolean inTabletMode) {
        int i = 1;
        if ((inTabletMode && this.mInTabletMode != 1) || (!inTabletMode && this.mInTabletMode != 0)) {
            if (!inTabletMode) {
                i = 0;
            }
            this.mInTabletMode = i;
            processKeyboardState();
        }
    }

    private void init() {
        Context context = this.mContext;
        this.mKeyboardName = context.getString(17039445);
        if (!TextUtils.isEmpty(this.mKeyboardName)) {
            LocalBluetoothManager bluetoothManager = LocalBluetoothManager.getInstance(context, null);
            if (bluetoothManager != null) {
                this.mEnabled = true;
                this.mCachedDeviceManager = bluetoothManager.getCachedDeviceManager();
                this.mLocalBluetoothAdapter = bluetoothManager.getBluetoothAdapter();
                this.mProfileManager = bluetoothManager.getProfileManager();
                bluetoothManager.getEventManager().registerCallback(new BluetoothCallbackHandler());
                InputManager im = (InputManager) context.getSystemService("input");
                im.registerOnTabletModeChangedListener(this, this.mHandler);
                this.mInTabletMode = im.isInTabletMode();
                processKeyboardState();
                this.mUIHandler = new KeyboardUIHandler();
            }
        }
    }

    private void processKeyboardState() {
        this.mHandler.removeMessages(2);
        if (!this.mEnabled) {
            this.mState = -1;
        } else if (!this.mBootCompleted) {
            this.mState = 1;
        } else if (this.mInTabletMode != 0) {
            if (this.mState == 3) {
                stopScanning();
            }
            this.mState = 2;
        } else {
            int btState = this.mLocalBluetoothAdapter.getState();
            if (btState == 11 || (btState == 12 && this.mState == 4)) {
                this.mUIHandler.sendEmptyMessage(9);
            }
            if (btState == 11) {
                this.mState = 4;
            } else if (btState != 12) {
                this.mState = 4;
                showBluetoothDialog();
            } else {
                CachedBluetoothDevice device = getPairedKeyboard();
                if (this.mState == 2 || this.mState == 4) {
                    if (device != null) {
                        this.mState = 6;
                        device.connect(false);
                        return;
                    }
                    this.mCachedDeviceManager.clearNonBondedDevices();
                }
                device = getDiscoveredKeyboard();
                if (device != null) {
                    this.mState = 5;
                    device.startPairing();
                    return;
                }
                this.mState = 3;
                startScanning();
            }
        }
    }

    public void onBootCompletedInternal() {
        this.mBootCompleted = true;
        this.mBootCompletedTime = SystemClock.uptimeMillis();
        if (this.mState == 1) {
            processKeyboardState();
        }
    }

    private void showBluetoothDialog() {
        if (isUserSetupComplete()) {
            long earliestDialogTime = this.mBootCompletedTime + 10000;
            if (earliestDialogTime < SystemClock.uptimeMillis()) {
                this.mUIHandler.sendEmptyMessage(8);
                return;
            } else {
                this.mHandler.sendEmptyMessageAtTime(2, earliestDialogTime);
                return;
            }
        }
        this.mLocalBluetoothAdapter.enable();
    }

    private boolean isUserSetupComplete() {
        if (Secure.getIntForUser(this.mContext.getContentResolver(), "user_setup_complete", 0, -2) != 0) {
            return true;
        }
        return false;
    }

    private CachedBluetoothDevice getPairedKeyboard() {
        for (BluetoothDevice d : this.mLocalBluetoothAdapter.getBondedDevices()) {
            if (this.mKeyboardName.equals(d.getName())) {
                return getCachedBluetoothDevice(d);
            }
        }
        return null;
    }

    private CachedBluetoothDevice getDiscoveredKeyboard() {
        for (CachedBluetoothDevice d : this.mCachedDeviceManager.getCachedDevicesCopy()) {
            if (d.getName().equals(this.mKeyboardName)) {
                return d;
            }
        }
        return null;
    }

    private CachedBluetoothDevice getCachedBluetoothDevice(BluetoothDevice d) {
        CachedBluetoothDevice cachedDevice = this.mCachedDeviceManager.findDevice(d);
        if (cachedDevice == null) {
            return this.mCachedDeviceManager.addDevice(this.mLocalBluetoothAdapter, this.mProfileManager, d);
        }
        return cachedDevice;
    }

    private void startScanning() {
        BluetoothLeScanner scanner = this.mLocalBluetoothAdapter.getBluetoothLeScanner();
        ScanFilter filter = new Builder().setDeviceName(this.mKeyboardName).build();
        ScanSettings settings = new ScanSettings.Builder().setCallbackType(1).setNumOfMatches(1).setScanMode(2).setReportDelay(0).build();
        this.mScanCallback = new KeyboardScanCallback();
        scanner.startScan(Arrays.asList(new ScanFilter[]{filter}), settings, this.mScanCallback);
        KeyboardHandler keyboardHandler = this.mHandler;
        int i = this.mScanAttempt + 1;
        this.mScanAttempt = i;
        this.mHandler.sendMessageDelayed(keyboardHandler.obtainMessage(10, i, 0), 30000);
    }

    private void stopScanning() {
        if (this.mScanCallback != null) {
            this.mLocalBluetoothAdapter.getBluetoothLeScanner().stopScan(this.mScanCallback);
            this.mScanCallback = null;
        }
    }

    private void bleAbortScanInternal(int scanAttempt) {
        if (this.mState == 3 && scanAttempt == this.mScanAttempt) {
            stopScanning();
            this.mState = 8;
        }
    }

    private void onDeviceAddedInternal(CachedBluetoothDevice d) {
        if (this.mState == 3 && d.getName().equals(this.mKeyboardName)) {
            stopScanning();
            d.startPairing();
            this.mState = 5;
        }
    }

    private void onBluetoothStateChangedInternal(int bluetoothState) {
        if (bluetoothState == 12 && this.mState == 4) {
            processKeyboardState();
        }
    }

    private void onDeviceBondStateChangedInternal(CachedBluetoothDevice d, int bondState) {
        if (d.getName().equals(this.mKeyboardName) && bondState == 12) {
            this.mState = 6;
        }
    }

    private void onBleScanFailedInternal() {
        this.mScanCallback = null;
        if (this.mState == 3) {
            this.mState = 8;
        }
    }

    private static String stateToString(int state) {
        switch (state) {
            case -1:
                return "STATE_NOT_ENABLED";
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return "STATE_WAITING_FOR_BOOT_COMPLETED";
            case 2:
                return "STATE_WAITING_FOR_TABLET_MODE_EXIT";
            case 3:
                return "STATE_WAITING_FOR_DEVICE_DISCOVERY";
            case 4:
                return "STATE_WAITING_FOR_BLUETOOTH";
            case 5:
                return "STATE_PAIRING";
            case 6:
                return "STATE_PAIRED";
            case 7:
                return "STATE_USER_CANCELLED";
            case 8:
                return "STATE_DEVICE_NOT_FOUND";
            default:
                return "STATE_UNKNOWN";
        }
    }
}
