package com.android.systemui.volume;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import java.util.Objects;

public class SegmentedButtons extends LinearLayout {
    private static final Typeface MEDIUM;
    private static final Typeface REGULAR;
    private Callback mCallback;
    private final OnClickListener mClick;
    private final Context mContext;
    private final LayoutInflater mInflater;
    private Object mSelectedValue;
    private final SpTexts mSpTexts;

    public interface Callback extends com.android.systemui.volume.Interaction.Callback {
        void onSelected(Object obj, boolean z);
    }

    /* renamed from: com.android.systemui.volume.SegmentedButtons.1 */
    class C05501 implements com.android.systemui.volume.Interaction.Callback {
        C05501() {
        }

        public void onInteraction() {
            SegmentedButtons.this.fireInteraction();
        }
    }

    /* renamed from: com.android.systemui.volume.SegmentedButtons.2 */
    class C05512 implements OnClickListener {
        C05512() {
        }

        public void onClick(View v) {
            SegmentedButtons.this.setSelectedValue(v.getTag(), true);
        }
    }

    static {
        REGULAR = Typeface.create("sans-serif", 0);
        MEDIUM = Typeface.create("sans-serif-medium", 0);
    }

    public SegmentedButtons(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mClick = new C05512();
        this.mContext = context;
        this.mInflater = LayoutInflater.from(this.mContext);
        setOrientation(0);
        this.mSpTexts = new SpTexts(this.mContext);
    }

    public void setCallback(Callback callback) {
        this.mCallback = callback;
    }

    public Object getSelectedValue() {
        return this.mSelectedValue;
    }

    public void setSelectedValue(Object value, boolean fromClick) {
        if (!Objects.equals(value, this.mSelectedValue)) {
            this.mSelectedValue = value;
            for (int i = 0; i < getChildCount(); i++) {
                Typeface typeface;
                TextView c = (TextView) getChildAt(i);
                boolean selected = Objects.equals(this.mSelectedValue, c.getTag());
                c.setSelected(selected);
                if (selected) {
                    typeface = MEDIUM;
                } else {
                    typeface = REGULAR;
                }
                c.setTypeface(typeface);
            }
            fireOnSelected(fromClick);
        }
    }

    public void addButton(int labelResId, int contentDescriptionResId, Object value) {
        Button b = (Button) this.mInflater.inflate(2130968637, this, false);
        b.setTag(2131755321, Integer.valueOf(labelResId));
        b.setText(labelResId);
        b.setContentDescription(getResources().getString(contentDescriptionResId));
        LayoutParams lp = (LayoutParams) b.getLayoutParams();
        if (getChildCount() == 0) {
            lp.rightMargin = 0;
            lp.leftMargin = 0;
        }
        b.setLayoutParams(lp);
        addView(b);
        b.setTag(value);
        b.setOnClickListener(this.mClick);
        Interaction.register(b, new C05501());
        this.mSpTexts.add(b);
    }

    public void updateLocale() {
        for (int i = 0; i < getChildCount(); i++) {
            Button b = (Button) getChildAt(i);
            b.setText(((Integer) b.getTag(2131755321)).intValue());
        }
    }

    private void fireOnSelected(boolean fromClick) {
        if (this.mCallback != null) {
            this.mCallback.onSelected(this.mSelectedValue, fromClick);
        }
    }

    private void fireInteraction() {
        if (this.mCallback != null) {
            this.mCallback.onInteraction();
        }
    }
}
