package com.android.systemui.statusbar.phone;

import android.animation.LayoutTransition;
import android.animation.LayoutTransition.TransitionListener;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.app.ActivityManagerNative;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewRootImpl;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.android.systemui.statusbar.policy.DeadZone;
import com.android.systemui.statusbar.policy.KeyButtonView;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

public class NavigationBarView extends LinearLayout {
    private Drawable mBackAltIcon;
    private Drawable mBackAltLandIcon;
    private Drawable mBackIcon;
    private Drawable mBackLandIcon;
    int mBarSize;
    private final NavigationBarTransitions mBarTransitions;
    View mCurrentView;
    private DeadZone mDeadZone;
    int mDisabledFlags;
    final Display mDisplay;
    private C0383H mHandler;
    private Drawable mHomeIcon;
    private Drawable mHomeLandIcon;
    private final OnClickListener mImeSwitcherClickListener;
    private boolean mIsLayoutRtl;
    private boolean mLayoutTransitionsEnabled;
    int mNavigationIconHints;
    private OnVerticalChangedListener mOnVerticalChangedListener;
    private Drawable mRecentIcon;
    private Drawable mRecentLandIcon;
    View[] mRotatedViews;
    boolean mScreenOn;
    boolean mShowMenu;
    private boolean mSwapKeys;
    private NavigationBarViewTaskSwitchHelper mTaskSwitchHelper;
    private Resources mThemedResources;
    private final NavTransitionListener mTransitionListener;
    boolean mVertical;
    private boolean mWakeAndUnlocking;

    /* renamed from: com.android.systemui.statusbar.phone.NavigationBarView.1 */
    class C03821 implements OnClickListener {
        C03821() {
        }

        public void onClick(View view) {
            ((InputMethodManager) NavigationBarView.this.mContext.getSystemService("input_method")).showInputMethodPicker(true);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.NavigationBarView.H */
    private class C0383H extends Handler {
        private C0383H() {
        }

        public void handleMessage(Message m) {
            switch (m.what) {
                case 8686:
                    String how = "" + m.obj;
                    int w = NavigationBarView.this.getWidth();
                    int h = NavigationBarView.this.getHeight();
                    int vw = NavigationBarView.this.mCurrentView.getWidth();
                    if (h != NavigationBarView.this.mCurrentView.getHeight() || w != vw) {
                        Log.w("PhoneStatusBar/NavigationBarView", String.format("*** Invalid layout in navigation bar (%s this=%dx%d cur=%dx%d)", new Object[]{how, Integer.valueOf(w), Integer.valueOf(h), Integer.valueOf(vw), Integer.valueOf(vh)}));
                        NavigationBarView.this.requestLayout();
                    }
                default:
            }
        }
    }

    private class NavTransitionListener implements TransitionListener {
        private boolean mBackTransitioning;
        private long mDuration;
        private boolean mHomeAppearing;
        private TimeInterpolator mInterpolator;
        private long mStartDelay;

        private NavTransitionListener() {
        }

        public void startTransition(LayoutTransition transition, ViewGroup container, View view, int transitionType) {
            if (view.getId() == 2131755176) {
                this.mBackTransitioning = true;
            } else if (view.getId() == 2131755178 && transitionType == 2) {
                this.mHomeAppearing = true;
                this.mStartDelay = transition.getStartDelay(transitionType);
                this.mDuration = transition.getDuration(transitionType);
                this.mInterpolator = transition.getInterpolator(transitionType);
            }
        }

        public void endTransition(LayoutTransition transition, ViewGroup container, View view, int transitionType) {
            if (view.getId() == 2131755176) {
                this.mBackTransitioning = false;
            } else if (view.getId() == 2131755178 && transitionType == 2) {
                this.mHomeAppearing = false;
            }
        }

        public void onBackAltCleared() {
            View backButton = NavigationBarView.this.getBackButton(NavigationBarView.this.mSwapKeys);
            if (!this.mBackTransitioning && backButton.getVisibility() == 0 && this.mHomeAppearing && NavigationBarView.this.getHomeButton().getAlpha() == 0.0f) {
                backButton.setAlpha(0.0f);
                ValueAnimator a = ObjectAnimator.ofFloat(backButton, "alpha", new float[]{0.0f, 1.0f});
                a.setStartDelay(this.mStartDelay);
                a.setDuration(this.mDuration);
                a.setInterpolator(this.mInterpolator);
                a.start();
            }
        }
    }

    public interface OnVerticalChangedListener {
        void onVerticalChanged(boolean z);
    }

    public NavigationBarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mCurrentView = null;
        this.mRotatedViews = new View[4];
        this.mDisabledFlags = 0;
        this.mNavigationIconHints = 0;
        this.mTransitionListener = new NavTransitionListener();
        this.mLayoutTransitionsEnabled = true;
        this.mImeSwitcherClickListener = new C03821();
        this.mHandler = new C0383H();
        this.mDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        Resources res = getContext().getResources();
        this.mBarSize = res.getDimensionPixelSize(2131296277);
        this.mVertical = false;
        this.mShowMenu = false;
        this.mTaskSwitchHelper = new NavigationBarViewTaskSwitchHelper(context);
        getIcons(res);
        this.mBarTransitions = new NavigationBarTransitions(this);
    }

    public void onSwapKeyChanged(boolean swapKeys, boolean animate) {
        if (swapKeys != this.mSwapKeys) {
            this.mSwapKeys = swapKeys;
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ViewRootImpl root = getViewRootImpl();
        if (root != null) {
            root.setDrawDuringWindowsAnimating(true);
        }
    }

    public BarTransitions getBarTransitions() {
        return this.mBarTransitions;
    }

    public void setBar(PhoneStatusBar phoneStatusBar) {
        this.mTaskSwitchHelper.setBar(phoneStatusBar);
    }

    public void setOnVerticalChangedListener(OnVerticalChangedListener onVerticalChangedListener) {
        this.mOnVerticalChangedListener = onVerticalChangedListener;
        notifyVerticalChangedListener(this.mVertical);
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.mTaskSwitchHelper.onTouchEvent(event)) {
            return true;
        }
        if (this.mDeadZone != null && event.getAction() == 4) {
            this.mDeadZone.poke(event);
        }
        return super.onTouchEvent(event);
    }

    public boolean onInterceptTouchEvent(MotionEvent event) {
        return this.mTaskSwitchHelper.onInterceptTouchEvent(event);
    }

    public void abortCurrentGesture() {
        getHomeButton().abortCurrentGesture();
    }

    public View getCurrentView() {
        return this.mCurrentView;
    }

    public View getRecentsButton(boolean swap) {
        return this.mCurrentView.findViewById(swap ? 2131755180 : 2131755179);
    }

    public View getMenuButton() {
        return this.mCurrentView.findViewById(2131755181);
    }

    public View getBackButton(boolean swap) {
        return this.mCurrentView.findViewById(swap ? 2131755177 : 2131755176);
    }

    public KeyButtonView getHomeButton() {
        return (KeyButtonView) this.mCurrentView.findViewById(2131755178);
    }

    public View getImeSwitchButton() {
        return this.mCurrentView.findViewById(2131755182);
    }

    private void getIcons(Resources res) {
        this.mBackIcon = res.getDrawable(2130837710);
        this.mBackLandIcon = this.mBackIcon;
        this.mBackAltIcon = res.getDrawable(2130837711);
        this.mBackAltLandIcon = this.mBackAltIcon;
        this.mRecentIcon = res.getDrawable(2130837719);
        this.mRecentLandIcon = res.getDrawable(2130837720);
        this.mHomeIcon = res.getDrawable(2130837713);
        this.mHomeLandIcon = res.getDrawable(2130837714);
    }

    private Drawable getHomeButtonDrawable() {
        return this.mVertical ? this.mHomeLandIcon : this.mHomeIcon;
    }

    private Drawable getRecentsButtonDrawable() {
        return this.mSwapKeys ? getBackDrawable() : getRecentsDrawable();
    }

    private Drawable getBackButtonDrawable() {
        return this.mSwapKeys ? getRecentsDrawable() : getBackDrawable();
    }

    private Drawable getBackDrawable() {
        return (this.mNavigationIconHints & 1) != 0 ? this.mVertical ? this.mBackAltLandIcon : this.mBackAltIcon : this.mVertical ? this.mBackLandIcon : this.mBackIcon;
    }

    private Drawable getRecentsDrawable() {
        return this.mVertical ? this.mRecentLandIcon : this.mRecentIcon;
    }

    public void updateResources(Resources res) {
        this.mThemedResources = res;
        getIcons(this.mThemedResources);
        this.mBarTransitions.updateResources(res);
        for (ViewGroup container : this.mRotatedViews) {
            if (container != null) {
                updateLightsOutResources(container);
            }
        }
    }

    private void updateLightsOutResources(ViewGroup container) {
        ViewGroup lightsOut = (ViewGroup) container.findViewById(2131755183);
        if (lightsOut != null) {
            int nChildren = lightsOut.getChildCount();
            for (int i = 0; i < nChildren; i++) {
                View child = lightsOut.getChildAt(i);
                if (child instanceof ImageView) {
                    ImageView iv = (ImageView) child;
                    iv.setImageDrawable(null);
                    iv.setImageDrawable(this.mThemedResources.getDrawable(2130837715));
                }
            }
        }
        this.mRecentLandIcon = this.mRecentIcon;
    }

    public void setLayoutDirection(int layoutDirection) {
        getIcons(this.mThemedResources != null ? this.mThemedResources : getContext().getResources());
        super.setLayoutDirection(layoutDirection);
    }

    public void notifyScreenOn(boolean screenOn) {
        this.mScreenOn = screenOn;
        setDisabledFlags(this.mDisabledFlags, true);
    }

    public void setNavigationIconHints(int hints) {
        setNavigationIconHints(hints, false);
    }

    public void setNavigationIconHints(int hints, boolean force) {
        int i = 0;
        if (force || hints != this.mNavigationIconHints) {
            boolean showImeButton;
            boolean backAlt;
            if ((hints & 1) != 0) {
                backAlt = true;
            } else {
                backAlt = false;
            }
            if (!((this.mNavigationIconHints & 1) == 0 || backAlt)) {
                this.mTransitionListener.onBackAltCleared();
            }
            this.mNavigationIconHints = hints;
            ImageView homeButton = getHomeButton();
            ImageView imeButton = (ImageView) getImeSwitchButton();
            setSwappableButtonsVisibility();
            KeyButtonView recentsButton = (KeyButtonView) getRecentsButton(this.mSwapKeys);
            KeyButtonView backButton = (KeyButtonView) getBackButton(this.mSwapKeys);
            homeButton.setImageDrawable(getHomeButtonDrawable());
            recentsButton.setImageDrawable(getRecentsButtonDrawable());
            backButton.setImageDrawable(getBackButtonDrawable());
            if ((hints & 2) != 0) {
                showImeButton = true;
            } else {
                showImeButton = false;
            }
            if (!showImeButton) {
                i = 4;
            }
            imeButton.setVisibility(i);
            setMenuVisibility(this.mShowMenu, true);
            setDisabledFlags(this.mDisabledFlags, true);
        }
    }

    public void setDisabledFlags(int disabledFlags) {
        setDisabledFlags(disabledFlags, false);
    }

    public void setDisabledFlags(int disabledFlags, boolean force) {
        int i = 4;
        boolean z = true;
        if (force || this.mDisabledFlags != disabledFlags) {
            boolean disableHome;
            boolean disableRecent;
            boolean disableBack;
            int i2;
            this.mDisabledFlags = disabledFlags;
            if ((2097152 & disabledFlags) != 0) {
                disableHome = true;
            } else {
                disableHome = false;
            }
            if ((16777216 & disabledFlags) != 0) {
                disableRecent = true;
            } else {
                disableRecent = false;
            }
            if ((4194304 & disabledFlags) == 0 || (this.mNavigationIconHints & 1) != 0) {
                disableBack = false;
            } else {
                disableBack = true;
            }
            boolean disableSearch;
            if ((33554432 & disabledFlags) != 0) {
                disableSearch = true;
            } else {
                disableSearch = false;
            }
            if (!(disableHome && disableRecent && disableBack && disableSearch)) {
                z = false;
            }
            setSlippery(z);
            ViewGroup navButtons = (ViewGroup) this.mCurrentView.findViewById(2131755175);
            if (navButtons != null) {
                LayoutTransition lt = navButtons.getLayoutTransition();
                if (!(lt == null || lt.getTransitionListeners().contains(this.mTransitionListener))) {
                    lt.addTransitionListener(this.mTransitionListener);
                }
            }
            if (inLockTask() && disableRecent && !disableHome) {
                disableRecent = false;
            }
            KeyButtonView homeButton = getHomeButton();
            if (disableHome) {
                i2 = 4;
            } else {
                i2 = 0;
            }
            homeButton.setVisibility(i2);
            View backButton = getBackButton(this.mSwapKeys);
            i2 = (this.mSwapKeys ? disableRecent : disableBack) ? 4 : 0;
            backButton.setVisibility(i2);
            View recentsButton = getRecentsButton(this.mSwapKeys);
            if (this.mSwapKeys ? disableBack : disableRecent) {
                i = 0;
            }
            recentsButton.setVisibility(i);
        }
    }

    private void setSwappableButtonsVisibility() {
        boolean z = true;
        boolean wasLayoutTransitionsEnabled = this.mLayoutTransitionsEnabled;
        setLayoutTransitionsEnabled(false);
        getRecentsButton(!this.mSwapKeys).setVisibility(8);
        if (this.mSwapKeys) {
            z = false;
        }
        getBackButton(z).setVisibility(8);
        getRecentsButton(this.mSwapKeys).setVisibility(8);
        getBackButton(this.mSwapKeys).setVisibility(8);
        getRecentsButton(this.mSwapKeys).setVisibility(0);
        getBackButton(this.mSwapKeys).setVisibility(0);
        setLayoutTransitionsEnabled(wasLayoutTransitionsEnabled);
    }

    private boolean inLockTask() {
        try {
            return ActivityManagerNative.getDefault().isInLockTaskMode();
        } catch (RemoteException e) {
            return false;
        }
    }

    public void setLayoutTransitionsEnabled(boolean enabled) {
        this.mLayoutTransitionsEnabled = enabled;
        updateLayoutTransitionsEnabled();
    }

    public void setWakeAndUnlocking(boolean wakeAndUnlocking) {
        setUseFadingAnimations(wakeAndUnlocking);
        this.mWakeAndUnlocking = wakeAndUnlocking;
        updateLayoutTransitionsEnabled();
    }

    private void updateLayoutTransitionsEnabled() {
        boolean enabled;
        if (this.mWakeAndUnlocking || !this.mLayoutTransitionsEnabled) {
            enabled = false;
        } else {
            enabled = true;
        }
        LayoutTransition lt = ((ViewGroup) this.mCurrentView.findViewById(2131755175)).getLayoutTransition();
        if (lt == null) {
            return;
        }
        if (enabled) {
            lt.enableTransitionType(2);
            lt.enableTransitionType(3);
            lt.enableTransitionType(0);
            lt.enableTransitionType(1);
            return;
        }
        lt.disableTransitionType(2);
        lt.disableTransitionType(3);
        lt.disableTransitionType(0);
        lt.disableTransitionType(1);
    }

    private void setUseFadingAnimations(boolean useFadingAnimations) {
        LayoutParams lp = (LayoutParams) getLayoutParams();
        if (lp != null) {
            boolean old = lp.windowAnimations != 0;
            if (!old && useFadingAnimations) {
                lp.windowAnimations = 2131492905;
            } else if (old && !useFadingAnimations) {
                lp.windowAnimations = 0;
            } else {
                return;
            }
            ((WindowManager) getContext().getSystemService("window")).updateViewLayout(this, lp);
        }
    }

    public void setSlippery(boolean newSlippery) {
        LayoutParams lp = (LayoutParams) getLayoutParams();
        if (lp != null) {
            boolean oldSlippery = (lp.flags & 536870912) != 0;
            if (!oldSlippery && newSlippery) {
                lp.flags |= 536870912;
            } else if (oldSlippery && !newSlippery) {
                lp.flags &= -536870913;
            } else {
                return;
            }
            ((WindowManager) getContext().getSystemService("window")).updateViewLayout(this, lp);
        }
    }

    public void setMenuVisibility(boolean show) {
        setMenuVisibility(show, false);
    }

    public void setMenuVisibility(boolean show, boolean force) {
        int i = 0;
        if (force || this.mShowMenu != show) {
            boolean shouldShow;
            this.mShowMenu = show;
            if (this.mShowMenu && (this.mNavigationIconHints & 2) == 0) {
                shouldShow = true;
            } else {
                shouldShow = false;
            }
            View menuButton = getMenuButton();
            if (!shouldShow) {
                i = 4;
            }
            menuButton.setVisibility(i);
        }
    }

    public void onFinishInflate() {
        View[] viewArr = this.mRotatedViews;
        View[] viewArr2 = this.mRotatedViews;
        View findViewById = findViewById(2131755174);
        viewArr2[2] = findViewById;
        viewArr[0] = findViewById;
        this.mRotatedViews[1] = findViewById(2131755185);
        this.mRotatedViews[3] = this.mRotatedViews[1];
        this.mCurrentView = this.mRotatedViews[0];
        getImeSwitchButton().setOnClickListener(this.mImeSwitcherClickListener);
        updateRTLOrder();
    }

    public void reorient() {
        int rot = this.mDisplay.getRotation();
        for (int i = 0; i < 4; i++) {
            this.mRotatedViews[i].setVisibility(8);
        }
        this.mCurrentView = this.mRotatedViews[rot];
        this.mCurrentView.setVisibility(0);
        updateLayoutTransitionsEnabled();
        getImeSwitchButton().setOnClickListener(this.mImeSwitcherClickListener);
        this.mDeadZone = (DeadZone) this.mCurrentView.findViewById(2131755184);
        this.mBarTransitions.init();
        setDisabledFlags(this.mDisabledFlags, true);
        setMenuVisibility(this.mShowMenu, true);
        updateTaskSwitchHelper();
        setNavigationIconHints(this.mNavigationIconHints, true);
    }

    private void updateTaskSwitchHelper() {
        boolean isRtl = true;
        if (getLayoutDirection() != 1) {
            isRtl = false;
        }
        this.mTaskSwitchHelper.setBarState(this.mVertical, isRtl);
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        boolean newVertical = w > 0 && h > w;
        if (newVertical != this.mVertical) {
            this.mVertical = newVertical;
            reorient();
            notifyVerticalChangedListener(newVertical);
        }
        postCheckForInvalidLayout("sizeChanged");
        super.onSizeChanged(w, h, oldw, oldh);
    }

    private void notifyVerticalChangedListener(boolean newVertical) {
        if (this.mOnVerticalChangedListener != null) {
            this.mOnVerticalChangedListener.onVerticalChanged(newVertical);
        }
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        updateRTLOrder();
        updateTaskSwitchHelper();
    }

    private void updateRTLOrder() {
        boolean isLayoutRtl = getResources().getConfiguration().getLayoutDirection() == 1;
        if (this.mIsLayoutRtl != isLayoutRtl) {
            View rotation90 = this.mRotatedViews[1];
            swapChildrenOrderIfVertical(rotation90.findViewById(2131755175));
            adjustExtraKeyGravity(rotation90, isLayoutRtl);
            View rotation270 = this.mRotatedViews[3];
            if (rotation90 != rotation270) {
                swapChildrenOrderIfVertical(rotation270.findViewById(2131755175));
                adjustExtraKeyGravity(rotation270, isLayoutRtl);
            }
            this.mIsLayoutRtl = isLayoutRtl;
        }
    }

    private void adjustExtraKeyGravity(View navBar, boolean isLayoutRtl) {
        int i = 80;
        View menu = navBar.findViewById(2131755181);
        View imeSwitcher = navBar.findViewById(2131755182);
        if (menu != null) {
            int i2;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) menu.getLayoutParams();
            if (isLayoutRtl) {
                i2 = 80;
            } else {
                i2 = 48;
            }
            lp.gravity = i2;
            menu.setLayoutParams(lp);
        }
        if (imeSwitcher != null) {
            lp = (FrameLayout.LayoutParams) imeSwitcher.getLayoutParams();
            if (!isLayoutRtl) {
                i = 48;
            }
            lp.gravity = i;
            imeSwitcher.setLayoutParams(lp);
        }
    }

    private void swapChildrenOrderIfVertical(View group) {
        if (group instanceof LinearLayout) {
            LinearLayout linearLayout = (LinearLayout) group;
            if (linearLayout.getOrientation() == 1) {
                int i;
                int childCount = linearLayout.getChildCount();
                ArrayList<View> childList = new ArrayList(childCount);
                for (i = 0; i < childCount; i++) {
                    childList.add(linearLayout.getChildAt(i));
                }
                linearLayout.removeAllViews();
                for (i = childCount - 1; i >= 0; i--) {
                    linearLayout.addView((View) childList.get(i));
                }
            }
        }
    }

    private String getResourceName(int resId) {
        if (resId == 0) {
            return "(null)";
        }
        try {
            return getContext().getResources().getResourceName(resId);
        } catch (NotFoundException e) {
            return "(unknown)";
        }
    }

    private void postCheckForInvalidLayout(String how) {
        this.mHandler.obtainMessage(8686, 0, 0, how).sendToTarget();
    }

    private static String visibilityToString(int vis) {
        switch (vis) {
            case 4:
                return "INVISIBLE";
            case 8:
                return "GONE";
            default:
                return "VISIBLE";
        }
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        boolean offscreen;
        pw.println("NavigationBarView {");
        Rect r = new Rect();
        Point size = new Point();
        this.mDisplay.getRealSize(size);
        pw.println(String.format("      this: " + PhoneStatusBar.viewInfo(this) + " " + visibilityToString(getVisibility()), new Object[0]));
        getWindowVisibleDisplayFrame(r);
        if (r.right > size.x || r.bottom > size.y) {
            offscreen = true;
        } else {
            offscreen = false;
        }
        pw.println("      window: " + r.toShortString() + " " + visibilityToString(getWindowVisibility()) + (offscreen ? " OFFSCREEN!" : ""));
        pw.println(String.format("      mCurrentView: id=%s (%dx%d) %s", new Object[]{getResourceName(this.mCurrentView.getId()), Integer.valueOf(this.mCurrentView.getWidth()), Integer.valueOf(this.mCurrentView.getHeight()), visibilityToString(this.mCurrentView.getVisibility())}));
        String str = "      disabled=0x%08x vertical=%s menu=%s";
        Object[] objArr = new Object[3];
        objArr[0] = Integer.valueOf(this.mDisabledFlags);
        objArr[1] = this.mVertical ? "true" : "false";
        objArr[2] = this.mShowMenu ? "true" : "false";
        pw.println(String.format(str, objArr));
        dumpButton(pw, "back", getBackButton(false));
        dumpButton(pw, "home", getHomeButton());
        dumpButton(pw, "rcnt", getRecentsButton(false));
        dumpButton(pw, "menu", getMenuButton());
        pw.println("    }");
    }

    private static void dumpButton(PrintWriter pw, String caption, View button) {
        pw.print("      " + caption + ": ");
        if (button == null) {
            pw.print("null");
        } else {
            pw.print(PhoneStatusBar.viewInfo(button) + " " + visibilityToString(button.getVisibility()) + " alpha=" + button.getAlpha());
        }
        pw.println();
    }
}
