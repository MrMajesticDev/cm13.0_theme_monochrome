package com.android.systemui.statusbar;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;

public abstract class ExpandableOutlineView extends ExpandableView {
    private boolean mCustomOutline;
    private float mOutlineAlpha;
    private final Rect mOutlineRect;
    private float mRoundCornerRadius;
    protected final int mRoundedRectCornerRadius;

    /* renamed from: com.android.systemui.statusbar.ExpandableOutlineView.1 */
    class C03121 extends ViewOutlineProvider {
        C03121() {
        }

        public void getOutline(View view, Outline outline) {
            if (ExpandableOutlineView.this.mCustomOutline) {
                outline.setRoundRect(ExpandableOutlineView.this.mOutlineRect, ExpandableOutlineView.this.mRoundCornerRadius);
            } else {
                outline.setRoundRect(0, ExpandableOutlineView.this.mClipTopAmount, ExpandableOutlineView.this.getWidth(), Math.max(ExpandableOutlineView.this.getActualHeight(), ExpandableOutlineView.this.mClipTopAmount), ExpandableOutlineView.this.mRoundCornerRadius);
            }
            outline.setAlpha(ExpandableOutlineView.this.mOutlineAlpha);
        }
    }

    public ExpandableOutlineView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mOutlineRect = new Rect();
        this.mRoundCornerRadius = 0.0f;
        this.mOutlineAlpha = 1.0f;
        this.mRoundedRectCornerRadius = getResources().getDimensionPixelSize(2131296392);
        setOutlineProvider(new C03121());
    }

    public void setActualHeight(int actualHeight, boolean notifyListeners) {
        super.setActualHeight(actualHeight, notifyListeners);
        invalidateOutline();
    }

    public void setClipTopAmount(int clipTopAmount) {
        super.setClipTopAmount(clipTopAmount);
        invalidateOutline();
    }

    protected void setOutlineAlpha(float alpha) {
        this.mOutlineAlpha = alpha;
        invalidateOutline();
    }

    protected void setOutlineRect(RectF rect) {
        if (rect != null) {
            setOutlineRect(rect.left, rect.top, rect.right, rect.bottom);
            return;
        }
        this.mCustomOutline = false;
        setClipToOutline(false);
        invalidateOutline();
    }

    protected void setOutlineRect(float left, float top, float right, float bottom) {
        this.mCustomOutline = true;
        setClipToOutline(true);
        this.mOutlineRect.set((int) left, (int) top, (int) right, (int) bottom);
        this.mOutlineRect.bottom = (int) Math.max(top, (float) this.mOutlineRect.bottom);
        this.mOutlineRect.right = (int) Math.max(left, (float) this.mOutlineRect.right);
        invalidateOutline();
    }

    protected void setRoundCornerRadius(float roundRadius) {
        this.mRoundCornerRadius = roundRadius;
    }
}
