package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.qs.QSDetailItems;
import com.android.systemui.qs.QSDetailItems.Item;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.ResourceIcon;
import com.android.systemui.statusbar.policy.CastController;
import com.android.systemui.statusbar.policy.CastController.CastDevice;
import com.android.systemui.statusbar.policy.KeyguardMonitor;
import java.util.LinkedHashMap;
import java.util.Set;

public class CastTile extends QSTile<BooleanState> {
    private static final Intent CAST_SETTINGS;
    private final Callback mCallback;
    private final CastController mController;
    private final CastDetailAdapter mDetailAdapter;
    private final KeyguardMonitor mKeyguard;

    private final class Callback implements com.android.systemui.statusbar.policy.CastController.Callback, com.android.systemui.statusbar.policy.KeyguardMonitor.Callback {
        private Callback() {
        }

        public void onCastDevicesChanged() {
            CastTile.this.refreshState();
        }

        public void onKeyguardChanged() {
            CastTile.this.refreshState();
        }
    }

    private final class CastDetailAdapter implements com.android.systemui.qs.QSDetailItems.Callback, DetailAdapter {
        private QSDetailItems mItems;
        private final LinkedHashMap<String, CastDevice> mVisibleOrder;

        /* renamed from: com.android.systemui.qs.tiles.CastTile.CastDetailAdapter.1 */
        class C01831 implements OnAttachStateChangeListener {
            C01831() {
            }

            public void onViewAttachedToWindow(View v) {
                if (CastTile.DEBUG) {
                    Log.d(CastTile.this.TAG, "onViewAttachedToWindow");
                }
            }

            public void onViewDetachedFromWindow(View v) {
                if (CastTile.DEBUG) {
                    Log.d(CastTile.this.TAG, "onViewDetachedFromWindow");
                }
                CastDetailAdapter.this.mVisibleOrder.clear();
            }
        }

        private CastDetailAdapter() {
            this.mVisibleOrder = new LinkedHashMap();
        }

        public int getTitle() {
            return 2131362196;
        }

        public Boolean getToggleState() {
            return null;
        }

        public Intent getSettingsIntent() {
            return CastTile.CAST_SETTINGS;
        }

        public void setToggleState(boolean state) {
        }

        public int getMetricsCategory() {
            return 151;
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            this.mItems = QSDetailItems.convertOrInflate(context, convertView, parent);
            this.mItems.setTagSuffix("Cast");
            if (convertView == null) {
                if (CastTile.DEBUG) {
                    Log.d(CastTile.this.TAG, "addOnAttachStateChangeListener");
                }
                this.mItems.addOnAttachStateChangeListener(new C01831());
            }
            this.mItems.setEmptyState(2130837626, 2131362200);
            this.mItems.setCallback(this);
            updateItems(CastTile.this.mController.getCastDevices());
            CastTile.this.mController.setDiscovering(true);
            return this.mItems;
        }

        private void updateItems(Set<CastDevice> devices) {
            if (this.mItems != null) {
                Item[] items = null;
                if (!(devices == null || devices.isEmpty())) {
                    CastDevice device;
                    Item item;
                    for (CastDevice device2 : devices) {
                        if (device2.state == 2) {
                            item = new Item();
                            item.icon = 2130837628;
                            item.line1 = CastTile.this.getDeviceName(device2);
                            item.line2 = CastTile.this.mContext.getString(2131362207);
                            item.tag = device2;
                            item.canDisconnect = true;
                            items = new Item[]{item};
                            break;
                        }
                    }
                    if (items == null) {
                        for (CastDevice device22 : devices) {
                            this.mVisibleOrder.put(device22.id, device22);
                        }
                        items = new Item[devices.size()];
                        int i = 0;
                        for (String id : this.mVisibleOrder.keySet()) {
                            device22 = (CastDevice) this.mVisibleOrder.get(id);
                            if (devices.contains(device22)) {
                                item = new Item();
                                item.icon = 2130837627;
                                item.line1 = CastTile.this.getDeviceName(device22);
                                if (device22.state == 1) {
                                    item.line2 = CastTile.this.mContext.getString(2131362208);
                                }
                                item.tag = device22;
                                int i2 = i + 1;
                                items[i] = item;
                                i = i2;
                            }
                        }
                    }
                }
                this.mItems.setItems(items);
            }
        }

        public void onDetailItemClick(Item item) {
            if (item != null && item.tag != null) {
                MetricsLogger.action(CastTile.this.mContext, 157);
                CastTile.this.mController.startCasting(item.tag);
            }
        }

        public void onDetailItemDisconnect(Item item) {
            if (item != null && item.tag != null) {
                MetricsLogger.action(CastTile.this.mContext, 158);
                CastTile.this.mController.stopCasting(item.tag);
            }
        }
    }

    static {
        CAST_SETTINGS = new Intent("android.settings.CAST_SETTINGS");
    }

    public CastTile(Host host) {
        super(host, "cast");
        this.mCallback = new Callback();
        this.mController = host.getCastController();
        this.mDetailAdapter = new CastDetailAdapter();
        this.mKeyguard = host.getKeyguardMonitor();
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void setListening(boolean listening) {
        if (this.mController != null) {
            if (DEBUG) {
                Log.d(this.TAG, "setListening " + listening);
            }
            if (listening) {
                this.mController.addCallback(this.mCallback);
                this.mKeyguard.addCallback(this.mCallback);
                return;
            }
            this.mController.setDiscovering(false);
            this.mController.removeCallback(this.mCallback);
            this.mKeyguard.removeCallback(this.mCallback);
        }
    }

    protected void handleUserSwitch(int newUserId) {
        super.handleUserSwitch(newUserId);
        if (this.mController != null) {
            this.mController.setCurrentUserId(newUserId);
        }
    }

    protected void handleToggleClick() {
        handleDetailClick();
    }

    protected void handleDetailClick() {
        MetricsLogger.action(this.mContext, getMetricsCategory());
        showDetail(true);
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        boolean z;
        if (this.mKeyguard.isSecure() && this.mKeyguard.isShowing() && !this.mKeyguard.canSkipBouncer()) {
            z = false;
        } else {
            z = true;
        }
        state.visible = z;
        state.label = this.mContext.getString(2131362196);
        state.value = false;
        state.autoMirrorDrawable = false;
        Set<CastDevice> devices = this.mController.getCastDevices();
        boolean connecting = false;
        for (CastDevice device : devices) {
            if (device.state == 2) {
                state.value = true;
                state.label = getDeviceName(device);
            } else if (device.state == 1) {
                connecting = true;
            }
        }
        if (!state.value && connecting) {
            state.label = this.mContext.getString(2131362208);
        }
        state.icon = ResourceIcon.get(state.value ? 2130837628 : 2130837627);
        this.mDetailAdapter.updateItems(devices);
    }

    public int getMetricsCategory() {
        return 114;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return null;
        }
        return this.mContext.getString(2131362142);
    }

    private String getDeviceName(CastDevice device) {
        return device.name != null ? device.name : this.mContext.getString(2131362198);
    }
}
