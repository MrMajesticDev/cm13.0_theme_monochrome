package com.android.systemui.egg;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

public class MLandActivity extends Activity {
    MLand mLand;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(2130968601);
        this.mLand = (MLand) findViewById(2131755153);
        this.mLand.setScoreFieldHolder((ViewGroup) findViewById(2131755160));
        this.mLand.setSplash(findViewById(2131755154));
        int numControllers = this.mLand.getGameControllers().size();
        if (numControllers > 0) {
            this.mLand.setupPlayers(numControllers);
        }
    }

    public void updateSplashPlayers() {
        int N = this.mLand.getNumPlayers();
        View minus = findViewById(2131755159);
        View plus = findViewById(2131755161);
        if (N == 1) {
            minus.setVisibility(4);
            plus.setVisibility(0);
            plus.requestFocus();
            return;
        }
        MLand mLand = this.mLand;
        if (N == 6) {
            minus.setVisibility(0);
            plus.setVisibility(4);
            minus.requestFocus();
            return;
        }
        minus.setVisibility(0);
        plus.setVisibility(0);
    }

    public void onPause() {
        this.mLand.stop();
        super.onPause();
    }

    public void onResume() {
        super.onResume();
        this.mLand.onAttachedToWindow();
        updateSplashPlayers();
        this.mLand.showSplash();
    }

    public void playerMinus(View v) {
        this.mLand.removePlayer();
        updateSplashPlayers();
    }

    public void playerPlus(View v) {
        this.mLand.addPlayer();
        updateSplashPlayers();
    }

    public void startButtonPressed(View v) {
        findViewById(2131755159).setVisibility(4);
        findViewById(2131755161).setVisibility(4);
        this.mLand.start(true);
    }
}
