package com.android.systemui.statusbar.policy;

public class AccessibilityContentDescriptions {
    static final int[] DATA_CONNECTION_STRENGTH;
    static final int[] ETHERNET_CONNECTION_VALUES;
    static final int[] PHONE_SIGNAL_STRENGTH;
    static final int[] WIFI_CONNECTION_STRENGTH;

    static {
        PHONE_SIGNAL_STRENGTH = new int[]{2131362030, 2131362031, 2131362032, 2131362033, 2131362034};
        DATA_CONNECTION_STRENGTH = new int[]{2131362035, 2131362036, 2131362037, 2131362038, 2131362039};
        WIFI_CONNECTION_STRENGTH = new int[]{2131361868, 2131361869, 2131361870, 2131361871, 2131361872};
        ETHERNET_CONNECTION_VALUES = new int[]{2131362047, 2131362048};
    }
}
