package com.android.systemui;

/* renamed from: com.android.systemui.R */
public final class C0095R {

    /* renamed from: com.android.systemui.R.styleable */
    public static final class styleable {
        public static final int[] AlphaOptimizedImageView;
        public static final int[] BatteryMeterView;
        public static final int[] BatteryMeterViewDrawable;
        public static final int[] CarrierText;
        public static final int[] Clock;
        public static final int[] DateView;
        public static final int[] DeadZone;
        public static final int[] KeyButtonView;
        public static final int[] KeyguardSecurityViewFlipper_Layout;
        public static final int[] NotificationLinearLayout;
        public static final int[] NotificationRowLayout;
        public static final int[] NumPadKey;
        public static final int[] PasswordTextView;
        public static final int[] PseudoGridView;
        public static final int[] RecentsPanelView;
        public static final int[] StatusBarWindowView_Layout;
        public static final int[] ToggleSlider;
        public static final int[] TonedIcon;
        public static final int[] UserAvatarView;
        public static final int[] UserDetailItemView;

        static {
            AlphaOptimizedImageView = new int[]{2130771994};
            BatteryMeterView = new int[]{2130771978};
            BatteryMeterViewDrawable = new int[]{16842927, 2130771995};
            CarrierText = new int[]{2130772001};
            Clock = new int[]{2130771979};
            DateView = new int[]{2130771986};
            DeadZone = new int[]{2130771974, 2130771975, 2130771976, 2130771977, 2130771980};
            KeyButtonView = new int[]{16843379, 2130771968, 2130771969};
            KeyguardSecurityViewFlipper_Layout = new int[]{2130771996, 2130771997};
            NotificationLinearLayout = new int[]{2130771971};
            NotificationRowLayout = new int[]{2130771972};
            NumPadKey = new int[]{2130771998, 2130771999};
            PasswordTextView = new int[]{2130772000};
            PseudoGridView = new int[]{2130771987, 2130771988, 2130771989};
            RecentsPanelView = new int[]{2130771973};
            StatusBarWindowView_Layout = new int[]{2130771993};
            ToggleSlider = new int[]{2130771970};
            TonedIcon = new int[]{2130771990, 2130771991, 2130771992};
            UserAvatarView = new int[]{2130771978, 2130771981, 2130771982, 2130771983};
            UserDetailItemView = new int[]{2130771984, 2130771985};
        }
    }
}
