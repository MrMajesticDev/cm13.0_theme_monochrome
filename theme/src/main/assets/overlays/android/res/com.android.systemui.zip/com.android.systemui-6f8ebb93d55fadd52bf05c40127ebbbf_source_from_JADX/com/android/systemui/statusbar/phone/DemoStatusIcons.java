package com.android.systemui.statusbar.phone;

import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.os.UserHandle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.android.internal.statusbar.StatusBarIcon;
import com.android.systemui.DemoMode;
import com.android.systemui.statusbar.StatusBarIconView;

public class DemoStatusIcons extends LinearLayout implements DemoMode {
    private boolean mDemoMode;
    private final int mIconSize;
    private final LinearLayout mStatusIcons;

    public DemoStatusIcons(LinearLayout statusIcons, int iconSize) {
        super(statusIcons.getContext());
        this.mStatusIcons = statusIcons;
        this.mIconSize = iconSize;
        setLayoutParams(this.mStatusIcons.getLayoutParams());
        setOrientation(this.mStatusIcons.getOrientation());
        setGravity(16);
        ViewGroup p = (ViewGroup) this.mStatusIcons.getParent();
        p.addView(this, p.indexOfChild(this.mStatusIcons));
    }

    public void dispatchDemoCommand(String command, Bundle args) {
        if (!this.mDemoMode && command.equals("enter")) {
            this.mDemoMode = true;
            this.mStatusIcons.setVisibility(8);
            setVisibility(0);
        } else if (this.mDemoMode && command.equals("exit")) {
            this.mDemoMode = false;
            this.mStatusIcons.setVisibility(0);
            setVisibility(8);
        } else if (this.mDemoMode && command.equals("status")) {
            int iconId;
            String volume = args.getString("volume");
            if (volume != null) {
                updateSlot("volume", null, volume.equals("vibrate") ? 2130837915 : 0);
            }
            String zen = args.getString("zen");
            if (zen != null) {
                iconId = zen.equals("important") ? 2130838154 : zen.equals("none") ? 2130838155 : 0;
                updateSlot("zen", null, iconId);
            }
            String bt = args.getString("bluetooth");
            if (bt != null) {
                iconId = bt.equals("disconnected") ? 2130837826 : bt.equals("connected") ? 2130837827 : 0;
                updateSlot("bluetooth", null, iconId);
            }
            String location = args.getString("location");
            if (location != null) {
                updateSlot("location", null, location.equals("show") ? 2130837870 : 0);
            }
            String alarm = args.getString("alarm");
            if (alarm != null) {
                updateSlot("alarm_clock", null, alarm.equals("show") ? 2130837823 : 0);
            }
            String tty = args.getString("tty");
            if (tty != null) {
                updateSlot("tty", null, tty.equals("show") ? 2130838138 : 0);
            }
            String mute = args.getString("mute");
            if (mute != null) {
                updateSlot("mute", null, mute.equals("show") ? 17301622 : 0);
            }
            String speakerphone = args.getString("speakerphone");
            if (speakerphone != null) {
                updateSlot("speakerphone", null, speakerphone.equals("show") ? 17301639 : 0);
            }
            String cast = args.getString("cast");
            if (cast != null) {
                updateSlot("cast", null, cast.equals("show") ? 2130837825 : 0);
            }
            String hotspot = args.getString("hotspot");
            if (hotspot != null) {
                updateSlot("hotspot", null, hotspot.equals("show") ? 2130837869 : 0);
            }
        }
    }

    private void updateSlot(String slot, String iconPkg, int iconId) {
        if (this.mDemoMode) {
            StatusBarIconView v;
            StatusBarIcon icon;
            if (iconPkg == null) {
                iconPkg = this.mContext.getPackageName();
            }
            int removeIndex = -1;
            int i = 0;
            while (i < getChildCount()) {
                v = (StatusBarIconView) getChildAt(i);
                if (!slot.equals(v.getTag())) {
                    i++;
                } else if (iconId == 0) {
                    removeIndex = i;
                    if (iconId == 0) {
                        icon = new StatusBarIcon(iconPkg, UserHandle.OWNER, iconId, 0, 0, "Demo");
                        v = new StatusBarIconView(getContext(), null, null);
                        v.setTag(slot);
                        v.set(icon);
                        addView(v, 0, new LayoutParams(this.mIconSize, this.mIconSize));
                    } else if (removeIndex != -1) {
                        removeViewAt(removeIndex);
                    }
                } else {
                    icon = v.getStatusBarIcon();
                    icon.icon = Icon.createWithResource(icon.icon.getResPackage(), iconId);
                    v.set(icon);
                    v.updateDrawable();
                    return;
                }
            }
            if (iconId == 0) {
                icon = new StatusBarIcon(iconPkg, UserHandle.OWNER, iconId, 0, 0, "Demo");
                v = new StatusBarIconView(getContext(), null, null);
                v.setTag(slot);
                v.set(icon);
                addView(v, 0, new LayoutParams(this.mIconSize, this.mIconSize));
            } else if (removeIndex != -1) {
                removeViewAt(removeIndex);
            }
        }
    }
}
