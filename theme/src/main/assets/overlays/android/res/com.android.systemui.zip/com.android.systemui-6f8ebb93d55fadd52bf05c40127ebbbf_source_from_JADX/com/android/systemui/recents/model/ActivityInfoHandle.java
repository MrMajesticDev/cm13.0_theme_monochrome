package com.android.systemui.recents.model;

import android.content.pm.ActivityInfo;

/* compiled from: RecentsTaskLoader */
class ActivityInfoHandle {
    ActivityInfo info;

    ActivityInfoHandle() {
    }
}
