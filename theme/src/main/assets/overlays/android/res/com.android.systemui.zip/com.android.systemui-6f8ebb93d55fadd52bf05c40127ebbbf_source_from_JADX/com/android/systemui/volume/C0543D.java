package com.android.systemui.volume;

import android.util.Log;

/* renamed from: com.android.systemui.volume.D */
class C0543D {
    public static boolean BUG;

    static {
        BUG = Log.isLoggable("volume", 3);
    }
}
