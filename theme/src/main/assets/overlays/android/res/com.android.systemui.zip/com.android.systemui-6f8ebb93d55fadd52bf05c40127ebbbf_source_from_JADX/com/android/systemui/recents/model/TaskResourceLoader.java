package com.android.systemui.recents.model;

import android.app.ActivityManager.TaskDescription;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.HandlerThread;
import com.android.systemui.recents.misc.SystemServicesProxy;
import com.android.systemui.recents.model.Task.TaskKey;

/* compiled from: RecentsTaskLoader */
class TaskResourceLoader implements Runnable {
    static boolean DEBUG;
    static String TAG;
    DrawableLruCache mApplicationIconCache;
    boolean mCancelled;
    Context mContext;
    BitmapDrawable mDefaultApplicationIcon;
    Bitmap mDefaultThumbnail;
    TaskResourceLoadQueue mLoadQueue;
    HandlerThread mLoadThread;
    Handler mLoadThreadHandler;
    Handler mMainThreadHandler;
    SystemServicesProxy mSystemServicesProxy;
    BitmapLruCache mThumbnailCache;
    boolean mWaitingOnLoadQueue;

    /* renamed from: com.android.systemui.recents.model.TaskResourceLoader.1 */
    class RecentsTaskLoader implements Runnable {
        final /* synthetic */ Drawable val$newIcon;
        final /* synthetic */ Bitmap val$newThumbnail;
        final /* synthetic */ Task val$t;

        RecentsTaskLoader(Task task, Bitmap bitmap, Drawable drawable) {
            this.val$t = task;
            this.val$newThumbnail = bitmap;
            this.val$newIcon = drawable;
        }

        public void run() {
            this.val$t.notifyTaskDataLoaded(this.val$newThumbnail, this.val$newIcon);
        }
    }

    static {
        TAG = "TaskResourceLoader";
        DEBUG = false;
    }

    public TaskResourceLoader(TaskResourceLoadQueue loadQueue, DrawableLruCache applicationIconCache, BitmapLruCache thumbnailCache, Bitmap defaultThumbnail, BitmapDrawable defaultApplicationIcon) {
        this.mLoadQueue = loadQueue;
        this.mApplicationIconCache = applicationIconCache;
        this.mThumbnailCache = thumbnailCache;
        this.mDefaultThumbnail = defaultThumbnail;
        this.mDefaultApplicationIcon = defaultApplicationIcon;
        this.mMainThreadHandler = new Handler();
        this.mLoadThread = new HandlerThread("Recents-TaskResourceLoader", 10);
        this.mLoadThread.start();
        this.mLoadThreadHandler = new Handler(this.mLoadThread.getLooper());
        this.mLoadThreadHandler.post(this);
    }

    void start(Context context) {
        this.mContext = context;
        this.mCancelled = false;
        this.mSystemServicesProxy = new SystemServicesProxy(context);
        synchronized (this.mLoadThread) {
            this.mLoadThread.notifyAll();
        }
    }

    void stop() {
        this.mCancelled = true;
        this.mSystemServicesProxy = null;
        if (this.mWaitingOnLoadQueue) {
            this.mContext = null;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
        r14 = this;
    L_0x0000:
        r0 = r14.mCancelled;
        if (r0 == 0) goto L_0x0019;
    L_0x0004:
        r0 = 0;
        r14.mContext = r0;
        r1 = r14.mLoadThread;
        monitor-enter(r1);
        r0 = r14.mLoadThread;	 Catch:{ InterruptedException -> 0x0014 }
        r0.wait();	 Catch:{ InterruptedException -> 0x0014 }
    L_0x000f:
        monitor-exit(r1);	 Catch:{ all -> 0x0011 }
        goto L_0x0000;
    L_0x0011:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0011 }
        throw r0;
    L_0x0014:
        r9 = move-exception;
        r9.printStackTrace();	 Catch:{ all -> 0x0011 }
        goto L_0x000f;
    L_0x0019:
        r8 = com.android.systemui.recents.RecentsConfiguration.getInstance();
        r4 = r14.mSystemServicesProxy;
        if (r4 == 0) goto L_0x00e6;
    L_0x0021:
        r0 = r14.mLoadQueue;
        r13 = r0.nextTask();
        if (r13 == 0) goto L_0x00e6;
    L_0x0029:
        r0 = r14.mApplicationIconCache;
        r1 = r13.key;
        r6 = r0.get(r1);
        r6 = (android.graphics.drawable.Drawable) r6;
        r0 = r14.mThumbnailCache;
        r1 = r13.key;
        r7 = r0.get(r1);
        r7 = (android.graphics.Bitmap) r7;
        if (r6 != 0) goto L_0x0095;
    L_0x003f:
        r1 = r13.key;
        r2 = r13.icon;
        r3 = r13.iconFilename;
        r0 = r14.mContext;
        r5 = r0.getResources();
        r0 = r14;
        r6 = r0.getTaskDescriptionIcon(r1, r2, r3, r4, r5);
        if (r6 != 0) goto L_0x008a;
    L_0x0052:
        r0 = r13.key;
        r0 = r0.baseIntent;
        r0 = r0.getComponent();
        r1 = r13.key;
        r1 = r1.userId;
        r10 = r4.getActivityInfo(r0, r1);
        if (r10 == 0) goto L_0x008a;
    L_0x0064:
        r0 = DEBUG;
        if (r0 == 0) goto L_0x0082;
    L_0x0068:
        r0 = TAG;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Loading icon: ";
        r1 = r1.append(r2);
        r2 = r13.key;
        r1 = r1.append(r2);
        r1 = r1.toString();
        android.util.Log.d(r0, r1);
    L_0x0082:
        r0 = r13.key;
        r0 = r0.userId;
        r6 = r4.getActivityIcon(r10, r0);
    L_0x008a:
        if (r6 != 0) goto L_0x008e;
    L_0x008c:
        r6 = r14.mDefaultApplicationIcon;
    L_0x008e:
        r0 = r14.mApplicationIconCache;
        r1 = r13.key;
        r0.put(r1, r6);
    L_0x0095:
        if (r7 != 0) goto L_0x00d2;
    L_0x0097:
        r0 = r8.svelteLevel;
        r1 = 3;
        if (r0 >= r1) goto L_0x00c2;
    L_0x009c:
        r0 = DEBUG;
        if (r0 == 0) goto L_0x00ba;
    L_0x00a0:
        r0 = TAG;
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Loading thumbnail: ";
        r1 = r1.append(r2);
        r2 = r13.key;
        r1 = r1.append(r2);
        r1 = r1.toString();
        android.util.Log.d(r0, r1);
    L_0x00ba:
        r0 = r13.key;
        r0 = r0.id;
        r7 = r4.getTaskThumbnail(r0);
    L_0x00c2:
        if (r7 != 0) goto L_0x00c6;
    L_0x00c4:
        r7 = r14.mDefaultThumbnail;
    L_0x00c6:
        r0 = r8.svelteLevel;
        r1 = 1;
        if (r0 >= r1) goto L_0x00d2;
    L_0x00cb:
        r0 = r14.mThumbnailCache;
        r1 = r13.key;
        r0.put(r1, r7);
    L_0x00d2:
        r0 = r14.mCancelled;
        if (r0 != 0) goto L_0x00e6;
    L_0x00d6:
        r11 = r6;
        r0 = r14.mDefaultThumbnail;
        if (r7 != r0) goto L_0x0106;
    L_0x00db:
        r12 = 0;
    L_0x00dc:
        r0 = r14.mMainThreadHandler;
        r1 = new com.android.systemui.recents.model.TaskResourceLoader$1;
        r1.<init>(r13, r12, r11);
        r0.post(r1);
    L_0x00e6:
        r0 = r14.mCancelled;
        if (r0 != 0) goto L_0x0000;
    L_0x00ea:
        r0 = r14.mLoadQueue;
        r0 = r0.isEmpty();
        if (r0 == 0) goto L_0x0000;
    L_0x00f2:
        r1 = r14.mLoadQueue;
        monitor-enter(r1);
        r0 = 1;
        r14.mWaitingOnLoadQueue = r0;	 Catch:{ InterruptedException -> 0x0108 }
        r0 = r14.mLoadQueue;	 Catch:{ InterruptedException -> 0x0108 }
        r0.wait();	 Catch:{ InterruptedException -> 0x0108 }
        r0 = 0;
        r14.mWaitingOnLoadQueue = r0;	 Catch:{ InterruptedException -> 0x0108 }
    L_0x0100:
        monitor-exit(r1);	 Catch:{ all -> 0x0103 }
        goto L_0x0000;
    L_0x0103:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0103 }
        throw r0;
    L_0x0106:
        r12 = r7;
        goto L_0x00dc;
    L_0x0108:
        r9 = move-exception;
        r9.printStackTrace();	 Catch:{ all -> 0x0103 }
        goto L_0x0100;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.recents.model.TaskResourceLoader.run():void");
    }

    Drawable getTaskDescriptionIcon(TaskKey taskKey, Bitmap iconBitmap, String iconFilename, SystemServicesProxy ssp, Resources res) {
        Bitmap tdIcon = iconBitmap != null ? iconBitmap : TaskDescription.loadTaskDescriptionIcon(iconFilename);
        if (tdIcon != null) {
            return ssp.getBadgedIcon(new BitmapDrawable(res, tdIcon), taskKey.userId);
        }
        return null;
    }
}
