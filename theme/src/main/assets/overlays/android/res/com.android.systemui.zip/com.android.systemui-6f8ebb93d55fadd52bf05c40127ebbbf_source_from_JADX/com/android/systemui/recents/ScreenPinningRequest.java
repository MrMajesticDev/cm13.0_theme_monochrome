package com.android.systemui.recents;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.ActivityManager;
import android.app.ActivityManagerNative;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.os.RemoteException;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;

public class ScreenPinningRequest implements OnClickListener {
    private final AccessibilityManager mAccessibilityService;
    private final Context mContext;
    private RequestWindowView mRequestWindow;
    private final WindowManager mWindowManager;

    private class RequestWindowView extends FrameLayout {
        private final ColorDrawable mColor;
        private ValueAnimator mColorAnim;
        private ViewGroup mLayout;
        private final BroadcastReceiver mReceiver;
        private boolean mShowCancel;
        private final Runnable mUpdateLayoutRunnable;

        /* renamed from: com.android.systemui.recents.ScreenPinningRequest.RequestWindowView.1 */
        class C02091 implements AnimatorUpdateListener {
            C02091() {
            }

            public void onAnimationUpdate(ValueAnimator animation) {
                RequestWindowView.this.mColor.setColor(((Integer) animation.getAnimatedValue()).intValue());
            }
        }

        /* renamed from: com.android.systemui.recents.ScreenPinningRequest.RequestWindowView.2 */
        class C02102 implements Runnable {
            C02102() {
            }

            public void run() {
                if (RequestWindowView.this.mLayout != null && RequestWindowView.this.mLayout.getParent() != null) {
                    RequestWindowView.this.mLayout.setLayoutParams(ScreenPinningRequest.this.getRequestLayoutParams(RequestWindowView.this.isLandscapePhone(RequestWindowView.this.mContext)));
                }
            }
        }

        /* renamed from: com.android.systemui.recents.ScreenPinningRequest.RequestWindowView.3 */
        class C02113 extends BroadcastReceiver {
            C02113() {
            }

            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals("android.intent.action.CONFIGURATION_CHANGED")) {
                    RequestWindowView.this.post(RequestWindowView.this.mUpdateLayoutRunnable);
                } else if (intent.getAction().equals("android.intent.action.USER_SWITCHED") || intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
                    ScreenPinningRequest.this.clearPrompt();
                }
            }
        }

        public RequestWindowView(Context context, boolean showCancel) {
            super(context);
            this.mColor = new ColorDrawable(0);
            this.mUpdateLayoutRunnable = new C02102();
            this.mReceiver = new C02113();
            setClickable(true);
            setOnClickListener(ScreenPinningRequest.this);
            setBackground(this.mColor);
            this.mShowCancel = showCancel;
        }

        public void onAttachedToWindow() {
            DisplayMetrics metrics = new DisplayMetrics();
            ScreenPinningRequest.this.mWindowManager.getDefaultDisplay().getMetrics(metrics);
            float density = metrics.density;
            boolean isLandscape = isLandscapePhone(this.mContext);
            inflateView(isLandscape);
            int bgColor = this.mContext.getColor(2131427406);
            if (ActivityManager.isHighEndGfx()) {
                this.mLayout.setAlpha(0.0f);
                if (isLandscape) {
                    this.mLayout.setTranslationX(96.0f * density);
                } else {
                    this.mLayout.setTranslationY(96.0f * density);
                }
                this.mLayout.animate().alpha(1.0f).translationX(0.0f).translationY(0.0f).setDuration(300).setInterpolator(new DecelerateInterpolator()).start();
                this.mColorAnim = ValueAnimator.ofObject(new ArgbEvaluator(), new Object[]{Integer.valueOf(0), Integer.valueOf(bgColor)});
                this.mColorAnim.addUpdateListener(new C02091());
                this.mColorAnim.setDuration(1000);
                this.mColorAnim.start();
            } else {
                this.mColor.setColor(bgColor);
            }
            IntentFilter filter = new IntentFilter("android.intent.action.CONFIGURATION_CHANGED");
            filter.addAction("android.intent.action.USER_SWITCHED");
            filter.addAction("android.intent.action.SCREEN_OFF");
            this.mContext.registerReceiver(this.mReceiver, filter);
        }

        private boolean isLandscapePhone(Context context) {
            Configuration config = this.mContext.getResources().getConfiguration();
            return config.orientation == 2 && config.smallestScreenWidthDp < 600;
        }

        private void inflateView(boolean isLandscape) {
            int backBgVisibility = 4;
            this.mLayout = (ViewGroup) View.inflate(getContext(), isLandscape ? 2130968635 : 2130968632, null);
            this.mLayout.setClickable(true);
            this.mLayout.setLayoutDirection(0);
            View buttons = this.mLayout.findViewById(2131755239);
            buttons.setLayoutDirection(3);
            this.mLayout.findViewById(2131755245).setLayoutDirection(3);
            swapChildrenIfRtlAndVertical(buttons);
            ((Button) this.mLayout.findViewById(2131755248)).setOnClickListener(ScreenPinningRequest.this);
            if (this.mShowCancel) {
                ((Button) this.mLayout.findViewById(2131755249)).setOnClickListener(ScreenPinningRequest.this);
            } else {
                ((Button) this.mLayout.findViewById(2131755249)).setVisibility(4);
            }
            ((TextView) this.mLayout.findViewById(2131755247)).setText(ScreenPinningRequest.this.mAccessibilityService.isEnabled() ? 2131362321 : 2131362320);
            if (!ScreenPinningRequest.this.mAccessibilityService.isEnabled()) {
                backBgVisibility = 0;
            }
            this.mLayout.findViewById(2131755242).setVisibility(backBgVisibility);
            this.mLayout.findViewById(2131755241).setVisibility(backBgVisibility);
            addView(this.mLayout, ScreenPinningRequest.this.getRequestLayoutParams(isLandscape));
        }

        private void swapChildrenIfRtlAndVertical(View group) {
            if (this.mContext.getResources().getConfiguration().getLayoutDirection() == 1) {
                LinearLayout linearLayout = (LinearLayout) group;
                if (linearLayout.getOrientation() == 1) {
                    int i;
                    int childCount = linearLayout.getChildCount();
                    ArrayList<View> childList = new ArrayList(childCount);
                    for (i = 0; i < childCount; i++) {
                        childList.add(linearLayout.getChildAt(i));
                    }
                    linearLayout.removeAllViews();
                    for (i = childCount - 1; i >= 0; i--) {
                        linearLayout.addView((View) childList.get(i));
                    }
                }
            }
        }

        public void onDetachedFromWindow() {
            this.mContext.unregisterReceiver(this.mReceiver);
        }

        protected void onConfigurationChanged() {
            removeAllViews();
            inflateView(isLandscapePhone(this.mContext));
        }
    }

    public ScreenPinningRequest(Context context) {
        this.mContext = context;
        this.mAccessibilityService = (AccessibilityManager) this.mContext.getSystemService("accessibility");
        this.mWindowManager = (WindowManager) this.mContext.getSystemService("window");
    }

    public void clearPrompt() {
        if (this.mRequestWindow != null) {
            this.mWindowManager.removeView(this.mRequestWindow);
            this.mRequestWindow = null;
        }
    }

    public void showPrompt(boolean allowCancel) {
        clearPrompt();
        this.mRequestWindow = new RequestWindowView(this.mContext, allowCancel);
        this.mRequestWindow.setSystemUiVisibility(256);
        this.mWindowManager.addView(this.mRequestWindow, getWindowLayoutParams());
    }

    public void onConfigurationChanged() {
        if (this.mRequestWindow != null) {
            this.mRequestWindow.onConfigurationChanged();
        }
    }

    private LayoutParams getWindowLayoutParams() {
        LayoutParams lp = new LayoutParams(-1, -1, 2024, 16777480, -3);
        lp.privateFlags |= 16;
        lp.setTitle("ScreenPinningConfirmation");
        lp.gravity = 119;
        return lp;
    }

    public void onClick(View v) {
        if (v.getId() == 2131755248 || this.mRequestWindow == v) {
            try {
                ActivityManagerNative.getDefault().startLockTaskModeOnCurrent();
            } catch (RemoteException e) {
            }
        }
        clearPrompt();
    }

    public FrameLayout.LayoutParams getRequestLayoutParams(boolean isLandscape) {
        return new FrameLayout.LayoutParams(-2, -2, isLandscape ? 21 : 81);
    }
}
