package com.android.systemui.statusbar.policy;

import android.content.Context;
import com.android.internal.view.RotationPolicy;
import com.android.internal.view.RotationPolicy.RotationPolicyListener;
import com.android.systemui.statusbar.policy.RotationLockController.RotationLockControllerCallback;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public final class RotationLockControllerImpl implements RotationLockController {
    private final CopyOnWriteArrayList<RotationLockControllerCallback> mCallbacks;
    private final Context mContext;
    private final RotationPolicyListener mRotationPolicyListener;

    /* renamed from: com.android.systemui.statusbar.policy.RotationLockControllerImpl.1 */
    class C04921 extends RotationPolicyListener {
        C04921() {
        }

        public void onChange() {
            RotationLockControllerImpl.this.notifyChanged();
        }
    }

    public RotationLockControllerImpl(Context context) {
        this.mCallbacks = new CopyOnWriteArrayList();
        this.mRotationPolicyListener = new C04921();
        this.mContext = context;
        setListening(true);
    }

    public void addRotationLockControllerCallback(RotationLockControllerCallback callback) {
        this.mCallbacks.add(callback);
        notifyChanged(callback);
    }

    public void removeRotationLockControllerCallback(RotationLockControllerCallback callback) {
        this.mCallbacks.remove(callback);
    }

    public int getRotationLockOrientation() {
        return RotationPolicy.getRotationLockOrientation(this.mContext);
    }

    public boolean isRotationLocked() {
        return RotationPolicy.isRotationLocked(this.mContext);
    }

    public void setRotationLocked(boolean locked) {
        RotationPolicy.setRotationLock(this.mContext, locked);
    }

    public boolean isRotationLockAffordanceVisible() {
        return RotationPolicy.isRotationLockToggleVisible(this.mContext);
    }

    public void setListening(boolean listening) {
        if (listening) {
            RotationPolicy.registerRotationPolicyListener(this.mContext, this.mRotationPolicyListener, -1);
        } else {
            RotationPolicy.unregisterRotationPolicyListener(this.mContext, this.mRotationPolicyListener);
        }
    }

    private void notifyChanged() {
        Iterator i$ = this.mCallbacks.iterator();
        while (i$.hasNext()) {
            notifyChanged((RotationLockControllerCallback) i$.next());
        }
    }

    private void notifyChanged(RotationLockControllerCallback callback) {
        callback.onRotationLockStateChanged(RotationPolicy.isRotationLocked(this.mContext), RotationPolicy.isRotationLockToggleVisible(this.mContext));
    }
}
