package com.android.systemui;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.widget.TextView;
import com.android.systemui.statusbar.policy.BatteryController;
import com.android.systemui.statusbar.policy.BatteryController.BatteryStateChangeCallback;
import java.text.NumberFormat;

public class BatteryLevelTextView extends TextView implements BatteryStateChangeCallback {
    private boolean mAttached;
    private boolean mBatteryCharging;
    private BatteryController mBatteryController;
    private boolean mForceShow;
    private int mPercentMode;
    private int mRequestedVisibility;
    private int mStyle;

    public BatteryLevelTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mRequestedVisibility = getVisibility();
    }

    public void setForceShown(boolean forceShow) {
        this.mForceShow = forceShow;
        updateVisibility();
    }

    public void setBatteryController(BatteryController batteryController) {
        this.mBatteryController = batteryController;
        if (this.mAttached) {
            this.mBatteryController.addStateChangedCallback(this);
        }
    }

    public void setVisibility(int visibility) {
        this.mRequestedVisibility = visibility;
        updateVisibility();
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setTextSize(0, (float) getResources().getDimensionPixelSize(2131296282));
    }

    public void onBatteryLevelChanged(int level, boolean pluggedIn, boolean charging) {
        setText(NumberFormat.getPercentInstance().format(((double) level) / 100.0d));
        if (this.mBatteryCharging != charging) {
            this.mBatteryCharging = charging;
            updateVisibility();
        }
    }

    public void onPowerSaveChanged() {
    }

    public void onBatteryStyleChanged(int style, int percentMode) {
        this.mStyle = style;
        this.mPercentMode = percentMode;
        updateVisibility();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.mBatteryController != null) {
            this.mBatteryController.addStateChangedCallback(this);
        }
        this.mAttached = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mAttached = false;
        if (this.mBatteryController != null) {
            this.mBatteryController.removeStateChangedCallback(this);
        }
    }

    private void updateVisibility() {
        boolean showNextPercent = true;
        if (!(this.mPercentMode == 2 || (this.mBatteryCharging && this.mPercentMode == 1))) {
            showNextPercent = false;
        }
        if (this.mStyle == 4) {
            showNextPercent = false;
        } else if (this.mStyle == 6) {
            showNextPercent = true;
        }
        if (showNextPercent || this.mForceShow) {
            super.setVisibility(this.mRequestedVisibility);
        } else {
            super.setVisibility(8);
        }
    }
}
