package com.android.keyguard;

import android.content.Context;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import com.android.internal.widget.LockPatternChecker;
import com.android.internal.widget.LockPatternChecker.OnCheckCallback;
import com.android.internal.widget.LockPatternUtils;
import com.android.internal.widget.LockPatternView;
import com.android.internal.widget.LockPatternView.Cell;
import com.android.internal.widget.LockPatternView.CellState;
import com.android.internal.widget.LockPatternView.DisplayMode;
import com.android.internal.widget.LockPatternView.OnPatternListener;
import com.android.keyguard.EmergencyButton.EmergencyButtonCallback;
import com.android.settingslib.animation.AppearAnimationCreator;
import com.android.settingslib.animation.AppearAnimationUtils;
import com.android.settingslib.animation.DisappearAnimationUtils;
import java.util.List;

public class KeyguardPatternView extends LinearLayout implements EmergencyButtonCallback, KeyguardSecurityView, AppearAnimationCreator<CellState> {
    private final AppearAnimationUtils mAppearAnimationUtils;
    private KeyguardSecurityCallback mCallback;
    private Runnable mCancelPatternRunnable;
    private ViewGroup mContainer;
    private CountDownTimer mCountdownTimer;
    private final DisappearAnimationUtils mDisappearAnimationUtils;
    private int mDisappearYTranslation;
    private View mEcaView;
    private final KeyguardUpdateMonitor mKeyguardUpdateMonitor;
    private long mLastPokeTime;
    private LockPatternUtils mLockPatternUtils;
    private LockPatternView mLockPatternView;
    private int mMaxCountdownTimes;
    private AsyncTask<?, ?, ?> mPendingLockCheck;
    private KeyguardMessageArea mSecurityMessageDisplay;
    private Rect mTempRect;

    /* renamed from: com.android.keyguard.KeyguardPatternView.1 */
    class C00191 implements Runnable {
        C00191() {
        }

        public void run() {
            KeyguardPatternView.this.mLockPatternView.clearPattern();
        }
    }

    /* renamed from: com.android.keyguard.KeyguardPatternView.2 */
    class C00202 extends CountDownTimer {
        C00202(long x0, long x1) {
            super(x0, x1);
        }

        public void onTick(long millisUntilFinished) {
            int secondsRemaining = (int) (millisUntilFinished / 1000);
            KeyguardPatternView.this.mSecurityMessageDisplay.setMessage(C0065R.string.kg_too_many_failed_attempts_countdown, true, Integer.valueOf(secondsRemaining));
        }

        public void onFinish() {
            KeyguardPatternView.this.mLockPatternView.setEnabled(true);
            KeyguardPatternView.this.displayDefaultSecurityMessage();
        }
    }

    /* renamed from: com.android.keyguard.KeyguardPatternView.3 */
    class C00213 implements Runnable {
        C00213() {
        }

        public void run() {
            KeyguardPatternView.this.enableClipping(true);
        }
    }

    /* renamed from: com.android.keyguard.KeyguardPatternView.4 */
    class C00224 implements Runnable {
        final /* synthetic */ Runnable val$finishRunnable;

        C00224(Runnable runnable) {
            this.val$finishRunnable = runnable;
        }

        public void run() {
            KeyguardPatternView.this.enableClipping(true);
            if (this.val$finishRunnable != null) {
                this.val$finishRunnable.run();
            }
        }
    }

    private class UnlockPatternListener implements OnPatternListener {

        /* renamed from: com.android.keyguard.KeyguardPatternView.UnlockPatternListener.1 */
        class C00231 implements OnCheckCallback {
            C00231() {
            }

            public void onChecked(boolean matched, int timeoutMs) {
                KeyguardPatternView.this.mLockPatternView.enableInput();
                KeyguardPatternView.this.mPendingLockCheck = null;
                UnlockPatternListener.this.onPatternChecked(matched, timeoutMs, true);
            }
        }

        private UnlockPatternListener() {
        }

        public void onPatternStart() {
            KeyguardPatternView.this.mLockPatternView.removeCallbacks(KeyguardPatternView.this.mCancelPatternRunnable);
            KeyguardPatternView.this.mSecurityMessageDisplay.setMessage((CharSequence) "", false);
        }

        public void onPatternCleared() {
        }

        public void onPatternCellAdded(List<Cell> list) {
            KeyguardPatternView.this.mCallback.userActivity();
        }

        public void onPatternDetected(List<Cell> pattern) {
            KeyguardPatternView.this.mLockPatternView.disableInput();
            if (KeyguardPatternView.this.mPendingLockCheck != null) {
                KeyguardPatternView.this.mPendingLockCheck.cancel(false);
            }
            if (pattern.size() < 4) {
                KeyguardPatternView.this.mLockPatternView.enableInput();
                onPatternChecked(false, 0, false);
                return;
            }
            KeyguardPatternView.this.mPendingLockCheck = LockPatternChecker.checkPattern(KeyguardPatternView.this.mLockPatternUtils, pattern, KeyguardUpdateMonitor.getCurrentUser(), new C00231());
            if (pattern.size() > 2) {
                KeyguardPatternView.this.mCallback.userActivity();
            }
        }

        private void onPatternChecked(boolean matched, int timeoutMs, boolean isValidPattern) {
            if (matched) {
                KeyguardPatternView.this.mLockPatternUtils.sanitizePassword();
                KeyguardPatternView.this.mCallback.reportUnlockAttempt(true, 0);
                KeyguardPatternView.this.mLockPatternView.setDisplayMode(DisplayMode.Correct);
                KeyguardPatternView.this.mCallback.dismiss(true);
                return;
            }
            KeyguardPatternView.this.mLockPatternView.setDisplayMode(DisplayMode.Wrong);
            if (isValidPattern) {
                KeyguardPatternView.this.mCallback.reportUnlockAttempt(false, timeoutMs);
                if (KeyguardPatternView.this.mMaxCountdownTimes <= 0 && timeoutMs > 0) {
                    KeyguardPatternView.this.handleAttemptLockout(KeyguardPatternView.this.mLockPatternUtils.setLockoutAttemptDeadline(KeyguardUpdateMonitor.getCurrentUser(), timeoutMs));
                }
            }
            if (timeoutMs == 0) {
                KeyguardPatternView.this.mSecurityMessageDisplay.setMessage(KeyguardPatternView.this.getMsgWithCnt(C0065R.string.kg_wrong_pattern), true);
                KeyguardPatternView.this.mLockPatternView.postDelayed(KeyguardPatternView.this.mCancelPatternRunnable, 2000);
            }
        }
    }

    public KeyguardPatternView(Context context) {
        this(context, null);
    }

    public KeyguardPatternView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mCountdownTimer = null;
        this.mLastPokeTime = -7000;
        this.mCancelPatternRunnable = new C00191();
        this.mTempRect = new Rect();
        this.mKeyguardUpdateMonitor = KeyguardUpdateMonitor.getInstance(this.mContext);
        this.mAppearAnimationUtils = new AppearAnimationUtils(context, 220, 1.5f, 2.0f, AnimationUtils.loadInterpolator(this.mContext, 17563662));
        this.mDisappearAnimationUtils = new DisappearAnimationUtils(context, 125, 1.2f, 0.6f, AnimationUtils.loadInterpolator(this.mContext, 17563663));
        this.mDisappearYTranslation = getResources().getDimensionPixelSize(C0065R.dimen.disappear_y_translation);
    }

    public void setKeyguardCallback(KeyguardSecurityCallback callback) {
        this.mCallback = callback;
    }

    public void setLockPatternUtils(LockPatternUtils utils) {
        this.mLockPatternUtils = utils;
    }

    protected void onFinishInflate() {
        boolean z;
        super.onFinishInflate();
        this.mMaxCountdownTimes = this.mContext.getResources().getInteger(C0065R.integer.config_max_unlock_countdown_times);
        this.mLockPatternUtils = this.mLockPatternUtils == null ? new LockPatternUtils(this.mContext) : this.mLockPatternUtils;
        this.mLockPatternView = (LockPatternView) findViewById(C0065R.id.lockPatternView);
        this.mLockPatternView.setSaveEnabled(false);
        this.mLockPatternView.setOnPatternListener(new UnlockPatternListener());
        LockPatternView lockPatternView = this.mLockPatternView;
        if (this.mLockPatternUtils.isVisiblePatternEnabled(KeyguardUpdateMonitor.getCurrentUser())) {
            z = false;
        } else {
            z = true;
        }
        lockPatternView.setInStealthMode(z);
        this.mLockPatternView.setTactileFeedbackEnabled(this.mLockPatternUtils.isTactileFeedbackEnabled());
        this.mSecurityMessageDisplay = (KeyguardMessageArea) KeyguardMessageArea.findSecurityMessageDisplay(this);
        this.mEcaView = findViewById(C0065R.id.keyguard_selector_fade_container);
        this.mContainer = (ViewGroup) findViewById(C0065R.id.container);
        EmergencyButton button = (EmergencyButton) findViewById(C0065R.id.emergency_call_button);
        if (button != null) {
            button.setCallback(this);
        }
    }

    public void onEmergencyButtonClickedWhenInCall() {
        this.mCallback.reset();
    }

    public boolean onTouchEvent(MotionEvent ev) {
        boolean result = super.onTouchEvent(ev);
        long elapsed = SystemClock.elapsedRealtime() - this.mLastPokeTime;
        if (result && elapsed > 6900) {
            this.mLastPokeTime = SystemClock.elapsedRealtime();
        }
        this.mTempRect.set(0, 0, 0, 0);
        offsetRectIntoDescendantCoords(this.mLockPatternView, this.mTempRect);
        ev.offsetLocation((float) this.mTempRect.left, (float) this.mTempRect.top);
        if (this.mLockPatternView.dispatchTouchEvent(ev) || result) {
            result = true;
        } else {
            result = false;
        }
        ev.offsetLocation((float) (-this.mTempRect.left), (float) (-this.mTempRect.top));
        return result;
    }

    public void reset() {
        this.mLockPatternView.enableInput();
        this.mLockPatternView.setEnabled(true);
        this.mLockPatternView.clearPattern();
        long deadline = this.mLockPatternUtils.getLockoutAttemptDeadline(KeyguardUpdateMonitor.getCurrentUser());
        if (deadline != 0) {
            handleAttemptLockout(deadline);
        } else {
            displayDefaultSecurityMessage();
        }
    }

    private void displayDefaultSecurityMessage() {
        this.mSecurityMessageDisplay.setMessage(getMsgWithCnt(C0065R.string.kg_pattern_instructions), false);
    }

    private String getMsgWithCnt(int msgId) {
        String msg = getContext().getString(msgId);
        if (this.mMaxCountdownTimes <= 0 || getRemainingCount() <= 0) {
            return msg;
        }
        int remaining = getRemainingCount();
        return msg + " - " + getContext().getResources().getString(C0065R.string.kg_remaining_attempts, new Object[]{Integer.valueOf(remaining)});
    }

    private int getRemainingCount() {
        return this.mMaxCountdownTimes - KeyguardUpdateMonitor.getInstance(this.mContext).getFailedUnlockAttempts();
    }

    private void handleAttemptLockout(long elapsedRealtimeDeadline) {
        this.mLockPatternView.clearPattern();
        this.mLockPatternView.setEnabled(false);
        this.mCountdownTimer = new C00202(elapsedRealtimeDeadline - SystemClock.elapsedRealtime(), 1000).start();
    }

    public boolean needsInput() {
        return false;
    }

    public void onPause() {
        if (this.mCountdownTimer != null) {
            this.mCountdownTimer.cancel();
            this.mCountdownTimer = null;
        }
        if (this.mPendingLockCheck != null) {
            this.mPendingLockCheck.cancel(false);
            this.mPendingLockCheck = null;
        }
    }

    public void onResume(int reason) {
        reset();
    }

    public void showPromptReason(int reason) {
        switch (reason) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                this.mSecurityMessageDisplay.setMessage(C0065R.string.kg_prompt_reason_restart_pattern, true);
            case 2:
                this.mSecurityMessageDisplay.setMessage(C0065R.string.kg_prompt_reason_timeout_pattern, true);
            default:
        }
    }

    public void showMessage(String message, int color) {
        this.mSecurityMessageDisplay.setNextMessageColor(color);
        this.mSecurityMessageDisplay.setMessage((CharSequence) message, true);
    }

    public void startAppearAnimation() {
        enableClipping(false);
        setAlpha(1.0f);
        setTranslationY(this.mAppearAnimationUtils.getStartTranslation());
        AppearAnimationUtils.startTranslationYAnimation(this, 0, 500, 0.0f, this.mAppearAnimationUtils.getInterpolator());
        this.mAppearAnimationUtils.startAnimation2d(this.mLockPatternView.getCellStates(), new C00213(), this);
        if (!TextUtils.isEmpty(this.mSecurityMessageDisplay.getText())) {
            this.mAppearAnimationUtils.createAnimation(this.mSecurityMessageDisplay, 0, 220, this.mAppearAnimationUtils.getStartTranslation(), true, this.mAppearAnimationUtils.getInterpolator(), null);
        }
    }

    public boolean startDisappearAnimation(Runnable finishRunnable) {
        this.mLockPatternView.clearPattern();
        enableClipping(false);
        setTranslationY(0.0f);
        AppearAnimationUtils.startTranslationYAnimation(this, 0, 300, -this.mDisappearAnimationUtils.getStartTranslation(), this.mDisappearAnimationUtils.getInterpolator());
        this.mDisappearAnimationUtils.startAnimation2d(this.mLockPatternView.getCellStates(), new C00224(finishRunnable), this);
        if (!TextUtils.isEmpty(this.mSecurityMessageDisplay.getText())) {
            this.mDisappearAnimationUtils.createAnimation(this.mSecurityMessageDisplay, 0, 200, (-this.mDisappearAnimationUtils.getStartTranslation()) * 3.0f, false, this.mDisappearAnimationUtils.getInterpolator(), null);
        }
        return true;
    }

    private void enableClipping(boolean enable) {
        setClipChildren(enable);
        this.mContainer.setClipToPadding(enable);
        this.mContainer.setClipChildren(enable);
    }

    public void createAnimation(CellState animatedCell, long delay, long duration, float translationY, boolean appearing, Interpolator interpolator, Runnable finishListener) {
        this.mLockPatternView.startCellStateAnimation(animatedCell, 1.0f, appearing ? 1.0f : 0.0f, appearing ? translationY : 0.0f, appearing ? 0.0f : translationY, appearing ? 0.0f : 1.0f, 1.0f, delay, duration, interpolator, finishListener);
        if (finishListener != null) {
            this.mAppearAnimationUtils.createAnimation(this.mEcaView, delay, duration, translationY, appearing, interpolator, null);
        }
    }

    public boolean hasOverlappingRendering() {
        return false;
    }
}
