package com.android.systemui.statusbar.policy;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources.NotFoundException;
import android.os.Looper;
import android.telephony.CellLocation;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.text.TextUtils;
import android.util.Log;
import android.util.NativeTextHelper;
import android.util.SparseArray;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.policy.NetworkController.IconState;
import com.android.systemui.statusbar.policy.NetworkControllerImpl.SubscriptionDefaults;
import java.io.PrintWriter;
import java.util.BitSet;
import java.util.Objects;

public class MobileSignalController extends SignalController<MobileState, MobileIconGroup> {
    private final int STATUS_BAR_STYLE_ANDROID_DEFAULT;
    private final int STATUS_BAR_STYLE_CDMA_1X_COMBINED;
    private final int STATUS_BAR_STYLE_DATA_VOICE;
    private final int STATUS_BAR_STYLE_DEFAULT_DATA;
    private int mCellIdentity;
    private Config mConfig;
    private int mDataNetType;
    private int mDataState;
    private MobileIconGroup mDefaultIcons;
    private final SubscriptionDefaults mDefaults;
    private String mLastDataSpn;
    private String mLastPlmn;
    private boolean mLastShowPlmn;
    private boolean mLastShowSpn;
    private String mLastSpn;
    private final String mNetworkNameDefault;
    private final String mNetworkNameSeparator;
    final SparseArray<MobileIconGroup> mNetworkToIconLookup;
    private int mNewCellIdentity;
    private final TelephonyManager mPhone;
    final PhoneStateListener mPhoneStateListener;
    private ServiceState mServiceState;
    private SignalStrength mSignalStrength;
    private int mStyle;
    final SubscriptionInfo mSubscriptionInfo;

    /* renamed from: com.android.systemui.statusbar.policy.MobileSignalController.1 */
    class C04841 implements Runnable {
        C04841() {
        }

        public void run() {
            MobileSignalController.this.mNetworkController.updateNetworkLabelView();
        }
    }

    static class MobileIconGroup extends IconGroup {
        final int mActivityId;
        final int mDataContentDescription;
        final int mDataType;
        final boolean mIsWide;
        final int mQsDataType;
        final int mSingleSignalIcon;
        final int mStackedDataIcon;
        final int mStackedVoiceIcon;

        public MobileIconGroup(String name, int[][] sbIcons, int[][] qsIcons, int[] contentDesc, int sbNullState, int qsNullState, int sbDiscState, int qsDiscState, int discContentDesc, int dataContentDesc, int dataType, boolean isWide, int qsDataType) {
            this(name, sbIcons, qsIcons, contentDesc, sbNullState, qsNullState, sbDiscState, qsDiscState, discContentDesc, dataContentDesc, dataType, isWide, qsDataType, 0, 0, 0, 0);
        }

        public MobileIconGroup(String name, int[][] sbIcons, int[][] qsIcons, int[] contentDesc, int sbNullState, int qsNullState, int sbDiscState, int qsDiscState, int discContentDesc, int dataContentDesc, int dataType, boolean isWide, int qsDataType, int singleSignalIcon, int stackedDataIcon, int stackedVoicelIcon, int activityId) {
            super(name, sbIcons, qsIcons, contentDesc, sbNullState, qsNullState, sbDiscState, qsDiscState, discContentDesc);
            this.mDataContentDescription = dataContentDesc;
            this.mDataType = dataType;
            this.mIsWide = isWide;
            this.mQsDataType = qsDataType;
            this.mSingleSignalIcon = singleSignalIcon;
            this.mStackedDataIcon = stackedDataIcon;
            this.mStackedVoiceIcon = stackedVoicelIcon;
            this.mActivityId = activityId;
        }
    }

    class MobilePhoneStateListener extends PhoneStateListener {
        public MobilePhoneStateListener(int subId, Looper looper) {
            super(subId, looper);
        }

        public void onSignalStrengthsChanged(SignalStrength signalStrength) {
            if (SignalController.DEBUG) {
                Log.d(MobileSignalController.this.mTag, "onSignalStrengthsChanged signalStrength=" + signalStrength + (signalStrength == null ? "" : " level=" + signalStrength.getLevel()));
            }
            MobileSignalController.this.mSignalStrength = signalStrength;
            MobileSignalController.this.updateTelephony();
        }

        public void onServiceStateChanged(ServiceState state) {
            if (SignalController.DEBUG) {
                Log.d(MobileSignalController.this.mTag, "onServiceStateChanged voiceState=" + state.getVoiceRegState() + " dataState=" + state.getDataRegState());
            }
            MobileSignalController.this.mServiceState = state;
            MobileSignalController.this.updateNetworkName(MobileSignalController.this.mLastShowSpn, MobileSignalController.this.mLastSpn, MobileSignalController.this.mLastDataSpn, MobileSignalController.this.mLastShowPlmn, MobileSignalController.this.mLastPlmn);
            MobileSignalController.this.updateTelephony();
        }

        public void onDataConnectionStateChanged(int state, int networkType) {
            if (SignalController.DEBUG) {
                Log.d(MobileSignalController.this.mTag, "onDataConnectionStateChanged: state=" + state + " type=" + networkType);
            }
            if (MobileSignalController.this.mContext.getResources().getBoolean(2131558435)) {
                CellLocation cl = MobileSignalController.this.mPhone.getCellLocation();
                if (cl instanceof GsmCellLocation) {
                    MobileSignalController.this.mNewCellIdentity = ((GsmCellLocation) cl).getCid();
                    Log.d(MobileSignalController.this.mTag, "onDataConnectionStateChanged, mNewCellIdentity = " + MobileSignalController.this.mNewCellIdentity);
                }
                Log.d(MobileSignalController.this.mTag, "onDataConnectionStateChanged, mCellIdentity = " + MobileSignalController.this.mCellIdentity + ", mNewCellIdentity = " + MobileSignalController.this.mNewCellIdentity + ", mDataNetType = " + MobileSignalController.this.mDataNetType + ", networkType = " + networkType);
                if (MobileSignalController.this.mCellIdentity != MobileSignalController.this.mNewCellIdentity) {
                    MobileSignalController.this.mDataNetType = networkType;
                } else if (networkType > MobileSignalController.this.mDataNetType) {
                    MobileSignalController.this.mDataNetType = networkType;
                }
                MobileSignalController.this.mDataState = state;
                MobileSignalController.this.updateTelephony();
                return;
            }
            MobileSignalController.this.mDataState = state;
            MobileSignalController.this.mDataNetType = networkType;
            MobileSignalController.this.updateTelephony();
        }

        public void onDataActivity(int direction) {
            if (SignalController.DEBUG) {
                Log.d(MobileSignalController.this.mTag, "onDataActivity: direction=" + direction);
            }
            MobileSignalController.this.setActivity(direction);
        }

        public void onCarrierNetworkChange(boolean active) {
            if (SignalController.DEBUG) {
                Log.d(MobileSignalController.this.mTag, "onCarrierNetworkChange: active=" + active);
            }
            ((MobileState) MobileSignalController.this.mCurrentState).carrierNetworkChangeMode = active;
            MobileSignalController.this.updateTelephony();
        }
    }

    static class MobileState extends State {
        boolean airplaneMode;
        boolean carrierNetworkChangeMode;
        int dataActivity;
        boolean dataConnected;
        boolean dataSim;
        boolean isDefault;
        boolean isEmergency;
        String networkName;
        String networkNameData;
        int voiceLevel;

        MobileState() {
        }

        public void copyFrom(State s) {
            super.copyFrom(s);
            MobileState state = (MobileState) s;
            this.dataSim = state.dataSim;
            this.networkName = state.networkName;
            this.networkNameData = state.networkNameData;
            this.dataConnected = state.dataConnected;
            this.isDefault = state.isDefault;
            this.isEmergency = state.isEmergency;
            this.airplaneMode = state.airplaneMode;
            this.carrierNetworkChangeMode = state.carrierNetworkChangeMode;
            this.dataActivity = state.dataActivity;
            this.voiceLevel = state.voiceLevel;
        }

        protected void toString(StringBuilder builder) {
            super.toString(builder);
            builder.append(',');
            builder.append("dataSim=").append(this.dataSim).append(',');
            builder.append("networkName=").append(this.networkName).append(',');
            builder.append("networkNameData=").append(this.networkNameData).append(',');
            builder.append("dataConnected=").append(this.dataConnected).append(',');
            builder.append("isDefault=").append(this.isDefault).append(',');
            builder.append("isEmergency=").append(this.isEmergency).append(',');
            builder.append("airplaneMode=").append(this.airplaneMode).append(',');
            builder.append("voiceLevel=").append(this.voiceLevel).append(',');
            builder.append("carrierNetworkChangeMode=").append(this.carrierNetworkChangeMode);
        }

        public boolean equals(Object o) {
            return super.equals(o) && Objects.equals(((MobileState) o).networkName, this.networkName) && Objects.equals(((MobileState) o).networkNameData, this.networkNameData) && ((MobileState) o).dataSim == this.dataSim && ((MobileState) o).dataConnected == this.dataConnected && ((MobileState) o).isEmergency == this.isEmergency && ((MobileState) o).airplaneMode == this.airplaneMode && ((MobileState) o).carrierNetworkChangeMode == this.carrierNetworkChangeMode && ((MobileState) o).voiceLevel == this.voiceLevel && ((MobileState) o).isDefault == this.isDefault;
        }
    }

    public MobileSignalController(Context context, Config config, boolean hasMobileData, TelephonyManager phone, CallbackHandler callbackHandler, NetworkControllerImpl networkController, SubscriptionInfo info, SubscriptionDefaults defaults, Looper receiverLooper) {
        super("MobileSignalController(" + info.getSubscriptionId() + ")", context, 0, callbackHandler, networkController);
        this.mDataNetType = 0;
        this.mDataState = 0;
        this.mCellIdentity = Integer.MAX_VALUE;
        this.mNewCellIdentity = Integer.MAX_VALUE;
        this.STATUS_BAR_STYLE_ANDROID_DEFAULT = 0;
        this.STATUS_BAR_STYLE_CDMA_1X_COMBINED = 1;
        this.STATUS_BAR_STYLE_DEFAULT_DATA = 2;
        this.STATUS_BAR_STYLE_DATA_VOICE = 3;
        this.mStyle = 0;
        this.mNetworkToIconLookup = new SparseArray();
        this.mConfig = config;
        this.mPhone = phone;
        this.mDefaults = defaults;
        this.mSubscriptionInfo = info;
        this.mPhoneStateListener = new MobilePhoneStateListener(info.getSubscriptionId(), receiverLooper);
        this.mNetworkNameSeparator = getStringIfExists(2131361973);
        this.mNetworkNameDefault = getStringIfExists(17040004);
        if (config.readIconsFromXml) {
            TelephonyIcons.readIconsFromXml(context);
            this.mDefaultIcons = !this.mConfig.showAtLeast3G ? TelephonyIcons.f25G : TelephonyIcons.THREE_G;
        } else {
            mapIconSets();
        }
        this.mStyle = context.getResources().getInteger(2131623954);
        String networkName = info.getCarrierName() != null ? info.getCarrierName().toString() : this.mNetworkNameDefault;
        MobileState mobileState = (MobileState) this.mLastState;
        ((MobileState) this.mCurrentState).networkName = networkName;
        mobileState.networkName = networkName;
        mobileState = (MobileState) this.mLastState;
        ((MobileState) this.mCurrentState).networkNameData = networkName;
        mobileState.networkNameData = networkName;
        mobileState = (MobileState) this.mLastState;
        ((MobileState) this.mCurrentState).enabled = hasMobileData;
        mobileState.enabled = hasMobileData;
        mobileState = (MobileState) this.mLastState;
        MobileState mobileState2 = (MobileState) this.mCurrentState;
        IconGroup iconGroup = this.mDefaultIcons;
        mobileState2.iconGroup = iconGroup;
        mobileState.iconGroup = iconGroup;
        updateDataSim();
    }

    public void setConfiguration(Config config) {
        this.mConfig = config;
        if (!config.readIconsFromXml) {
            mapIconSets();
        }
        updateTelephony();
    }

    public void setAirplaneMode(boolean airplaneMode) {
        ((MobileState) this.mCurrentState).airplaneMode = airplaneMode;
        notifyListenersIfNecessary();
    }

    public void updateConnectivity(BitSet connectedTransports, BitSet validatedTransports) {
        boolean isValidated = validatedTransports.get(this.mTransportType);
        ((MobileState) this.mCurrentState).isDefault = connectedTransports.get(this.mTransportType);
        MobileState mobileState = (MobileState) this.mCurrentState;
        int i = (isValidated || !((MobileState) this.mCurrentState).isDefault) ? 1 : 0;
        mobileState.inetCondition = i;
        notifyListenersIfNecessary();
    }

    public void setCarrierNetworkChangeMode(boolean carrierNetworkChangeMode) {
        ((MobileState) this.mCurrentState).carrierNetworkChangeMode = carrierNetworkChangeMode;
        updateTelephony();
    }

    public void registerListener() {
        this.mPhone.listen(this.mPhoneStateListener, 66017);
    }

    public void unregisterListener() {
        this.mPhone.listen(this.mPhoneStateListener, 0);
    }

    private void mapIconSets() {
        this.mNetworkToIconLookup.clear();
        this.mNetworkToIconLookup.put(5, TelephonyIcons.THREE_G);
        this.mNetworkToIconLookup.put(6, TelephonyIcons.THREE_G);
        this.mNetworkToIconLookup.put(12, TelephonyIcons.THREE_G);
        this.mNetworkToIconLookup.put(14, TelephonyIcons.THREE_G);
        this.mNetworkToIconLookup.put(3, TelephonyIcons.THREE_G);
        this.mNetworkToIconLookup.put(17, TelephonyIcons.THREE_G);
        if (this.mConfig.showAtLeast3G) {
            this.mNetworkToIconLookup.put(0, TelephonyIcons.THREE_G);
            this.mNetworkToIconLookup.put(2, TelephonyIcons.THREE_G);
            this.mNetworkToIconLookup.put(4, TelephonyIcons.THREE_G);
            this.mNetworkToIconLookup.put(7, TelephonyIcons.THREE_G);
            this.mDefaultIcons = TelephonyIcons.THREE_G;
        } else {
            this.mNetworkToIconLookup.put(0, TelephonyIcons.UNKNOWN);
            this.mNetworkToIconLookup.put(2, TelephonyIcons.f24E);
            this.mNetworkToIconLookup.put(4, TelephonyIcons.ONE_X);
            this.mNetworkToIconLookup.put(7, TelephonyIcons.ONE_X);
            this.mDefaultIcons = TelephonyIcons.f25G;
        }
        if (this.mContext.getResources().getBoolean(2131558435)) {
            this.mNetworkToIconLookup.put(2, TelephonyIcons.f24E);
        }
        MobileIconGroup hGroup = TelephonyIcons.THREE_G;
        if (this.mConfig.hspaDataDistinguishable) {
            hGroup = TelephonyIcons.f26H;
        }
        this.mNetworkToIconLookup.put(8, hGroup);
        this.mNetworkToIconLookup.put(9, hGroup);
        this.mNetworkToIconLookup.put(10, hGroup);
        if (this.mContext.getResources().getBoolean(2131558434)) {
            this.mNetworkToIconLookup.put(15, TelephonyIcons.FOUR_G);
        } else {
            this.mNetworkToIconLookup.put(15, hGroup);
        }
        if (this.mContext.getResources().getBoolean(2131558435)) {
            this.mNetworkToIconLookup.put(8, TelephonyIcons.THREE_G_PLUS);
            this.mNetworkToIconLookup.put(9, TelephonyIcons.THREE_G_PLUS);
            this.mNetworkToIconLookup.put(10, TelephonyIcons.THREE_G_PLUS);
            this.mNetworkToIconLookup.put(15, TelephonyIcons.H_PLUS);
        }
        if (this.mConfig.show4gForLte) {
            if (this.mContext.getResources().getBoolean(2131558437)) {
                this.mNetworkToIconLookup.put(13, TelephonyIcons.FOUR_G_LTE);
            } else {
                this.mNetworkToIconLookup.put(13, TelephonyIcons.FOUR_G);
            }
            this.mNetworkToIconLookup.put(19, TelephonyIcons.FOUR_G_PLUS);
        } else {
            this.mNetworkToIconLookup.put(13, TelephonyIcons.LTE);
            this.mNetworkToIconLookup.put(19, TelephonyIcons.LTE);
        }
        if (this.mContext.getResources().getBoolean(2131558435)) {
            this.mNetworkToIconLookup.put(13, TelephonyIcons.LTE);
            this.mNetworkToIconLookup.put(19, TelephonyIcons.WFC);
        } else {
            this.mNetworkToIconLookup.put(13, TelephonyIcons.FOUR_G);
            this.mNetworkToIconLookup.put(19, TelephonyIcons.FOUR_G_PLUS);
        }
        this.mNetworkToIconLookup.put(18, TelephonyIcons.WFC);
    }

    public void notifyListeners() {
        if (this.mConfig.readIconsFromXml) {
            generateIconGroup();
        }
        MobileIconGroup icons = (MobileIconGroup) getIcons();
        String contentDescription = getStringIfExists(getContentDescription());
        String dataContentDescription = getStringIfExists(icons.mDataContentDescription);
        boolean showDataIcon = ((MobileState) this.mCurrentState).dataConnected || ((MobileState) this.mCurrentState).iconGroup == TelephonyIcons.ROAMING;
        boolean z = ((MobileState) this.mCurrentState).enabled && !((MobileState) this.mCurrentState).airplaneMode;
        IconState statusIcon = new IconState(z, getCurrentIconId(), contentDescription);
        int qsTypeIcon = 0;
        IconState qsIcon = null;
        String description = null;
        if (((MobileState) this.mCurrentState).dataSim) {
            qsTypeIcon = showDataIcon ? icons.mQsDataType : 0;
            z = ((MobileState) this.mCurrentState).enabled && !((MobileState) this.mCurrentState).isEmergency;
            qsIcon = new IconState(z, getQsCurrentIconId(), contentDescription);
            description = ((MobileState) this.mCurrentState).isEmergency ? null : ((MobileState) this.mCurrentState).networkName;
        }
        boolean activityIn = ((MobileState) this.mCurrentState).dataConnected && !((MobileState) this.mCurrentState).carrierNetworkChangeMode && ((MobileState) this.mCurrentState).activityIn;
        boolean activityOut = ((MobileState) this.mCurrentState).dataConnected && !((MobileState) this.mCurrentState).carrierNetworkChangeMode && ((MobileState) this.mCurrentState).activityOut;
        int i = (((MobileState) this.mCurrentState).isDefault || ((MobileState) this.mCurrentState).iconGroup == TelephonyIcons.ROAMING) ? 1 : 0;
        this.mCallbackHandler.setMobileDataIndicators(statusIcon, qsIcon, (showDataIcon & i) & (this.mStyle == 0 ? 1 : 0) ? icons.mDataType : 0, qsTypeIcon, activityIn, activityOut, showMobileActivity() ? 0 : icons.mActivityId, showMobileActivity() ? icons.mActivityId : 0, icons.mStackedDataIcon, icons.mStackedVoiceIcon, dataContentDescription, description, icons.mIsWide, this.mSubscriptionInfo.getSubscriptionId());
        this.mCallbackHandler.post(new C04841());
    }

    protected MobileState cleanState() {
        return new MobileState();
    }

    public int getCurrentIconId() {
        if (this.mConfig.readIconsFromXml && ((MobileState) this.mCurrentState).connected) {
            return ((MobileIconGroup) getIcons()).mSingleSignalIcon;
        }
        return super.getCurrentIconId();
    }

    private boolean hasService() {
        boolean z = true;
        if (this.mServiceState == null) {
            return false;
        }
        switch (this.mServiceState.getVoiceRegState()) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 2:
                if (this.mServiceState.getDataRegState() != 0) {
                    z = false;
                }
                return z;
            case 3:
                return false;
            default:
                return true;
        }
    }

    private boolean isCdma() {
        return (this.mSignalStrength == null || this.mSignalStrength.isGsm()) ? false : true;
    }

    public boolean isEmergencyOnly() {
        return this.mServiceState != null && this.mServiceState.isEmergencyOnly();
    }

    private boolean isRoaming() {
        if (isCdma()) {
            int iconMode = this.mServiceState.getCdmaEriIconMode();
            if (this.mServiceState.getCdmaEriIconIndex() == 1 || (iconMode != 0 && iconMode != 1)) {
                return false;
            }
            return true;
        } else if (this.mServiceState == null || !this.mServiceState.getRoaming()) {
            return false;
        } else {
            return true;
        }
    }

    private boolean isCarrierNetworkChangeActive() {
        return ((MobileState) this.mCurrentState).carrierNetworkChangeMode;
    }

    public void handleBroadcast(Intent intent) {
        String action = intent.getAction();
        if (action.equals("android.provider.Telephony.SPN_STRINGS_UPDATED")) {
            updateNetworkName(intent.getBooleanExtra("showSpn", false), intent.getStringExtra("spn"), intent.getStringExtra("spnData"), intent.getBooleanExtra("showPlmn", false), intent.getStringExtra("plmn"));
            notifyListenersIfNecessary();
        } else if (action.equals("android.intent.action.ACTION_DEFAULT_DATA_SUBSCRIPTION_CHANGED")) {
            updateDataSim();
            notifyListenersIfNecessary();
        } else if (action.equals("android.intent.action.LOCALE_CHANGED") && this.mConfig.showLocale) {
            updateNetworkName(this.mLastShowSpn, this.mLastSpn, this.mLastDataSpn, this.mLastShowPlmn, this.mLastPlmn);
            notifyListenersIfNecessary();
        }
    }

    private void updateDataSim() {
        boolean z = true;
        int defaultDataSub = this.mDefaults.getDefaultDataSubId();
        if (SubscriptionManager.isValidSubscriptionId(defaultDataSub)) {
            MobileState mobileState = (MobileState) this.mCurrentState;
            if (defaultDataSub != this.mSubscriptionInfo.getSubscriptionId()) {
                z = false;
            }
            mobileState.dataSim = z;
            return;
        }
        ((MobileState) this.mCurrentState).dataSim = true;
    }

    private String getLocalString(String originalString) {
        return NativeTextHelper.getLocalString(this.mContext, originalString, 17236038, 17236039);
    }

    private String getNetworkClassString(ServiceState state) {
        if (state == null || (state.getDataRegState() != 0 && state.getVoiceRegState() != 0)) {
            return "";
        }
        int chosenNetType;
        int voiceNetType = state.getVoiceNetworkType();
        int dataNetType = state.getDataNetworkType();
        if (dataNetType == 0) {
            chosenNetType = voiceNetType;
        } else {
            chosenNetType = dataNetType;
        }
        TelephonyManager tm = (TelephonyManager) this.mContext.getSystemService("phone");
        return networkClassToString(TelephonyManager.getNetworkClass(chosenNetType));
    }

    private String networkClassToString(int networkClass) {
        int[] classIds = new int[]{17039446, 17039447, 17039448, 17039449};
        String classString = null;
        if (networkClass < classIds.length) {
            classString = this.mContext.getResources().getString(classIds[networkClass]);
        }
        return classString == null ? "" : classString;
    }

    void updateNetworkName(boolean showSpn, String spn, String dataSpn, boolean showPlmn, String plmn) {
        this.mLastShowSpn = showSpn;
        this.mLastSpn = spn;
        this.mLastDataSpn = dataSpn;
        this.mLastShowPlmn = showPlmn;
        this.mLastPlmn = plmn;
        if (CHATTY) {
            Log.d("CarrierLabel", "updateNetworkName showSpn=" + showSpn + " spn=" + spn + " dataSpn=" + dataSpn + " showPlmn=" + showPlmn + " plmn=" + plmn);
        }
        if (this.mConfig.showLocale) {
            if (showSpn && !TextUtils.isEmpty(spn)) {
                spn = getLocalString(spn);
            }
            if (showSpn && !TextUtils.isEmpty(dataSpn)) {
                dataSpn = getLocalString(dataSpn);
            }
            if (showPlmn && !TextUtils.isEmpty(plmn)) {
                plmn = getLocalString(plmn);
            }
        }
        if (showPlmn && showSpn && !TextUtils.isEmpty(spn) && !TextUtils.isEmpty(plmn) && plmn.equals(spn)) {
            showSpn = false;
        }
        String networkClass = getNetworkClassString(this.mServiceState);
        StringBuilder str = new StringBuilder();
        StringBuilder strData = new StringBuilder();
        if (showPlmn && plmn != null) {
            str.append(plmn);
            strData.append(plmn);
            if (this.mConfig.showRat) {
                str.append(" ").append(networkClass);
                strData.append(" ").append(networkClass);
            }
        }
        if (showSpn && spn != null) {
            if (str.length() != 0) {
                str.append(this.mNetworkNameSeparator);
            }
            str.append(spn);
            if (this.mConfig.showRat) {
                str.append(" ").append(networkClass);
            }
        }
        if (str.length() != 0) {
            ((MobileState) this.mCurrentState).networkName = str.toString();
        } else {
            ((MobileState) this.mCurrentState).networkName = this.mNetworkNameDefault;
        }
        if (showSpn && dataSpn != null) {
            if (strData.length() != 0) {
                strData.append(this.mNetworkNameSeparator);
            }
            strData.append(dataSpn);
            if (this.mConfig.showRat) {
                strData.append(" ").append(networkClass);
            }
        }
        if (strData.length() != 0) {
            ((MobileState) this.mCurrentState).networkNameData = strData.toString();
            return;
        }
        ((MobileState) this.mCurrentState).networkNameData = this.mNetworkNameDefault;
    }

    private final void updateTelephony() {
        boolean z = true;
        if (DEBUG) {
            Log.d(this.mTag, "updateTelephony: hasService=" + hasService() + " ss=" + this.mSignalStrength);
        }
        MobileState mobileState = (MobileState) this.mCurrentState;
        boolean z2 = hasService() && this.mSignalStrength != null;
        mobileState.connected = z2;
        if (((MobileState) this.mCurrentState).connected) {
            if (this.mSignalStrength.isGsm() || !this.mConfig.alwaysShowCdmaRssi) {
                ((MobileState) this.mCurrentState).level = this.mSignalStrength.getLevel();
                if (this.mConfig.showRsrpSignalLevelforLTE) {
                    int dataType = this.mServiceState.getDataNetworkType();
                    if (dataType == 13 || dataType == 19) {
                        ((MobileState) this.mCurrentState).level = getAlternateLteLevel(this.mSignalStrength);
                    }
                }
            } else {
                ((MobileState) this.mCurrentState).level = this.mSignalStrength.getCdmaLevel();
            }
        }
        if (this.mNetworkToIconLookup.indexOfKey(this.mDataNetType) >= 0) {
            ((MobileState) this.mCurrentState).iconGroup = (IconGroup) this.mNetworkToIconLookup.get(this.mDataNetType);
        } else {
            ((MobileState) this.mCurrentState).iconGroup = this.mDefaultIcons;
        }
        mobileState = (MobileState) this.mCurrentState;
        if (!(((MobileState) this.mCurrentState).connected && this.mDataState == 2)) {
            z = false;
        }
        mobileState.dataConnected = z;
        if (isCarrierNetworkChangeActive()) {
            ((MobileState) this.mCurrentState).iconGroup = TelephonyIcons.CARRIER_NETWORK_CHANGE;
        } else if (isRoaming() && !this.mContext.getResources().getBoolean(2131558436)) {
            ((MobileState) this.mCurrentState).iconGroup = TelephonyIcons.ROAMING;
        }
        if (isEmergencyOnly() != ((MobileState) this.mCurrentState).isEmergency) {
            ((MobileState) this.mCurrentState).isEmergency = isEmergencyOnly();
            this.mNetworkController.recalculateEmergency();
        }
        if (!(((MobileState) this.mCurrentState).networkName != this.mNetworkNameDefault || this.mServiceState == null || TextUtils.isEmpty(this.mServiceState.getOperatorAlphaShort()))) {
            ((MobileState) this.mCurrentState).networkName = this.mServiceState.getOperatorAlphaShort();
        }
        if (this.mConfig.readIconsFromXml) {
            ((MobileState) this.mCurrentState).voiceLevel = getVoiceSignalLevel();
        }
        notifyListenersIfNecessary();
    }

    private void generateIconGroup() {
        int level = ((MobileState) this.mCurrentState).level;
        int voiceLevel = ((MobileState) this.mCurrentState).voiceLevel;
        int inet = ((MobileState) this.mCurrentState).inetCondition;
        boolean dataConnected = ((MobileState) this.mCurrentState).dataConnected;
        boolean roaming = isRoaming();
        int voiceType = getVoiceNetworkType();
        int dataType = getDataNetworkType();
        int[][] sbIcons = TelephonyIcons.TELEPHONY_SIGNAL_STRENGTH;
        int[][] qsIcons = TelephonyIcons.QS_TELEPHONY_SIGNAL_STRENGTH;
        int[] contentDesc = AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH;
        int discContentDesc = AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0];
        int stackedDataIcon = 0;
        int stackedVoiceIcon = 0;
        int slotId = getSimSlotIndex();
        if (slotId < 0 || slotId > this.mPhone.getPhoneCount()) {
            Log.e(this.mTag, "generateIconGroup invalid slotId:" + slotId);
            return;
        }
        int chosenNetworkType;
        int dataTypeIcon;
        int qsDataTypeIcon;
        int dataContentDesc;
        if (DEBUG) {
            Log.d(this.mTag, "generateIconGroup slot:" + slotId + " style:" + this.mStyle + " connected:" + ((MobileState) this.mCurrentState).connected + " inetCondition:" + inet + " roaming:" + roaming + " level:" + level + " voiceLevel:" + voiceLevel + " dataConnected:" + dataConnected + " dataActivity:" + ((MobileState) this.mCurrentState).dataActivity + " CS:" + voiceType + "/" + TelephonyManager.getNetworkTypeName(voiceType) + ", PS:" + dataType + "/" + TelephonyManager.getNetworkTypeName(dataType));
        }
        if (dataType == 0) {
            chosenNetworkType = voiceType;
        } else {
            chosenNetworkType = dataType;
        }
        TelephonyIcons.updateDataType(slotId, chosenNetworkType, this.mConfig.showAtLeast3G, this.mConfig.show4gForLte, this.mConfig.hspaDataDistinguishable, inet);
        int singleSignalIcon = TelephonyIcons.getSignalStrengthIcon(slotId, inet, level, roaming);
        if (DEBUG) {
            Log.d(this.mTag, "singleSignalIcon:" + getResourceName(singleSignalIcon));
        }
        int dataActivityId = (!((MobileState) this.mCurrentState).dataConnected || slotId < 0) ? 0 : TelephonyIcons.getDataActivity(slotId, ((MobileState) this.mCurrentState).dataActivity);
        int unstackedSignalIcon = TelephonyIcons.convertMobileStrengthIcon(singleSignalIcon);
        if (DEBUG) {
            Log.d(this.mTag, "unstackedSignalIcon:" + getResourceName(unstackedSignalIcon));
        }
        if (singleSignalIcon != unstackedSignalIcon) {
            stackedDataIcon = singleSignalIcon;
            singleSignalIcon = unstackedSignalIcon;
        }
        if (this.mStyle == 1) {
            if (!roaming && showDataAndVoice()) {
                stackedVoiceIcon = TelephonyIcons.getStackedVoiceIcon(voiceLevel);
            } else if (roaming && dataActivityId != 0) {
                singleSignalIcon = TelephonyIcons.getRoamingSignalIconId(level, inet);
            }
        }
        if (stackedVoiceIcon == 0) {
            stackedDataIcon = 0;
        }
        contentDesc = TelephonyIcons.getSignalStrengthDes(slotId);
        int sbDiscState = TelephonyIcons.getSignalNullIcon(slotId);
        if (DEBUG) {
            Log.d(this.mTag, "singleSignalIcon=" + getResourceName(singleSignalIcon) + " dataActivityId=" + getResourceName(dataActivityId) + " stackedDataIcon=" + getResourceName(stackedDataIcon) + " stackedVoiceIcon=" + getResourceName(stackedVoiceIcon));
        }
        if (dataType == 18) {
            dataTypeIcon = 2130837831;
            qsDataTypeIcon = 2130837655;
            dataContentDesc = 2131362067;
        } else {
            dataTypeIcon = TelephonyIcons.getDataTypeIcon(slotId);
            dataContentDesc = TelephonyIcons.getDataTypeDesc(slotId);
            qsDataTypeIcon = TelephonyIcons.getQSDataTypeIcon(slotId);
        }
        if (roaming) {
            dataTypeIcon = 2130837840;
            qsDataTypeIcon = 2130837678;
        }
        if (DEBUG) {
            Log.d(this.mTag, "updateDataNetType, dataTypeIcon=" + getResourceName(dataTypeIcon) + " qsDataTypeIcon=" + getResourceName(qsDataTypeIcon) + " dataContentDesc=" + dataContentDesc);
        }
        ((MobileState) this.mCurrentState).iconGroup = new MobileIconGroup(TelephonyManager.getNetworkTypeName(dataType), sbIcons, qsIcons, contentDesc, 0, 0, sbDiscState, 2130837676, discContentDesc, dataContentDesc, dataTypeIcon, false, qsDataTypeIcon, singleSignalIcon, stackedDataIcon, stackedVoiceIcon, dataActivityId);
    }

    private int getSimSlotIndex() {
        int slotId = -1;
        if (this.mSubscriptionInfo != null) {
            slotId = this.mSubscriptionInfo.getSimSlotIndex();
        }
        if (DEBUG) {
            Log.d(this.mTag, "getSimSlotIndex, slotId: " + slotId);
        }
        return slotId;
    }

    private boolean showMobileActivity() {
        return this.mStyle == 2 || this.mStyle == 0;
    }

    private int getVoiceNetworkType() {
        if (this.mServiceState == null) {
            return 0;
        }
        return this.mServiceState.getVoiceNetworkType();
    }

    private int getDataNetworkType() {
        if (this.mServiceState == null) {
            return 0;
        }
        return this.mServiceState.getDataNetworkType();
    }

    private int getVoiceSignalLevel() {
        if (this.mSignalStrength == null) {
            return 0;
        }
        boolean isCdma;
        if (2 == TelephonyManager.getDefault().getCurrentPhoneType(this.mSubscriptionInfo.getSubscriptionId())) {
            isCdma = true;
        } else {
            isCdma = false;
        }
        return isCdma ? this.mSignalStrength.getCdmaLevel() : this.mSignalStrength.getGsmLevel();
    }

    private boolean showDataAndVoice() {
        if (this.mStyle != 1) {
            return false;
        }
        int dataType = getDataNetworkType();
        int voiceType = getVoiceNetworkType();
        if (dataType != 5 && dataType != 5 && dataType != 6 && dataType != 12 && dataType != 14 && dataType != 13 && dataType != 19) {
            return false;
        }
        if (voiceType == 7 || voiceType == 4) {
            return true;
        }
        return false;
    }

    private int getAlternateLteLevel(SignalStrength signalStrength) {
        int lteRsrp = signalStrength.getLteDbm();
        int rsrpLevel = 0;
        if (lteRsrp > -44) {
            rsrpLevel = 0;
        } else if (lteRsrp >= -97) {
            rsrpLevel = 4;
        } else if (lteRsrp >= -105) {
            rsrpLevel = 3;
        } else if (lteRsrp >= -113) {
            rsrpLevel = 2;
        } else if (lteRsrp >= -120) {
            rsrpLevel = 1;
        } else if (lteRsrp >= -140) {
            rsrpLevel = 0;
        }
        if (DEBUG) {
            Log.d(this.mTag, "getAlternateLteLevel lteRsrp:" + lteRsrp + " rsrpLevel = " + rsrpLevel);
        }
        return rsrpLevel;
    }

    protected String getResourceName(int resId) {
        if (resId == 0) {
            return "(null)";
        }
        try {
            return this.mContext.getResources().getResourceName(resId);
        } catch (NotFoundException e) {
            return "(unknown)";
        }
    }

    void setActivity(int activity) {
        boolean z = false;
        MobileState mobileState = (MobileState) this.mCurrentState;
        boolean z2 = activity == 3 || activity == 1;
        mobileState.activityIn = z2;
        mobileState = (MobileState) this.mCurrentState;
        if (activity == 3 || activity == 2) {
            z = true;
        }
        mobileState.activityOut = z;
        if (this.mConfig.readIconsFromXml) {
            ((MobileState) this.mCurrentState).dataActivity = activity;
        }
        notifyListenersIfNecessary();
    }

    public void dump(PrintWriter pw) {
        super.dump(pw);
        pw.println("  mSubscription=" + this.mSubscriptionInfo + ",");
        pw.println("  mServiceState=" + this.mServiceState + ",");
        pw.println("  mSignalStrength=" + this.mSignalStrength + ",");
        pw.println("  mDataState=" + this.mDataState + ",");
        pw.println("  mDataNetType=" + this.mDataNetType + ",");
    }
}
