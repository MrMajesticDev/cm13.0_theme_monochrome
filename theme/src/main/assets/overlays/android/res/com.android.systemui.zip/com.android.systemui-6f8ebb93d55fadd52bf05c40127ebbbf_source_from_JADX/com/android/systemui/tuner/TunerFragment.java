package com.android.systemui.tuner;

import android.app.AlertDialog.Builder;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceFragment;
import android.preference.PreferenceGroup;
import android.provider.Settings.Secure;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.tuner.TunerService.Tunable;

public class TunerFragment extends PreferenceFragment {
    private final SettingObserver mSettingObserver;

    /* renamed from: com.android.systemui.tuner.TunerFragment.1 */
    class C05251 implements OnPreferenceClickListener {
        C05251() {
        }

        public boolean onPreferenceClick(Preference preference) {
            FragmentTransaction ft = TunerFragment.this.getFragmentManager().beginTransaction();
            ft.replace(16908290, new DemoModeFragment(), "DemoMode");
            ft.addToBackStack(null);
            ft.commit();
            return true;
        }
    }

    /* renamed from: com.android.systemui.tuner.TunerFragment.2 */
    class C05262 implements OnClickListener {
        C05262() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Secure.putInt(TunerFragment.this.getContext().getContentResolver(), "seen_tuner_warning", 1);
        }
    }

    /* renamed from: com.android.systemui.tuner.TunerFragment.3 */
    class C05273 implements Runnable {
        C05273() {
        }

        public void run() {
            TunerFragment.this.getActivity().finish();
        }
    }

    private final class SettingObserver extends ContentObserver {
        public SettingObserver() {
            super(new Handler());
        }

        public void onChange(boolean selfChange, Uri uri, int userId) {
            super.onChange(selfChange, uri, userId);
        }
    }

    public TunerFragment() {
        this.mSettingObserver = new SettingObserver();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(2131165185);
        getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);
        setHasOptionsMenu(true);
        findPreference("demo_mode").setOnPreferenceClickListener(new C05251());
        if (Secure.getInt(getContext().getContentResolver(), "seen_tuner_warning", 0) == 0) {
            new Builder(getContext()).setTitle(2131362361).setMessage(2131362362).setPositiveButton(2131362364, new C05262()).show();
        }
    }

    public void onResume() {
        super.onResume();
        registerPrefs(getPreferenceScreen());
        MetricsLogger.visibility(getContext(), 227, true);
    }

    public void onPause() {
        super.onPause();
        getContext().getContentResolver().unregisterContentObserver(this.mSettingObserver);
        unregisterPrefs(getPreferenceScreen());
        MetricsLogger.visibility(getContext(), 227, false);
    }

    private void registerPrefs(PreferenceGroup group) {
        TunerService tunerService = TunerService.get(getContext());
        int N = group.getPreferenceCount();
        for (int i = 0; i < N; i++) {
            Preference pref = group.getPreference(i);
            if (pref instanceof StatusBarSwitch) {
                tunerService.addTunable((Tunable) pref, "icon_blacklist");
            } else if (pref instanceof PreferenceGroup) {
                registerPrefs((PreferenceGroup) pref);
            }
        }
    }

    private void unregisterPrefs(PreferenceGroup group) {
        TunerService tunerService = TunerService.get(getContext());
        int N = group.getPreferenceCount();
        for (int i = 0; i < N; i++) {
            Preference pref = group.getPreference(i);
            if (pref instanceof Tunable) {
                tunerService.removeTunable((Tunable) pref);
            } else if (pref instanceof PreferenceGroup) {
                registerPrefs((PreferenceGroup) pref);
            }
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.add(0, 2, 0, 2131362366);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 2:
                TunerService.showResetRequest(getContext(), new C05273());
                return true;
            case 16908332:
                getActivity().finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
