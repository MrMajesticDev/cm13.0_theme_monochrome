package com.android.systemui.statusbar.policy;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.UserHandle;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextClock;

public class SplitClockView extends LinearLayout {
    private TextClock mAmPmView;
    private BroadcastReceiver mIntentReceiver;
    private TextClock mTimeView;

    /* renamed from: com.android.systemui.statusbar.policy.SplitClockView.1 */
    class C04941 extends BroadcastReceiver {
        C04941() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.TIME_SET".equals(action) || "android.intent.action.TIMEZONE_CHANGED".equals(action) || "android.intent.action.LOCALE_CHANGED".equals(action) || "android.intent.action.CONFIGURATION_CHANGED".equals(action) || "android.intent.action.USER_SWITCHED".equals(action)) {
                SplitClockView.this.updatePatterns();
            }
        }
    }

    public SplitClockView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mIntentReceiver = new C04941();
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mTimeView = (TextClock) findViewById(2131755269);
        this.mAmPmView = (TextClock) findViewById(2131755270);
        this.mTimeView.setShowCurrentUserTime(true);
        this.mAmPmView.setShowCurrentUserTime(true);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.TIME_SET");
        filter.addAction("android.intent.action.TIMEZONE_CHANGED");
        filter.addAction("android.intent.action.LOCALE_CHANGED");
        filter.addAction("android.intent.action.CONFIGURATION_CHANGED");
        filter.addAction("android.intent.action.USER_SWITCHED");
        getContext().registerReceiverAsUser(this.mIntentReceiver, UserHandle.ALL, filter, null, null);
        updatePatterns();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getContext().unregisterReceiver(this.mIntentReceiver);
    }

    private void updatePatterns() {
        String timeString;
        String amPmString;
        String formatString = DateFormat.getTimeFormatString(getContext(), ActivityManager.getCurrentUser());
        int index = getAmPmPartEndIndex(formatString);
        if (index == -1) {
            timeString = formatString;
            amPmString = "";
        } else {
            timeString = formatString.substring(0, index);
            amPmString = formatString.substring(index);
        }
        this.mTimeView.setFormat12Hour(timeString);
        this.mTimeView.setFormat24Hour(timeString);
        this.mTimeView.setContentDescriptionFormat12Hour(formatString);
        this.mTimeView.setContentDescriptionFormat24Hour(formatString);
        this.mAmPmView.setFormat12Hour(amPmString);
        this.mAmPmView.setFormat24Hour(amPmString);
    }

    private static int getAmPmPartEndIndex(String formatString) {
        boolean hasAmPm = false;
        int length = formatString.length();
        int i = length - 1;
        while (i >= 0) {
            boolean isAmPm;
            char c = formatString.charAt(i);
            if (c == 'a') {
                isAmPm = true;
            } else {
                isAmPm = false;
            }
            boolean isWhitespace = Character.isWhitespace(c);
            if (isAmPm) {
                hasAmPm = true;
            }
            if (isAmPm || isWhitespace) {
                i--;
            } else if (i == length - 1) {
                return -1;
            } else {
                return hasAmPm ? i + 1 : -1;
            }
        }
        if (hasAmPm) {
            return 0;
        }
        return -1;
    }
}
