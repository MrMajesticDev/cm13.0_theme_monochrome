package com.android.systemui.recents;

import android.app.ActivityManager.RunningTaskInfo;
import android.app.ActivityOptions;
import android.app.ActivityOptions.OnAnimationStartedListener;
import android.app.ITaskStackListener.Stub;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.SystemClock;
import android.os.UserHandle;
import android.provider.Settings.Global;
import android.util.MutableBoolean;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import com.android.systemui.Prefs;
import com.android.systemui.RecentsComponent;
import com.android.systemui.RecentsComponent.Callbacks;
import com.android.systemui.SystemUI;
import com.android.systemui.recents.Constants.Values.App;
import com.android.systemui.recents.misc.Console;
import com.android.systemui.recents.misc.SystemServicesProxy;
import com.android.systemui.recents.model.RecentsTaskLoadPlan;
import com.android.systemui.recents.model.RecentsTaskLoadPlan.Options;
import com.android.systemui.recents.model.RecentsTaskLoader;
import com.android.systemui.recents.model.Task;
import com.android.systemui.recents.model.Task.TaskKey;
import com.android.systemui.recents.model.TaskGrouping;
import com.android.systemui.recents.model.TaskStack;
import com.android.systemui.recents.views.TaskStackView;
import com.android.systemui.recents.views.TaskStackViewLayoutAlgorithm;
import com.android.systemui.recents.views.TaskStackViewLayoutAlgorithm.VisibilityReport;
import com.android.systemui.recents.views.TaskViewHeader;
import com.android.systemui.recents.views.TaskViewTransform;
import com.android.systemui.statusbar.phone.PhoneStatusBar;
import java.util.ArrayList;

public class Recents extends SystemUI implements OnAnimationStartedListener, RecentsComponent {
    static Recents sInstance;
    static RecentsTaskLoadPlan sInstanceLoadPlan;
    static Callbacks sRecentsComponentCallbacks;
    RecentsAppWidgetHost mAppWidgetHost;
    boolean mBootCompleted;
    boolean mCanReuseTaskStackViews;
    RecentsConfiguration mConfig;
    TaskStackView mDummyStackView;
    Handler mHandler;
    TaskViewHeader mHeaderBar;
    final Object mHeaderBarLock;
    LayoutInflater mInflater;
    long mLastToggleTime;
    int mNavBarHeight;
    int mNavBarWidth;
    RecentsOwnerEventProxyReceiver mProxyBroadcastReceiver;
    boolean mStartAnimationTriggered;
    int mStatusBarHeight;
    Rect mSystemInsets;
    SystemServicesProxy mSystemServicesProxy;
    Rect mTaskStackBounds;
    TaskStackListenerImpl mTaskStackListener;
    Bitmap mThumbnailTransitionBitmapCache;
    Task mThumbnailTransitionBitmapCacheKey;
    TaskViewTransform mTmpTransform;
    boolean mTriggeredFromAltTab;
    Rect mWindowRect;

    /* renamed from: com.android.systemui.recents.Recents.1 */
    class C02001 extends AsyncTask<Void, Void, Bitmap> {
        final /* synthetic */ Task val$toTask;
        final /* synthetic */ TaskViewTransform val$toTransform;

        C02001(Task task, TaskViewTransform taskViewTransform) {
            this.val$toTask = task;
            this.val$toTransform = taskViewTransform;
        }

        protected Bitmap doInBackground(Void... params) {
            return Recents.this.drawThumbnailTransitionBitmap(this.val$toTask, this.val$toTransform);
        }

        protected void onPostExecute(Bitmap bitmap) {
            Recents.this.mThumbnailTransitionBitmapCache = bitmap;
            Recents.this.mThumbnailTransitionBitmapCacheKey = this.val$toTask;
        }
    }

    /* renamed from: com.android.systemui.recents.Recents.2 */
    class C02022 extends BroadcastReceiver {

        /* renamed from: com.android.systemui.recents.Recents.2.1 */
        class C02011 implements Runnable {
            C02011() {
            }

            public void run() {
                Recents.this.onAnimationStarted();
            }
        }

        C02022() {
        }

        public void onReceive(Context context, Intent intent) {
            if (getResultCode() == -1) {
                Recents.this.mStartAnimationTriggered = true;
            } else {
                Recents.this.mHandler.postDelayed(new C02011(), 25);
            }
        }
    }

    class RecentsOwnerEventProxyReceiver extends BroadcastReceiver {
        RecentsOwnerEventProxyReceiver() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            boolean z = true;
            switch (action.hashCode()) {
                case 162746857:
                    if (action.equals("action_notify_recents_visibility_change")) {
                        z = false;
                        break;
                    }
                    break;
                case 1703590511:
                    if (action.equals("action_screen_pinning_request")) {
                        z = true;
                        break;
                    }
                    break;
            }
            switch (z) {
                case C0065R.styleable.NumPadKey_digit /*0*/:
                    Recents.visibilityChanged(intent.getBooleanExtra("recentsVisibility", false));
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    Recents.onStartScreenPinning(context);
                default:
            }
        }
    }

    class TaskStackListenerImpl extends Stub implements Runnable {
        Handler mHandler;

        public TaskStackListenerImpl(Handler handler) {
            this.mHandler = handler;
        }

        public void onTaskStackChanged() {
            this.mHandler.removeCallbacks(this);
            this.mHandler.post(this);
        }

        public void run() {
            if (!Recents.this.mConfig.multiStackEnabled && RecentsConfiguration.getInstance().svelteLevel == 0) {
                RecentsTaskLoader loader = RecentsTaskLoader.getInstance();
                RunningTaskInfo runningTaskInfo = loader.getSystemServicesProxy().getTopMostTask();
                RecentsTaskLoadPlan plan = loader.createLoadPlan(Recents.this.mContext);
                loader.preloadTasks(plan, true);
                Options launchOpts = new Options();
                if (runningTaskInfo != null) {
                    launchOpts.runningTaskId = runningTaskInfo.id;
                }
                launchOpts.numVisibleTasks = 2;
                launchOpts.numVisibleTaskThumbnails = 2;
                launchOpts.onlyLoadForCache = true;
                launchOpts.onlyLoadPausedActivities = true;
                loader.loadTasks(Recents.this.mContext, plan, launchOpts);
            }
        }
    }

    public Recents() {
        this.mCanReuseTaskStackViews = true;
        this.mWindowRect = new Rect();
        this.mTaskStackBounds = new Rect();
        this.mSystemInsets = new Rect();
        this.mTmpTransform = new TaskViewTransform();
        this.mHeaderBarLock = new Object();
    }

    public static Recents getInstanceAndStartIfNeeded(Context ctx) {
        if (sInstance == null) {
            sInstance = new Recents();
            sInstance.mContext = ctx;
            sInstance.start();
            sInstance.onBootCompleted();
        }
        return sInstance;
    }

    static Intent createLocalBroadcastIntent(Context context, String action) {
        Intent intent = new Intent(action);
        intent.setPackage(context.getPackageName());
        intent.addFlags(335544320);
        return intent;
    }

    @ProxyFromPrimaryToCurrentUser
    public void start() {
        if (sInstance == null) {
            sInstance = this;
        }
        RecentsTaskLoader.initialize(this.mContext);
        this.mInflater = LayoutInflater.from(this.mContext);
        this.mSystemServicesProxy = new SystemServicesProxy(this.mContext);
        this.mHandler = new Handler();
        this.mTaskStackBounds = new Rect();
        this.mAppWidgetHost = new RecentsAppWidgetHost(this.mContext, App.AppWidgetHostId);
        this.mTaskStackListener = new TaskStackListenerImpl(this.mHandler);
        this.mSystemServicesProxy.registerTaskStackListener(this.mTaskStackListener);
        if (this.mSystemServicesProxy.isForegroundUserOwner()) {
            this.mProxyBroadcastReceiver = new RecentsOwnerEventProxyReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction("action_notify_recents_visibility_change");
            filter.addAction("action_screen_pinning_request");
            this.mContext.registerReceiverAsUser(this.mProxyBroadcastReceiver, UserHandle.CURRENT, filter, null, this.mHandler);
        }
        TaskStackViewLayoutAlgorithm.initializeCurve();
        reloadHeaderBarLayout();
        RecentsTaskLoader loader = RecentsTaskLoader.getInstance();
        RecentsTaskLoadPlan plan = loader.createLoadPlan(this.mContext);
        loader.preloadTasks(plan, true);
        Options launchOpts = new Options();
        launchOpts.numVisibleTasks = loader.getApplicationIconCacheSize();
        launchOpts.numVisibleTaskThumbnails = loader.getThumbnailCacheSize();
        launchOpts.onlyLoadForCache = true;
        loader.loadTasks(this.mContext, plan, launchOpts);
        putComponent(Recents.class, this);
    }

    public void onBootCompleted() {
        this.mBootCompleted = true;
    }

    @ProxyFromPrimaryToCurrentUser
    public void showRecents(boolean triggeredFromAltTab, View statusBarView) {
        if (!isDeviceProvisioned()) {
            return;
        }
        if (this.mSystemServicesProxy.isForegroundUserOwner()) {
            showRecentsInternal(triggeredFromAltTab);
            return;
        }
        Intent intent = createLocalBroadcastIntent(this.mContext, "com.android.systemui.recents.action.SHOW_RECENTS_FOR_USER");
        intent.putExtra("triggeredFromAltTab", triggeredFromAltTab);
        this.mContext.sendBroadcastAsUser(intent, UserHandle.CURRENT);
    }

    void showRecentsInternal(boolean triggeredFromAltTab) {
        this.mTriggeredFromAltTab = triggeredFromAltTab;
        try {
            RunningTaskInfo topTask = this.mSystemServicesProxy.getTopMostTask();
            if (topTask == null || !this.mSystemServicesProxy.isRecentsTopMost(topTask, null)) {
                startRecentsActivity();
                return;
            }
            Intent intent = createLocalBroadcastIntent(this.mContext, "action_alt_tab_traversal");
            intent.putExtra("triggeredFromAltTab", triggeredFromAltTab);
            this.mContext.sendBroadcastAsUser(intent, UserHandle.CURRENT);
        } catch (ActivityNotFoundException e) {
            Console.logRawError("Failed to launch RecentAppsIntent", e);
        }
    }

    @ProxyFromPrimaryToCurrentUser
    public void hideRecents(boolean triggeredFromAltTab, boolean triggeredFromHomeKey) {
        if (!isDeviceProvisioned()) {
            return;
        }
        if (this.mSystemServicesProxy.isForegroundUserOwner()) {
            hideRecentsInternal(triggeredFromAltTab, triggeredFromHomeKey);
            return;
        }
        Intent intent = createLocalBroadcastIntent(this.mContext, "com.android.systemui.recents.action.HIDE_RECENTS_FOR_USER");
        intent.putExtra("triggeredFromAltTab", triggeredFromAltTab);
        intent.putExtra("triggeredFromHomeKey", triggeredFromHomeKey);
        this.mContext.sendBroadcastAsUser(intent, UserHandle.CURRENT);
    }

    void hideRecentsInternal(boolean triggeredFromAltTab, boolean triggeredFromHomeKey) {
        if (this.mBootCompleted) {
            Intent intent = createLocalBroadcastIntent(this.mContext, "action_hide_recents_activity");
            intent.putExtra("triggeredFromAltTab", triggeredFromAltTab);
            intent.putExtra("triggeredFromHomeKey", triggeredFromHomeKey);
            this.mContext.sendBroadcastAsUser(intent, UserHandle.CURRENT);
        }
    }

    @ProxyFromPrimaryToCurrentUser
    public void toggleRecents(Display display, int layoutDirection, View statusBarView) {
        if (!isDeviceProvisioned()) {
            return;
        }
        if (this.mSystemServicesProxy.isForegroundUserOwner()) {
            toggleRecentsInternal();
            return;
        }
        this.mContext.sendBroadcastAsUser(createLocalBroadcastIntent(this.mContext, "com.android.systemui.recents.action.TOGGLE_RECENTS_FOR_USER"), UserHandle.CURRENT);
    }

    void toggleRecentsInternal() {
        this.mTriggeredFromAltTab = false;
        try {
            toggleRecentsActivity();
        } catch (ActivityNotFoundException e) {
            Console.logRawError("Failed to launch RecentAppsIntent", e);
        }
    }

    @ProxyFromPrimaryToCurrentUser
    public void preloadRecents() {
        if (!isDeviceProvisioned()) {
            return;
        }
        if (this.mSystemServicesProxy.isForegroundUserOwner()) {
            preloadRecentsInternal();
            return;
        }
        this.mContext.sendBroadcastAsUser(createLocalBroadcastIntent(this.mContext, "com.android.systemui.recents.action.PRELOAD_RECENTS_FOR_USER"), UserHandle.CURRENT);
    }

    void preloadRecentsInternal() {
        RunningTaskInfo topTask = this.mSystemServicesProxy.getTopMostTask();
        MutableBoolean topTaskHome = new MutableBoolean(true);
        RecentsTaskLoader loader = RecentsTaskLoader.getInstance();
        sInstanceLoadPlan = loader.createLoadPlan(this.mContext);
        if (topTask != null && !this.mSystemServicesProxy.isRecentsTopMost(topTask, topTaskHome)) {
            sInstanceLoadPlan.preloadRawTasks(topTaskHome.value);
            loader.preloadTasks(sInstanceLoadPlan, topTaskHome.value);
            TaskStack top = (TaskStack) sInstanceLoadPlan.getAllTaskStacks().get(0);
            if (top.getTaskCount() > 0) {
                preCacheThumbnailTransitionBitmapAsync(topTask, top, this.mDummyStackView, topTaskHome.value);
            }
        }
    }

    public void cancelPreloadingRecents() {
    }

    void showRelativeAffiliatedTask(boolean showNextTask) {
        TaskStack focusedStack;
        int focusedStackId = this.mSystemServicesProxy.getFocusedStack();
        RecentsTaskLoader loader = RecentsTaskLoader.getInstance();
        RecentsTaskLoadPlan plan = loader.createLoadPlan(this.mContext);
        loader.preloadTasks(plan, true);
        if (!this.mConfig.multiStackEnabled) {
            focusedStack = (TaskStack) plan.getAllTaskStacks().get(0);
        } else if (focusedStackId >= 0) {
            focusedStack = plan.getTaskStack(focusedStackId);
        } else {
            return;
        }
        if (focusedStack != null && focusedStack.getTaskCount() != 0) {
            RunningTaskInfo runningTask = this.mSystemServicesProxy.getTopMostTask();
            if (runningTask != null) {
                if (!this.mSystemServicesProxy.isInHomeStack(runningTask.id)) {
                    ArrayList<Task> tasks = focusedStack.getTasks();
                    Task toTask = null;
                    ActivityOptions launchOpts = null;
                    int taskCount = tasks.size();
                    int numAffiliatedTasks = 0;
                    for (int i = 0; i < taskCount; i++) {
                        Task task = (Task) tasks.get(i);
                        if (task.key.id == runningTask.id) {
                            TaskKey toTaskKey;
                            TaskGrouping group = task.group;
                            if (showNextTask) {
                                toTaskKey = group.getNextTaskInGroup(task);
                                launchOpts = ActivityOptions.makeCustomAnimation(this.mContext, 2131034269, 2131034268);
                            } else {
                                toTaskKey = group.getPrevTaskInGroup(task);
                                launchOpts = ActivityOptions.makeCustomAnimation(this.mContext, 2131034272, 2131034271);
                            }
                            if (toTaskKey != null) {
                                toTask = focusedStack.findTaskWithId(toTaskKey.id);
                            }
                            numAffiliatedTasks = group.getTaskCount();
                            if (toTask == null) {
                                MetricsLogger.count(this.mContext, "overview_affiliated_task_launch", 1);
                                if (toTask.isActive) {
                                    this.mSystemServicesProxy.startActivityFromRecents(this.mContext, toTask.key.id, toTask.activityLabel, launchOpts);
                                    return;
                                }
                                this.mSystemServicesProxy.moveTaskToFront(toTask.key.id, launchOpts);
                            } else if (numAffiliatedTasks <= 1) {
                            } else {
                                if (showNextTask) {
                                    this.mSystemServicesProxy.startInPlaceAnimationOnFrontMostApplication(ActivityOptions.makeCustomInPlaceAnimation(this.mContext, 2131034270));
                                    return;
                                }
                                this.mSystemServicesProxy.startInPlaceAnimationOnFrontMostApplication(ActivityOptions.makeCustomInPlaceAnimation(this.mContext, 2131034267));
                            }
                        }
                    }
                    if (toTask == null) {
                        MetricsLogger.count(this.mContext, "overview_affiliated_task_launch", 1);
                        if (toTask.isActive) {
                            this.mSystemServicesProxy.startActivityFromRecents(this.mContext, toTask.key.id, toTask.activityLabel, launchOpts);
                            return;
                        }
                        this.mSystemServicesProxy.moveTaskToFront(toTask.key.id, launchOpts);
                    } else if (numAffiliatedTasks <= 1) {
                        if (showNextTask) {
                            this.mSystemServicesProxy.startInPlaceAnimationOnFrontMostApplication(ActivityOptions.makeCustomInPlaceAnimation(this.mContext, 2131034270));
                            return;
                        }
                        this.mSystemServicesProxy.startInPlaceAnimationOnFrontMostApplication(ActivityOptions.makeCustomInPlaceAnimation(this.mContext, 2131034267));
                    }
                }
            }
        }
    }

    public void showNextAffiliatedTask() {
        if (isDeviceProvisioned()) {
            MetricsLogger.count(this.mContext, "overview_affiliated_task_next", 1);
            showRelativeAffiliatedTask(true);
        }
    }

    public void showPrevAffiliatedTask() {
        if (isDeviceProvisioned()) {
            MetricsLogger.count(this.mContext, "overview_affiliated_task_prev", 1);
            showRelativeAffiliatedTask(false);
        }
    }

    @ProxyFromPrimaryToCurrentUser
    public void onConfigurationChanged(Configuration newConfig) {
        if (this.mSystemServicesProxy.isForegroundUserOwner()) {
            configurationChanged();
            return;
        }
        this.mContext.sendBroadcastAsUser(createLocalBroadcastIntent(this.mContext, "com.android.systemui.recents.action.CONFIG_CHANGED_FOR_USER"), UserHandle.CURRENT);
    }

    void configurationChanged() {
        this.mCanReuseTaskStackViews = false;
        reloadHeaderBarLayout();
    }

    void reloadHeaderBarLayout() {
        int i;
        Resources res = this.mContext.getResources();
        this.mWindowRect = this.mSystemServicesProxy.getWindowRect();
        this.mStatusBarHeight = res.getDimensionPixelSize(17104919);
        this.mNavBarHeight = res.getDimensionPixelSize(17104920);
        this.mNavBarWidth = res.getDimensionPixelSize(17104922);
        this.mConfig = RecentsConfiguration.reinitialize(this.mContext, this.mSystemServicesProxy);
        this.mConfig.updateOnConfigurationChange();
        Rect searchBarBounds = new Rect();
        if (this.mSystemServicesProxy.getOrBindSearchAppWidget(this.mContext, this.mAppWidgetHost) != null) {
            this.mConfig.getSearchBarBounds(this.mWindowRect.width(), this.mWindowRect.height(), this.mStatusBarHeight, searchBarBounds);
        }
        RecentsConfiguration recentsConfiguration = this.mConfig;
        int width = this.mWindowRect.width();
        int height = this.mWindowRect.height();
        int i2 = this.mStatusBarHeight;
        if (this.mConfig.hasTransposedNavBar) {
            i = this.mNavBarWidth;
        } else {
            i = 0;
        }
        recentsConfiguration.getAvailableTaskStackBounds(width, height, i2, i, searchBarBounds, this.mTaskStackBounds);
        if (this.mConfig.isLandscape && this.mConfig.hasTransposedNavBar) {
            this.mSystemInsets.set(0, this.mStatusBarHeight, this.mNavBarWidth, 0);
        } else {
            this.mSystemInsets.set(0, this.mStatusBarHeight, 0, this.mNavBarHeight);
        }
        this.mDummyStackView = new TaskStackView(this.mContext, new TaskStack());
        TaskStackViewLayoutAlgorithm algo = this.mDummyStackView.getStackAlgorithm();
        Rect taskStackBounds = new Rect(this.mTaskStackBounds);
        taskStackBounds.bottom -= this.mSystemInsets.bottom;
        algo.computeRects(this.mWindowRect.width(), this.mWindowRect.height(), taskStackBounds);
        Rect taskViewSize = algo.getUntransformedTaskViewSize();
        int taskBarHeight = res.getDimensionPixelSize(2131296353);
        synchronized (this.mHeaderBarLock) {
            this.mHeaderBar = (TaskViewHeader) this.mInflater.inflate(2130968629, null, false);
            this.mHeaderBar.measure(MeasureSpec.makeMeasureSpec(taskViewSize.width(), 1073741824), MeasureSpec.makeMeasureSpec(taskBarHeight, 1073741824));
            this.mHeaderBar.layout(0, 0, taskViewSize.width(), taskBarHeight);
        }
    }

    void toggleRecentsActivity() {
        if (SystemClock.elapsedRealtime() - this.mLastToggleTime >= 350) {
            RunningTaskInfo topTask = this.mSystemServicesProxy.getTopMostTask();
            MutableBoolean isTopTaskHome = new MutableBoolean(true);
            if (topTask == null || !this.mSystemServicesProxy.isRecentsTopMost(topTask, isTopTaskHome)) {
                startRecentsActivity(topTask, isTopTaskHome.value);
                return;
            }
            this.mContext.sendBroadcastAsUser(createLocalBroadcastIntent(this.mContext, "action_toggle_recents_activity"), UserHandle.CURRENT);
            this.mLastToggleTime = SystemClock.elapsedRealtime();
        }
    }

    void startRecentsActivity() {
        RunningTaskInfo topTask = this.mSystemServicesProxy.getTopMostTask();
        MutableBoolean isTopTaskHome = new MutableBoolean(true);
        if (topTask == null || !this.mSystemServicesProxy.isRecentsTopMost(topTask, isTopTaskHome)) {
            startRecentsActivity(topTask, isTopTaskHome.value);
        }
    }

    ActivityOptions getUnknownTransitionActivityOptions() {
        this.mStartAnimationTriggered = false;
        return ActivityOptions.makeCustomAnimation(this.mContext, 2131034263, 2131034264, this.mHandler, this);
    }

    ActivityOptions getHomeTransitionActivityOptions(boolean fromSearchHome) {
        this.mStartAnimationTriggered = false;
        if (fromSearchHome) {
            return ActivityOptions.makeCustomAnimation(this.mContext, 2131034261, 2131034262, this.mHandler, this);
        }
        return ActivityOptions.makeCustomAnimation(this.mContext, 2131034259, 2131034260, this.mHandler, this);
    }

    ActivityOptions getThumbnailTransitionActivityOptions(RunningTaskInfo topTask, TaskStack stack, TaskStackView stackView) {
        Bitmap thumbnail;
        Task toTask = new Task();
        TaskViewTransform toTransform = getThumbnailTransitionTransform(stack, stackView, topTask.id, toTask);
        Rect toTaskRect = toTransform.rect;
        if (this.mThumbnailTransitionBitmapCacheKey == null || this.mThumbnailTransitionBitmapCacheKey.key == null || !this.mThumbnailTransitionBitmapCacheKey.key.equals(toTask.key)) {
            preloadIcon(topTask);
            thumbnail = drawThumbnailTransitionBitmap(toTask, toTransform);
        } else {
            thumbnail = this.mThumbnailTransitionBitmapCache;
            this.mThumbnailTransitionBitmapCacheKey = null;
            this.mThumbnailTransitionBitmapCache = null;
        }
        if (thumbnail == null) {
            return getUnknownTransitionActivityOptions();
        }
        this.mStartAnimationTriggered = false;
        return ActivityOptions.makeThumbnailAspectScaleDownAnimation(this.mDummyStackView, thumbnail, toTaskRect.left, toTaskRect.top, toTaskRect.width(), toTaskRect.height(), this.mHandler, this);
    }

    void preloadIcon(RunningTaskInfo task) {
        Options launchOpts = new Options();
        launchOpts.runningTaskId = task.id;
        launchOpts.loadThumbnails = false;
        launchOpts.onlyLoadForCache = true;
        RecentsTaskLoader.getInstance().loadTasks(this.mContext, sInstanceLoadPlan, launchOpts);
    }

    void preCacheThumbnailTransitionBitmapAsync(RunningTaskInfo topTask, TaskStack stack, TaskStackView stackView, boolean isTopTaskHome) {
        preloadIcon(topTask);
        this.mDummyStackView.updateMinMaxScrollForStack(stack, this.mTriggeredFromAltTab, isTopTaskHome);
        Task toTask = new Task();
        new C02001(toTask, getThumbnailTransitionTransform(stack, stackView, topTask.id, toTask)).execute(new Void[0]);
    }

    Bitmap drawThumbnailTransitionBitmap(Task toTask, TaskViewTransform toTransform) {
        if (toTransform == null || toTask.key == null) {
            return null;
        }
        Bitmap thumbnail;
        synchronized (this.mHeaderBarLock) {
            thumbnail = Bitmap.createBitmap((int) (((float) this.mHeaderBar.getMeasuredWidth()) * toTransform.scale), (int) (((float) this.mHeaderBar.getMeasuredHeight()) * toTransform.scale), Config.ARGB_8888);
            Canvas c = new Canvas(thumbnail);
            c.scale(toTransform.scale, toTransform.scale);
            this.mHeaderBar.rebindToTask(toTask);
            this.mHeaderBar.draw(c);
            c.setBitmap(null);
        }
        return thumbnail.createAshmemBitmap();
    }

    TaskViewTransform getThumbnailTransitionTransform(TaskStack stack, TaskStackView stackView, int runningTaskId, Task runningTaskOut) {
        Task task = null;
        ArrayList<Task> tasks = stack.getTasks();
        if (runningTaskId != -1) {
            for (int i = tasks.size() - 1; i >= 0; i--) {
                Task t = (Task) tasks.get(i);
                if (t.key.id == runningTaskId) {
                    task = t;
                    runningTaskOut.copyFrom(t);
                    break;
                }
            }
        }
        if (task == null) {
            task = (Task) tasks.get(tasks.size() - 1);
            runningTaskOut.copyFrom(task);
        }
        stackView.getScroller().setStackScrollToInitialState();
        this.mTmpTransform = stackView.getStackAlgorithm().getStackTransform(task, stackView.getScroller().getStackScroll(), this.mTmpTransform, null);
        return this.mTmpTransform;
    }

    void startRecentsActivity(RunningTaskInfo topTask, boolean isTopTaskHome) {
        RecentsTaskLoader loader = RecentsTaskLoader.getInstance();
        RecentsConfiguration.reinitialize(this.mContext, this.mSystemServicesProxy);
        if (this.mTriggeredFromAltTab || sInstanceLoadPlan == null) {
            sInstanceLoadPlan = loader.createLoadPlan(this.mContext);
        }
        if (this.mConfig.multiStackEnabled) {
            loader.preloadTasks(sInstanceLoadPlan, true);
            this.mDummyStackView.updateMinMaxScrollForStack((TaskStack) sInstanceLoadPlan.getAllTaskStacks().get(0), this.mTriggeredFromAltTab, true);
            startAlternateRecentsActivity(topTask, getUnknownTransitionActivityOptions(), true, false, false, this.mDummyStackView.computeStackVisibilityReport());
            return;
        }
        if (this.mTriggeredFromAltTab || !sInstanceLoadPlan.hasTasks()) {
            loader.preloadTasks(sInstanceLoadPlan, isTopTaskHome);
        }
        TaskStack stack = (TaskStack) sInstanceLoadPlan.getAllTaskStacks().get(0);
        this.mDummyStackView.updateMinMaxScrollForStack(stack, this.mTriggeredFromAltTab, isTopTaskHome);
        VisibilityReport stackVr = this.mDummyStackView.computeStackVisibilityReport();
        boolean hasRecentTasks = stack.getTaskCount() > 0;
        boolean useThumbnailTransition = (topTask == null || isTopTaskHome || !hasRecentTasks) ? false : true;
        if (useThumbnailTransition) {
            ActivityOptions opts = getThumbnailTransitionActivityOptions(topTask, stack, this.mDummyStackView);
            if (opts != null) {
                startAlternateRecentsActivity(topTask, opts, false, false, true, stackVr);
            } else {
                useThumbnailTransition = false;
            }
        }
        if (!useThumbnailTransition) {
            if (hasRecentTasks) {
                String homeActivityPackage = this.mSystemServicesProxy.getHomeActivityPackageName();
                boolean fromSearchHome = homeActivityPackage != null && homeActivityPackage.equals(Prefs.getString(this.mContext, "searchAppWidgetPackage", null));
                startAlternateRecentsActivity(topTask, getHomeTransitionActivityOptions(fromSearchHome), true, fromSearchHome, false, stackVr);
            } else {
                startAlternateRecentsActivity(topTask, getUnknownTransitionActivityOptions(), true, false, false, stackVr);
            }
        }
        this.mLastToggleTime = SystemClock.elapsedRealtime();
    }

    void startAlternateRecentsActivity(RunningTaskInfo topTask, ActivityOptions opts, boolean fromHome, boolean fromSearchHome, boolean fromThumbnail, VisibilityReport vr) {
        boolean z;
        RecentsConfiguration recentsConfiguration = this.mConfig;
        if (fromSearchHome || fromHome) {
            z = true;
        } else {
            z = false;
        }
        recentsConfiguration.launchedFromHome = z;
        this.mConfig.launchedFromSearchHome = fromSearchHome;
        this.mConfig.launchedFromAppWithThumbnail = fromThumbnail;
        this.mConfig.launchedToTaskId = topTask != null ? topTask.id : -1;
        this.mConfig.launchedWithAltTab = this.mTriggeredFromAltTab;
        this.mConfig.launchedReuseTaskStackViews = this.mCanReuseTaskStackViews;
        this.mConfig.launchedNumVisibleTasks = vr.numVisibleTasks;
        this.mConfig.launchedNumVisibleThumbnails = vr.numVisibleThumbnails;
        this.mConfig.launchedHasConfigurationChanged = false;
        Intent intent = new Intent("com.android.systemui.recents.SHOW_RECENTS");
        intent.setClassName("com.android.systemui", "com.android.systemui.recents.RecentsActivity");
        intent.setFlags(276840448);
        if (opts != null) {
            this.mContext.startActivityAsUser(intent, opts.toBundle(), UserHandle.CURRENT);
        } else {
            this.mContext.startActivityAsUser(intent, UserHandle.CURRENT);
        }
        this.mCanReuseTaskStackViews = true;
    }

    public void setCallback(Callbacks cb) {
        sRecentsComponentCallbacks = cb;
    }

    @ProxyFromAnyToPrimaryUser
    public static void notifyVisibilityChanged(Context context, SystemServicesProxy ssp, boolean visible) {
        if (ssp.isForegroundUserOwner()) {
            visibilityChanged(visible);
            return;
        }
        Intent intent = createLocalBroadcastIntent(context, "action_notify_recents_visibility_change");
        intent.putExtra("recentsVisibility", visible);
        context.sendBroadcastAsUser(intent, UserHandle.OWNER);
    }

    static void visibilityChanged(boolean visible) {
        if (sRecentsComponentCallbacks != null) {
            sRecentsComponentCallbacks.onVisibilityChanged(visible);
        }
    }

    @ProxyFromAnyToPrimaryUser
    public static void startScreenPinning(Context context, SystemServicesProxy ssp) {
        if (ssp.isForegroundUserOwner()) {
            onStartScreenPinning(context);
        } else {
            context.sendBroadcastAsUser(createLocalBroadcastIntent(context, "action_screen_pinning_request"), UserHandle.OWNER);
        }
    }

    static void onStartScreenPinning(Context context) {
        PhoneStatusBar statusBar = (PhoneStatusBar) getInstanceAndStartIfNeeded(context).mContext.getComponent(PhoneStatusBar.class);
        if (statusBar != null) {
            statusBar.showScreenPinningRequest(false);
        }
    }

    private boolean isDeviceProvisioned() {
        return Global.getInt(this.mContext.getContentResolver(), "device_provisioned", 0) != 0;
    }

    public static RecentsTaskLoadPlan consumeInstanceLoadPlan() {
        RecentsTaskLoadPlan plan = sInstanceLoadPlan;
        sInstanceLoadPlan = null;
        return plan;
    }

    public void onAnimationStarted() {
        if (!this.mStartAnimationTriggered) {
            BroadcastReceiver fallbackReceiver = new C02022();
            this.mContext.sendOrderedBroadcastAsUser(createLocalBroadcastIntent(this.mContext, "action_start_enter_animation"), UserHandle.CURRENT, null, fallbackReceiver, null, 0, null, null);
        }
    }
}
