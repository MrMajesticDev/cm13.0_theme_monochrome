package com.android.keyguard;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;
import com.android.internal.telephony.ITelephony.Stub;
import com.android.internal.telephony.IccCardConstants.State;

public class KeyguardSimPinView extends KeyguardPinBasedInputView {
    private CheckSimPin mCheckSimPinThread;
    private int mRemainingAttempts;
    private AlertDialog mRemainingAttemptsDialog;
    private boolean mShowDefaultMessage;
    private ImageView mSimImageView;
    private ProgressDialog mSimUnlockProgressDialog;
    private int mSubId;
    KeyguardUpdateMonitorCallback mUpdateMonitorCallback;

    /* renamed from: com.android.keyguard.KeyguardSimPinView.1 */
    class C00321 extends KeyguardUpdateMonitorCallback {
        C00321() {
        }

        public void onSimStateChanged(int subId, int slotId, State simState) {
            KeyguardSimPinView.this.resetState();
        }
    }

    private abstract class CheckSimPin extends Thread {
        private final String mPin;
        private int mSubId;

        /* renamed from: com.android.keyguard.KeyguardSimPinView.CheckSimPin.1 */
        class C00361 implements Runnable {
            final /* synthetic */ int[] val$result;

            C00361(int[] iArr) {
                this.val$result = iArr;
            }

            public void run() {
                CheckSimPin.this.onSimCheckResponse(this.val$result[0], this.val$result[1]);
            }
        }

        /* renamed from: com.android.keyguard.KeyguardSimPinView.CheckSimPin.2 */
        class C00372 implements Runnable {
            C00372() {
            }

            public void run() {
                CheckSimPin.this.onSimCheckResponse(2, -1);
            }
        }

        abstract void onSimCheckResponse(int i, int i2);

        protected CheckSimPin(String pin, int subId) {
            this.mPin = pin;
            this.mSubId = subId;
        }

        public void run() {
            try {
                KeyguardSimPinView.this.post(new C00361(Stub.asInterface(ServiceManager.checkService("phone")).supplyPinReportResultForSubscriber(this.mSubId, this.mPin)));
            } catch (RemoteException e) {
                Log.e("KeyguardSimPinView", "RemoteException for supplyPinReportResult:", e);
                KeyguardSimPinView.this.post(new C00372());
            }
        }
    }

    /* renamed from: com.android.keyguard.KeyguardSimPinView.2 */
    class C00342 extends CheckSimPin {

        /* renamed from: com.android.keyguard.KeyguardSimPinView.2.1 */
        class C00331 implements Runnable {
            final /* synthetic */ int val$attemptsRemaining;
            final /* synthetic */ int val$result;

            C00331(int i, int i2) {
                this.val$attemptsRemaining = i;
                this.val$result = i2;
            }

            public void run() {
                KeyguardSimPinView.this.mRemainingAttempts = this.val$attemptsRemaining;
                if (KeyguardSimPinView.this.mSimUnlockProgressDialog != null) {
                    KeyguardSimPinView.this.mSimUnlockProgressDialog.hide();
                }
                KeyguardSimPinView.this.resetPasswordText(true);
                if (this.val$result == 0) {
                    KeyguardUpdateMonitor.getInstance(KeyguardSimPinView.this.getContext()).reportSimUnlocked(KeyguardSimPinView.this.mSubId);
                    KeyguardSimPinView.this.mRemainingAttempts = -1;
                    KeyguardSimPinView.this.mShowDefaultMessage = true;
                    if (KeyguardSimPinView.this.mCallback != null) {
                        KeyguardSimPinView.this.mCallback.dismiss(true);
                    }
                } else {
                    KeyguardSimPinView.this.mShowDefaultMessage = false;
                    if (this.val$result != 1) {
                        KeyguardSimPinView.this.mSecurityMessageDisplay.setMessage(KeyguardSimPinView.this.getContext().getString(C0065R.string.kg_password_pin_failed), true);
                    } else if (this.val$attemptsRemaining <= 2) {
                        KeyguardSimPinView.this.getSimRemainingAttemptsDialog(this.val$attemptsRemaining).show();
                    } else {
                        KeyguardSimPinView.this.mSecurityMessageDisplay.setMessage(KeyguardSimPinView.this.getPinPasswordErrorMessage(this.val$attemptsRemaining, false), true);
                    }
                }
                KeyguardSimPinView.this.mCallback.userActivity();
                KeyguardSimPinView.this.mCheckSimPinThread = null;
            }
        }

        C00342(String x0, int x1) {
            super(x0, x1);
        }

        void onSimCheckResponse(int result, int attemptsRemaining) {
            KeyguardSimPinView.this.post(new C00331(attemptsRemaining, result));
        }
    }

    /* renamed from: com.android.keyguard.KeyguardSimPinView.3 */
    class C00353 extends CheckSimPin {
        C00353(String x0, int x1) {
            super(x0, x1);
        }

        void onSimCheckResponse(int result, int attemptsRemaining) {
            Log.d("KeyguardSimPinView", "onSimCheckResponse  dummy One result" + result + " attemptsRemaining=" + attemptsRemaining);
            if (attemptsRemaining >= 0) {
                KeyguardSimPinView.this.mRemainingAttempts = attemptsRemaining;
                KeyguardSimPinView.this.mSecurityMessageDisplay.setMessage(KeyguardSimPinView.this.getPinPasswordErrorMessage(attemptsRemaining, true), true);
            }
        }
    }

    public KeyguardSimPinView(Context context) {
        this(context, null);
    }

    public KeyguardSimPinView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mSimUnlockProgressDialog = null;
        this.mShowDefaultMessage = true;
        this.mRemainingAttempts = -1;
        this.mUpdateMonitorCallback = new C00321();
    }

    public void resetState() {
        super.resetState();
        if (this.mShowDefaultMessage) {
            showDefaultMessage();
        }
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        resetState();
    }

    protected int getPromtReasonStringRes(int reason) {
        return 0;
    }

    private String getPinPasswordErrorMessage(int attemptsRemaining, boolean isDefault) {
        if (attemptsRemaining == 0) {
            return getContext().getString(C0065R.string.kg_password_wrong_pin_code_pukked);
        }
        if (attemptsRemaining > 0) {
            return getContext().getResources().getQuantityString(isDefault ? C0065R.plurals.kg_password_default_pin_message : C0065R.plurals.kg_password_wrong_pin_code, attemptsRemaining, new Object[]{Integer.valueOf(attemptsRemaining)});
        }
        return getContext().getString(isDefault ? C0065R.string.kg_sim_pin_instructions : C0065R.string.kg_password_pin_failed);
    }

    protected boolean shouldLockout(long deadline) {
        return false;
    }

    protected int getPasswordTextViewId() {
        return C0065R.id.simPinEntry;
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mSecurityMessageDisplay.setTimeout(0);
        if (this.mEcaView instanceof EmergencyCarrierArea) {
            ((EmergencyCarrierArea) this.mEcaView).setCarrierTextVisible(true);
        }
        this.mSimImageView = (ImageView) findViewById(C0065R.id.keyguard_sim);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.mShowDefaultMessage) {
            showDefaultMessage();
        }
        KeyguardUpdateMonitor.getInstance(this.mContext).registerCallback(this.mUpdateMonitorCallback);
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        KeyguardUpdateMonitor.getInstance(this.mContext).removeCallback(this.mUpdateMonitorCallback);
    }

    public void onPause() {
        if (this.mSimUnlockProgressDialog != null) {
            this.mSimUnlockProgressDialog.dismiss();
            this.mSimUnlockProgressDialog = null;
        }
    }

    private Dialog getSimUnlockProgressDialog() {
        if (this.mSimUnlockProgressDialog == null) {
            this.mSimUnlockProgressDialog = new ProgressDialog(this.mContext);
            this.mSimUnlockProgressDialog.setMessage(this.mContext.getString(C0065R.string.kg_sim_unlock_progress_dialog_message));
            this.mSimUnlockProgressDialog.setIndeterminate(true);
            this.mSimUnlockProgressDialog.setCancelable(false);
            this.mSimUnlockProgressDialog.getWindow().setType(2009);
        }
        return this.mSimUnlockProgressDialog;
    }

    private Dialog getSimRemainingAttemptsDialog(int remaining) {
        String msg = getPinPasswordErrorMessage(remaining, false);
        if (this.mRemainingAttemptsDialog == null) {
            Builder builder = new Builder(this.mContext);
            builder.setMessage(msg);
            builder.setCancelable(false);
            builder.setNeutralButton(C0065R.string.ok, null);
            this.mRemainingAttemptsDialog = builder.create();
            this.mRemainingAttemptsDialog.getWindow().setType(2009);
        } else {
            this.mRemainingAttemptsDialog.setMessage(msg);
        }
        return this.mRemainingAttemptsDialog;
    }

    protected void verifyPasswordAndUnlock() {
        if (this.mPasswordEntry.getText().length() < 4) {
            this.mSecurityMessageDisplay.setMessage(C0065R.string.kg_invalid_sim_pin_hint, true);
            resetPasswordText(true);
            this.mCallback.userActivity();
            return;
        }
        getSimUnlockProgressDialog().show();
        if (this.mCheckSimPinThread == null) {
            this.mCheckSimPinThread = new C00342(this.mPasswordEntry.getText(), this.mSubId);
            this.mCheckSimPinThread.start();
        }
    }

    public void startAppearAnimation() {
    }

    public boolean startDisappearAnimation(Runnable finishRunnable) {
        return false;
    }

    private void showDefaultMessage() {
        KeyguardUpdateMonitor monitor = KeyguardUpdateMonitor.getInstance(this.mContext);
        this.mSubId = monitor.getNextSubIdForState(State.PIN_REQUIRED);
        if (!SubscriptionManager.isValidSubscriptionId(this.mSubId)) {
            return;
        }
        if (this.mRemainingAttempts >= 0) {
            this.mSecurityMessageDisplay.setMessage(getPinPasswordErrorMessage(this.mRemainingAttempts, true), true);
            return;
        }
        CharSequence msg;
        int count = TelephonyManager.getDefault().getSimCount();
        Resources rez = getResources();
        int color = -1;
        if (count < 2) {
            msg = rez.getString(C0065R.string.kg_sim_pin_instructions);
        } else {
            SubscriptionInfo info = monitor.getSubscriptionInfoForSubId(this.mSubId);
            CharSequence displayName = info != null ? info.getDisplayName() : "";
            msg = rez.getString(C0065R.string.kg_sim_pin_instructions_multi, new Object[]{displayName});
            if (info != null) {
                color = info.getIconTint();
            }
        }
        this.mSecurityMessageDisplay.setMessage(msg, true);
        this.mSimImageView.setImageTintList(ColorStateList.valueOf(color));
        new C00353("", this.mSubId).start();
    }
}
