package com.android.systemui.statusbar;

import android.content.Context;
import android.content.res.Configuration;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

public class EmptyShadeView extends StackScrollerDecorView {
    public EmptyShadeView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        ((TextView) findViewById(2131755303)).setText(2131362289);
    }

    protected View findContentView() {
        return findViewById(2131755303);
    }
}
