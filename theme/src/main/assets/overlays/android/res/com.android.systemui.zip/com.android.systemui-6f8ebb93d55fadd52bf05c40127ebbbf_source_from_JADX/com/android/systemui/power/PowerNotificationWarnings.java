package com.android.systemui.power;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.AudioAttributes.Builder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.UserHandle;
import android.provider.Settings.Global;
import android.util.Slog;
import com.android.systemui.power.PowerUI.WarningsUI;
import com.android.systemui.statusbar.phone.PhoneStatusBar;
import com.android.systemui.statusbar.phone.SystemUIDialog;
import java.io.PrintWriter;
import java.text.NumberFormat;

public class PowerNotificationWarnings implements WarningsUI {
    private static final AudioAttributes AUDIO_ATTRIBUTES;
    private static final boolean DEBUG;
    private static final String[] SHOWING_STRINGS;
    private int mBatteryLevel;
    private int mBucket;
    private long mBucketDroppedNegativeTimeMs;
    private final Context mContext;
    private final Handler mHandler;
    private boolean mInvalidCharger;
    private final NotificationManager mNoMan;
    private final Intent mOpenBatterySettings;
    private final Intent mOpenSaverSettings;
    private boolean mPlaySound;
    private final PowerManager mPowerMan;
    private final Receiver mReceiver;
    private boolean mSaver;
    private SystemUIDialog mSaverConfirmation;
    private long mScreenOffTime;
    private int mShowing;
    private final OnClickListener mStartSaverMode;
    private boolean mWarning;

    /* renamed from: com.android.systemui.power.PowerNotificationWarnings.1 */
    class C01431 implements OnDismissListener {
        C01431() {
        }

        public void onDismiss(DialogInterface dialog) {
            PowerNotificationWarnings.this.mSaverConfirmation = null;
        }
    }

    /* renamed from: com.android.systemui.power.PowerNotificationWarnings.2 */
    class C01452 implements OnClickListener {

        /* renamed from: com.android.systemui.power.PowerNotificationWarnings.2.1 */
        class C01441 implements Runnable {
            C01441() {
            }

            public void run() {
                PowerNotificationWarnings.this.setSaverMode(true);
            }
        }

        C01452() {
        }

        public void onClick(DialogInterface dialog, int which) {
            AsyncTask.execute(new C01441());
        }
    }

    private final class Receiver extends BroadcastReceiver {
        private Receiver() {
        }

        public void init() {
            IntentFilter filter = new IntentFilter();
            filter.addAction("PNW.batterySettings");
            filter.addAction("PNW.startSaver");
            filter.addAction("PNW.stopSaver");
            filter.addAction("PNW.dismissedWarning");
            PowerNotificationWarnings.this.mContext.registerReceiverAsUser(this, UserHandle.ALL, filter, "android.permission.STATUS_BAR_SERVICE", PowerNotificationWarnings.this.mHandler);
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            Slog.i("PowerUI.Notification", "Received " + action);
            if (action.equals("PNW.batterySettings")) {
                PowerNotificationWarnings.this.dismissLowBatteryNotification();
                PowerNotificationWarnings.this.mContext.startActivityAsUser(PowerNotificationWarnings.this.mOpenBatterySettings, UserHandle.CURRENT);
            } else if (action.equals("PNW.startSaver")) {
                PowerNotificationWarnings.this.dismissLowBatteryNotification();
                PowerNotificationWarnings.this.showStartSaverConfirmation();
            } else if (action.equals("PNW.stopSaver")) {
                PowerNotificationWarnings.this.dismissSaverNotification();
                PowerNotificationWarnings.this.dismissLowBatteryNotification();
                PowerNotificationWarnings.this.setSaverMode(false);
            } else if (action.equals("PNW.dismissedWarning")) {
                PowerNotificationWarnings.this.dismissLowBatteryWarning();
            }
        }
    }

    static {
        DEBUG = PowerUI.DEBUG;
        SHOWING_STRINGS = new String[]{"SHOWING_NOTHING", "SHOWING_WARNING", "SHOWING_SAVER", "SHOWING_INVALID_CHARGER"};
        AUDIO_ATTRIBUTES = new Builder().setContentType(4).setUsage(13).build();
    }

    public PowerNotificationWarnings(Context context, PhoneStatusBar phoneStatusBar) {
        this.mHandler = new Handler();
        this.mReceiver = new Receiver();
        this.mOpenBatterySettings = settings("android.intent.action.POWER_USAGE_SUMMARY");
        this.mOpenSaverSettings = settings("android.settings.BATTERY_SAVER_SETTINGS");
        this.mStartSaverMode = new C01452();
        this.mContext = context;
        this.mNoMan = (NotificationManager) context.getSystemService("notification");
        this.mPowerMan = (PowerManager) context.getSystemService("power");
        this.mReceiver.init();
    }

    public void dump(PrintWriter pw) {
        pw.print("mSaver=");
        pw.println(this.mSaver);
        pw.print("mWarning=");
        pw.println(this.mWarning);
        pw.print("mPlaySound=");
        pw.println(this.mPlaySound);
        pw.print("mInvalidCharger=");
        pw.println(this.mInvalidCharger);
        pw.print("mShowing=");
        pw.println(SHOWING_STRINGS[this.mShowing]);
        pw.print("mSaverConfirmation=");
        pw.println(this.mSaverConfirmation != null ? "not null" : null);
    }

    public void update(int batteryLevel, int bucket, long screenOffTime) {
        this.mBatteryLevel = batteryLevel;
        if (bucket >= 0) {
            this.mBucketDroppedNegativeTimeMs = 0;
        } else if (bucket < this.mBucket) {
            this.mBucketDroppedNegativeTimeMs = System.currentTimeMillis();
        }
        this.mBucket = bucket;
        this.mScreenOffTime = screenOffTime;
    }

    public void showSaverMode(boolean mode) {
        this.mSaver = mode;
        if (this.mSaver && this.mSaverConfirmation != null) {
            this.mSaverConfirmation.dismiss();
        }
        updateNotification();
    }

    private void updateNotification() {
        if (DEBUG) {
            Slog.d("PowerUI.Notification", "updateNotification mWarning=" + this.mWarning + " mPlaySound=" + this.mPlaySound + " mSaver=" + this.mSaver + " mInvalidCharger=" + this.mInvalidCharger);
        }
        if (this.mInvalidCharger) {
            showInvalidChargerNotification();
            this.mShowing = 3;
        } else if (this.mWarning) {
            showWarningNotification();
            this.mShowing = 1;
        } else if (this.mSaver) {
            showSaverNotification();
            this.mShowing = 2;
        } else {
            this.mNoMan.cancelAsUser("low_battery", 2131755032, UserHandle.ALL);
            this.mShowing = 0;
        }
    }

    private void showInvalidChargerNotification() {
        Notification n = new Notification.Builder(this.mContext).setSmallIcon(2130837612).setWhen(0).setShowWhen(false).setOngoing(true).setContentTitle(this.mContext.getString(2131361961)).setContentText(this.mContext.getString(2131361962)).setPriority(2).setVisibility(1).setColor(this.mContext.getColor(17170521)).build();
        if (n.headsUpContentView != null) {
            n.headsUpContentView.setViewVisibility(16908352, 8);
        }
        this.mNoMan.notifyAsUser("low_battery", 2131755032, n, UserHandle.ALL);
    }

    private void showWarningNotification() {
        int textRes = this.mSaver ? 2131361959 : 2131361958;
        String percentage = NumberFormat.getPercentInstance().format(((double) this.mBatteryLevel) / 100.0d);
        Notification.Builder nb = new Notification.Builder(this.mContext).setSmallIcon(2130837612).setWhen(this.mBucketDroppedNegativeTimeMs).setShowWhen(false).setContentTitle(this.mContext.getString(2131361957)).setContentText(this.mContext.getString(textRes, new Object[]{percentage})).setOnlyAlertOnce(true).setDeleteIntent(pendingBroadcast("PNW.dismissedWarning")).setPriority(2).setVisibility(1).setColor(this.mContext.getColor(17170522));
        if (hasBatterySettings()) {
            nb.setContentIntent(pendingBroadcast("PNW.batterySettings"));
        }
        if (this.mSaver) {
            addStopSaverAction(nb);
        } else {
            nb.addAction(0, this.mContext.getString(2131361966), pendingBroadcast("PNW.startSaver"));
        }
        if (this.mPlaySound) {
            attachLowBatterySound(nb);
            this.mPlaySound = false;
        }
        Notification n = nb.build();
        if (n.headsUpContentView != null) {
            n.headsUpContentView.setViewVisibility(16908352, 8);
        }
        this.mNoMan.notifyAsUser("low_battery", 2131755032, n, UserHandle.ALL);
    }

    private void showSaverNotification() {
        Notification.Builder nb = new Notification.Builder(this.mContext).setSmallIcon(2130837613).setContentTitle(this.mContext.getString(2131362281)).setContentText(this.mContext.getString(2131362282)).setOngoing(true).setShowWhen(false).setVisibility(1).setColor(this.mContext.getColor(17170522));
        addStopSaverAction(nb);
        if (hasSaverSettings()) {
            nb.setContentIntent(pendingActivity(this.mOpenSaverSettings));
        }
        this.mNoMan.notifyAsUser("low_battery", 2131755032, nb.build(), UserHandle.ALL);
    }

    private void addStopSaverAction(Notification.Builder nb) {
        nb.addAction(0, this.mContext.getString(2131362283), pendingBroadcast("PNW.stopSaver"));
    }

    private void dismissSaverNotification() {
        if (this.mSaver) {
            Slog.i("PowerUI.Notification", "dismissing saver notification");
        }
        this.mSaver = false;
        updateNotification();
    }

    private PendingIntent pendingActivity(Intent intent) {
        return PendingIntent.getActivityAsUser(this.mContext, 0, intent, 0, null, UserHandle.CURRENT);
    }

    private PendingIntent pendingBroadcast(String action) {
        return PendingIntent.getBroadcastAsUser(this.mContext, 0, new Intent(action), 0, UserHandle.CURRENT);
    }

    private static Intent settings(String action) {
        return new Intent(action).setFlags(1551892480);
    }

    public boolean isInvalidChargerWarningShowing() {
        return this.mInvalidCharger;
    }

    public void updateLowBatteryWarning() {
        updateNotification();
    }

    public void dismissLowBatteryWarning() {
        if (DEBUG) {
            Slog.d("PowerUI.Notification", "dismissing low battery warning: level=" + this.mBatteryLevel);
        }
        dismissLowBatteryNotification();
    }

    private void dismissLowBatteryNotification() {
        if (this.mWarning) {
            Slog.i("PowerUI.Notification", "dismissing low battery notification");
        }
        this.mWarning = false;
        updateNotification();
    }

    private boolean hasBatterySettings() {
        return this.mOpenBatterySettings.resolveActivity(this.mContext.getPackageManager()) != null;
    }

    private boolean hasSaverSettings() {
        return this.mOpenSaverSettings.resolveActivity(this.mContext.getPackageManager()) != null;
    }

    public void showLowBatteryWarning(boolean playSound) {
        Slog.i("PowerUI.Notification", "show low battery warning: level=" + this.mBatteryLevel + " [" + this.mBucket + "] playSound=" + playSound);
        this.mPlaySound = playSound;
        this.mWarning = true;
        updateNotification();
    }

    private void attachLowBatterySound(Notification.Builder b) {
        ContentResolver cr = this.mContext.getContentResolver();
        int silenceAfter = Global.getInt(cr, "low_battery_sound_timeout", 0);
        long offTime = SystemClock.elapsedRealtime() - this.mScreenOffTime;
        if (silenceAfter <= 0 || this.mScreenOffTime <= 0 || offTime <= ((long) silenceAfter)) {
            if (DEBUG) {
                Slog.d("PowerUI.Notification", "playing low battery sound. pick-a-doop!");
            }
            if (Global.getInt(cr, "power_sounds_enabled", 1) == 1) {
                String soundPath = Global.getString(cr, "low_battery_sound");
                if (soundPath != null) {
                    Uri soundUri = Uri.parse("file://" + soundPath);
                    if (soundUri != null) {
                        b.setSound(soundUri, AUDIO_ATTRIBUTES);
                        if (DEBUG) {
                            Slog.d("PowerUI.Notification", "playing sound " + soundUri);
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            }
            return;
        }
        Slog.i("PowerUI.Notification", "screen off too long (" + offTime + "ms, limit " + silenceAfter + "ms): not waking up the user with low battery sound");
    }

    public void dismissInvalidChargerWarning() {
        dismissInvalidChargerNotification();
    }

    private void dismissInvalidChargerNotification() {
        if (this.mInvalidCharger) {
            Slog.i("PowerUI.Notification", "dismissing invalid charger notification");
        }
        this.mInvalidCharger = false;
        updateNotification();
    }

    public void showInvalidChargerWarning() {
        this.mInvalidCharger = true;
        updateNotification();
    }

    public void userSwitched() {
        updateNotification();
    }

    private void showStartSaverConfirmation() {
        if (this.mSaverConfirmation == null) {
            SystemUIDialog d = new SystemUIDialog(this.mContext);
            d.setTitle(2131361964);
            d.setMessage(17040789);
            d.setNegativeButton(17039360, null);
            d.setPositiveButton(2131361965, this.mStartSaverMode);
            d.setShowForAllUsers(true);
            d.setOnDismissListener(new C01431());
            d.show();
            this.mSaverConfirmation = d;
        }
    }

    private void setSaverMode(boolean mode) {
        this.mPowerMan.setPowerSaveMode(mode);
    }
}
