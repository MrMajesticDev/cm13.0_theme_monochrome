package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.ResourceIcon;
import com.android.systemui.qs.SecureSetting;

public class FloatingTile extends QSTile<BooleanState> {
    private final FloatingDetailAdapter mDetailAdapter;
    private final SecureSetting mSetting;

    /* renamed from: com.android.systemui.qs.tiles.FloatingTile.1 */
    class C01911 extends SecureSetting {
        C01911(Context x0, Handler x1, String x2) {
            super(x0, x1, x2);
        }

        protected void handleValueChanged(int value, boolean observedChange) {
            FloatingTile.this.handleRefreshState(Integer.valueOf(value));
        }
    }

    private class FloatingDetailAdapter implements DetailAdapter {
        private ViewGroup mMessageContainer;
        private TextView mMessageText;

        private FloatingDetailAdapter() {
        }

        public int getMetricsCategory() {
            return 264;
        }

        public int getTitle() {
            return 2131361928;
        }

        public Boolean getToggleState() {
            return Boolean.valueOf(((BooleanState) FloatingTile.this.mState).value);
        }

        public void setToggleState(boolean state) {
            MetricsLogger.action(FloatingTile.this.mContext, 263, state);
            if (!state) {
                FloatingTile.this.showDetail(false);
            }
            FloatingTile.this.setEnabled(state);
            FloatingTile.this.fireToggleStateChanged(state);
            FloatingTile.this.refreshState();
        }

        public Intent getSettingsIntent() {
            return null;
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            LinearLayout mDetails = convertView != null ? (LinearLayout) convertView : (LinearLayout) LayoutInflater.from(context).inflate(2130968579, parent, false);
            if (convertView == null) {
                this.mMessageContainer = (ViewGroup) mDetails.findViewById(2131755076);
                this.mMessageText = (TextView) mDetails.findViewById(2131755077);
                this.mMessageText.setText(FloatingTile.this.mContext.getString(2131361929));
                this.mMessageContainer.setVisibility(0);
            }
            setToggleState(true);
            return mDetails;
        }
    }

    public FloatingTile(Host host) {
        super(host, "floating");
        this.mDetailAdapter = new FloatingDetailAdapter();
        this.mSetting = new C01911(this.mContext, this.mHandler, "floating_headsup");
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    protected void handleUserSwitch(int newUserId) {
        this.mSetting.setUserId(newUserId);
        handleRefreshState(Integer.valueOf(this.mSetting.getValue()));
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    protected void handleToggleClick() {
        setEnabled(!((BooleanState) this.mState).value);
        refreshState();
    }

    protected void handleDetailClick() {
        showDetail(true);
    }

    protected void handleLongClick() {
    }

    private void setEnabled(boolean enabled) {
        this.mSetting.setValue(enabled ? 1 : 0);
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        boolean enable = (arg instanceof Integer ? ((Integer) arg).intValue() : this.mSetting.getValue()) != 0;
        state.value = enable;
        state.visible = true;
        state.label = this.mContext.getString(2131361928);
        if (enable) {
            state.icon = ResourceIcon.get(2130837632);
        } else {
            state.icon = ResourceIcon.get(2130837633);
        }
    }

    public int getMetricsCategory() {
        return 262;
    }

    public void setListening(boolean listening) {
    }
}
