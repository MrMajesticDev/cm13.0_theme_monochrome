package com.android.systemui.statusbar.phone;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import com.android.systemui.doze.DozeHost.PulseCallback;
import com.android.systemui.doze.DozeLog;

public class DozeScrimController {
    private static final boolean DEBUG;
    private Animator mBehindAnimator;
    private float mBehindTarget;
    private final Interpolator mDozeAnimationInterpolator;
    private final DozeParameters mDozeParameters;
    private boolean mDozing;
    private final Handler mHandler;
    private Animator mInFrontAnimator;
    private float mInFrontTarget;
    private PulseCallback mPulseCallback;
    private final Runnable mPulseIn;
    private final Runnable mPulseInFinished;
    private final Interpolator mPulseInInterpolator;
    private final Interpolator mPulseInInterpolatorPickup;
    private final Runnable mPulseOut;
    private final Runnable mPulseOutFinished;
    private final Interpolator mPulseOutInterpolator;
    private int mPulseReason;
    private final ScrimController mScrimController;

    /* renamed from: com.android.systemui.statusbar.phone.DozeScrimController.1 */
    class C03471 implements AnimatorUpdateListener {
        final /* synthetic */ boolean val$inFront;

        C03471(boolean z) {
            this.val$inFront = z;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            DozeScrimController.this.setDozeAlpha(this.val$inFront, ((Float) animation.getAnimatedValue()).floatValue());
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.DozeScrimController.2 */
    class C03482 extends AnimatorListenerAdapter {
        final /* synthetic */ Runnable val$endRunnable;
        final /* synthetic */ boolean val$inFront;

        C03482(boolean z, Runnable runnable) {
            this.val$inFront = z;
            this.val$endRunnable = runnable;
        }

        public void onAnimationEnd(Animator animation) {
            DozeScrimController.this.setCurrentAnimator(this.val$inFront, null);
            if (this.val$endRunnable != null) {
                this.val$endRunnable.run();
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.DozeScrimController.3 */
    class C03493 implements Runnable {
        C03493() {
        }

        public void run() {
            if (DozeScrimController.DEBUG) {
                Log.d("DozeScrimController", "Pulse in, mDozing=" + DozeScrimController.this.mDozing + " mPulseReason=" + DozeLog.pulseReasonToString(DozeScrimController.this.mPulseReason));
            }
            if (DozeScrimController.this.mDozing) {
                DozeLog.tracePulseStart(DozeScrimController.this.mPulseReason);
                DozeScrimController.this.pulseStarted();
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.DozeScrimController.4 */
    class C03504 implements Runnable {
        C03504() {
        }

        public void run() {
            if (DozeScrimController.DEBUG) {
                Log.d("DozeScrimController", "Pulse in finished, mDozing=" + DozeScrimController.this.mDozing);
            }
            if (DozeScrimController.this.mDozing) {
                DozeScrimController.this.mHandler.postDelayed(DozeScrimController.this.mPulseOut, (long) DozeScrimController.this.mDozeParameters.getPulseVisibleDuration());
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.DozeScrimController.5 */
    class C03515 implements Runnable {
        C03515() {
        }

        public void run() {
            if (DozeScrimController.DEBUG) {
                Log.d("DozeScrimController", "Pulse out, mDozing=" + DozeScrimController.this.mDozing);
            }
            if (DozeScrimController.this.mDozing) {
                DozeScrimController.this.startScrimAnimation(true, 1.0f, (long) DozeScrimController.this.mDozeParameters.getPulseOutDuration(), DozeScrimController.this.mPulseOutInterpolator, DozeScrimController.this.mPulseOutFinished);
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.DozeScrimController.6 */
    class C03526 implements Runnable {
        C03526() {
        }

        public void run() {
            if (DozeScrimController.DEBUG) {
                Log.d("DozeScrimController", "Pulse out finished");
            }
            DozeLog.tracePulseFinish();
            DozeScrimController.this.pulseFinished();
        }
    }

    static {
        DEBUG = Log.isLoggable("DozeScrimController", 3);
    }

    public DozeScrimController(ScrimController scrimController, Context context) {
        this.mPulseInInterpolator = PhoneStatusBar.ALPHA_OUT;
        this.mPulseOutInterpolator = PhoneStatusBar.ALPHA_IN;
        this.mHandler = new Handler();
        this.mPulseIn = new C03493();
        this.mPulseInFinished = new C03504();
        this.mPulseOut = new C03515();
        this.mPulseOutFinished = new C03526();
        this.mScrimController = scrimController;
        this.mDozeParameters = new DozeParameters(context);
        Interpolator loadInterpolator = AnimationUtils.loadInterpolator(context, 17563662);
        this.mPulseInInterpolatorPickup = loadInterpolator;
        this.mDozeAnimationInterpolator = loadInterpolator;
    }

    public void setDozing(boolean dozing, boolean animate) {
        if (this.mDozing != dozing) {
            this.mDozing = dozing;
            if (this.mDozing) {
                abortAnimations();
                this.mScrimController.setDozeBehindAlpha(1.0f);
                this.mScrimController.setDozeInFrontAlpha(1.0f);
                return;
            }
            cancelPulsing();
            if (animate) {
                startScrimAnimation(false, 0.0f, 700, this.mDozeAnimationInterpolator);
                startScrimAnimation(true, 0.0f, 700, this.mDozeAnimationInterpolator);
                return;
            }
            abortAnimations();
            this.mScrimController.setDozeBehindAlpha(0.0f);
            this.mScrimController.setDozeInFrontAlpha(0.0f);
        }
    }

    public void pulse(PulseCallback callback, int reason) {
        if (callback == null) {
            throw new IllegalArgumentException("callback must not be null");
        } else if (this.mDozing && this.mPulseCallback == null) {
            this.mPulseCallback = callback;
            this.mPulseReason = reason;
            this.mHandler.post(this.mPulseIn);
        } else {
            callback.onPulseFinished();
        }
    }

    public void abortPulsing() {
        cancelPulsing();
        if (this.mDozing) {
            this.mScrimController.setDozeBehindAlpha(1.0f);
            this.mScrimController.setDozeInFrontAlpha(1.0f);
        }
    }

    public void onScreenTurnedOn() {
        if (isPulsing()) {
            boolean pickup = this.mPulseReason == 3;
            startScrimAnimation(true, 0.0f, (long) this.mDozeParameters.getPulseInDuration(pickup), pickup ? this.mPulseInInterpolatorPickup : this.mPulseInInterpolator, this.mPulseInFinished);
        }
    }

    public boolean isPulsing() {
        return this.mPulseCallback != null;
    }

    private void cancelPulsing() {
        if (DEBUG) {
            Log.d("DozeScrimController", "Cancel pulsing");
        }
        if (this.mPulseCallback != null) {
            this.mHandler.removeCallbacks(this.mPulseIn);
            this.mHandler.removeCallbacks(this.mPulseOut);
            pulseFinished();
        }
    }

    private void pulseStarted() {
        if (this.mPulseCallback != null) {
            this.mPulseCallback.onPulseStarted();
        }
    }

    private void pulseFinished() {
        if (this.mPulseCallback != null) {
            this.mPulseCallback.onPulseFinished();
            this.mPulseCallback = null;
        }
    }

    private void abortAnimations() {
        if (this.mInFrontAnimator != null) {
            this.mInFrontAnimator.cancel();
        }
        if (this.mBehindAnimator != null) {
            this.mBehindAnimator.cancel();
        }
    }

    private void startScrimAnimation(boolean inFront, float target, long duration, Interpolator interpolator) {
        startScrimAnimation(inFront, target, duration, interpolator, null);
    }

    private void startScrimAnimation(boolean inFront, float target, long duration, Interpolator interpolator, Runnable endRunnable) {
        Animator current = getCurrentAnimator(inFront);
        if (current != null) {
            if (getCurrentTarget(inFront) != target) {
                current.cancel();
            } else {
                return;
            }
        }
        ValueAnimator anim = ValueAnimator.ofFloat(new float[]{getDozeAlpha(inFront), target});
        anim.addUpdateListener(new C03471(inFront));
        anim.setInterpolator(interpolator);
        anim.setDuration(duration);
        anim.addListener(new C03482(inFront, endRunnable));
        anim.start();
        setCurrentAnimator(inFront, anim);
        setCurrentTarget(inFront, target);
    }

    private float getCurrentTarget(boolean inFront) {
        return inFront ? this.mInFrontTarget : this.mBehindTarget;
    }

    private void setCurrentTarget(boolean inFront, float target) {
        if (inFront) {
            this.mInFrontTarget = target;
        } else {
            this.mBehindTarget = target;
        }
    }

    private Animator getCurrentAnimator(boolean inFront) {
        return inFront ? this.mInFrontAnimator : this.mBehindAnimator;
    }

    private void setCurrentAnimator(boolean inFront, Animator animator) {
        if (inFront) {
            this.mInFrontAnimator = animator;
        } else {
            this.mBehindAnimator = animator;
        }
    }

    private void setDozeAlpha(boolean inFront, float alpha) {
        if (inFront) {
            this.mScrimController.setDozeInFrontAlpha(alpha);
        } else {
            this.mScrimController.setDozeBehindAlpha(alpha);
        }
    }

    private float getDozeAlpha(boolean inFront) {
        return inFront ? this.mScrimController.getDozeInFrontAlpha() : this.mScrimController.getDozeBehindAlpha();
    }
}
