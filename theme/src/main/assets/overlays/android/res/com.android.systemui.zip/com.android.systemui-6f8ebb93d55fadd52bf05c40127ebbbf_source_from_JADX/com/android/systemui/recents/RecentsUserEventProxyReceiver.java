package com.android.systemui.recents;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.keyguard.C0065R;

public class RecentsUserEventProxyReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        Recents recents = Recents.getInstanceAndStartIfNeeded(context);
        String action = intent.getAction();
        boolean z = true;
        switch (action.hashCode()) {
            case -1960634864:
                if (action.equals("com.android.systemui.recents.action.TOGGLE_RECENTS_FOR_USER")) {
                    z = true;
                    break;
                }
                break;
            case -340040703:
                if (action.equals("com.android.systemui.recents.action.PRELOAD_RECENTS_FOR_USER")) {
                    z = true;
                    break;
                }
                break;
            case -154002142:
                if (action.equals("com.android.systemui.recents.action.HIDE_RECENTS_FOR_USER")) {
                    z = true;
                    break;
                }
                break;
            case 1112992967:
                if (action.equals("com.android.systemui.recents.action.SHOW_RECENTS_FOR_USER")) {
                    z = false;
                    break;
                }
                break;
            case 1675603494:
                if (action.equals("com.android.systemui.recents.action.CONFIG_CHANGED_FOR_USER")) {
                    z = true;
                    break;
                }
                break;
        }
        switch (z) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                recents.showRecentsInternal(intent.getBooleanExtra("triggeredFromAltTab", false));
            case C0065R.styleable.NumPadKey_textView /*1*/:
                recents.hideRecentsInternal(intent.getBooleanExtra("triggeredFromAltTab", false), intent.getBooleanExtra("triggeredFromHomeKey", false));
            case true:
                recents.toggleRecentsInternal();
            case true:
                recents.preloadRecentsInternal();
            case true:
                recents.configurationChanged();
            default:
        }
    }
}
