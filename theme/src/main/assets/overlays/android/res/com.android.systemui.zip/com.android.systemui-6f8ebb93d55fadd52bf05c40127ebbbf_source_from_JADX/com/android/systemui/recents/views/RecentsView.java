package com.android.systemui.recents.views;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.ActivityOptions.OnAnimationStartedListener;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IRemoteCallback.Stub;
import android.os.RemoteException;
import android.os.UserHandle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.WindowInsets;
import android.view.WindowManagerGlobal;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.recents.RecentsAppWidgetHostView;
import com.android.systemui.recents.RecentsConfiguration;
import com.android.systemui.recents.misc.SystemServicesProxy;
import com.android.systemui.recents.model.RecentsPackageMonitor;
import com.android.systemui.recents.model.RecentsPackageMonitor.PackageCallbacks;
import com.android.systemui.recents.model.RecentsTaskLoader;
import com.android.systemui.recents.model.Task;
import com.android.systemui.recents.model.TaskStack;
import com.android.systemui.recents.views.ViewAnimation.TaskViewEnterContext;
import com.android.systemui.recents.views.ViewAnimation.TaskViewExitContext;
import java.util.ArrayList;
import java.util.List;

public class RecentsView extends FrameLayout implements PackageCallbacks, TaskStackViewCallbacks {
    RecentsViewCallbacks mCb;
    RecentsConfiguration mConfig;
    DebugOverlayView mDebugOverlay;
    LayoutInflater mInflater;
    RecentsViewLayoutAlgorithm mLayoutAlgorithm;
    RecentsAppWidgetHostView mSearchBar;
    ArrayList<TaskStack> mStacks;
    List<TaskStackView> mTaskStackViews;

    public interface RecentsViewCallbacks {
        void onAllTaskViewsDismissed();

        void onExitToHomeAnimationTriggered();

        void onScreenPinningRequest();

        void onTaskLaunchFailed();

        void onTaskResize(Task task);

        void onTaskViewClicked();

        void runAfterPause(Runnable runnable);
    }

    /* renamed from: com.android.systemui.recents.views.RecentsView.1 */
    class C02201 implements Runnable {
        final /* synthetic */ OnAnimationStartedListener val$animStartedListener;
        final /* synthetic */ int val$offsetX;
        final /* synthetic */ int val$offsetY;
        final /* synthetic */ TaskViewTransform val$transform;
        final /* synthetic */ TaskView val$tv;

        /* renamed from: com.android.systemui.recents.views.RecentsView.1.1 */
        class C02191 extends Stub {

            /* renamed from: com.android.systemui.recents.views.RecentsView.1.1.1 */
            class C02181 implements Runnable {
                C02181() {
                }

                public void run() {
                    if (C02201.this.val$animStartedListener != null) {
                        C02201.this.val$animStartedListener.onAnimationStarted();
                    }
                }
            }

            C02191() {
            }

            public void sendResult(Bundle data) throws RemoteException {
                RecentsView.this.post(new C02181());
            }
        }

        C02201(TaskView taskView, int i, int i2, TaskViewTransform taskViewTransform, OnAnimationStartedListener onAnimationStartedListener) {
            this.val$tv = taskView;
            this.val$offsetX = i;
            this.val$offsetY = i2;
            this.val$transform = taskViewTransform;
            this.val$animStartedListener = onAnimationStartedListener;
        }

        public void run() {
            if (this.val$tv.isFocusedTask()) {
                this.val$tv.unsetFocusedTask();
            }
            float scale = this.val$tv.getScaleX();
            Bitmap b = Bitmap.createBitmap((int) (((float) this.val$tv.mHeaderView.getMeasuredWidth()) * scale), (int) (((float) this.val$tv.mHeaderView.getMeasuredHeight()) * scale), Config.ARGB_8888);
            Canvas c = new Canvas(b);
            c.scale(this.val$tv.getScaleX(), this.val$tv.getScaleY());
            this.val$tv.mHeaderView.draw(c);
            c.setBitmap(null);
            b = b.createAshmemBitmap();
            int[] pts = new int[2];
            this.val$tv.getLocationOnScreen(pts);
            try {
                WindowManagerGlobal.getWindowManagerService().overridePendingAppTransitionAspectScaledThumb(b, pts[0] + this.val$offsetX, pts[1] + this.val$offsetY, this.val$transform.rect.width(), this.val$transform.rect.height(), new C02191(), true);
            } catch (RemoteException e) {
                Log.w("RecentsView", "Error overriding app transition", e);
            }
        }
    }

    /* renamed from: com.android.systemui.recents.views.RecentsView.2 */
    class C02212 implements Runnable {
        final /* synthetic */ SystemServicesProxy val$ssp;

        C02212(SystemServicesProxy systemServicesProxy) {
            this.val$ssp = systemServicesProxy;
        }

        public void run() {
            this.val$ssp.cancelThumbnailTransition(((Activity) RecentsView.this.getContext()).getTaskId());
            this.val$ssp.cancelWindowTransition(RecentsView.this.mConfig.launchedToTaskId);
        }
    }

    /* renamed from: com.android.systemui.recents.views.RecentsView.3 */
    class C02233 implements OnAnimationStartedListener {
        boolean mTriggered;
        final /* synthetic */ long val$enterDuration;
        final /* synthetic */ Task val$task;

        /* renamed from: com.android.systemui.recents.views.RecentsView.3.1 */
        class C02221 implements Runnable {
            C02221() {
            }

            public void run() {
                RecentsView.this.mCb.onScreenPinningRequest();
            }
        }

        C02233(Task task, long j) {
            this.val$task = task;
            this.val$enterDuration = j;
            this.mTriggered = false;
        }

        public void onAnimationStarted() {
            RecentsView.this.cancelLaunchedTaskWindowTransitionWithDelay(this.val$task, this.val$enterDuration / 2);
            if (!this.mTriggered) {
                RecentsView.this.postDelayed(new C02221(), 350);
                this.mTriggered = true;
            }
        }
    }

    /* renamed from: com.android.systemui.recents.views.RecentsView.4 */
    class C02244 implements Runnable {
        final /* synthetic */ ActivityOptions val$launchOpts;
        final /* synthetic */ boolean val$lockToTask;
        final /* synthetic */ SystemServicesProxy val$ssp;
        final /* synthetic */ Task val$task;

        C02244(Task task, SystemServicesProxy systemServicesProxy, ActivityOptions activityOptions, boolean z) {
            this.val$task = task;
            this.val$ssp = systemServicesProxy;
            this.val$launchOpts = activityOptions;
            this.val$lockToTask = z;
        }

        public void run() {
            if (this.val$task.isActive) {
                this.val$ssp.moveTaskToFront(this.val$task.key.id, this.val$launchOpts);
            } else if (!this.val$ssp.startActivityFromRecents(RecentsView.this.getContext(), this.val$task.key.id, this.val$task.activityLabel, this.val$launchOpts)) {
                RecentsView.this.onTaskViewDismissed(this.val$task);
                if (RecentsView.this.mCb != null) {
                    RecentsView.this.mCb.onTaskLaunchFailed();
                }
                MetricsLogger.count(RecentsView.this.getContext(), "overview_task_launch_failed", 1);
            } else if (this.val$launchOpts == null && this.val$lockToTask) {
                RecentsView.this.mCb.onScreenPinningRequest();
            }
        }
    }

    /* renamed from: com.android.systemui.recents.views.RecentsView.5 */
    class C02255 implements Runnable {
        final /* synthetic */ Task val$t;

        C02255(Task task) {
            this.val$t = task;
        }

        public void run() {
            Intent baseIntent = this.val$t.key.baseIntent;
            baseIntent.setFlags(268447744);
            RecentsView.this.mContext.startActivity(baseIntent);
        }
    }

    public RecentsView(Context context) {
        super(context);
        this.mTaskStackViews = new ArrayList();
    }

    public RecentsView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RecentsView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public RecentsView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        this.mTaskStackViews = new ArrayList();
        this.mConfig = RecentsConfiguration.getInstance();
        this.mInflater = LayoutInflater.from(context);
        this.mLayoutAlgorithm = new RecentsViewLayoutAlgorithm(this.mConfig);
    }

    public void setCallbacks(RecentsViewCallbacks cb) {
        this.mCb = cb;
    }

    public void setTaskStacks(ArrayList<TaskStack> stacks) {
        int i;
        int numStacks = stacks.size();
        int numTaskStacksToKeep = 0;
        if (this.mConfig.launchedReuseTaskStackViews) {
            numTaskStacksToKeep = Math.min(this.mTaskStackViews.size(), numStacks);
        }
        for (i = this.mTaskStackViews.size() - 1; i >= numTaskStacksToKeep; i--) {
            removeView((View) this.mTaskStackViews.remove(i));
        }
        for (i = 0; i < numTaskStacksToKeep; i++) {
            TaskStackView tsv = (TaskStackView) this.mTaskStackViews.get(i);
            tsv.reset();
            tsv.setStack((TaskStack) stacks.get(i));
        }
        this.mStacks = stacks;
        for (i = this.mTaskStackViews.size(); i < numStacks; i++) {
            TaskStackView stackView = new TaskStackView(getContext(), (TaskStack) stacks.get(i));
            stackView.setCallbacks(this);
            addView(stackView);
            this.mTaskStackViews.add(stackView);
        }
        if (this.mConfig.debugModeEnabled) {
            for (i = this.mTaskStackViews.size() - 1; i >= 0; i--) {
                ((TaskStackView) this.mTaskStackViews.get(i)).setDebugOverlay(this.mDebugOverlay);
            }
        }
        requestLayout();
    }

    List<TaskStackView> getTaskStackViews() {
        return this.mTaskStackViews;
    }

    public Task getNextTaskOrTopTask(Task taskToSearch) {
        Task returnTask = null;
        boolean found = false;
        List<TaskStackView> stackViews = getTaskStackViews();
        for (int i = stackViews.size() - 1; i >= 0; i--) {
            ArrayList<Task> taskList = ((TaskStackView) stackViews.get(i)).getStack().getTasks();
            for (int j = taskList.size() - 1; j >= 0; j--) {
                Task task = (Task) taskList.get(j);
                if (found) {
                    return task;
                }
                if (returnTask == null) {
                    returnTask = task;
                }
                if (task == taskToSearch) {
                    found = true;
                }
            }
        }
        return returnTask;
    }

    public boolean launchFocusedTask() {
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            TaskStackView stackView = (TaskStackView) stackViews.get(i);
            TaskStack stack = stackView.getStack();
            List<TaskView> taskViews = stackView.getTaskViews();
            int taskViewCount = taskViews.size();
            for (int j = 0; j < taskViewCount; j++) {
                TaskView tv = (TaskView) taskViews.get(j);
                Task task = tv.getTask();
                if (tv.isFocusedTask()) {
                    onTaskViewClicked(stackView, tv, stack, task, false);
                    tv.unsetFocusedTask();
                    return true;
                }
            }
        }
        return false;
    }

    public boolean launchTask(Task task) {
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            TaskStackView stackView = (TaskStackView) stackViews.get(i);
            TaskStack stack = stackView.getStack();
            List<TaskView> taskViews = stackView.getTaskViews();
            int taskViewCount = taskViews.size();
            for (int j = 0; j < taskViewCount; j++) {
                TaskView tv = (TaskView) taskViews.get(j);
                if (tv.getTask() == task) {
                    onTaskViewClicked(stackView, tv, stack, task, false);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean launchPreviousTask() {
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            TaskStackView stackView = (TaskStackView) stackViews.get(i);
            TaskStack stack = stackView.getStack();
            ArrayList<Task> tasks = stack.getTasks();
            if (!tasks.isEmpty()) {
                int taskCount = tasks.size();
                for (int j = 0; j < taskCount; j++) {
                    if (((Task) tasks.get(j)).isLaunchTarget) {
                        Task task = (Task) tasks.get(j);
                        onTaskViewClicked(stackView, stackView.getChildViewForTask(task), stack, task, false);
                        return true;
                    }
                }
                continue;
            }
        }
        return false;
    }

    public void startEnterRecentsAnimation(TaskViewEnterContext ctx) {
        ctx.postAnimationTrigger.increment();
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            ((TaskStackView) stackViews.get(i)).startEnterRecentsAnimation(ctx);
        }
        ctx.postAnimationTrigger.decrement();
    }

    public void startExitToHomeAnimation(TaskViewExitContext ctx) {
        ctx.postAnimationTrigger.increment();
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            ((TaskStackView) stackViews.get(i)).startExitToHomeAnimation(ctx);
        }
        ctx.postAnimationTrigger.decrement();
        this.mCb.onExitToHomeAnimationTriggered();
    }

    public void setSearchBar(RecentsAppWidgetHostView searchBar) {
        if (this.mSearchBar != null && indexOfChild(this.mSearchBar) > -1) {
            removeView(this.mSearchBar);
        }
        if (searchBar != null) {
            this.mSearchBar = searchBar;
            addView(this.mSearchBar);
        }
    }

    public boolean hasValidSearchBar() {
        return (this.mSearchBar == null || this.mSearchBar.isReinflateRequired()) ? false : true;
    }

    public void setSearchBarVisibility(int visibility) {
        if (this.mSearchBar != null) {
            this.mSearchBar.setVisibility(visibility);
            this.mSearchBar.bringToFront();
        }
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        Rect searchBarSpaceBounds = new Rect();
        if (this.mSearchBar != null) {
            this.mConfig.getSearchBarBounds(width, height, this.mConfig.systemInsets.top, searchBarSpaceBounds);
            this.mSearchBar.measure(MeasureSpec.makeMeasureSpec(searchBarSpaceBounds.width(), 1073741824), MeasureSpec.makeMeasureSpec(searchBarSpaceBounds.height(), 1073741824));
        }
        Rect taskStackBounds = new Rect();
        this.mConfig.getAvailableTaskStackBounds(width, height, this.mConfig.systemInsets.top, this.mConfig.systemInsets.right, searchBarSpaceBounds, taskStackBounds);
        List<TaskStackView> stackViews = getTaskStackViews();
        List<Rect> stackViewsBounds = this.mLayoutAlgorithm.computeStackRects(stackViews, taskStackBounds);
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            TaskStackView stackView = (TaskStackView) stackViews.get(i);
            if (stackView.getVisibility() != 8) {
                stackView.setStackInsetRect((Rect) stackViewsBounds.get(i));
                stackView.measure(widthMeasureSpec, heightMeasureSpec);
            }
        }
        setMeasuredDimension(width, height);
    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        if (this.mSearchBar != null) {
            Rect searchBarSpaceBounds = new Rect();
            this.mConfig.getSearchBarBounds(getMeasuredWidth(), getMeasuredHeight(), this.mConfig.systemInsets.top, searchBarSpaceBounds);
            this.mSearchBar.layout(searchBarSpaceBounds.left, searchBarSpaceBounds.top, searchBarSpaceBounds.right, searchBarSpaceBounds.bottom);
        }
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            TaskStackView stackView = (TaskStackView) stackViews.get(i);
            if (stackView.getVisibility() != 8) {
                stackView.layout(left, top, stackView.getMeasuredWidth() + left, stackView.getMeasuredHeight() + top);
            }
        }
    }

    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        this.mConfig.updateSystemInsets(insets.getSystemWindowInsets());
        requestLayout();
        return insets.consumeSystemWindowInsets();
    }

    public void onUserInteraction() {
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            ((TaskStackView) stackViews.get(i)).onUserInteraction();
        }
    }

    public void focusNextTask(boolean forward) {
        List<TaskStackView> stackViews = getTaskStackViews();
        if (!stackViews.isEmpty()) {
            ((TaskStackView) stackViews.get(0)).focusNextTask(forward);
        }
    }

    public void refocusCurrentTask(boolean scrollToNewPosition) {
        List<TaskStackView> stackViews = getTaskStackViews();
        if (!stackViews.isEmpty()) {
            TaskStackView stackView = (TaskStackView) stackViews.get(0);
            stackView.focusTask(stackView.mFocusedTaskIndex, scrollToNewPosition);
        }
    }

    public void dismissFocusedTask() {
        List<TaskStackView> stackViews = getTaskStackViews();
        if (!stackViews.isEmpty()) {
            ((TaskStackView) stackViews.get(0)).dismissFocusedTask();
        }
    }

    public boolean ensureFocusedTask(boolean findClosestToCenter) {
        List<TaskStackView> stackViews = getTaskStackViews();
        if (stackViews.isEmpty()) {
            return false;
        }
        return ((TaskStackView) stackViews.get(0)).ensureFocusedTask(findClosestToCenter);
    }

    public boolean unfilterFilteredStacks() {
        if (this.mStacks == null) {
            return false;
        }
        boolean stacksUnfiltered = false;
        int numStacks = this.mStacks.size();
        for (int i = 0; i < numStacks; i++) {
            TaskStack stack = (TaskStack) this.mStacks.get(i);
            if (stack.hasFilteredTasks()) {
                stack.unfilterTasks();
                stacksUnfiltered = true;
            }
        }
        return stacksUnfiltered;
    }

    public void disableLayersForOneFrame() {
        List<TaskStackView> stackViews = getTaskStackViews();
        for (int i = 0; i < stackViews.size(); i++) {
            ((TaskStackView) stackViews.get(i)).disableLayersForOneFrame();
        }
    }

    private void postDrawHeaderThumbnailTransitionRunnable(TaskView tv, int offsetX, int offsetY, TaskViewTransform transform, OnAnimationStartedListener animStartedListener) {
        this.mCb.runAfterPause(new C02201(tv, offsetX, offsetY, transform, animStartedListener));
    }

    private void cancelLaunchedTaskWindowTransitionWithDelay(Task task, long delay) {
        SystemServicesProxy ssp = RecentsTaskLoader.getInstance().getSystemServicesProxy();
        if (this.mConfig.launchedToTaskId != -1 && this.mConfig.launchedToTaskId != task.key.id) {
            new Handler().postDelayed(new C02212(ssp), delay);
        }
    }

    public void resetHasBeenTouched() {
        List<TaskStackView> stackViews = getTaskStackViews();
        if (!stackViews.isEmpty()) {
            ((TaskStackView) stackViews.get(0)).resetHasBeenTouched();
        }
    }

    public boolean hasBeenTouched() {
        List<TaskStackView> stackViews = getTaskStackViews();
        if (stackViews.isEmpty()) {
            return false;
        }
        return ((TaskStackView) stackViews.get(0)).hasBeenTouched();
    }

    public void onTaskViewClicked(TaskStackView stackView, TaskView tv, TaskStack stack, Task task, boolean lockToTask) {
        View sourceView;
        if (this.mCb != null) {
            this.mCb.onTaskViewClicked();
        }
        TaskViewTransform transform = new TaskViewTransform();
        int offsetX = 0;
        int offsetY = 0;
        float stackScroll = stackView.getScroller().getStackScroll();
        if (tv == null) {
            sourceView = stackView;
            transform = stackView.getStackAlgorithm().getStackTransform(task, stackScroll, transform, null);
            offsetX = transform.rect.left;
            offsetY = this.mConfig.displayRect.height();
        } else {
            sourceView = tv.mThumbnailView;
            transform = stackView.getStackAlgorithm().getStackTransform(task, stackScroll, transform, null);
        }
        SystemServicesProxy ssp = RecentsTaskLoader.getInstance().getSystemServicesProxy();
        long enterDuration = AnimationUtils.loadAnimation(getContext(), 2131034263).getDuration();
        ActivityOptions opts = null;
        if (task.thumbnail != null && task.thumbnail.getWidth() > 0 && task.thumbnail.getHeight() > 0) {
            OnAnimationStartedListener animStartedListener = null;
            if (lockToTask) {
                animStartedListener = new C02233(task, enterDuration);
            } else {
                cancelLaunchedTaskWindowTransitionWithDelay(task, enterDuration / 2);
            }
            if (tv != null) {
                postDrawHeaderThumbnailTransitionRunnable(tv, offsetX, offsetY, transform, animStartedListener);
            }
            if (this.mConfig.multiStackEnabled) {
                opts = ActivityOptions.makeCustomAnimation(sourceView.getContext(), 2131034263, 2131034264, sourceView.getHandler(), animStartedListener);
            } else {
                opts = ActivityOptions.makeThumbnailAspectScaleUpAnimation(sourceView, Bitmap.createBitmap(1, 1, Config.ALPHA_8).createAshmemBitmap(), offsetX, offsetY, transform.rect.width(), transform.rect.height(), sourceView.getHandler(), animStartedListener);
            }
        }
        Runnable launchRunnable = new C02244(task, ssp, opts, lockToTask);
        int taskIndexFromFront = 0;
        int taskIndex = stack.indexOfTask(task);
        if (taskIndex > -1) {
            taskIndexFromFront = (stack.getTaskCount() - taskIndex) - 1;
        }
        MetricsLogger.histogram(getContext(), "overview_task_launch_index", taskIndexFromFront);
        if (tv == null) {
            launchRunnable.run();
        } else if (task.group == null || task.group.isFrontMostTask(task)) {
            stackView.startLaunchTaskAnimation(tv, null, lockToTask);
            launchRunnable.run();
        } else {
            stackView.startLaunchTaskAnimation(tv, launchRunnable, lockToTask);
        }
    }

    public void onTaskViewAppInfoClicked(Task t) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", t.key.baseIntent.getComponent().getPackageName(), null));
        intent.setComponent(intent.resolveActivity(getContext().getPackageManager()));
        TaskStackBuilder.create(getContext()).addNextIntentWithParentStack(intent).startActivities(null, new UserHandle(t.key.userId));
    }

    public void onTaskFloatClicked(Task t) {
        onRecentsHidden();
        this.mCb.onTaskLaunchFailed();
        post(new C02255(t));
    }

    public void onTaskViewDismissed(Task t) {
        RecentsTaskLoader loader = RecentsTaskLoader.getInstance();
        loader.deleteTaskData(t, false);
        loader.getSystemServicesProxy().removeTask(t.key.id);
    }

    public void onAllTaskViewsDismissed(ArrayList<Task> removedTasks) {
        if (removedTasks != null) {
            int taskCount = removedTasks.size();
            for (int i = 0; i < taskCount; i++) {
                onTaskViewDismissed((Task) removedTasks.get(i));
            }
        }
        this.mCb.onAllTaskViewsDismissed();
        MetricsLogger.count(getContext(), "overview_task_all_dismissed", 1);
    }

    public void onRecentsHidden() {
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            ((TaskStackView) stackViews.get(i)).onRecentsHidden();
        }
    }

    public void onTaskResize(Task t) {
        if (this.mCb != null) {
            this.mCb.onTaskResize(t);
        }
    }

    public void onPackagesChanged(RecentsPackageMonitor monitor, String packageName, int userId) {
        List<TaskStackView> stackViews = getTaskStackViews();
        int stackCount = stackViews.size();
        for (int i = 0; i < stackCount; i++) {
            ((TaskStackView) stackViews.get(i)).onPackagesChanged(monitor, packageName, userId);
        }
    }
}
