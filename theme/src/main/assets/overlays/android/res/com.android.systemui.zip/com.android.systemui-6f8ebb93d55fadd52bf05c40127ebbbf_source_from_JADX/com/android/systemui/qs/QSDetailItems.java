package com.android.systemui.qs;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.systemui.FontSizeUtils;

public class QSDetailItems extends FrameLayout {
    private static final boolean DEBUG;
    private Callback mCallback;
    private final Context mContext;
    private View mEmpty;
    private ImageView mEmptyIcon;
    private TextView mEmptyText;
    private final C0152H mHandler;
    private LinearLayout mItems;
    private boolean mItemsVisible;
    private int mMaxItems;
    private View mMinHeightSpacer;
    private String mTag;

    /* renamed from: com.android.systemui.qs.QSDetailItems.1 */
    class C01501 implements OnClickListener {
        final /* synthetic */ Item val$item;

        C01501(Item item) {
            this.val$item = item;
        }

        public void onClick(View v) {
            if (QSDetailItems.this.mCallback != null) {
                QSDetailItems.this.mCallback.onDetailItemClick(this.val$item);
            }
        }
    }

    /* renamed from: com.android.systemui.qs.QSDetailItems.2 */
    class C01512 implements OnClickListener {
        final /* synthetic */ Item val$item;

        C01512(Item item) {
            this.val$item = item;
        }

        public void onClick(View v) {
            if (QSDetailItems.this.mCallback != null) {
                QSDetailItems.this.mCallback.onDetailItemDisconnect(this.val$item);
            }
        }
    }

    public interface Callback {
        void onDetailItemClick(Item item);

        void onDetailItemDisconnect(Item item);
    }

    /* renamed from: com.android.systemui.qs.QSDetailItems.H */
    private class C0152H extends Handler {
        public C0152H() {
            super(Looper.getMainLooper());
        }

        public void handleMessage(Message msg) {
            boolean z = true;
            if (msg.what == 1) {
                QSDetailItems.this.handleSetItems((Item[]) msg.obj);
            } else if (msg.what == 2) {
                QSDetailItems.this.handleSetCallback((Callback) msg.obj);
            } else if (msg.what == 3) {
                QSDetailItems qSDetailItems = QSDetailItems.this;
                if (msg.arg1 == 0) {
                    z = false;
                }
                qSDetailItems.handleSetItemsVisible(z);
            }
        }
    }

    public static class Item {
        public boolean canDisconnect;
        public int icon;
        public CharSequence line1;
        public CharSequence line2;
        public Drawable overlay;
        public Object tag;
    }

    static {
        DEBUG = Log.isLoggable("QSDetailItems", 3);
    }

    public QSDetailItems(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mHandler = new C0152H();
        this.mItemsVisible = true;
        this.mContext = context;
        this.mTag = "QSDetailItems";
    }

    public static QSDetailItems convertOrInflate(Context context, View convert, ViewGroup parent) {
        if (convert instanceof QSDetailItems) {
            return (QSDetailItems) convert;
        }
        return (QSDetailItems) LayoutInflater.from(context).inflate(2130968614, parent, false);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mItems = (LinearLayout) findViewById(16908298);
        this.mItems.setVisibility(8);
        this.mEmpty = findViewById(16908292);
        this.mEmpty.setVisibility(8);
        this.mEmptyText = (TextView) this.mEmpty.findViewById(16908310);
        this.mEmptyIcon = (ImageView) this.mEmpty.findViewById(16908294);
        this.mMinHeightSpacer = findViewById(2131755202);
        this.mMaxItems = getResources().getInteger(2131623953);
        setMinHeightInItems(this.mMaxItems);
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        FontSizeUtils.updateFontSize(this.mEmptyText, 2131296332);
        int count = this.mItems.getChildCount();
        for (int i = 0; i < count; i++) {
            View item = this.mItems.getChildAt(i);
            FontSizeUtils.updateFontSize(item, 16908310, 2131296330);
            FontSizeUtils.updateFontSize(item, 16908304, 2131296331);
        }
    }

    public void setTagSuffix(String suffix) {
        this.mTag = "QSDetailItems." + suffix;
    }

    public void setEmptyState(int icon, int text) {
        this.mEmptyIcon.setImageResource(icon);
        this.mEmptyText.setText(text);
    }

    public void setMinHeightInItems(int minHeightInItems) {
        LayoutParams lp = this.mMinHeightSpacer.getLayoutParams();
        lp.height = getResources().getDimensionPixelSize(2131296326) * minHeightInItems;
        this.mMinHeightSpacer.setLayoutParams(lp);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (DEBUG) {
            Log.d(this.mTag, "onAttachedToWindow");
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (DEBUG) {
            Log.d(this.mTag, "onDetachedFromWindow");
        }
        this.mCallback = null;
    }

    public void setCallback(Callback callback) {
        this.mHandler.removeMessages(2);
        this.mHandler.obtainMessage(2, callback).sendToTarget();
    }

    public void setItems(Item[] items) {
        this.mHandler.removeMessages(1);
        this.mHandler.obtainMessage(1, items).sendToTarget();
    }

    public void setItemsVisible(boolean visible) {
        int i;
        this.mHandler.removeMessages(3);
        C0152H c0152h = this.mHandler;
        if (visible) {
            i = 1;
        } else {
            i = 0;
        }
        c0152h.obtainMessage(3, i, 0).sendToTarget();
    }

    private void handleSetCallback(Callback callback) {
        this.mCallback = callback;
    }

    private void handleSetItems(Item[] items) {
        int itemCount;
        int i;
        int i2;
        int i3 = 8;
        if (items != null) {
            itemCount = Math.min(items.length, this.mMaxItems);
        } else {
            itemCount = 0;
        }
        View view = this.mEmpty;
        if (itemCount == 0) {
            i = 0;
        } else {
            i = 8;
        }
        view.setVisibility(i);
        LinearLayout linearLayout = this.mItems;
        if (itemCount != 0) {
            i3 = 0;
        }
        linearLayout.setVisibility(i3);
        for (i2 = this.mItems.getChildCount() - 1; i2 >= itemCount; i2--) {
            this.mItems.removeViewAt(i2);
        }
        for (i2 = 0; i2 < itemCount; i2++) {
            bind(items[i2], this.mItems.getChildAt(i2));
        }
    }

    private void handleSetItemsVisible(boolean visible) {
        if (this.mItemsVisible != visible) {
            this.mItemsVisible = visible;
            for (int i = 0; i < this.mItems.getChildCount(); i++) {
                this.mItems.getChildAt(i).setVisibility(this.mItemsVisible ? 0 : 4);
            }
        }
    }

    private void bind(Item item, View view) {
        boolean twoLines;
        int i;
        int i2 = 0;
        if (view == null) {
            view = LayoutInflater.from(this.mContext).inflate(2130968613, this, false);
            this.mItems.addView(view);
        }
        view.setVisibility(this.mItemsVisible ? 0 : 4);
        ImageView iv = (ImageView) view.findViewById(16908294);
        iv.setImageResource(item.icon);
        iv.getOverlay().clear();
        if (item.overlay != null) {
            item.overlay.setBounds(0, 0, item.overlay.getIntrinsicWidth(), item.overlay.getIntrinsicHeight());
            iv.getOverlay().add(item.overlay);
        }
        TextView title = (TextView) view.findViewById(16908310);
        title.setText(item.line1);
        TextView summary = (TextView) view.findViewById(16908304);
        if (TextUtils.isEmpty(item.line2)) {
            twoLines = false;
        } else {
            twoLines = true;
        }
        title.setMaxLines(twoLines ? 1 : 2);
        if (twoLines) {
            i = 0;
        } else {
            i = 8;
        }
        summary.setVisibility(i);
        summary.setText(twoLines ? item.line2 : null);
        view.setOnClickListener(new C01501(item));
        ImageView disconnect = (ImageView) view.findViewById(16908296);
        if (!item.canDisconnect) {
            i2 = 8;
        }
        disconnect.setVisibility(i2);
        disconnect.setOnClickListener(new C01512(item));
    }
}
