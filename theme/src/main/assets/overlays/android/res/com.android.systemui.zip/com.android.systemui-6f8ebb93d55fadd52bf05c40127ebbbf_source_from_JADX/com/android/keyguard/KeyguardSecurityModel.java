package com.android.keyguard;

import android.content.Context;
import android.telephony.SubscriptionManager;
import com.android.internal.telephony.IccCardConstants.State;
import com.android.internal.widget.LockPatternUtils;

public class KeyguardSecurityModel {
    private final Context mContext;
    private final boolean mIsPukScreenAvailable;
    private LockPatternUtils mLockPatternUtils;

    public enum SecurityMode {
        Invalid,
        None,
        Pattern,
        Password,
        PIN,
        SimPin,
        SimPuk
    }

    KeyguardSecurityModel(Context context) {
        this.mContext = context;
        this.mLockPatternUtils = new LockPatternUtils(context);
        this.mIsPukScreenAvailable = this.mContext.getResources().getBoolean(17956937);
    }

    void setLockPatternUtils(LockPatternUtils utils) {
        this.mLockPatternUtils = utils;
    }

    SecurityMode getSecurityMode() {
        KeyguardUpdateMonitor monitor = KeyguardUpdateMonitor.getInstance(this.mContext);
        if (SubscriptionManager.isValidSubscriptionId(monitor.getNextSubIdForState(State.PIN_REQUIRED))) {
            return SecurityMode.SimPin;
        }
        if (this.mIsPukScreenAvailable && SubscriptionManager.isValidSubscriptionId(monitor.getNextSubIdForState(State.PUK_REQUIRED))) {
            return SecurityMode.SimPuk;
        }
        int security = this.mLockPatternUtils.getActivePasswordQuality(KeyguardUpdateMonitor.getCurrentUser());
        switch (security) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                return SecurityMode.None;
            case 65536:
                return SecurityMode.Pattern;
            case 131072:
            case 196608:
                return SecurityMode.PIN;
            case 262144:
            case 327680:
            case 393216:
                return SecurityMode.Password;
            default:
                throw new IllegalStateException("Unknown security quality:" + security);
        }
    }
}
