package com.android.systemui.volume;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.animation.LayoutTransition;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.AudioSystem;
import android.os.Debug;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnClickListener;
import android.view.View.OnLayoutChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.policy.ZenModeController;
import com.android.systemui.volume.VolumeDialogController.Callbacks;
import com.android.systemui.volume.VolumeDialogController.State;
import com.android.systemui.volume.VolumeDialogController.StreamState;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class VolumeDialog {
    private static final String TAG;
    private final Accessibility mAccessibility;
    private final ColorStateList mActiveSliderTint;
    private int mActiveStream;
    private final AudioManager mAudioManager;
    private boolean mAutomute;
    private Callback mCallback;
    private final OnClickListener mClickExpand;
    private final OnClickListener mClickSettings;
    private long mCollapseTime;
    private final Context mContext;
    private final VolumeDialogController mController;
    private final Callbacks mControllerCallbackH;
    private final CustomDialog mDialog;
    private final ViewGroup mDialogContentView;
    private final ViewGroup mDialogView;
    private final SparseBooleanArray mDynamic;
    private final ImageButton mExpandButton;
    private final int mExpandButtonAnimationDuration;
    private boolean mExpandButtonAnimationRunning;
    private int mExpandButtonRes;
    private boolean mExpanded;
    private final C0565H mHandler;
    private final ColorStateList mInactiveSliderTint;
    private final KeyguardManager mKeyguard;
    private int mLastActiveStream;
    private final LayoutTransition mLayoutTransition;
    private final VolumeDialogMotion mMotion;
    private boolean mPendingRecheckAll;
    private boolean mPendingStateChanged;
    private final List<VolumeRow> mRows;
    private SafetyWarningDialog mSafetyWarning;
    private final Object mSafetyWarningLock;
    private final View mSettingsButton;
    private boolean mShowHeaders;
    private boolean mShowing;
    private boolean mSilentMode;
    private final SpTexts mSpTexts;
    private State mState;
    private final ZenFooter mZenFooter;

    /* renamed from: com.android.systemui.volume.VolumeDialog.1 */
    class C05551 implements com.android.systemui.volume.VolumeDialogMotion.Callback {
        C05551() {
        }

        public void onAnimatingChanged(boolean animating) {
            if (!animating) {
                if (VolumeDialog.this.mPendingStateChanged) {
                    VolumeDialog.this.mHandler.sendEmptyMessage(7);
                    VolumeDialog.this.mPendingStateChanged = false;
                }
                if (VolumeDialog.this.mPendingRecheckAll) {
                    VolumeDialog.this.mHandler.sendEmptyMessage(4);
                    VolumeDialog.this.mPendingRecheckAll = false;
                }
            }
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.2 */
    class C05562 implements OnLayoutChangeListener {
        final /* synthetic */ VolumeRow val$row;

        C05562(VolumeRow volumeRow) {
            this.val$row = volumeRow;
        }

        public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
            boolean moved = (VolumeDialog.this.mLastActiveStream == VolumeDialog.this.mActiveStream && oldLeft == left && oldTop == top) ? false : true;
            if (C0543D.BUG) {
                Log.d(VolumeDialog.TAG, "onLayoutChange moved=" + moved + " old=" + new Rect(oldLeft, oldTop, oldRight, oldBottom).toShortString() + "," + VolumeDialog.this.mLastActiveStream + " new=" + new Rect(left, top, right, bottom).toShortString() + "," + VolumeDialog.this.mActiveStream);
            }
            VolumeDialog.this.mLastActiveStream = VolumeDialog.this.mActiveStream;
            if (moved) {
                int i = 0;
                while (i < VolumeDialog.this.mDialogContentView.getChildCount()) {
                    View c = VolumeDialog.this.mDialogContentView.getChildAt(i);
                    if (!c.isShown()) {
                        i++;
                    } else if (c == this.val$row.view) {
                        VolumeDialog.this.repositionExpandAnim(this.val$row);
                        return;
                    } else {
                        return;
                    }
                }
            }
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.3 */
    class C05573 implements OnTouchListener {
        private boolean mDragging;
        private final Rect mSliderHitRect;
        final /* synthetic */ VolumeRow val$row;

        C05573(VolumeRow volumeRow) {
            this.val$row = volumeRow;
            this.mSliderHitRect = new Rect();
        }

        @SuppressLint({"ClickableViewAccessibility"})
        public boolean onTouch(View v, MotionEvent event) {
            this.val$row.slider.getHitRect(this.mSliderHitRect);
            if (!this.mDragging && event.getActionMasked() == 0 && event.getY() < ((float) this.mSliderHitRect.top)) {
                this.mDragging = true;
            }
            if (!this.mDragging) {
                return false;
            }
            event.offsetLocation((float) (-this.mSliderHitRect.left), (float) (-this.mSliderHitRect.top));
            this.val$row.slider.dispatchTouchEvent(event);
            if (event.getActionMasked() != 1 && event.getActionMasked() != 3) {
                return true;
            }
            this.mDragging = false;
            return true;
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.4 */
    class C05584 implements OnClickListener {
        final /* synthetic */ VolumeRow val$row;
        final /* synthetic */ int val$stream;

        C05584(VolumeRow volumeRow, int i) {
            this.val$row = volumeRow;
            this.val$stream = i;
        }

        public void onClick(View v) {
            boolean wasZero = true;
            int i = 0;
            Events.writeEvent(VolumeDialog.this.mContext, 7, Integer.valueOf(this.val$row.stream), Integer.valueOf(this.val$row.iconState));
            VolumeDialog.this.mController.setActiveStream(this.val$row.stream);
            VolumeDialogController access$2400;
            int i2;
            if (this.val$row.stream == 2) {
                boolean hasVibrator = VolumeDialog.this.mController.hasVibrator();
                if (VolumeDialog.this.mState.ringerModeInternal != 2) {
                    VolumeDialog.this.mController.setRingerMode(2, false);
                    if (this.val$row.ss.level == 0) {
                        VolumeDialog.this.mController.setStreamVolume(this.val$stream, 1);
                    }
                } else if (hasVibrator) {
                    VolumeDialog.this.mController.setRingerMode(1, false);
                } else {
                    if (this.val$row.ss.level != 0) {
                        wasZero = false;
                    }
                    access$2400 = VolumeDialog.this.mController;
                    i2 = this.val$stream;
                    if (wasZero) {
                        i = this.val$row.lastAudibleLevel;
                    }
                    access$2400.setStreamVolume(i2, i);
                }
            } else {
                boolean vmute;
                if (this.val$row.ss.level == 0) {
                    vmute = true;
                } else {
                    vmute = false;
                }
                access$2400 = VolumeDialog.this.mController;
                i2 = this.val$stream;
                if (vmute) {
                    i = this.val$row.lastAudibleLevel;
                }
                access$2400.setStreamVolume(i2, i);
            }
            this.val$row.userAttempt = 0;
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.5 */
    class C05595 implements Runnable {
        C05595() {
        }

        public void run() {
            VolumeDialog.this.setExpandedH(false);
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.6 */
    class C05606 implements Runnable {
        C05606() {
        }

        public void run() {
            VolumeDialog.this.mExpandButtonAnimationRunning = false;
            VolumeDialog.this.updateExpandButtonH();
            VolumeDialog.this.rescheduleTimeoutH();
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.7 */
    class C05617 extends SafetyWarningDialog {
        C05617(Context x0, AudioManager x1) {
            super(x0, x1);
        }

        protected void cleanUp() {
            synchronized (VolumeDialog.this.mSafetyWarningLock) {
                VolumeDialog.this.mSafetyWarning = null;
            }
            VolumeDialog.this.recheckH(null);
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.8 */
    class C05628 implements Callbacks {
        C05628() {
        }

        public void onShowRequested(int reason) {
            VolumeDialog.this.showH(reason);
        }

        public void onDismissRequested(int reason) {
            VolumeDialog.this.dismissH(reason);
        }

        public void onScreenOff() {
            VolumeDialog.this.dismissH(4);
        }

        public void onStateChanged(State state) {
            VolumeDialog.this.onStateChangedH(state);
        }

        public void onLayoutDirectionChanged(int layoutDirection) {
            VolumeDialog.this.mDialogView.setLayoutDirection(layoutDirection);
        }

        public void onConfigurationChanged() {
            VolumeDialog.this.updateWindowWidthH();
            VolumeDialog.this.mSpTexts.update();
            VolumeDialog.this.mZenFooter.onConfigurationChanged();
        }

        public void onShowVibrateHint() {
            if (VolumeDialog.this.mSilentMode) {
                VolumeDialog.this.mController.setRingerMode(0, false);
            }
        }

        public void onShowSilentHint() {
            if (VolumeDialog.this.mSilentMode) {
                VolumeDialog.this.mController.setRingerMode(2, false);
            }
        }

        public void onShowSafetyWarning(int flags) {
            VolumeDialog.this.showSafetyWarningH(flags);
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.9 */
    class C05639 implements OnClickListener {
        C05639() {
        }

        public void onClick(View v) {
            if (!VolumeDialog.this.mExpandButtonAnimationRunning) {
                boolean newExpand;
                if (VolumeDialog.this.mExpanded) {
                    newExpand = false;
                } else {
                    newExpand = true;
                }
                Events.writeEvent(VolumeDialog.this.mContext, 3, Boolean.valueOf(newExpand));
                VolumeDialog.this.setExpandedH(newExpand);
            }
        }
    }

    private final class Accessibility extends AccessibilityDelegate {
        private boolean mFeedbackEnabled;
        private AccessibilityManager mMgr;
        private OnAttachStateChangeListener mOnAttachStateChangeListener;

        /* renamed from: com.android.systemui.volume.VolumeDialog.Accessibility.1 */
        class C05641 implements OnAttachStateChangeListener {
            C05641() {
            }

            public void onViewDetachedFromWindow(View v) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialog.TAG, "onViewDetachedFromWindow");
                }
            }

            public void onViewAttachedToWindow(View v) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialog.TAG, "onViewAttachedToWindow");
                }
                Accessibility.this.updateFeedbackEnabled();
            }
        }

        private Accessibility() {
            this.mOnAttachStateChangeListener = new C05641();
        }

        public void init() {
            this.mMgr = (AccessibilityManager) VolumeDialog.this.mContext.getSystemService("accessibility");
            VolumeDialog.this.mDialogView.addOnAttachStateChangeListener(this.mOnAttachStateChangeListener);
            updateFeedbackEnabled();
        }

        public boolean onRequestSendAccessibilityEvent(ViewGroup host, View child, AccessibilityEvent event) {
            VolumeDialog.this.rescheduleTimeoutH();
            return super.onRequestSendAccessibilityEvent(host, child, event);
        }

        public void cleanup() {
            VolumeDialog.this.mDialogView.removeOnAttachStateChangeListener(this.mOnAttachStateChangeListener);
        }

        private void updateFeedbackEnabled() {
            this.mFeedbackEnabled = computeFeedbackEnabled();
        }

        private boolean computeFeedbackEnabled() {
            for (AccessibilityServiceInfo asi : this.mMgr.getEnabledAccessibilityServiceList(-1)) {
                if (asi.feedbackType != 0 && asi.feedbackType != 16) {
                    return true;
                }
            }
            return false;
        }
    }

    public interface Callback {
        void onSettingsClicked();
    }

    private final class CustomDialog extends Dialog {
        public CustomDialog(Context context) {
            super(context);
        }

        public boolean dispatchTouchEvent(MotionEvent ev) {
            VolumeDialog.this.rescheduleTimeoutH();
            return super.dispatchTouchEvent(ev);
        }

        protected void onStop() {
            super.onStop();
            boolean animating = VolumeDialog.this.mMotion.isAnimating();
            if (C0543D.BUG) {
                Log.d(VolumeDialog.TAG, "onStop animating=" + animating);
            }
            if (animating) {
                VolumeDialog.this.mPendingRecheckAll = true;
            } else {
                VolumeDialog.this.mHandler.sendEmptyMessage(4);
            }
        }

        public boolean onTouchEvent(MotionEvent event) {
            if (!isShowing() || event.getAction() != 4) {
                return false;
            }
            VolumeDialog.this.dismissH(1);
            return true;
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialog.H */
    private final class C0565H extends Handler {
        public C0565H() {
            super(Looper.getMainLooper());
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    VolumeDialog.this.showH(msg.arg1);
                case 2:
                    VolumeDialog.this.dismissH(msg.arg1);
                case 3:
                    VolumeDialog.this.recheckH((VolumeRow) msg.obj);
                case 4:
                    VolumeDialog.this.recheckH(null);
                case 5:
                    VolumeDialog.this.setStreamImportantH(msg.arg1, msg.arg2 != 0);
                case 6:
                    VolumeDialog.this.rescheduleTimeoutH();
                case 7:
                    VolumeDialog.this.onStateChangedH(VolumeDialog.this.mState);
                case 8:
                    VolumeDialog.this.updateDialogBottomMarginH();
                default:
            }
        }
    }

    private static class VolumeRow {
        private ObjectAnimator anim;
        private int animTargetProgress;
        private int cachedExpandButtonRes;
        private int cachedIconRes;
        private boolean cachedShowHeaders;
        private ColorStateList cachedSliderTint;
        private TextView header;
        private ImageButton icon;
        private int iconMuteRes;
        private int iconRes;
        private int iconState;
        private boolean important;
        private int lastAudibleLevel;
        private int requestedLevel;
        private ImageButton settingsButton;
        private SeekBar slider;
        private View space;
        private StreamState ss;
        private int stream;
        private boolean tracking;
        private long userAttempt;
        private View view;

        private VolumeRow() {
            this.requestedLevel = -1;
            this.cachedShowHeaders = true;
            this.lastAudibleLevel = 1;
        }
    }

    private final class VolumeSeekBarChangeListener implements OnSeekBarChangeListener {
        private final VolumeRow mRow;

        private VolumeSeekBarChangeListener(VolumeRow row) {
            this.mRow = row;
        }

        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if (this.mRow.ss != null) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialog.TAG, AudioSystem.streamToString(this.mRow.stream) + " onProgressChanged " + progress + " fromUser=" + fromUser);
                }
                if (fromUser) {
                    if (this.mRow.ss.levelMin > 0) {
                        int minProgress = this.mRow.ss.levelMin * 100;
                        if (progress < minProgress) {
                            seekBar.setProgress(minProgress);
                        }
                    }
                    int userLevel = VolumeDialog.getImpliedLevel(seekBar, progress);
                    if (this.mRow.ss.level != userLevel || (this.mRow.ss.muted && userLevel > 0)) {
                        this.mRow.userAttempt = SystemClock.uptimeMillis();
                        if (this.mRow.requestedLevel != userLevel) {
                            VolumeDialog.this.mController.setStreamVolume(this.mRow.stream, userLevel);
                            this.mRow.requestedLevel = userLevel;
                            Events.writeEvent(VolumeDialog.this.mContext, 9, Integer.valueOf(this.mRow.stream), Integer.valueOf(userLevel));
                        }
                    }
                }
            }
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
            if (C0543D.BUG) {
                Log.d(VolumeDialog.TAG, "onStartTrackingTouch " + this.mRow.stream);
            }
            VolumeDialog.this.mController.setActiveStream(this.mRow.stream);
            this.mRow.tracking = true;
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            if (C0543D.BUG) {
                Log.d(VolumeDialog.TAG, "onStopTrackingTouch " + this.mRow.stream);
            }
            this.mRow.tracking = false;
            this.mRow.userAttempt = SystemClock.uptimeMillis();
            int userLevel = VolumeDialog.getImpliedLevel(seekBar, seekBar.getProgress());
            Events.writeEvent(VolumeDialog.this.mContext, 16, Integer.valueOf(this.mRow.stream), Integer.valueOf(userLevel));
            if (this.mRow.ss.level != userLevel) {
                VolumeDialog.this.mHandler.sendMessageDelayed(VolumeDialog.this.mHandler.obtainMessage(3, this.mRow), 1000);
            }
        }
    }

    static {
        TAG = Util.logTag(VolumeDialog.class);
    }

    public VolumeDialog(Context context, int windowType, VolumeDialogController controller, ZenModeController zenModeController, Callback callback) {
        this.mHandler = new C0565H();
        this.mRows = new ArrayList();
        this.mDynamic = new SparseBooleanArray();
        this.mSafetyWarningLock = new Object();
        this.mAccessibility = new Accessibility();
        this.mShowHeaders = true;
        this.mAutomute = true;
        this.mSilentMode = true;
        this.mControllerCallbackH = new C05628();
        this.mClickExpand = new C05639();
        this.mClickSettings = new OnClickListener() {

            /* renamed from: com.android.systemui.volume.VolumeDialog.10.1 */
            class C05541 implements Runnable {
                C05541() {
                }

                public void run() {
                    Events.writeEvent(VolumeDialog.this.mContext, 8, new Object[0]);
                    if (VolumeDialog.this.mCallback != null) {
                        VolumeDialog.this.mCallback.onSettingsClicked();
                    }
                }
            }

            public void onClick(View v) {
                VolumeDialog.this.mSettingsButton.postDelayed(new C05541(), 200);
            }
        };
        this.mContext = context;
        this.mController = controller;
        this.mCallback = callback;
        this.mSpTexts = new SpTexts(this.mContext);
        this.mKeyguard = (KeyguardManager) context.getSystemService("keyguard");
        this.mAudioManager = (AudioManager) context.getSystemService("audio");
        this.mDialog = new CustomDialog(this.mContext);
        Window window = this.mDialog.getWindow();
        window.requestFeature(1);
        window.setBackgroundDrawable(new ColorDrawable(0));
        window.clearFlags(2);
        window.addFlags(17563944);
        this.mDialog.setCanceledOnTouchOutside(true);
        Resources res = this.mContext.getResources();
        LayoutParams lp = window.getAttributes();
        lp.type = windowType;
        lp.format = -3;
        lp.setTitle(VolumeDialog.class.getSimpleName());
        lp.gravity = 49;
        lp.y = res.getDimensionPixelSize(2131296464);
        lp.gravity = 48;
        lp.windowAnimations = -1;
        window.setAttributes(lp);
        window.setSoftInputMode(48);
        this.mActiveSliderTint = loadColorStateList(2131427345);
        this.mInactiveSliderTint = loadColorStateList(2131427419);
        this.mDialog.setContentView(2130968653);
        this.mDialogView = (ViewGroup) this.mDialog.findViewById(2131755335);
        this.mDialogContentView = (ViewGroup) this.mDialog.findViewById(2131755337);
        this.mExpandButton = (ImageButton) this.mDialogView.findViewById(2131755336);
        this.mExpandButton.setOnClickListener(this.mClickExpand);
        updateWindowWidthH();
        updateExpandButtonH();
        this.mLayoutTransition = new LayoutTransition();
        this.mLayoutTransition.setDuration(new ValueAnimator().getDuration() / 2);
        this.mDialogContentView.setLayoutTransition(this.mLayoutTransition);
        this.mMotion = new VolumeDialogMotion(this.mDialog, this.mDialogView, this.mDialogContentView, this.mExpandButton, new C05551());
        addRow(2, 2130837734, 2130837735, true);
        addRow(3, 2130837728, 2130837731, true);
        addRow(4, 2130837721, 2130837722, false);
        addRow(0, 2130837740, 2130837740, false);
        addRow(6, 2130837723, 2130837723, false);
        addRow(1, 2130837738, 2130837739, false);
        this.mSettingsButton = this.mDialog.findViewById(2131755342);
        this.mSettingsButton.setOnClickListener(this.mClickSettings);
        this.mExpandButtonAnimationDuration = res.getInteger(2131623988);
        this.mZenFooter = (ZenFooter) this.mDialog.findViewById(2131755343);
        this.mZenFooter.init(zenModeController);
        this.mAccessibility.init();
        controller.addCallback(this.mControllerCallbackH, this.mHandler);
        controller.getState();
    }

    private ColorStateList loadColorStateList(int colorResId) {
        return ColorStateList.valueOf(this.mContext.getColor(colorResId));
    }

    private void updateWindowWidthH() {
        ViewGroup.LayoutParams lp = this.mDialogView.getLayoutParams();
        DisplayMetrics dm = this.mContext.getResources().getDisplayMetrics();
        if (C0543D.BUG) {
            Log.d(TAG, "updateWindowWidth dm.w=" + dm.widthPixels);
        }
        int w = dm.widthPixels;
        int max = this.mContext.getResources().getDimensionPixelSize(2131296305);
        if (w > max) {
            w = max;
        }
        lp.width = w - (this.mContext.getResources().getDimensionPixelSize(2131296368) * 2);
        this.mDialogView.setLayoutParams(lp);
    }

    public void setStreamImportant(int stream, boolean important) {
        this.mHandler.obtainMessage(5, stream, important ? 1 : 0).sendToTarget();
    }

    public void setShowHeaders(boolean showHeaders) {
        if (showHeaders != this.mShowHeaders) {
            this.mShowHeaders = showHeaders;
            this.mHandler.sendEmptyMessage(4);
        }
    }

    public void setAutomute(boolean automute) {
        if (this.mAutomute != automute) {
            this.mAutomute = automute;
            this.mHandler.sendEmptyMessage(4);
        }
    }

    public void setSilentMode(boolean silentMode) {
        if (this.mSilentMode != silentMode) {
            this.mSilentMode = silentMode;
            this.mHandler.sendEmptyMessage(4);
        }
    }

    private void addRow(int stream, int iconRes, int iconMuteRes, boolean important) {
        VolumeRow row = initRow(stream, iconRes, iconMuteRes, important);
        if (!this.mRows.isEmpty()) {
            View v = new View(this.mContext);
            v.setId(16908288);
            this.mDialogContentView.addView(v, this.mDialogContentView.getChildCount() - 1, new LinearLayout.LayoutParams(-1, this.mContext.getResources().getDimensionPixelSize(2131296463)));
            row.space = v;
        }
        row.settingsButton.addOnLayoutChangeListener(new C05562(row));
        this.mDialogContentView.addView(row.view, this.mDialogContentView.getChildCount() - 1);
        this.mRows.add(row);
    }

    private boolean isAttached() {
        return this.mDialogContentView != null && this.mDialogContentView.isAttachedToWindow();
    }

    private VolumeRow getActiveRow() {
        for (VolumeRow row : this.mRows) {
            if (row.stream == this.mActiveStream) {
                return row;
            }
        }
        return (VolumeRow) this.mRows.get(0);
    }

    private VolumeRow findRow(int stream) {
        for (VolumeRow row : this.mRows) {
            if (row.stream == stream) {
                return row;
            }
        }
        return null;
    }

    private void repositionExpandAnim(VolumeRow row) {
        int[] loc = new int[2];
        row.settingsButton.getLocationInWindow(loc);
        MarginLayoutParams mlp = (MarginLayoutParams) this.mDialogView.getLayoutParams();
        int x = loc[0] - mlp.leftMargin;
        int y = loc[1] - mlp.topMargin;
        if (C0543D.BUG) {
            Log.d(TAG, "repositionExpandAnim x=" + x + " y=" + y);
        }
        this.mExpandButton.setTranslationX((float) x);
        this.mExpandButton.setTranslationY((float) y);
        this.mExpandButton.setTag(Integer.valueOf(y));
    }

    public void dump(PrintWriter writer) {
        writer.println(VolumeDialog.class.getSimpleName() + " state:");
        writer.print("  mShowing: ");
        writer.println(this.mShowing);
        writer.print("  mExpanded: ");
        writer.println(this.mExpanded);
        writer.print("  mExpandButtonAnimationRunning: ");
        writer.println(this.mExpandButtonAnimationRunning);
        writer.print("  mActiveStream: ");
        writer.println(this.mActiveStream);
        writer.print("  mDynamic: ");
        writer.println(this.mDynamic);
        writer.print("  mShowHeaders: ");
        writer.println(this.mShowHeaders);
        writer.print("  mAutomute: ");
        writer.println(this.mAutomute);
        writer.print("  mSilentMode: ");
        writer.println(this.mSilentMode);
        writer.print("  mCollapseTime: ");
        writer.println(this.mCollapseTime);
        writer.print("  mAccessibility.mFeedbackEnabled: ");
        writer.println(this.mAccessibility.mFeedbackEnabled);
    }

    private static int getImpliedLevel(SeekBar seekBar, int progress) {
        int m = seekBar.getMax();
        int n = (m / 100) - 1;
        if (progress == 0) {
            return 0;
        }
        return progress == m ? m / 100 : ((int) ((((float) progress) / ((float) m)) * ((float) n))) + 1;
    }

    @SuppressLint({"InflateParams"})
    private VolumeRow initRow(int stream, int iconRes, int iconMuteRes, boolean important) {
        VolumeRow row = new VolumeRow();
        row.stream = stream;
        row.iconRes = iconRes;
        row.iconMuteRes = iconMuteRes;
        row.important = important;
        row.view = this.mDialog.getLayoutInflater().inflate(2130968654, null);
        row.view.setTag(row);
        row.header = (TextView) row.view.findViewById(2131755339);
        this.mSpTexts.add(row.header);
        row.slider = (SeekBar) row.view.findViewById(2131755341);
        row.slider.setProgressTintMode(Mode.SRC_ATOP);
        row.slider.setThumbTintMode(Mode.SRC_ATOP);
        row.slider.setOnSeekBarChangeListener(new VolumeSeekBarChangeListener(row, null));
        row.view.setOnTouchListener(new C05573(row));
        row.icon = (ImageButton) row.view.findViewById(2131755340);
        row.icon.setImageResource(iconRes);
        row.icon.setOnClickListener(new C05584(row, stream));
        row.settingsButton = (ImageButton) row.view.findViewById(2131755342);
        row.settingsButton.setOnClickListener(this.mClickSettings);
        return row;
    }

    private void showH(int reason) {
        if (C0543D.BUG) {
            Log.d(TAG, "showH r=" + Events.DISMISS_REASONS[reason]);
        }
        this.mHandler.removeMessages(1);
        this.mHandler.removeMessages(2);
        rescheduleTimeoutH();
        if (!this.mShowing) {
            this.mShowing = true;
            this.mMotion.startShow();
            Events.writeEvent(this.mContext, 0, Integer.valueOf(reason), Boolean.valueOf(this.mKeyguard.isKeyguardLocked()));
            this.mController.notifyVisible(true);
        }
    }

    protected void rescheduleTimeoutH() {
        this.mHandler.removeMessages(2);
        int timeout = computeTimeoutH();
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(2, 3, 0), (long) timeout);
        if (C0543D.BUG) {
            Log.d(TAG, "rescheduleTimeout " + timeout + " " + Debug.getCaller());
        }
        this.mController.userActivity();
    }

    private int computeTimeoutH() {
        if (this.mAccessibility.mFeedbackEnabled) {
            return 20000;
        }
        if (this.mSafetyWarning != null || this.mExpanded || this.mExpandButtonAnimationRunning) {
            return 5000;
        }
        if (this.mActiveStream == 3) {
            return 1500;
        }
        return 3000;
    }

    protected void dismissH(int reason) {
        if (!this.mMotion.isAnimating()) {
            this.mHandler.removeMessages(2);
            this.mHandler.removeMessages(1);
            if (this.mShowing) {
                this.mShowing = false;
                this.mMotion.startDismiss(new C05595());
                Events.writeEvent(this.mContext, 1, Integer.valueOf(reason));
                this.mController.notifyVisible(false);
                synchronized (this.mSafetyWarningLock) {
                    if (this.mSafetyWarning != null) {
                        if (C0543D.BUG) {
                            Log.d(TAG, "SafetyWarning dismissed");
                        }
                        this.mSafetyWarning.dismiss();
                    }
                }
            }
        }
    }

    private void updateDialogBottomMarginH() {
        boolean collapsing = this.mCollapseTime != 0 && System.currentTimeMillis() - this.mCollapseTime < getConservativeCollapseDuration();
        MarginLayoutParams mlp = (MarginLayoutParams) this.mDialogView.getLayoutParams();
        int bottomMargin = collapsing ? this.mDialogContentView.getHeight() : this.mContext.getResources().getDimensionPixelSize(2131296466);
        if (bottomMargin != mlp.bottomMargin) {
            if (C0543D.BUG) {
                Log.d(TAG, "bottomMargin " + mlp.bottomMargin + " -> " + bottomMargin);
            }
            mlp.bottomMargin = bottomMargin;
            this.mDialogView.setLayoutParams(mlp);
        }
    }

    private long getConservativeCollapseDuration() {
        return (long) (this.mExpandButtonAnimationDuration * 3);
    }

    private void prepareForCollapse() {
        this.mHandler.removeMessages(8);
        this.mCollapseTime = System.currentTimeMillis();
        updateDialogBottomMarginH();
        this.mHandler.sendEmptyMessageDelayed(8, getConservativeCollapseDuration());
    }

    private void setExpandedH(boolean expanded) {
        if (this.mExpanded != expanded) {
            this.mExpanded = expanded;
            this.mExpandButtonAnimationRunning = isAttached();
            if (C0543D.BUG) {
                Log.d(TAG, "setExpandedH " + expanded);
            }
            if (!this.mExpanded && this.mExpandButtonAnimationRunning) {
                prepareForCollapse();
            }
            updateRowsH();
            if (this.mExpandButtonAnimationRunning) {
                Drawable d = this.mExpandButton.getDrawable();
                if (d instanceof AnimatedVectorDrawable) {
                    AnimatedVectorDrawable avd = (AnimatedVectorDrawable) d.getConstantState().newDrawable();
                    this.mExpandButton.setImageDrawable(avd);
                    avd.start();
                    this.mHandler.postDelayed(new C05606(), (long) this.mExpandButtonAnimationDuration);
                }
            }
            rescheduleTimeoutH();
        }
    }

    private void updateExpandButtonH() {
        if (C0543D.BUG) {
            Log.d(TAG, "updateExpandButtonH");
        }
        this.mExpandButton.setClickable(!this.mExpandButtonAnimationRunning);
        if (!this.mExpandButtonAnimationRunning || !isAttached()) {
            int res = this.mExpanded ? 2130837725 : 2130837727;
            if (res != this.mExpandButtonRes) {
                int i;
                this.mExpandButtonRes = res;
                this.mExpandButton.setImageResource(res);
                ImageButton imageButton = this.mExpandButton;
                Context context = this.mContext;
                if (this.mExpanded) {
                    i = 2131362318;
                } else {
                    i = 2131362317;
                }
                imageButton.setContentDescription(context.getString(i));
            }
        }
    }

    private boolean isVisibleH(VolumeRow row, boolean isActive) {
        return (this.mExpanded && row.view.getVisibility() == 0) || ((this.mExpanded && (row.important || isActive)) || (!this.mExpanded && isActive));
    }

    private void updateRowsH() {
        if (C0543D.BUG) {
            Log.d(TAG, "updateRowsH");
        }
        VolumeRow activeRow = getActiveRow();
        updateFooterH();
        updateExpandButtonH();
        if (!this.mShowing) {
            trimObsoleteH();
        }
        for (VolumeRow row : this.mRows) {
            boolean isActive;
            boolean z;
            int expandButtonRes;
            if (row == activeRow) {
                isActive = true;
            } else {
                isActive = false;
            }
            boolean visible = isVisibleH(row, isActive);
            Util.setVisOrGone(row.view, visible);
            View access$400 = row.space;
            if (visible && this.mExpanded) {
                z = true;
            } else {
                z = false;
            }
            Util.setVisOrGone(access$400, z);
            if (this.mExpanded) {
                expandButtonRes = 2130837737;
            } else {
                expandButtonRes = 0;
            }
            if (expandButtonRes != row.cachedExpandButtonRes) {
                row.cachedExpandButtonRes = expandButtonRes;
                if (expandButtonRes == 0) {
                    row.settingsButton.setImageDrawable(null);
                } else {
                    row.settingsButton.setImageResource(expandButtonRes);
                }
            }
            Util.setVisOrInvis(row.settingsButton, false);
            updateVolumeRowHeaderVisibleH(row);
            TextView access$1800 = row.header;
            float f = (this.mExpanded && isActive) ? 1.0f : 0.5f;
            access$1800.setAlpha(f);
            updateVolumeRowSliderTintH(row, isActive);
        }
    }

    private void trimObsoleteH() {
        if (C0543D.BUG) {
            Log.d(TAG, "trimObsoleteH");
        }
        for (int i = this.mRows.size() - 1; i >= 0; i--) {
            VolumeRow row = (VolumeRow) this.mRows.get(i);
            if (!(row.ss == null || !row.ss.dynamic || this.mDynamic.get(row.stream))) {
                this.mRows.remove(i);
                this.mDialogContentView.removeView(row.view);
                this.mDialogContentView.removeView(row.space);
            }
        }
    }

    private void onStateChangedH(State state) {
        boolean animating = this.mMotion.isAnimating();
        if (C0543D.BUG) {
            Log.d(TAG, "onStateChangedH animating=" + animating);
        }
        this.mState = state;
        if (animating) {
            this.mPendingStateChanged = true;
            return;
        }
        this.mDynamic.clear();
        for (int i = 0; i < state.states.size(); i++) {
            int stream = state.states.keyAt(i);
            if (((StreamState) state.states.valueAt(i)).dynamic) {
                this.mDynamic.put(stream, true);
                if (findRow(stream) == null) {
                    addRow(stream, 2130837732, 2130837733, true);
                }
            }
        }
        if (this.mActiveStream != state.activeStream) {
            this.mActiveStream = state.activeStream;
            updateRowsH();
            rescheduleTimeoutH();
        }
        for (VolumeRow row : this.mRows) {
            updateVolumeRowH(row);
        }
        updateFooterH();
    }

    private void updateFooterH() {
        boolean wasVisible;
        boolean visible;
        if (C0543D.BUG) {
            Log.d(TAG, "updateFooterH");
        }
        if (this.mZenFooter.getVisibility() == 0) {
            wasVisible = true;
        } else {
            wasVisible = false;
        }
        if (this.mState.zenMode == 0 || !this.mAudioManager.isStreamAffectedByRingerMode(this.mActiveStream)) {
            visible = false;
        } else {
            visible = true;
        }
        if (!(wasVisible == visible || visible)) {
            prepareForCollapse();
        }
        Util.setVisOrGone(this.mZenFooter, visible);
        this.mZenFooter.update();
    }

    private void updateVolumeRowH(VolumeRow row) {
        if (C0543D.BUG) {
            Log.d(TAG, "updateVolumeRowH s=" + row.stream);
        }
        if (this.mState != null) {
            StreamState ss = (StreamState) this.mState.states.get(row.stream);
            if (ss != null) {
                int i;
                boolean isRingVibrate;
                boolean isRingSilent;
                boolean isZenAlarms;
                boolean isZenNone;
                boolean isZenPriority;
                boolean isRingZenNone;
                boolean isRingLimited;
                boolean zenMuted;
                int max;
                String text;
                Context context;
                Object[] objArr;
                boolean iconEnabled;
                int iconRes;
                boolean enableSlider;
                int vlevel;
                row.ss = ss;
                if (ss.level > 0) {
                    row.lastAudibleLevel = ss.level;
                }
                if (ss.level == row.requestedLevel) {
                    row.requestedLevel = -1;
                }
                boolean isRingStream = row.stream == 2;
                boolean isSystemStream = row.stream == 1;
                boolean isAlarmStream = row.stream == 4;
                boolean isMusicStream = row.stream == 3;
                if (isRingStream) {
                    i = this.mState.ringerModeInternal;
                    if (r0 == 1) {
                        isRingVibrate = true;
                        if (isRingStream) {
                            if (this.mState.ringerModeInternal == 0) {
                                isRingSilent = true;
                                i = this.mState.zenMode;
                                isZenAlarms = r0 != 3;
                                i = this.mState.zenMode;
                                isZenNone = r0 != 2;
                                i = this.mState.zenMode;
                                isZenPriority = r0 != 1;
                                isRingZenNone = (isRingStream || isSystemStream) && isZenNone;
                                isRingLimited = isRingStream && isZenPriority;
                                zenMuted = isZenAlarms ? isRingStream || isSystemStream : isZenNone ? isRingStream || isSystemStream || isAlarmStream || isMusicStream : false;
                                max = ss.levelMax * 100;
                                if (max != row.slider.getMax()) {
                                    row.slider.setMax(max);
                                }
                                updateVolumeRowHeaderVisibleH(row);
                                text = ss.name;
                                if (this.mShowHeaders) {
                                    if (isRingZenNone) {
                                        context = this.mContext;
                                        objArr = new Object[1];
                                        objArr[0] = ss.name;
                                        text = context.getString(2131362336, objArr);
                                    } else if (!isRingVibrate && isRingLimited) {
                                        context = this.mContext;
                                        objArr = new Object[1];
                                        objArr[0] = ss.name;
                                        text = context.getString(2131362338, objArr);
                                    } else if (isRingVibrate) {
                                        context = this.mContext;
                                        objArr = new Object[1];
                                        objArr[0] = ss.name;
                                        text = context.getString(2131362334, objArr);
                                    } else if (!ss.muted || (this.mAutomute && ss.level == 0)) {
                                        context = this.mContext;
                                        objArr = new Object[1];
                                        objArr[0] = ss.name;
                                        text = context.getString(2131362333, objArr);
                                    } else if (isRingLimited) {
                                        context = this.mContext;
                                        objArr = new Object[1];
                                        objArr[0] = ss.name;
                                        text = context.getString(2131362337, objArr);
                                    }
                                }
                                Util.setText(row.header, text);
                                iconEnabled = (this.mAutomute || ss.muteSupported) && !zenMuted;
                                row.icon.setEnabled(iconEnabled);
                                row.icon.setAlpha(iconEnabled ? 1.0f : 0.5f);
                                iconRes = isRingVibrate ? 2130837736 : (isRingSilent || zenMuted) ? row.cachedIconRes : ss.routedToBluetooth ? ss.muted ? 2130837730 : 2130837729 : (this.mAutomute && ss.level == 0) ? row.iconMuteRes : ss.muted ? row.iconMuteRes : row.iconRes;
                                if (iconRes != row.cachedIconRes) {
                                    if (row.cachedIconRes != 0 && isRingVibrate) {
                                        this.mController.vibrate();
                                    }
                                    row.cachedIconRes = iconRes;
                                    row.icon.setImageResource(iconRes);
                                }
                                i = iconRes != 2130837736 ? 3 : (iconRes != 2130837730 || iconRes == row.iconMuteRes) ? 2 : (iconRes == 2130837729 || iconRes == row.iconRes) ? 1 : 0;
                                row.iconState = i;
                                row.icon.setContentDescription(ss.name);
                                enableSlider = zenMuted;
                                vlevel = (row.ss.muted || (!isRingVibrate && (isRingStream || zenMuted))) ? row.ss.level : 0;
                                updateVolumeRowSliderH(row, enableSlider, vlevel);
                            }
                        }
                        isRingSilent = false;
                        i = this.mState.zenMode;
                        if (r0 != 3) {
                        }
                        i = this.mState.zenMode;
                        if (r0 != 2) {
                        }
                        i = this.mState.zenMode;
                        if (r0 != 1) {
                        }
                        if (!isRingStream) {
                        }
                        if (!isRingStream) {
                        }
                        if (isZenAlarms) {
                            if (!isRingStream) {
                            }
                        }
                        max = ss.levelMax * 100;
                        if (max != row.slider.getMax()) {
                            row.slider.setMax(max);
                        }
                        updateVolumeRowHeaderVisibleH(row);
                        text = ss.name;
                        if (this.mShowHeaders) {
                            if (isRingZenNone) {
                                context = this.mContext;
                                objArr = new Object[1];
                                objArr[0] = ss.name;
                                text = context.getString(2131362336, objArr);
                            } else {
                                if (!isRingVibrate) {
                                }
                                if (isRingVibrate) {
                                    context = this.mContext;
                                    objArr = new Object[1];
                                    objArr[0] = ss.name;
                                    text = context.getString(2131362334, objArr);
                                } else {
                                    if (ss.muted) {
                                    }
                                    context = this.mContext;
                                    objArr = new Object[1];
                                    objArr[0] = ss.name;
                                    text = context.getString(2131362333, objArr);
                                }
                            }
                        }
                        Util.setText(row.header, text);
                        if (!this.mAutomute) {
                        }
                        row.icon.setEnabled(iconEnabled);
                        if (iconEnabled) {
                        }
                        row.icon.setAlpha(iconEnabled ? 1.0f : 0.5f);
                        if (isRingVibrate) {
                        }
                        if (iconRes != row.cachedIconRes) {
                            this.mController.vibrate();
                            row.cachedIconRes = iconRes;
                            row.icon.setImageResource(iconRes);
                        }
                        if (iconRes != 2130837736) {
                            if (iconRes != 2130837730) {
                            }
                        }
                        row.iconState = i;
                        row.icon.setContentDescription(ss.name);
                        if (zenMuted) {
                        }
                        if (row.ss.muted) {
                        }
                        updateVolumeRowSliderH(row, enableSlider, vlevel);
                    }
                }
                isRingVibrate = false;
                if (isRingStream) {
                    if (this.mState.ringerModeInternal == 0) {
                        isRingSilent = true;
                        i = this.mState.zenMode;
                        if (r0 != 3) {
                        }
                        i = this.mState.zenMode;
                        if (r0 != 2) {
                        }
                        i = this.mState.zenMode;
                        if (r0 != 1) {
                        }
                        if (isRingStream) {
                        }
                        if (isRingStream) {
                        }
                        if (isZenAlarms) {
                            if (isRingStream) {
                            }
                        }
                        max = ss.levelMax * 100;
                        if (max != row.slider.getMax()) {
                            row.slider.setMax(max);
                        }
                        updateVolumeRowHeaderVisibleH(row);
                        text = ss.name;
                        if (this.mShowHeaders) {
                            if (isRingZenNone) {
                                context = this.mContext;
                                objArr = new Object[1];
                                objArr[0] = ss.name;
                                text = context.getString(2131362336, objArr);
                            } else {
                                if (!isRingVibrate) {
                                }
                                if (isRingVibrate) {
                                    context = this.mContext;
                                    objArr = new Object[1];
                                    objArr[0] = ss.name;
                                    text = context.getString(2131362334, objArr);
                                } else {
                                    if (ss.muted) {
                                    }
                                    context = this.mContext;
                                    objArr = new Object[1];
                                    objArr[0] = ss.name;
                                    text = context.getString(2131362333, objArr);
                                }
                            }
                        }
                        Util.setText(row.header, text);
                        if (this.mAutomute) {
                        }
                        row.icon.setEnabled(iconEnabled);
                        if (iconEnabled) {
                        }
                        row.icon.setAlpha(iconEnabled ? 1.0f : 0.5f);
                        if (isRingVibrate) {
                        }
                        if (iconRes != row.cachedIconRes) {
                            this.mController.vibrate();
                            row.cachedIconRes = iconRes;
                            row.icon.setImageResource(iconRes);
                        }
                        if (iconRes != 2130837736) {
                        }
                        row.iconState = i;
                        row.icon.setContentDescription(ss.name);
                        if (zenMuted) {
                        }
                        if (row.ss.muted) {
                        }
                        updateVolumeRowSliderH(row, enableSlider, vlevel);
                    }
                }
                isRingSilent = false;
                i = this.mState.zenMode;
                if (r0 != 3) {
                }
                i = this.mState.zenMode;
                if (r0 != 2) {
                }
                i = this.mState.zenMode;
                if (r0 != 1) {
                }
                if (isRingStream) {
                }
                if (isRingStream) {
                }
                if (isZenAlarms) {
                    if (isZenNone) {
                    }
                }
                max = ss.levelMax * 100;
                if (max != row.slider.getMax()) {
                    row.slider.setMax(max);
                }
                updateVolumeRowHeaderVisibleH(row);
                text = ss.name;
                if (this.mShowHeaders) {
                    if (isRingZenNone) {
                        if (!isRingVibrate) {
                        }
                        if (isRingVibrate) {
                            if (ss.muted) {
                            }
                            context = this.mContext;
                            objArr = new Object[1];
                            objArr[0] = ss.name;
                            text = context.getString(2131362333, objArr);
                        } else {
                            context = this.mContext;
                            objArr = new Object[1];
                            objArr[0] = ss.name;
                            text = context.getString(2131362334, objArr);
                        }
                    } else {
                        context = this.mContext;
                        objArr = new Object[1];
                        objArr[0] = ss.name;
                        text = context.getString(2131362336, objArr);
                    }
                }
                Util.setText(row.header, text);
                if (this.mAutomute) {
                }
                row.icon.setEnabled(iconEnabled);
                if (iconEnabled) {
                }
                row.icon.setAlpha(iconEnabled ? 1.0f : 0.5f);
                if (isRingVibrate) {
                    if (isRingSilent) {
                    }
                }
                if (iconRes != row.cachedIconRes) {
                    this.mController.vibrate();
                    row.cachedIconRes = iconRes;
                    row.icon.setImageResource(iconRes);
                }
                if (iconRes != 2130837736) {
                    if (iconRes != 2130837730) {
                    }
                }
                row.iconState = i;
                row.icon.setContentDescription(ss.name);
                if (zenMuted) {
                }
                if (row.ss.muted) {
                }
                updateVolumeRowSliderH(row, enableSlider, vlevel);
            }
        }
    }

    private void updateVolumeRowHeaderVisibleH(VolumeRow row) {
        boolean showHeaders;
        boolean dynamic;
        if (row.ss == null || !row.ss.dynamic) {
            dynamic = false;
        } else {
            dynamic = true;
        }
        if (this.mShowHeaders || (this.mExpanded && dynamic)) {
            showHeaders = true;
        } else {
            showHeaders = false;
        }
        if (row.cachedShowHeaders != showHeaders) {
            row.cachedShowHeaders = showHeaders;
            Util.setVisOrGone(row.header, showHeaders);
        }
    }

    private void updateVolumeRowSliderTintH(VolumeRow row, boolean isActive) {
        if (isActive && this.mExpanded) {
            row.slider.requestFocus();
        }
        ColorStateList tint = (isActive && row.slider.isEnabled()) ? this.mActiveSliderTint : this.mInactiveSliderTint;
        if (tint != row.cachedSliderTint) {
            row.cachedSliderTint = tint;
            row.slider.setProgressTintList(tint);
            row.slider.setThumbTintList(tint);
        }
    }

    private void updateVolumeRowSliderH(VolumeRow row, boolean enable, int vlevel) {
        row.slider.setEnabled(enable);
        updateVolumeRowSliderTintH(row, row.stream == this.mActiveStream);
        if (!row.tracking) {
            int progress = row.slider.getProgress();
            int level = getImpliedLevel(row.slider, progress);
            boolean rowVisible = row.view.getVisibility() == 0;
            boolean inGracePeriod = SystemClock.uptimeMillis() - row.userAttempt < 1000;
            this.mHandler.removeMessages(3, row);
            if (this.mShowing && rowVisible && inGracePeriod) {
                if (C0543D.BUG) {
                    Log.d(TAG, "inGracePeriod");
                }
                this.mHandler.sendMessageAtTime(this.mHandler.obtainMessage(3, row), row.userAttempt + 1000);
            } else if (vlevel != level || !this.mShowing || !rowVisible) {
                int newProgress = vlevel * 100;
                if (progress == newProgress) {
                    return;
                }
                if (!this.mShowing || !rowVisible) {
                    if (row.anim != null) {
                        row.anim.cancel();
                    }
                    row.slider.setProgress(newProgress);
                } else if (row.anim == null || !row.anim.isRunning() || row.animTargetProgress != newProgress) {
                    if (row.anim == null) {
                        row.anim = ObjectAnimator.ofInt(row.slider, "progress", new int[]{progress, newProgress});
                        row.anim.setInterpolator(new DecelerateInterpolator());
                    } else {
                        row.anim.cancel();
                        row.anim.setIntValues(new int[]{progress, newProgress});
                    }
                    row.animTargetProgress = newProgress;
                    row.anim.setDuration(80);
                    row.anim.start();
                }
            }
        }
    }

    private void recheckH(VolumeRow row) {
        if (row == null) {
            if (C0543D.BUG) {
                Log.d(TAG, "recheckH ALL");
            }
            trimObsoleteH();
            for (VolumeRow r : this.mRows) {
                updateVolumeRowH(r);
            }
            return;
        }
        if (C0543D.BUG) {
            Log.d(TAG, "recheckH " + row.stream);
        }
        updateVolumeRowH(row);
    }

    private void setStreamImportantH(int stream, boolean important) {
        for (VolumeRow row : this.mRows) {
            if (row.stream == stream) {
                row.important = important;
                return;
            }
        }
    }

    private void showSafetyWarningH(int flags) {
        if ((flags & 1025) != 0 || this.mShowing) {
            synchronized (this.mSafetyWarningLock) {
                if (this.mSafetyWarning != null) {
                    return;
                }
                this.mSafetyWarning = new C05617(this.mContext, this.mController.getAudioManager());
                this.mSafetyWarning.show();
                recheckH(null);
            }
        }
        rescheduleTimeoutH();
    }

    public void cleanup() {
        this.mController.removeCallback(this.mControllerCallbackH);
        this.mZenFooter.cleanup();
        this.mAccessibility.cleanup();
    }
}
