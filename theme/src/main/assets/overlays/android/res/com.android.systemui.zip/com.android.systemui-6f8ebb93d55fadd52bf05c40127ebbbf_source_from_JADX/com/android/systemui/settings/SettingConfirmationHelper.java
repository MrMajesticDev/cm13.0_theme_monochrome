package com.android.systemui.settings;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings.Secure;
import android.util.Log;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.SettingConfirmationSnackbarView;

public final class SettingConfirmationHelper {

    /* renamed from: com.android.systemui.settings.SettingConfirmationHelper.1 */
    static class C02691 implements Runnable {
        final /* synthetic */ OnSettingChoiceListener val$listener;
        final /* synthetic */ String val$settingName;

        C02691(OnSettingChoiceListener onSettingChoiceListener, String str) {
            this.val$listener = onSettingChoiceListener;
            this.val$settingName = str;
        }

        public void run() {
            this.val$listener.onSettingConfirm(this.val$settingName);
        }
    }

    /* renamed from: com.android.systemui.settings.SettingConfirmationHelper.2 */
    static class C02702 implements Runnable {
        final /* synthetic */ OnSettingChoiceListener val$listener;
        final /* synthetic */ String val$settingName;

        C02702(OnSettingChoiceListener onSettingChoiceListener, String str) {
            this.val$listener = onSettingChoiceListener;
            this.val$settingName = str;
        }

        public void run() {
            this.val$listener.onSettingDeny(this.val$settingName);
        }
    }

    /* renamed from: com.android.systemui.settings.SettingConfirmationHelper.3 */
    static class C02713 implements Runnable {
        final /* synthetic */ boolean val$defaultValue;
        final /* synthetic */ OnSettingChoiceListener val$listener;
        final /* synthetic */ String val$settingName;

        C02713(boolean z, OnSettingChoiceListener onSettingChoiceListener, String str) {
            this.val$defaultValue = z;
            this.val$listener = onSettingChoiceListener;
            this.val$settingName = str;
        }

        public void run() {
            if (this.val$defaultValue) {
                this.val$listener.onSettingConfirm(this.val$settingName);
            } else {
                this.val$listener.onSettingDeny(this.val$settingName);
            }
        }
    }

    public interface OnSettingChoiceListener {
        void onSettingConfirm(String str);

        void onSettingDeny(String str);
    }

    /* renamed from: com.android.systemui.settings.SettingConfirmationHelper.4 */
    static class C02724 implements OnSettingChoiceListener {
        final /* synthetic */ boolean val$defaultValue;
        final /* synthetic */ OnSettingChoiceListener val$listener;
        final /* synthetic */ ContentResolver val$resolver;
        final /* synthetic */ String val$settingName;

        C02724(String str, ContentResolver contentResolver, boolean z, OnSettingChoiceListener onSettingChoiceListener) {
            this.val$settingName = str;
            this.val$resolver = contentResolver;
            this.val$defaultValue = z;
            this.val$listener = onSettingChoiceListener;
        }

        public void onSettingConfirm(String settingNameTest) {
            if (settingNameTest.equals(this.val$settingName)) {
                SettingConfirmationHelper.setSetting(this.val$resolver, this.val$settingName, 1);
                if (this.val$defaultValue) {
                    this.val$listener.onSettingConfirm(this.val$settingName);
                    return;
                }
                return;
            }
            Log.w("SettingConfirmation", this.val$settingName + ": Ignoring unexpected confirmation");
        }

        public void onSettingDeny(String settingNameTest) {
            if (settingNameTest.equals(this.val$settingName)) {
                SettingConfirmationHelper.setSetting(this.val$resolver, this.val$settingName, 2);
                if (this.val$defaultValue) {
                    this.val$listener.onSettingDeny(this.val$settingName);
                    return;
                }
                return;
            }
            Log.w("SettingConfirmation", this.val$settingName + ": Ignoring unexpected denial");
        }
    }

    private static int getSetting(ContentResolver resolver, String settingName) {
        return Secure.getIntForUser(resolver, settingName, 0, ActivityManager.getCurrentUser());
    }

    private static void setSetting(ContentResolver resolver, String settingName, int settingValue) {
        Secure.putIntForUser(resolver, settingName, settingValue, ActivityManager.getCurrentUser());
    }

    public static boolean get(ContentResolver resolver, String settingName, boolean fallback) {
        if (resolver == null) {
            throw new IllegalArgumentException("resolver == null");
        } else if (settingName == null) {
            throw new IllegalArgumentException("settingName == null");
        } else {
            switch (getSetting(resolver, settingName)) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    return true;
                case 2:
                    return false;
                default:
                    return fallback;
            }
        }
    }

    public static void prompt(SettingConfirmationSnackbarView snackbar, String settingName, boolean defaultValue, String message, OnSettingChoiceListener listener, Handler handler) {
        if (snackbar == null) {
            throw new IllegalArgumentException("snackbar == null");
        } else if (settingName == null) {
            throw new IllegalArgumentException("settingName == null");
        } else if (message == null) {
            throw new IllegalArgumentException("message == null");
        } else if (listener == null) {
            throw new IllegalArgumentException("listener == null");
        } else {
            if (handler == null) {
                handler = new Handler(Looper.getMainLooper());
            }
            ContentResolver resolver = snackbar.getContext().getContentResolver();
            switch (getSetting(resolver, settingName)) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    handler.post(new C02691(listener, settingName));
                case 2:
                    handler.post(new C02702(listener, settingName));
                default:
                    handler.post(new C02713(defaultValue, listener, settingName));
                    snackbar.show(settingName, message, new C02724(settingName, resolver, defaultValue, listener), handler);
            }
        }
    }
}
