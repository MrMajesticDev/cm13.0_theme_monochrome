package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.ResourceIcon;
import com.android.systemui.statusbar.policy.KeyguardMonitor;
import com.android.systemui.statusbar.policy.LocationController;
import com.android.systemui.statusbar.policy.LocationController.LocationSettingsChangeCallback;
import com.android.systemui.volume.SegmentedButtons;
import java.util.ArrayList;
import java.util.List;

public class LocationTile extends QSTile<BooleanState> {
    public static final Integer[] LOCATION_SETTINGS;
    private static final Intent LOCATION_SETTINGS_INTENT;
    private final Callback mCallback;
    private final LocationController mController;
    private final LocationDetailAdapter mDetailAdapter;
    private final AnimationIcon mDisable;
    private final AnimationIcon mEnable;
    private final KeyguardMonitor mKeyguard;
    private int mLastState;
    private final List<Integer> mLocationList;

    private final class Callback implements com.android.systemui.statusbar.policy.KeyguardMonitor.Callback, LocationSettingsChangeCallback {
        private Callback() {
        }

        public void onLocationSettingsChanged(boolean enabled) {
            LocationTile.this.refreshState();
        }

        public void onKeyguardChanged() {
            LocationTile.this.refreshState();
        }
    }

    private class LocationDetailAdapter implements OnItemClickListener, DetailAdapter {
        private SegmentedButtons mButtons;
        private final com.android.systemui.volume.SegmentedButtons.Callback mButtonsCallback;
        private ViewGroup mMessageContainer;
        private TextView mMessageText;

        /* renamed from: com.android.systemui.qs.tiles.LocationTile.LocationDetailAdapter.1 */
        class C01971 implements com.android.systemui.volume.SegmentedButtons.Callback {
            C01971() {
            }

            public void onSelected(Object value, boolean fromClick) {
                if (value != null && LocationDetailAdapter.this.mButtons.isShown()) {
                    LocationTile.this.mLastState = ((Integer) value).intValue();
                    if (fromClick) {
                        MetricsLogger.action(LocationTile.this.mContext, 122, LocationTile.this.mLastState);
                        LocationDetailAdapter.this.refresh(LocationTile.this.mLastState);
                    }
                }
            }

            public void onInteraction() {
            }
        }

        private LocationDetailAdapter() {
            this.mButtonsCallback = new C01971();
        }

        public int getMetricsCategory() {
            return 260;
        }

        public int getTitle() {
            return 2131361918;
        }

        public Boolean getToggleState() {
            return Boolean.valueOf(((BooleanState) LocationTile.this.mState).value);
        }

        public Intent getSettingsIntent() {
            return LocationTile.LOCATION_SETTINGS_INTENT;
        }

        public void setToggleState(boolean state) {
            LocationTile.this.mController.setLocationEnabled(state);
            LocationTile.this.showDetail(false);
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            LinearLayout details = convertView != null ? (LinearLayout) convertView : (LinearLayout) LayoutInflater.from(context).inflate(2130968600, parent, false);
            LocationTile.this.mLastState = LocationTile.this.mController.getLocationCurrentState();
            if (convertView == null) {
                this.mButtons = (SegmentedButtons) details.findViewById(2131755150);
                this.mButtons.addButton(2131361917, 2131361916, Integer.valueOf(3));
                this.mButtons.addButton(2131361913, 2131361912, Integer.valueOf(2));
                this.mButtons.addButton(2131361915, 2131361914, Integer.valueOf(1));
                this.mButtons.setCallback(this.mButtonsCallback);
                this.mMessageContainer = (ViewGroup) details.findViewById(2131755151);
                this.mMessageText = (TextView) details.findViewById(2131755152);
                this.mButtons.setSelectedValue(Integer.valueOf(LocationTile.this.mLastState), false);
            }
            return details;
        }

        private void refresh(int state) {
            LocationTile.this.mController.setLocationMode(LocationTile.this.mLastState);
            switch (state) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    this.mMessageText.setText(LocationTile.this.mContext.getString(2131361925));
                    this.mMessageContainer.setVisibility(0);
                case 2:
                    this.mMessageText.setText(LocationTile.this.mContext.getString(2131361924));
                    this.mMessageContainer.setVisibility(0);
                case 3:
                    this.mMessageText.setText(LocationTile.this.mContext.getString(2131361923));
                    this.mMessageContainer.setVisibility(0);
                default:
                    this.mMessageContainer.setVisibility(8);
            }
        }

        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            LocationTile.this.mController.setLocationMode(((Integer) parent.getItemAtPosition(position)).intValue());
        }
    }

    static {
        LOCATION_SETTINGS_INTENT = new Intent("android.settings.LOCATION_SOURCE_SETTINGS");
        LOCATION_SETTINGS = new Integer[]{Integer.valueOf(3), Integer.valueOf(2), Integer.valueOf(1)};
    }

    public LocationTile(Host host) {
        super(host, "location");
        this.mEnable = new AnimationIcon(2130837709);
        this.mDisable = new AnimationIcon(2130837707);
        this.mLocationList = new ArrayList();
        this.mCallback = new Callback();
        this.mController = host.getLocationController();
        this.mDetailAdapter = new LocationDetailAdapter();
        this.mKeyguard = host.getKeyguardMonitor();
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void setListening(boolean listening) {
        if (listening) {
            this.mController.addSettingsChangedCallback(this.mCallback);
            this.mKeyguard.addCallback(this.mCallback);
            return;
        }
        this.mController.removeSettingsChangedCallback(this.mCallback);
        this.mKeyguard.removeCallback(this.mCallback);
    }

    protected void handleToggleClick() {
        boolean z;
        boolean z2 = false;
        boolean wasEnabled = ((BooleanState) this.mState).value;
        Context context = this.mContext;
        int metricsCategory = getMetricsCategory();
        if (wasEnabled) {
            z = false;
        } else {
            z = true;
        }
        MetricsLogger.action(context, metricsCategory, z);
        LocationController locationController = this.mController;
        if (!wasEnabled) {
            z2 = true;
        }
        locationController.setLocationEnabled(z2);
        this.mEnable.setAllowAnimation(true);
        this.mDisable.setAllowAnimation(true);
    }

    protected void handleDetailClick() {
        if (!((BooleanState) this.mState).value) {
            ((BooleanState) this.mState).value = true;
            this.mController.setLocationEnabled(true);
        }
        showDetail(true);
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        boolean locationEnabled;
        boolean z = true;
        int currentState = this.mController.getLocationCurrentState();
        if (currentState != 0) {
            locationEnabled = true;
        } else {
            locationEnabled = false;
        }
        if (this.mKeyguard.isShowing()) {
            z = false;
        }
        state.visible = z;
        state.value = locationEnabled;
        state.label = this.mContext.getString(getStateLabelRes(currentState));
        switch (currentState) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                state.contentDescription = this.mContext.getString(2131362126);
                state.icon = this.mDisable;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                state.contentDescription = this.mContext.getString(2131361910);
                state.icon = ResourceIcon.get(2130837639);
            case 2:
                state.contentDescription = this.mContext.getString(2131361909);
                state.icon = ResourceIcon.get(2130837638);
            case 3:
                state.contentDescription = this.mContext.getString(2131361911);
                state.icon = this.mEnable;
            default:
                state.contentDescription = this.mContext.getString(2131362127);
        }
    }

    private int getStateLabelRes(int currentState) {
        switch (currentState) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                return 2131362182;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return 2131361914;
            case 2:
                return 2131361912;
            case 3:
                return 2131361916;
            default:
                return 2131362181;
        }
    }

    public int getMetricsCategory() {
        return 122;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131362129);
        }
        return this.mContext.getString(2131362128);
    }
}
