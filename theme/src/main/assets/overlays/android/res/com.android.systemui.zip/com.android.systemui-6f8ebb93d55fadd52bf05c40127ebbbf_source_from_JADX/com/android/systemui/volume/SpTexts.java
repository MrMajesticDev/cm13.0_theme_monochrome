package com.android.systemui.volume;

import android.content.Context;
import android.content.res.Resources;
import android.util.ArrayMap;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.widget.TextView;

public class SpTexts {
    private final Context mContext;
    private final ArrayMap<TextView, Integer> mTexts;
    private final Runnable mUpdateAll;

    /* renamed from: com.android.systemui.volume.SpTexts.1 */
    class C05521 implements OnAttachStateChangeListener {
        final /* synthetic */ int val$sp;
        final /* synthetic */ TextView val$text;

        C05521(TextView textView, int i) {
            this.val$text = textView;
            this.val$sp = i;
        }

        public void onViewDetachedFromWindow(View v) {
        }

        public void onViewAttachedToWindow(View v) {
            SpTexts.this.setTextSizeH(this.val$text, this.val$sp);
        }
    }

    /* renamed from: com.android.systemui.volume.SpTexts.2 */
    class C05532 implements Runnable {
        C05532() {
        }

        public void run() {
            for (int i = 0; i < SpTexts.this.mTexts.size(); i++) {
                SpTexts.this.setTextSizeH((TextView) SpTexts.this.mTexts.keyAt(i), ((Integer) SpTexts.this.mTexts.valueAt(i)).intValue());
            }
        }
    }

    public SpTexts(Context context) {
        this.mTexts = new ArrayMap();
        this.mUpdateAll = new C05532();
        this.mContext = context;
    }

    public int add(TextView text) {
        if (text == null) {
            return 0;
        }
        Resources res = this.mContext.getResources();
        float fontScale = res.getConfiguration().fontScale;
        int sp = (int) ((text.getTextSize() / fontScale) / res.getDisplayMetrics().density);
        this.mTexts.put(text, Integer.valueOf(sp));
        text.addOnAttachStateChangeListener(new C05521(text, sp));
        return sp;
    }

    public void update() {
        if (!this.mTexts.isEmpty()) {
            ((TextView) this.mTexts.keyAt(0)).post(this.mUpdateAll);
        }
    }

    private void setTextSizeH(TextView text, int sp) {
        text.setTextSize(2, (float) sp);
    }
}
