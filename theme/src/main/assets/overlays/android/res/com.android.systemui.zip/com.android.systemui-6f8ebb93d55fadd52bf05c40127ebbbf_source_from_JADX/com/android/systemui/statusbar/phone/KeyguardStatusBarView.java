package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.android.systemui.BatteryLevelTextView;
import com.android.systemui.BatteryMeterView;
import com.android.systemui.statusbar.policy.BatteryController;
import com.android.systemui.statusbar.policy.KeyguardUserSwitcher;
import com.android.systemui.statusbar.policy.UserInfoController;
import com.android.systemui.statusbar.policy.UserInfoController.OnUserInfoChangedListener;
import com.android.systemui.statusbar.policy.UserSwitcherController;

public class KeyguardStatusBarView extends RelativeLayout {
    private BatteryController mBatteryController;
    private BatteryLevelTextView mBatteryLevel;
    private BatteryMeterView mBatteryMeter;
    private TextView mCarrierLabel;
    private Interpolator mFastOutSlowInInterpolator;
    private KeyguardUserSwitcher mKeyguardUserSwitcher;
    private boolean mKeyguardUserSwitcherShowing;
    private ImageView mMultiUserAvatar;
    private MultiUserSwitch mMultiUserSwitch;
    private View mSystemIconsSuperContainer;
    private int mSystemIconsSwitcherHiddenExpandedMargin;
    private OnUserInfoChangedListener mUserInfoChangedListener;
    private UserInfoController mUserInfoController;

    /* renamed from: com.android.systemui.statusbar.phone.KeyguardStatusBarView.1 */
    class C03761 implements OnUserInfoChangedListener {
        C03761() {
        }

        public void onUserInfoChanged(String name, Drawable picture) {
            KeyguardStatusBarView.this.mMultiUserAvatar.setImageDrawable(picture);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.KeyguardStatusBarView.2 */
    class C03782 implements OnPreDrawListener {
        final /* synthetic */ int val$systemIconsCurrentX;
        final /* synthetic */ boolean val$userSwitcherVisible;

        /* renamed from: com.android.systemui.statusbar.phone.KeyguardStatusBarView.2.1 */
        class C03771 implements Runnable {
            C03771() {
            }

            public void run() {
                KeyguardStatusBarView.this.mMultiUserSwitch.setAlpha(1.0f);
                KeyguardStatusBarView.this.getOverlay().remove(KeyguardStatusBarView.this.mMultiUserSwitch);
            }
        }

        C03782(boolean z, int i) {
            this.val$userSwitcherVisible = z;
            this.val$systemIconsCurrentX = i;
        }

        public boolean onPreDraw() {
            long j;
            KeyguardStatusBarView.this.getViewTreeObserver().removeOnPreDrawListener(this);
            boolean userSwitcherHiding = this.val$userSwitcherVisible && KeyguardStatusBarView.this.mMultiUserSwitch.getParent() != KeyguardStatusBarView.this;
            KeyguardStatusBarView.this.mSystemIconsSuperContainer.setX((float) this.val$systemIconsCurrentX);
            ViewPropertyAnimator duration = KeyguardStatusBarView.this.mSystemIconsSuperContainer.animate().translationX(0.0f).setDuration(400);
            if (userSwitcherHiding) {
                j = 300;
            } else {
                j = 0;
            }
            duration.setStartDelay(j).setInterpolator(KeyguardStatusBarView.this.mFastOutSlowInInterpolator).start();
            if (userSwitcherHiding) {
                KeyguardStatusBarView.this.getOverlay().add(KeyguardStatusBarView.this.mMultiUserSwitch);
                KeyguardStatusBarView.this.mMultiUserSwitch.animate().alpha(0.0f).setDuration(300).setStartDelay(0).setInterpolator(PhoneStatusBar.ALPHA_OUT).withEndAction(new C03771()).start();
            } else {
                KeyguardStatusBarView.this.mMultiUserSwitch.setAlpha(0.0f);
                KeyguardStatusBarView.this.mMultiUserSwitch.animate().alpha(1.0f).setDuration(300).setStartDelay(200).setInterpolator(PhoneStatusBar.ALPHA_IN);
            }
            return true;
        }
    }

    public KeyguardStatusBarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mUserInfoChangedListener = new C03761();
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mSystemIconsSuperContainer = findViewById(2131755139);
        this.mMultiUserSwitch = (MultiUserSwitch) findViewById(2131755137);
        this.mMultiUserAvatar = (ImageView) findViewById(2131755138);
        this.mBatteryMeter = (BatteryMeterView) findViewById(2131755334);
        this.mBatteryLevel = (BatteryLevelTextView) findViewById(2131755141);
        this.mCarrierLabel = (TextView) findViewById(2131755142);
        loadDimens();
        this.mFastOutSlowInInterpolator = AnimationUtils.loadInterpolator(getContext(), 17563661);
        updateUserSwitcher();
        updateVisibilities();
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.mCarrierLabel.setTextSize(0, (float) getResources().getDimensionPixelSize(17105140));
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mUserInfoController != null) {
            this.mUserInfoController.removeListener(this.mUserInfoChangedListener);
        }
    }

    private void loadDimens() {
        this.mSystemIconsSwitcherHiddenExpandedMargin = getResources().getDimensionPixelSize(2131296401);
    }

    private void updateVisibilities() {
        int i = 0;
        if (this.mMultiUserSwitch.getParent() != this && !this.mKeyguardUserSwitcherShowing) {
            if (this.mMultiUserSwitch.getParent() != null) {
                getOverlay().remove(this.mMultiUserSwitch);
            }
            addView(this.mMultiUserSwitch, 0);
        } else if (this.mMultiUserSwitch.getParent() == this && this.mKeyguardUserSwitcherShowing) {
            removeView(this.mMultiUserSwitch);
        }
        this.mBatteryLevel.setVisibility(0);
        boolean showCarrierText = getResources().getBoolean(2131558432);
        TextView textView = this.mCarrierLabel;
        if (!showCarrierText) {
            i = 8;
        }
        textView.setVisibility(i);
    }

    private void updateSystemIconsLayoutParams() {
        LayoutParams lp = (LayoutParams) this.mSystemIconsSuperContainer.getLayoutParams();
        int marginEnd = this.mKeyguardUserSwitcherShowing ? this.mSystemIconsSwitcherHiddenExpandedMargin : 0;
        if (marginEnd != lp.getMarginEnd()) {
            lp.setMarginEnd(marginEnd);
            this.mSystemIconsSuperContainer.setLayoutParams(lp);
        }
    }

    private void updateUserSwitcher() {
        boolean keyguardSwitcherAvailable = this.mKeyguardUserSwitcher != null;
        this.mMultiUserSwitch.setClickable(keyguardSwitcherAvailable);
        this.mMultiUserSwitch.setFocusable(keyguardSwitcherAvailable);
        this.mMultiUserSwitch.setKeyguardMode(keyguardSwitcherAvailable);
    }

    public void setBatteryController(BatteryController batteryController) {
        this.mBatteryController = batteryController;
        this.mBatteryMeter.setBatteryController(batteryController);
        this.mBatteryMeter.setChargingAnimationsEnabled(true);
        this.mBatteryLevel.setBatteryController(batteryController);
    }

    public void setUserSwitcherController(UserSwitcherController controller) {
        this.mMultiUserSwitch.setUserSwitcherController(controller);
    }

    public void setUserInfoController(UserInfoController userInfoController) {
        this.mUserInfoController = userInfoController;
        userInfoController.addListener(this.mUserInfoChangedListener);
    }

    public void setKeyguardUserSwitcher(KeyguardUserSwitcher keyguardUserSwitcher) {
        this.mKeyguardUserSwitcher = keyguardUserSwitcher;
        this.mMultiUserSwitch.setKeyguardUserSwitcher(keyguardUserSwitcher);
        updateUserSwitcher();
    }

    public void setKeyguardUserSwitcherShowing(boolean showing, boolean animate) {
        this.mKeyguardUserSwitcherShowing = showing;
        if (animate) {
            animateNextLayoutChange();
        }
        updateVisibilities();
        updateSystemIconsLayoutParams();
    }

    private void animateNextLayoutChange() {
        getViewTreeObserver().addOnPreDrawListener(new C03782(this.mMultiUserSwitch.getParent() == this, this.mSystemIconsSuperContainer.getLeft()));
    }

    public void setVisibility(int visibility) {
        super.setVisibility(visibility);
        if (visibility != 0) {
            this.mSystemIconsSuperContainer.animate().cancel();
            this.mMultiUserSwitch.animate().cancel();
            this.mMultiUserSwitch.setAlpha(1.0f);
        }
    }

    public boolean hasOverlappingRendering() {
        return false;
    }
}
