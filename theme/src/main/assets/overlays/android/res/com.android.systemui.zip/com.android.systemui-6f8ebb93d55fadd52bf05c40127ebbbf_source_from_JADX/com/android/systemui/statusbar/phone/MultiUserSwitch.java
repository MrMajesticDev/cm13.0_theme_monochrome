package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.os.UserHandle;
import android.os.UserManager;
import android.provider.ContactsContract.Profile;
import android.provider.ContactsContract.QuickContact;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.android.systemui.qs.QSPanel;
import com.android.systemui.statusbar.policy.KeyguardUserSwitcher;
import com.android.systemui.statusbar.policy.UserSwitcherController;
import com.android.systemui.statusbar.policy.UserSwitcherController.BaseUserAdapter;

public class MultiUserSwitch extends FrameLayout implements OnClickListener {
    private boolean mKeyguardMode;
    private KeyguardUserSwitcher mKeyguardUserSwitcher;
    private QSPanel mQsPanel;
    private final int[] mTmpInt2;
    private BaseUserAdapter mUserListener;
    final UserManager mUserManager;
    private UserSwitcherController mUserSwitcherController;

    /* renamed from: com.android.systemui.statusbar.phone.MultiUserSwitch.1 */
    class C03791 extends BaseUserAdapter {
        C03791(UserSwitcherController x0) {
            super(x0);
        }

        public void notifyDataSetChanged() {
            MultiUserSwitch.this.refreshContentDescription();
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            return null;
        }
    }

    public MultiUserSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mTmpInt2 = new int[2];
        this.mUserManager = UserManager.get(getContext());
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        setOnClickListener(this);
        refreshContentDescription();
    }

    public void setQsPanel(QSPanel qsPanel) {
        this.mQsPanel = qsPanel;
        setUserSwitcherController(qsPanel.getHost().getUserSwitcherController());
    }

    public void setUserSwitcherController(UserSwitcherController userSwitcherController) {
        this.mUserSwitcherController = userSwitcherController;
        registerListener();
        refreshContentDescription();
    }

    public void setKeyguardUserSwitcher(KeyguardUserSwitcher keyguardUserSwitcher) {
        this.mKeyguardUserSwitcher = keyguardUserSwitcher;
    }

    public void setKeyguardMode(boolean keyguardShowing) {
        this.mKeyguardMode = keyguardShowing;
        registerListener();
    }

    private void registerListener() {
        if (UserSwitcherController.isUserSwitcherAvailable(this.mUserManager) && this.mUserListener == null) {
            UserSwitcherController controller = this.mUserSwitcherController;
            if (controller != null) {
                this.mUserListener = new C03791(controller);
                refreshContentDescription();
            }
        }
    }

    public void onClick(View v) {
        if (!UserSwitcherController.isUserSwitcherAvailable(this.mUserManager)) {
            getContext().startActivityAsUser(QuickContact.composeQuickContactsIntent(getContext(), v, Profile.CONTENT_URI, 3, null), new UserHandle(-2));
            if (this.mQsPanel != null) {
                this.mQsPanel.getHost().collapsePanels();
            }
        } else if (this.mKeyguardMode) {
            if (this.mKeyguardUserSwitcher != null) {
                this.mKeyguardUserSwitcher.show(true);
            }
        } else if (this.mQsPanel != null && this.mUserSwitcherController != null) {
            View center;
            if (getChildCount() > 0) {
                center = getChildAt(0);
            } else {
                center = this;
            }
            center.getLocationInWindow(this.mTmpInt2);
            int[] iArr = this.mTmpInt2;
            iArr[0] = iArr[0] + (center.getWidth() / 2);
            iArr = this.mTmpInt2;
            iArr[1] = iArr[1] + (center.getHeight() / 2);
            this.mQsPanel.showDetailAdapter(true, this.mUserSwitcherController.userDetailAdapter, this.mTmpInt2);
        }
    }

    public void setClickable(boolean clickable) {
        super.setClickable(clickable);
        refreshContentDescription();
    }

    private void refreshContentDescription() {
        String currentUser = null;
        if (UserSwitcherController.isUserSwitcherAvailable(this.mUserManager) && this.mUserSwitcherController != null) {
            currentUser = this.mUserSwitcherController.getCurrentUserName(this.mContext);
        }
        String text = null;
        if (isClickable()) {
            if (!UserSwitcherController.isUserSwitcherAvailable(this.mUserManager)) {
                text = this.mContext.getString(2131362263);
            } else if (TextUtils.isEmpty(currentUser)) {
                text = this.mContext.getString(2131362260);
            } else {
                text = this.mContext.getString(2131362261, new Object[]{currentUser});
            }
        } else if (!TextUtils.isEmpty(currentUser)) {
            text = this.mContext.getString(2131362262, new Object[]{currentUser});
        }
        if (!TextUtils.equals(getContentDescription(), text)) {
            setContentDescription(text);
        }
    }

    public boolean hasOverlappingRendering() {
        return false;
    }
}
