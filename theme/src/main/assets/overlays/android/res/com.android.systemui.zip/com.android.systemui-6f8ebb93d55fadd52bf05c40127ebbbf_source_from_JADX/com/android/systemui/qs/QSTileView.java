package com.android.systemui.qs;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.MathUtils;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;
import com.android.systemui.FontSizeUtils;
import com.android.systemui.qs.QSTile.State;
import java.util.Objects;

public class QSTileView extends ViewGroup {
    private static final Typeface CONDENSED;
    private OnClickListener mClickPrimary;
    private OnClickListener mClickSecondary;
    protected final Context mContext;
    private final View mDivider;
    private boolean mDual;
    private QSDualTileLabel mDualLabel;
    private final int mDualTileVerticalPaddingPx;
    private final C0173H mHandler;
    private final View mIcon;
    private final int mIconSizePx;
    private TextView mLabel;
    private OnLongClickListener mLongClick;
    private RippleDrawable mRipple;
    private final Drawable mTileBackground;
    private final int mTilePaddingBelowIconPx;
    private int mTilePaddingTopPx;
    private final int mTileSpacingPx;
    private final Drawable mTileTopBackground;
    private final View mTopBackgroundView;
    private RippleDrawable mTopRipple;

    /* renamed from: com.android.systemui.qs.QSTileView.H */
    private class C0173H extends Handler {
        public C0173H() {
            super(Looper.getMainLooper());
        }

        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                QSTileView.this.handleStateChanged((State) msg.obj);
            }
        }
    }

    static {
        CONDENSED = Typeface.create("sans-serif-condensed", 0);
    }

    public QSTileView(Context context) {
        super(context);
        this.mHandler = new C0173H();
        this.mContext = context;
        Resources res = context.getResources();
        this.mIconSizePx = res.getDimensionPixelSize(2131296313);
        this.mTileSpacingPx = res.getDimensionPixelSize(2131296324);
        this.mTilePaddingBelowIconPx = res.getDimensionPixelSize(2131296322);
        this.mDualTileVerticalPaddingPx = res.getDimensionPixelSize(2131296318);
        this.mTileBackground = newTileBackground();
        this.mTileTopBackground = newTileBackground();
        recreateLabel();
        setClipChildren(false);
        this.mTopBackgroundView = new View(context);
        this.mTopBackgroundView.setId(View.generateViewId());
        addView(this.mTopBackgroundView);
        this.mIcon = createIcon();
        addView(this.mIcon);
        this.mDivider = new View(this.mContext);
        this.mDivider.setBackgroundColor(context.getColor(2131427361));
        this.mDivider.setLayoutParams(new LayoutParams(-1, res.getDimensionPixelSize(2131296315)));
        addView(this.mDivider);
        setClickable(true);
        updateTopPadding();
        setId(View.generateViewId());
    }

    private void updateTopPadding() {
        Resources res = getResources();
        float largeFactor = (MathUtils.constrain(getResources().getConfiguration().fontScale, 1.0f, 1.3f) - 1.0f) / 0.29999995f;
        this.mTilePaddingTopPx = Math.round(((1.0f - largeFactor) * ((float) res.getDimensionPixelSize(2131296320))) + (((float) res.getDimensionPixelSize(2131296321)) * largeFactor));
        requestLayout();
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        updateTopPadding();
        FontSizeUtils.updateFontSize(this.mLabel, 2131296314);
        if (this.mDualLabel != null) {
            this.mDualLabel.setTextSize(0, (float) getResources().getDimensionPixelSize(2131296314));
        }
    }

    private synchronized void recreateLabel() {
        boolean z = true;
        synchronized (this) {
            CharSequence labelText;
            CharSequence labelDescription;
            if (this.mDualLabel != null) {
                labelText = this.mDualLabel.getText();
                labelDescription = this.mDualLabel.getContentDescription();
            } else if (this.mLabel != null) {
                labelText = this.mLabel.getText();
                labelDescription = this.mLabel.getContentDescription();
            } else {
                labelText = "";
                labelDescription = "";
            }
            Resources res = this.mContext.getResources();
            if (this.mDual) {
                boolean z2;
                if (this.mLabel != null) {
                    removeView(this.mLabel);
                    this.mLabel = null;
                }
                QSDualTileLabel dualLabel = this.mDualLabel == null ? new QSDualTileLabel(this.mContext) : this.mDualLabel;
                dualLabel.setId(View.generateViewId());
                dualLabel.setBackgroundResource(2130837508);
                dualLabel.setFirstLineCaret(this.mContext.getDrawable(2130837792));
                dualLabel.setTextColor(this.mContext.getColor(2131427362));
                dualLabel.setPadding(0, this.mDualTileVerticalPaddingPx, 0, this.mDualTileVerticalPaddingPx);
                dualLabel.setTypeface(CONDENSED);
                dualLabel.setTextSize(0, (float) res.getDimensionPixelSize(2131296314));
                dualLabel.setOnClickListener(this.mClickSecondary);
                if (this.mClickSecondary != null) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                dualLabel.setClickable(z2);
                dualLabel.setOnLongClickListener(this.mLongClick);
                if (this.mLongClick == null) {
                    z = false;
                }
                dualLabel.setLongClickable(z);
                dualLabel.setFocusable(true);
                dualLabel.setText(labelText);
                dualLabel.setContentDescription(labelDescription);
                if (this.mDualLabel == null) {
                    this.mDualLabel = dualLabel;
                    addView(dualLabel);
                }
            } else {
                if (this.mDualLabel != null) {
                    this.mDualLabel.setOnClickListener(null);
                    this.mDualLabel.setClickable(false);
                    this.mDualLabel.setOnLongClickListener(null);
                    this.mDualLabel.setLongClickable(false);
                    this.mDualLabel.setFocusable(false);
                    removeView(this.mDualLabel);
                    this.mDualLabel = null;
                }
                TextView label = this.mLabel == null ? new TextView(this.mContext) : this.mLabel;
                label.setId(16908310);
                label.setTextColor(this.mContext.getColor(2131427362));
                label.setGravity(1);
                label.setMinLines(2);
                label.setPadding(0, 0, 0, 0);
                label.setTypeface(CONDENSED);
                label.setTextSize(0, (float) res.getDimensionPixelSize(2131296314));
                label.setClickable(false);
                label.setText(labelText);
                label.setContentDescription(labelDescription);
                if (this.mLabel == null) {
                    this.mLabel = label;
                    addView(label);
                }
            }
        }
    }

    public boolean isDual() {
        return this.mDual;
    }

    public synchronized void setDual(boolean dual) {
        boolean changed;
        RippleDrawable rippleDrawable;
        View priority;
        boolean z;
        int i;
        Drawable drawable;
        if (dual != this.mDual) {
            changed = true;
        } else {
            changed = false;
        }
        this.mDual = dual;
        if (this.mTileBackground instanceof RippleDrawable) {
            rippleDrawable = (RippleDrawable) this.mTileBackground;
        } else {
            rippleDrawable = null;
        }
        this.mRipple = rippleDrawable;
        if (this.mTileTopBackground instanceof RippleDrawable) {
            rippleDrawable = (RippleDrawable) this.mTileTopBackground;
        } else {
            rippleDrawable = null;
        }
        this.mTopRipple = rippleDrawable;
        if (getWidth() != 0) {
            updateRippleSize(getWidth(), getHeight());
        }
        if (dual) {
            priority = this.mTopBackgroundView;
        } else {
            priority = this;
        }
        View other = dual ? this : this.mTopBackgroundView;
        priority.setOnClickListener(this.mClickPrimary);
        if (this.mClickPrimary != null) {
            z = true;
        } else {
            z = false;
        }
        priority.setClickable(z);
        priority.setOnLongClickListener(this.mLongClick);
        if (this.mLongClick != null) {
            z = true;
        } else {
            z = false;
        }
        priority.setLongClickable(z);
        other.setOnClickListener(null);
        other.setClickable(false);
        other.setOnLongClickListener(null);
        other.setLongClickable(false);
        if (dual) {
            i = 2;
        } else {
            i = 1;
        }
        setImportantForAccessibility(i);
        View view = this.mTopBackgroundView;
        if (dual) {
            drawable = this.mTileTopBackground;
        } else {
            drawable = null;
        }
        view.setBackground(drawable);
        setBackground(dual ? null : this.mTileBackground);
        this.mTopBackgroundView.setFocusable(dual);
        if (dual) {
            z = false;
        } else {
            z = true;
        }
        setFocusable(z);
        this.mDivider.setVisibility(dual ? 0 : 8);
        if (changed) {
            recreateLabel();
            updateTopPadding();
        }
        postInvalidate();
    }

    public void init(OnClickListener clickPrimary, OnClickListener clickSecondary, OnLongClickListener longClick) {
        View priority;
        boolean z = true;
        this.mClickPrimary = clickPrimary;
        this.mClickSecondary = clickSecondary;
        this.mLongClick = longClick;
        if (this.mDual) {
            priority = this.mTopBackgroundView;
        } else {
            priority = this;
        }
        View other = this.mDual ? this : this.mTopBackgroundView;
        if (priority != null) {
            boolean z2;
            priority.setOnClickListener(clickPrimary);
            if (clickPrimary != null) {
                z2 = true;
            } else {
                z2 = false;
            }
            priority.setClickable(z2);
            priority.setOnLongClickListener(longClick);
            if (longClick != null) {
                z2 = true;
            } else {
                z2 = false;
            }
            priority.setLongClickable(z2);
        }
        if (other != null) {
            other.setOnClickListener(null);
            other.setClickable(false);
            other.setOnLongClickListener(null);
            other.setLongClickable(false);
        }
        if (this.mDualLabel != null) {
            this.mDualLabel.setOnClickListener(clickSecondary);
            this.mDualLabel.setClickable(clickSecondary != null);
            this.mDualLabel.setOnLongClickListener(longClick);
            QSDualTileLabel qSDualTileLabel = this.mDualLabel;
            if (longClick == null) {
                z = false;
            }
            qSDualTileLabel.setLongClickable(z);
        }
    }

    protected View createIcon() {
        ImageView icon = new ImageView(this.mContext);
        icon.setId(16908294);
        icon.setScaleType(ScaleType.CENTER_INSIDE);
        return icon;
    }

    private Drawable newTileBackground() {
        TypedArray ta = this.mContext.obtainStyledAttributes(new int[]{16843868});
        Drawable d = ta.getDrawable(0);
        ta.recycle();
        return d;
    }

    private View labelView() {
        return this.mDual ? this.mDualLabel : this.mLabel;
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = MeasureSpec.getSize(widthMeasureSpec);
        int h = MeasureSpec.getSize(heightMeasureSpec);
        this.mIcon.measure(MeasureSpec.makeMeasureSpec(w, Integer.MIN_VALUE), exactly(this.mIconSizePx));
        labelView().measure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(h, Integer.MIN_VALUE));
        if (this.mDual) {
            this.mDivider.measure(widthMeasureSpec, exactly(this.mDivider.getLayoutParams().height));
        }
        this.mTopBackgroundView.measure(widthMeasureSpec, exactly((this.mIconSizePx + this.mTilePaddingBelowIconPx) + this.mTilePaddingTopPx));
        setMeasuredDimension(w, h);
    }

    private static int exactly(int size) {
        return MeasureSpec.makeMeasureSpec(size, 1073741824);
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = getMeasuredWidth();
        int h = getMeasuredHeight();
        layout(this.mTopBackgroundView, 0, this.mTileSpacingPx);
        int iconLeft = (w - this.mIcon.getMeasuredWidth()) / 2;
        layout(this.mIcon, iconLeft, (0 + this.mTileSpacingPx) + this.mTilePaddingTopPx);
        updateRippleSize(w, h);
        int top = this.mIcon.getBottom() + this.mTilePaddingBelowIconPx;
        if (this.mDual) {
            layout(this.mDivider, 0, top);
            top = this.mDivider.getBottom();
        }
        layout(labelView(), 0, top);
    }

    private void updateRippleSize(int width, int height) {
        int cx = width / 2;
        int cy = this.mDual ? this.mIcon.getTop() + (this.mIcon.getHeight() / 2) : height / 2;
        int rad = (int) (((float) this.mIcon.getHeight()) * 1.25f);
        if (this.mRipple != null) {
            this.mRipple.setHotspotBounds(cx - rad, cy - rad, cx + rad, cy + rad);
        }
        if (this.mTopRipple != null) {
            this.mTopRipple.setHotspotBounds(cx - rad, cy - rad, cx + rad, cy + rad);
        }
    }

    private static void layout(View child, int left, int top) {
        child.layout(left, top, child.getMeasuredWidth() + left, child.getMeasuredHeight() + top);
    }

    protected void handleStateChanged(State state) {
        if (this.mIcon instanceof ImageView) {
            setIcon((ImageView) this.mIcon, state);
        }
        if (this.mDual) {
            this.mDualLabel.setText(state.label);
            this.mDualLabel.setContentDescription(state.dualLabelContentDescription);
            this.mTopBackgroundView.setContentDescription(state.contentDescription);
            return;
        }
        this.mLabel.setText(state.label);
        setContentDescription(state.contentDescription);
    }

    protected void setIcon(ImageView iv, State state) {
        if (!Objects.equals(state.icon, iv.getTag(2131755027))) {
            Drawable d = state.icon != null ? state.icon.getDrawable(this.mContext) : null;
            if (d != null && state.autoMirrorDrawable) {
                d.setAutoMirrored(true);
            }
            iv.setImageDrawable(d);
            iv.setTag(2131755027, state.icon);
            if (d instanceof Animatable) {
                Animatable a = (Animatable) d;
                if ((state.icon instanceof AnimationIcon) && !iv.isShown()) {
                    a.stop();
                }
            }
        }
    }

    public void onStateChanged(State state) {
        this.mHandler.obtainMessage(1, state).sendToTarget();
    }

    public DragShadowBuilder getDragShadowBuilder() {
        return new DragShadowBuilder(this.mIcon);
    }
}
