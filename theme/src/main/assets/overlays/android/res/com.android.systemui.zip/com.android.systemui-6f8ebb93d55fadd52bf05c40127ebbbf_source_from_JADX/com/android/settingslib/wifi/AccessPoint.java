package com.android.settingslib.wifi;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkInfo.DetailedState;
import android.net.NetworkInfo.State;
import android.net.wifi.IWifiManager.Stub;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TtsSpan.VerbatimBuilder;
import android.util.Log;
import android.util.LruCache;
import com.android.keyguard.C0065R;
import com.android.settingslib.C0066R;

public class AccessPoint implements Comparable<AccessPoint> {
    public boolean foundInScanResult;
    private AccessPointListener mAccessPointListener;
    private WifiConfiguration mConfig;
    private final Context mContext;
    private WifiInfo mInfo;
    private NetworkInfo mNetworkInfo;
    private int mRssi;
    public LruCache<String, ScanResult> mScanResultCache;
    private long mSeen;
    private int networkId;
    private int pskType;
    private int security;
    private String ssid;

    public interface AccessPointListener {
        void onAccessPointChanged(AccessPoint accessPoint);

        void onLevelChanged(AccessPoint accessPoint);
    }

    AccessPoint(Context context, ScanResult result) {
        this.mScanResultCache = new LruCache(32);
        this.networkId = -1;
        this.pskType = 0;
        this.mRssi = Integer.MAX_VALUE;
        this.mSeen = 0;
        this.foundInScanResult = false;
        this.mContext = context;
        initWithScanResult(result);
    }

    AccessPoint(Context context, WifiConfiguration config) {
        this.mScanResultCache = new LruCache(32);
        this.networkId = -1;
        this.pskType = 0;
        this.mRssi = Integer.MAX_VALUE;
        this.mSeen = 0;
        this.foundInScanResult = false;
        this.mContext = context;
        loadConfig(config);
    }

    public int compareTo(AccessPoint other) {
        if (isActive() && !other.isActive()) {
            return -1;
        }
        if (!isActive() && other.isActive()) {
            return 1;
        }
        if (this.mRssi != Integer.MAX_VALUE && other.mRssi == Integer.MAX_VALUE) {
            return -1;
        }
        if (this.mRssi == Integer.MAX_VALUE && other.mRssi != Integer.MAX_VALUE) {
            return 1;
        }
        if (this.networkId != -1 && other.networkId == -1) {
            return -1;
        }
        if (this.networkId == -1 && other.networkId != -1) {
            return 1;
        }
        int difference = WifiManager.compareSignalLevel(other.mRssi, this.mRssi);
        return difference == 0 ? this.ssid.compareToIgnoreCase(other.ssid) : difference;
    }

    public boolean equals(Object other) {
        if ((other instanceof AccessPoint) && compareTo((AccessPoint) other) == 0) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        int result = 0;
        if (this.mInfo != null) {
            result = 0 + (this.mInfo.hashCode() * 13);
        }
        return ((result + (this.mRssi * 19)) + (this.networkId * 23)) + (this.ssid.hashCode() * 29);
    }

    public String toString() {
        StringBuilder builder = new StringBuilder().append("AccessPoint(").append(this.ssid);
        if (isSaved()) {
            builder.append(',').append("saved");
        }
        if (isActive()) {
            builder.append(',').append("active");
        }
        if (isEphemeral()) {
            builder.append(',').append("ephemeral");
        }
        if (isConnectable()) {
            builder.append(',').append("connectable");
        }
        if (this.security != 0) {
            builder.append(',').append(securityToString(this.security, this.pskType));
        }
        return builder.append(')').toString();
    }

    public boolean matches(ScanResult result) {
        return this.ssid.equals(result.SSID) && this.security == getSecurity(result);
    }

    public boolean matches(WifiConfiguration config) {
        if (config.isPasspoint() && this.mConfig != null && this.mConfig.isPasspoint()) {
            return config.FQDN.equals(this.mConfig.providerFriendlyName);
        }
        return this.ssid.equals(removeDoubleQuotes(config.SSID)) && this.security == getSecurity(config);
    }

    public WifiConfiguration getConfig() {
        return this.mConfig;
    }

    public void clearConfig() {
        this.mConfig = null;
        this.networkId = -1;
    }

    public int getLevel() {
        if (this.mRssi == Integer.MAX_VALUE) {
            return -1;
        }
        return WifiManager.calculateSignalLevel(this.mRssi, 4);
    }

    public int getRssi() {
        int rssi = Integer.MIN_VALUE;
        for (ScanResult result : this.mScanResultCache.snapshot().values()) {
            if (result.level > rssi) {
                rssi = result.level;
            }
        }
        return rssi;
    }

    public long getSeen() {
        long seen = 0;
        for (ScanResult result : this.mScanResultCache.snapshot().values()) {
            if (result.timestamp > seen) {
                seen = result.timestamp;
            }
        }
        return seen;
    }

    public int getSecurity() {
        return this.security;
    }

    public String getSsidStr() {
        return this.ssid;
    }

    public CharSequence getSsid() {
        SpannableString str = new SpannableString(this.ssid);
        str.setSpan(new VerbatimBuilder(this.ssid).build(), 0, this.ssid.length(), 18);
        return str;
    }

    public DetailedState getDetailedState() {
        return this.mNetworkInfo != null ? this.mNetworkInfo.getDetailedState() : null;
    }

    public String getSummary() {
        return getSettingsSummary();
    }

    public String getSettingsSummary() {
        StringBuilder summary = new StringBuilder();
        if (isActive() && this.mConfig != null && this.mConfig.isPasspoint()) {
            summary.append(getSummary(this.mContext, getDetailedState(), false, this.mConfig.providerFriendlyName));
        } else if (isActive()) {
            Context context = this.mContext;
            DetailedState detailedState = getDetailedState();
            boolean z = this.mInfo != null && this.mInfo.isEphemeral();
            summary.append(getSummary(context, detailedState, z));
        } else if (this.mConfig != null && this.mConfig.isPasspoint()) {
            String format = this.mContext.getString(C0066R.string.available_via_passpoint);
            Object[] objArr = new Object[1];
            objArr[0] = this.mConfig.providerFriendlyName;
            summary.append(String.format(format, objArr));
        } else if (this.mConfig == null || !this.mConfig.hasNoInternetAccess()) {
            if (this.mConfig != null && ((this.mConfig.status == 1 && this.mConfig.disableReason != 0) || this.mConfig.autoJoinStatus >= 128)) {
                if (this.mConfig.autoJoinStatus < 128) {
                    switch (this.mConfig.disableReason) {
                        case C0065R.styleable.NumPadKey_digit /*0*/:
                        case 4:
                            summary.append(this.mContext.getString(C0066R.string.wifi_disabled_generic));
                            break;
                        case C0065R.styleable.NumPadKey_textView /*1*/:
                        case 2:
                            summary.append(this.mContext.getString(C0066R.string.wifi_disabled_network_failure));
                            break;
                        case 3:
                            summary.append(this.mContext.getString(C0066R.string.wifi_disabled_password_failure));
                            break;
                        default:
                            break;
                    }
                } else if (this.mConfig.disableReason == 2) {
                    summary.append(this.mContext.getString(C0066R.string.wifi_disabled_network_failure));
                } else if (this.mConfig.disableReason == 3) {
                    summary.append(this.mContext.getString(C0066R.string.wifi_disabled_password_failure));
                } else {
                    summary.append(this.mContext.getString(C0066R.string.wifi_disabled_wifi_failure));
                }
            } else if (this.mRssi == Integer.MAX_VALUE) {
                summary.append(this.mContext.getString(C0066R.string.wifi_not_in_range));
            } else if (this.mConfig != null) {
                summary.append(this.mContext.getString(C0066R.string.wifi_remembered));
            }
        } else {
            summary.append(this.mContext.getString(C0066R.string.wifi_no_internet));
        }
        if (WifiTracker.sVerboseLogging > 0) {
            if (!(this.mInfo == null || this.mNetworkInfo == null)) {
                summary.append(" f=" + Integer.toString(this.mInfo.getFrequency()));
            }
            summary.append(" " + getVisibilityStatus());
            if (this.mConfig != null && this.mConfig.autoJoinStatus > 0) {
                summary.append(" (" + this.mConfig.autoJoinStatus);
                if (this.mConfig.blackListTimestamp > 0) {
                    long diff = (System.currentTimeMillis() - this.mConfig.blackListTimestamp) / 1000;
                    long sec = diff % 60;
                    long min = (diff / 60) % 60;
                    long hour = (min / 60) % 60;
                    summary.append(", ");
                    if (hour > 0) {
                        summary.append(Long.toString(hour) + "h ");
                    }
                    summary.append(Long.toString(min) + "m ");
                    summary.append(Long.toString(sec) + "s ");
                }
                summary.append(")");
            }
            if (this.mConfig != null && this.mConfig.numIpConfigFailures > 0) {
                summary.append(" ipf=").append(this.mConfig.numIpConfigFailures);
            }
            if (this.mConfig != null && this.mConfig.numConnectionFailures > 0) {
                summary.append(" cf=").append(this.mConfig.numConnectionFailures);
            }
            if (this.mConfig != null && this.mConfig.numAuthFailures > 0) {
                summary.append(" authf=").append(this.mConfig.numAuthFailures);
            }
            if (this.mConfig != null && this.mConfig.numNoInternetAccessReports > 0) {
                summary.append(" noInt=").append(this.mConfig.numNoInternetAccessReports);
            }
        }
        return summary.toString();
    }

    private String getVisibilityStatus() {
        StringBuilder visibility = new StringBuilder();
        StringBuilder scans24GHz = null;
        StringBuilder scans5GHz = null;
        String bssid = null;
        long now = System.currentTimeMillis();
        if (this.mInfo != null) {
            bssid = this.mInfo.getBSSID();
            if (bssid != null) {
                visibility.append(" ").append(bssid);
            }
            visibility.append(" rssi=").append(this.mInfo.getRssi());
            visibility.append(" ");
            visibility.append(" score=").append(this.mInfo.score);
            Object[] objArr = new Object[1];
            objArr[0] = Double.valueOf(this.mInfo.txSuccessRate);
            visibility.append(String.format(" tx=%.1f,", objArr));
            objArr = new Object[1];
            objArr[0] = Double.valueOf(this.mInfo.txRetriesRate);
            visibility.append(String.format("%.1f,", objArr));
            objArr = new Object[1];
            objArr[0] = Double.valueOf(this.mInfo.txBadRate);
            visibility.append(String.format("%.1f ", objArr));
            objArr = new Object[1];
            objArr[0] = Double.valueOf(this.mInfo.rxSuccessRate);
            visibility.append(String.format("rx=%.1f", objArr));
        }
        int rssi5 = WifiConfiguration.INVALID_RSSI;
        int rssi24 = WifiConfiguration.INVALID_RSSI;
        int num5 = 0;
        int num24 = 0;
        int numBlackListed = 0;
        int n24 = 0;
        int n5 = 0;
        for (ScanResult result : this.mScanResultCache.snapshot().values()) {
            if (result.seen != 0) {
                String str;
                int i;
                if (result.autoJoinStatus != 0) {
                    numBlackListed++;
                }
                int i2 = result.frequency;
                if (r0 >= 4900) {
                    i2 = result.frequency;
                    if (r0 <= 5900) {
                        num5++;
                        if (now - result.seen <= 20000) {
                            i2 = result.frequency;
                            if (r0 >= 4900) {
                                i2 = result.frequency;
                                if (r0 <= 5900) {
                                    i2 = result.level;
                                    if (r0 > rssi5) {
                                        rssi5 = result.level;
                                    }
                                    if (n5 >= 4) {
                                        if (scans5GHz == null) {
                                            scans5GHz = new StringBuilder();
                                        }
                                        str = result.BSSID;
                                        scans5GHz.append(" \n{").append(r0);
                                        if (bssid != null) {
                                            if (result.BSSID.equals(bssid)) {
                                                scans5GHz.append("*");
                                            }
                                        }
                                        i = result.frequency;
                                        scans5GHz.append("=").append(r0);
                                        i = result.level;
                                        scans5GHz.append(",").append(r0);
                                        if (result.autoJoinStatus != 0) {
                                            i = result.autoJoinStatus;
                                            scans5GHz.append(",st=").append(r0);
                                        }
                                        if (result.numIpConfigFailures != 0) {
                                            i = result.numIpConfigFailures;
                                            scans5GHz.append(",ipf=").append(r0);
                                        }
                                        scans5GHz.append("}");
                                        n5++;
                                    }
                                }
                            }
                            i2 = result.frequency;
                            if (r0 >= 2400) {
                                i2 = result.frequency;
                                if (r0 <= 2500) {
                                    i2 = result.level;
                                    if (r0 > rssi24) {
                                        rssi24 = result.level;
                                    }
                                    if (n24 >= 4) {
                                        if (scans24GHz == null) {
                                            scans24GHz = new StringBuilder();
                                        }
                                        str = result.BSSID;
                                        scans24GHz.append(" \n{").append(r0);
                                        if (bssid != null) {
                                            if (result.BSSID.equals(bssid)) {
                                                scans24GHz.append("*");
                                            }
                                        }
                                        i = result.frequency;
                                        scans24GHz.append("=").append(r0);
                                        i = result.level;
                                        scans24GHz.append(",").append(r0);
                                        if (result.autoJoinStatus != 0) {
                                            i = result.autoJoinStatus;
                                            scans24GHz.append(",st=").append(r0);
                                        }
                                        if (result.numIpConfigFailures != 0) {
                                            i = result.numIpConfigFailures;
                                            scans24GHz.append(",ipf=").append(r0);
                                        }
                                        scans24GHz.append("}");
                                        n24++;
                                    }
                                }
                            }
                        }
                    }
                }
                i2 = result.frequency;
                if (r0 >= 2400) {
                    i2 = result.frequency;
                    if (r0 <= 2500) {
                        num24++;
                    }
                }
                if (now - result.seen <= 20000) {
                    i2 = result.frequency;
                    if (r0 >= 4900) {
                        i2 = result.frequency;
                        if (r0 <= 5900) {
                            i2 = result.level;
                            if (r0 > rssi5) {
                                rssi5 = result.level;
                            }
                            if (n5 >= 4) {
                                if (scans5GHz == null) {
                                    scans5GHz = new StringBuilder();
                                }
                                str = result.BSSID;
                                scans5GHz.append(" \n{").append(r0);
                                if (bssid != null) {
                                    if (result.BSSID.equals(bssid)) {
                                        scans5GHz.append("*");
                                    }
                                }
                                i = result.frequency;
                                scans5GHz.append("=").append(r0);
                                i = result.level;
                                scans5GHz.append(",").append(r0);
                                if (result.autoJoinStatus != 0) {
                                    i = result.autoJoinStatus;
                                    scans5GHz.append(",st=").append(r0);
                                }
                                if (result.numIpConfigFailures != 0) {
                                    i = result.numIpConfigFailures;
                                    scans5GHz.append(",ipf=").append(r0);
                                }
                                scans5GHz.append("}");
                                n5++;
                            }
                        }
                    }
                    i2 = result.frequency;
                    if (r0 >= 2400) {
                        i2 = result.frequency;
                        if (r0 <= 2500) {
                            i2 = result.level;
                            if (r0 > rssi24) {
                                rssi24 = result.level;
                            }
                            if (n24 >= 4) {
                                if (scans24GHz == null) {
                                    scans24GHz = new StringBuilder();
                                }
                                str = result.BSSID;
                                scans24GHz.append(" \n{").append(r0);
                                if (bssid != null) {
                                    if (result.BSSID.equals(bssid)) {
                                        scans24GHz.append("*");
                                    }
                                }
                                i = result.frequency;
                                scans24GHz.append("=").append(r0);
                                i = result.level;
                                scans24GHz.append(",").append(r0);
                                if (result.autoJoinStatus != 0) {
                                    i = result.autoJoinStatus;
                                    scans24GHz.append(",st=").append(r0);
                                }
                                if (result.numIpConfigFailures != 0) {
                                    i = result.numIpConfigFailures;
                                    scans24GHz.append(",ipf=").append(r0);
                                }
                                scans24GHz.append("}");
                                n24++;
                            }
                        }
                    }
                }
            }
        }
        visibility.append(" [");
        if (num24 > 0) {
            visibility.append("(").append(num24).append(")");
            if (n24 > 4) {
                visibility.append("max=").append(rssi24);
                if (scans24GHz != null) {
                    visibility.append(",").append(scans24GHz.toString());
                }
            } else if (scans24GHz != null) {
                visibility.append(scans24GHz.toString());
            }
        }
        visibility.append(";");
        if (num5 > 0) {
            visibility.append("(").append(num5).append(")");
            if (n5 > 4) {
                visibility.append("max=").append(rssi5);
                if (scans5GHz != null) {
                    visibility.append(",").append(scans5GHz.toString());
                }
            } else if (scans5GHz != null) {
                visibility.append(scans5GHz.toString());
            }
        }
        if (numBlackListed > 0) {
            visibility.append("!").append(numBlackListed);
        }
        visibility.append("]");
        return visibility.toString();
    }

    public boolean isActive() {
        return (this.mNetworkInfo == null || (this.networkId == -1 && this.mNetworkInfo.getState() == State.DISCONNECTED)) ? false : true;
    }

    public boolean isConnectable() {
        return getLevel() != -1 && getDetailedState() == null;
    }

    public boolean isEphemeral() {
        return (this.mInfo == null || !this.mInfo.isEphemeral() || this.mNetworkInfo == null || this.mNetworkInfo.getState() == State.DISCONNECTED) ? false : true;
    }

    public boolean isPasspoint() {
        return this.mConfig != null && this.mConfig.isPasspoint();
    }

    private boolean isInfoForThisAccessPoint(WifiConfiguration config, WifiInfo info) {
        if (isPasspoint() || this.networkId == -1) {
            if (config != null) {
                return matches(config);
            }
            return false;
        } else if (this.networkId == info.getNetworkId()) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isSaved() {
        return this.networkId != -1;
    }

    public void generateOpenNetworkConfig() {
        if (this.security != 0) {
            throw new IllegalStateException();
        } else if (this.mConfig == null) {
            this.mConfig = new WifiConfiguration();
            this.mConfig.SSID = convertToQuotedString(this.ssid);
            this.mConfig.allowedKeyManagement.set(0);
        }
    }

    void loadConfig(WifiConfiguration config) {
        if (config.isPasspoint()) {
            this.ssid = config.providerFriendlyName;
        } else {
            this.ssid = config.SSID == null ? "" : removeDoubleQuotes(config.SSID);
        }
        this.security = getSecurity(config);
        this.networkId = config.networkId;
        this.mConfig = config;
    }

    private void initWithScanResult(ScanResult result) {
        this.ssid = result.SSID;
        this.security = getSecurity(result);
        if (this.security == 2) {
            this.pskType = getPskType(result);
        }
        this.mRssi = result.level;
        this.mSeen = result.timestamp;
    }

    boolean update(ScanResult result) {
        if (!matches(result)) {
            return false;
        }
        this.mScanResultCache.get(result.BSSID);
        this.mScanResultCache.put(result.BSSID, result);
        int oldLevel = getLevel();
        int oldRssi = getRssi();
        this.mSeen = getSeen();
        this.mRssi = (getRssi() + oldRssi) / 2;
        int newLevel = getLevel();
        if (!(newLevel <= 0 || newLevel == oldLevel || this.mAccessPointListener == null)) {
            this.mAccessPointListener.onLevelChanged(this);
        }
        if (this.security == 2) {
            this.pskType = getPskType(result);
        }
        if (this.mAccessPointListener != null) {
            this.mAccessPointListener.onAccessPointChanged(this);
        }
        return true;
    }

    boolean update(WifiConfiguration config, WifiInfo info, NetworkInfo networkInfo) {
        boolean reorder = false;
        if (info != null && isInfoForThisAccessPoint(config, info)) {
            reorder = this.mInfo == null;
            this.mRssi = info.getRssi();
            this.mInfo = info;
            this.mNetworkInfo = networkInfo;
            if (this.mAccessPointListener != null) {
                this.mAccessPointListener.onAccessPointChanged(this);
            }
        } else if (this.mInfo != null) {
            reorder = true;
            this.mInfo = null;
            this.mNetworkInfo = null;
            if (this.mAccessPointListener != null) {
                this.mAccessPointListener.onAccessPointChanged(this);
            }
        }
        return reorder;
    }

    void update(WifiConfiguration config) {
        this.mConfig = config;
        this.networkId = config.networkId;
        if (this.mAccessPointListener != null) {
            this.mAccessPointListener.onAccessPointChanged(this);
        }
    }

    public static String getSummary(Context context, String ssid, DetailedState state, boolean isEphemeral, String passpointProvider) {
        if (state == DetailedState.CONNECTED && ssid == null) {
            if (!TextUtils.isEmpty(passpointProvider)) {
                return String.format(context.getString(C0066R.string.connected_via_passpoint), new Object[]{passpointProvider});
            } else if (isEphemeral) {
                return context.getString(C0066R.string.connected_via_wfa);
            }
        }
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService("connectivity");
        if (state == DetailedState.CONNECTED) {
            Network nw;
            try {
                nw = Stub.asInterface(ServiceManager.getService("wifi")).getCurrentNetwork();
            } catch (RemoteException e) {
                nw = null;
            }
            NetworkCapabilities nc = cm.getNetworkCapabilities(nw);
            if (!(nc == null || nc.hasCapability(16))) {
                return context.getString(C0066R.string.wifi_connected_no_internet);
            }
        }
        String[] formats = context.getResources().getStringArray(ssid == null ? C0066R.array.wifi_status : C0066R.array.wifi_status_with_ssid);
        int index = state.ordinal();
        if (index >= formats.length || formats[index].length() == 0) {
            return "";
        }
        return String.format(formats[index], new Object[]{ssid});
    }

    public static String getSummary(Context context, DetailedState state, boolean isEphemeral) {
        return getSummary(context, null, state, isEphemeral, null);
    }

    public static String getSummary(Context context, DetailedState state, boolean isEphemeral, String passpointProvider) {
        return getSummary(context, null, state, isEphemeral, passpointProvider);
    }

    public static String convertToQuotedString(String string) {
        return "\"" + string + "\"";
    }

    private static int getPskType(ScanResult result) {
        boolean wpa = result.capabilities.contains("WPA-PSK");
        boolean wpa2 = result.capabilities.contains("WPA2-PSK");
        if (wpa2 && wpa) {
            return 3;
        }
        if (wpa2) {
            return 2;
        }
        if (wpa) {
            return 1;
        }
        Log.w("SettingsLib.AccessPoint", "Received abnormal flag string: " + result.capabilities);
        return 0;
    }

    private static int getSecurity(ScanResult result) {
        if (result.capabilities.contains("WEP")) {
            return 1;
        }
        if (result.capabilities.contains("PSK")) {
            return 2;
        }
        if (result.capabilities.contains("EAP")) {
            return 3;
        }
        return 0;
    }

    static int getSecurity(WifiConfiguration config) {
        if (config.allowedKeyManagement.get(1)) {
            return 2;
        }
        if (config.allowedKeyManagement.get(2) || config.allowedKeyManagement.get(3)) {
            return 3;
        }
        if (config.wepKeys[0] == null) {
            return 0;
        }
        return 1;
    }

    public static String securityToString(int security, int pskType) {
        if (security == 1) {
            return "WEP";
        }
        if (security == 2) {
            if (pskType == 1) {
                return "WPA";
            }
            if (pskType == 2) {
                return "WPA2";
            }
            if (pskType == 3) {
                return "WPA_WPA2";
            }
            return "PSK";
        } else if (security == 3) {
            return "EAP";
        } else {
            return "NONE";
        }
    }

    static String removeDoubleQuotes(String string) {
        if (TextUtils.isEmpty(string)) {
            return "";
        }
        int length = string.length();
        if (length > 1 && string.charAt(0) == '\"' && string.charAt(length - 1) == '\"') {
            return string.substring(1, length - 1);
        }
        return string;
    }
}
