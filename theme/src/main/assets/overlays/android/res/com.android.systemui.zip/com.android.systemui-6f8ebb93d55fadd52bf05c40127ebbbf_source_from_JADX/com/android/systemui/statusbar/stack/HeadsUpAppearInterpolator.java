package com.android.systemui.statusbar.stack;

import android.graphics.Path;
import android.view.animation.PathInterpolator;

public class HeadsUpAppearInterpolator extends PathInterpolator {
    public HeadsUpAppearInterpolator() {
        super(getAppearPath());
    }

    private static Path getAppearPath() {
        Path path = new Path();
        path.moveTo(0.0f, 0.0f);
        float xTot = (250.0f + 150.0f) + 100.0f;
        path.cubicTo((0.9f * 250.0f) / xTot, 0.0f, (0.8f * 250.0f) / xTot, 90.0f / 80.0f, 250.0f / xTot, 90.0f / 80.0f);
        path.cubicTo(((0.4f * 150.0f) + 250.0f) / xTot, 90.0f / 80.0f, ((0.2f * 150.0f) + 250.0f) / xTot, 78.0f / 80.0f, (250.0f + 150.0f) / xTot, 78.0f / 80.0f);
        path.cubicTo(((250.0f + 150.0f) + (0.4f * 100.0f)) / xTot, 78.0f / 80.0f, ((250.0f + 150.0f) + (0.2f * 100.0f)) / xTot, 1.0f, 1.0f, 1.0f);
        return path;
    }
}
