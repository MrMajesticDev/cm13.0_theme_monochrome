package com.android.systemui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

public class ViewInvertHelper {
    private final Paint mDarkPaint;
    private final long mFadeDuration;
    private final ColorMatrix mGrayscaleMatrix;
    private final Interpolator mLinearOutSlowInInterpolator;
    private final ColorMatrix mMatrix;
    private final View mTarget;

    /* renamed from: com.android.systemui.ViewInvertHelper.1 */
    class C01021 implements AnimatorUpdateListener {
        C01021() {
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            ViewInvertHelper.this.updateInvertPaint(((Float) animation.getAnimatedValue()).floatValue());
            ViewInvertHelper.this.mTarget.setLayerType(2, ViewInvertHelper.this.mDarkPaint);
        }
    }

    /* renamed from: com.android.systemui.ViewInvertHelper.2 */
    class C01032 extends AnimatorListenerAdapter {
        final /* synthetic */ boolean val$invert;

        C01032(boolean z) {
            this.val$invert = z;
        }

        public void onAnimationEnd(Animator animation) {
            if (!this.val$invert) {
                ViewInvertHelper.this.mTarget.setLayerType(0, null);
            }
        }
    }

    public ViewInvertHelper(View target, long fadeDuration) {
        this.mDarkPaint = new Paint();
        this.mMatrix = new ColorMatrix();
        this.mGrayscaleMatrix = new ColorMatrix();
        this.mTarget = target;
        this.mLinearOutSlowInInterpolator = AnimationUtils.loadInterpolator(this.mTarget.getContext(), 17563662);
        this.mFadeDuration = fadeDuration;
    }

    public void fade(boolean invert, long delay) {
        float startIntensity;
        float endIntensity = 1.0f;
        if (invert) {
            startIntensity = 0.0f;
        } else {
            startIntensity = 1.0f;
        }
        if (!invert) {
            endIntensity = 0.0f;
        }
        ValueAnimator animator = ValueAnimator.ofFloat(new float[]{startIntensity, endIntensity});
        animator.addUpdateListener(new C01021());
        animator.addListener(new C01032(invert));
        animator.setDuration(this.mFadeDuration);
        animator.setInterpolator(this.mLinearOutSlowInInterpolator);
        animator.setStartDelay(delay);
        animator.start();
    }

    public void update(boolean invert) {
        if (invert) {
            updateInvertPaint(1.0f);
            this.mTarget.setLayerType(2, this.mDarkPaint);
            return;
        }
        this.mTarget.setLayerType(0, null);
    }

    private void updateInvertPaint(float intensity) {
        float components = 1.0f - (2.0f * intensity);
        this.mMatrix.set(new float[]{components, 0.0f, 0.0f, 0.0f, 255.0f * intensity, 0.0f, components, 0.0f, 0.0f, 255.0f * intensity, 0.0f, 0.0f, components, 0.0f, 255.0f * intensity, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f});
        this.mGrayscaleMatrix.setSaturation(1.0f - intensity);
        this.mMatrix.preConcat(this.mGrayscaleMatrix);
        this.mDarkPaint.setColorFilter(new ColorMatrixColorFilter(this.mMatrix));
    }
}
