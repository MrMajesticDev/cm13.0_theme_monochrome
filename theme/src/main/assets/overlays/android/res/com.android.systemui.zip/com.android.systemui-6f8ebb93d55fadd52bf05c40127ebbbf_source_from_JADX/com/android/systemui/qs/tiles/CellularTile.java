package com.android.systemui.qs.tiles;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.ResourceIcon;
import com.android.systemui.qs.QSTile.SignalState;
import com.android.systemui.qs.QSTileView;
import com.android.systemui.qs.SignalTileView;
import com.android.systemui.statusbar.policy.NetworkController;
import com.android.systemui.statusbar.policy.NetworkController.IconState;
import com.android.systemui.statusbar.policy.NetworkController.MobileDataController;
import com.android.systemui.statusbar.policy.NetworkController.MobileDataController.DataUsageInfo;
import com.android.systemui.statusbar.policy.SignalCallbackAdapter;

public class CellularTile extends QSTile<SignalState> {
    private static final Intent CELLULAR_SETTINGS;
    private final NetworkController mController;
    private final MobileDataController mDataController;
    private final CellularDetailAdapter mDetailAdapter;
    private final CellSignalCallback mSignalCallback;

    private static final class CallbackInfo {
        boolean activityIn;
        boolean activityOut;
        boolean airplaneModeEnabled;
        String dataContentDescription;
        int dataTypeIconId;
        boolean enabled;
        String enabledDesc;
        boolean isDataTypeIconWide;
        int mobileSignalIconId;
        boolean noSim;
        String signalContentDescription;
        boolean wifiEnabled;

        private CallbackInfo() {
        }
    }

    private final class CellSignalCallback extends SignalCallbackAdapter {
        private final CallbackInfo mInfo;

        private CellSignalCallback() {
            this.mInfo = new CallbackInfo();
        }

        public void setWifiIndicators(boolean enabled, IconState statusIcon, IconState qsIcon, boolean activityIn, boolean activityOut, String description) {
            this.mInfo.wifiEnabled = enabled;
            CellularTile.this.refreshState(this.mInfo);
        }

        public void setMobileDataIndicators(IconState statusIcon, IconState qsIcon, int statusType, int qsType, boolean activityIn, boolean activityOut, int dataActivityId, int mobileActivityId, int stackedDataIcon, int stackedVoiceIcon, String typeContentDescription, String description, boolean isWide, int subId) {
            if (qsIcon != null) {
                this.mInfo.enabled = qsIcon.visible;
                this.mInfo.mobileSignalIconId = qsIcon.icon;
                this.mInfo.signalContentDescription = qsIcon.contentDescription;
                this.mInfo.dataTypeIconId = qsType;
                this.mInfo.dataContentDescription = typeContentDescription;
                this.mInfo.activityIn = activityIn;
                this.mInfo.activityOut = activityOut;
                this.mInfo.enabledDesc = description;
                CallbackInfo callbackInfo = this.mInfo;
                boolean z = qsType != 0 && isWide;
                callbackInfo.isDataTypeIconWide = z;
                CellularTile.this.refreshState(this.mInfo);
            }
        }

        public void setNoSims(boolean show) {
            this.mInfo.noSim = show;
            if (this.mInfo.noSim) {
                this.mInfo.mobileSignalIconId = 0;
                this.mInfo.dataTypeIconId = 0;
                this.mInfo.enabled = true;
                this.mInfo.enabledDesc = CellularTile.this.mContext.getString(C0065R.string.keyguard_missing_sim_message_short);
                this.mInfo.signalContentDescription = this.mInfo.enabledDesc;
            }
            CellularTile.this.refreshState(this.mInfo);
        }

        public void setIsAirplaneMode(IconState icon) {
            this.mInfo.airplaneModeEnabled = icon.visible;
            CellularTile.this.refreshState(this.mInfo);
        }

        public void setMobileDataEnabled(boolean enabled) {
            CellularTile.this.mDetailAdapter.setMobileDataEnabled(enabled);
        }
    }

    private final class CellularDetailAdapter implements DetailAdapter {
        private CellularDetailAdapter() {
        }

        public int getTitle() {
            return 2131362213;
        }

        public Boolean getToggleState() {
            return CellularTile.this.mDataController.isMobileDataSupported() ? Boolean.valueOf(CellularTile.this.mDataController.isMobileDataEnabled()) : null;
        }

        public Intent getSettingsIntent() {
            return CellularTile.CELLULAR_SETTINGS;
        }

        public void setToggleState(boolean state) {
            MetricsLogger.action(CellularTile.this.mContext, 155, state);
            CellularTile.this.mDataController.setMobileDataEnabled(state);
        }

        public int getMetricsCategory() {
            return 117;
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            DataUsageDetailView v = (DataUsageDetailView) (convertView != null ? convertView : LayoutInflater.from(CellularTile.this.mContext).inflate(2130968578, parent, false));
            DataUsageInfo info = CellularTile.this.mDataController.getDataUsageInfo();
            if (info != null) {
                v.bind(info);
            }
            return v;
        }

        public void setMobileDataEnabled(boolean enabled) {
            CellularTile.this.fireToggleStateChanged(enabled);
        }
    }

    static {
        CELLULAR_SETTINGS = new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$DataUsageSummaryActivity"));
    }

    public CellularTile(Host host) {
        super(host, "cell");
        this.mSignalCallback = new CellSignalCallback();
        this.mController = host.getNetworkController();
        this.mDataController = this.mController.getMobileDataController();
        this.mDetailAdapter = new CellularDetailAdapter();
    }

    protected SignalState newTileState() {
        return new SignalState();
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    public void setListening(boolean listening) {
        if (listening) {
            this.mController.addSignalCallback(this.mSignalCallback);
        } else {
            this.mController.removeSignalCallback(this.mSignalCallback);
        }
    }

    public QSTileView createTileView(Context context) {
        return new SignalTileView(context);
    }

    protected void handleToggleClick() {
        MetricsLogger.action(this.mContext, getMetricsCategory());
        if (this.mDataController.isMobileDataSupported()) {
            this.mDataController.setMobileDataEnabled(!this.mDataController.isMobileDataEnabled());
        } else {
            this.mHost.startActivityDismissingKeyguard(CELLULAR_SETTINGS);
        }
    }

    protected void handleDetailClick() {
        MetricsLogger.action(this.mContext, getMetricsCategory());
        if (this.mDataController.isMobileDataSupported()) {
            showDetail(true);
        } else {
            this.mHost.startActivityDismissingKeyguard(CELLULAR_SETTINGS);
        }
    }

    protected void handleUpdateState(SignalState state, Object arg) {
        state.visible = this.mController.hasMobileDataFeature();
        if (state.visible) {
            boolean z;
            int i;
            boolean z2;
            CallbackInfo cb = (CallbackInfo) arg;
            if (cb == null) {
                cb = this.mSignalCallback.mInfo;
            }
            Resources r = this.mContext.getResources();
            int iconId = cb.noSim ? 2130837641 : (!cb.enabled || cb.airplaneModeEnabled) ? 2130837660 : cb.mobileSignalIconId > 0 ? cb.mobileSignalIconId : 2130837676;
            state.icon = ResourceIcon.get(iconId);
            state.isOverlayIconWide = cb.isDataTypeIconWide;
            if (cb.noSim) {
                z = false;
            } else {
                z = true;
            }
            state.autoMirrorDrawable = z;
            if (!cb.enabled || cb.dataTypeIconId <= 0) {
                i = 0;
            } else {
                i = cb.dataTypeIconId;
            }
            state.overlayIconId = i;
            if (iconId != 2130837641) {
                z2 = true;
            } else {
                z2 = false;
            }
            state.filter = z2;
            if (cb.enabled && cb.activityIn) {
                z2 = true;
            } else {
                z2 = false;
            }
            state.activityIn = z2;
            if (cb.enabled && cb.activityOut) {
                z2 = true;
            } else {
                z2 = false;
            }
            state.activityOut = z2;
            state.label = cb.enabled ? removeTrailingPeriod(cb.enabledDesc) : r.getString(2131362185);
            String signalContentDesc = (!cb.enabled || cb.mobileSignalIconId <= 0) ? r.getString(2131362049) : cb.signalContentDescription;
            String dataContentDesc = (!cb.enabled || cb.dataTypeIconId <= 0 || cb.wifiEnabled) ? r.getString(2131362035) : cb.dataContentDescription;
            state.contentDescription = r.getString(2131362108, new Object[]{signalContentDesc, dataContentDesc, state.label});
        }
    }

    public int getMetricsCategory() {
        return 115;
    }

    public static String removeTrailingPeriod(String string) {
        if (string == null) {
            return null;
        }
        int length = string.length();
        if (string.endsWith(".")) {
            return string.substring(0, length - 1);
        }
        return string;
    }
}
