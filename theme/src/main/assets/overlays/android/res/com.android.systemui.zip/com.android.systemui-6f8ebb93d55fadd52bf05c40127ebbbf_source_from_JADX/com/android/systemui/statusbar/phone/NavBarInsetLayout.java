package com.android.systemui.statusbar.phone;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.android.systemui.C0095R;
import com.android.systemui.statusbar.BaseStatusBar;

public class NavBarInsetLayout extends FrameLayout {
    public static final boolean DEBUG;
    private int mLeftInset;
    boolean mLeftInsetMode;
    private int mRightInset;
    private final Paint mTransparentSrcPaint;

    public static class InsetLayoutParams extends LayoutParams {
        public boolean ignoreRightInset;

        public InsetLayoutParams(int width, int height) {
            super(width, height);
        }

        public InsetLayoutParams(Context c, AttributeSet attrs) {
            super(c, attrs);
            TypedArray a = c.obtainStyledAttributes(attrs, C0095R.styleable.StatusBarWindowView_Layout);
            this.ignoreRightInset = a.getBoolean(0, false);
            a.recycle();
        }
    }

    static {
        DEBUG = BaseStatusBar.DEBUG;
    }

    public NavBarInsetLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mLeftInsetMode = false;
        this.mLeftInset = 0;
        this.mRightInset = 0;
        this.mTransparentSrcPaint = new Paint();
        setMotionEventSplittingEnabled(false);
        this.mTransparentSrcPaint.setColor(0);
        this.mTransparentSrcPaint.setXfermode(new PorterDuffXfermode(Mode.SRC));
    }

    protected boolean fitSystemWindows(Rect insets) {
        boolean paddingChanged = true;
        if (getFitsSystemWindows()) {
            if (this.mLeftInsetMode) {
                if (insets.right == getPaddingRight() && insets.top == getPaddingTop() && insets.bottom == getPaddingBottom()) {
                    paddingChanged = false;
                }
                if (insets.left != this.mLeftInset) {
                    this.mLeftInset = insets.left;
                    applyMargins();
                }
            } else {
                if (insets.left == getPaddingLeft() && insets.top == getPaddingTop() && insets.bottom == getPaddingBottom()) {
                    paddingChanged = false;
                }
                if (insets.right != this.mRightInset) {
                    this.mRightInset = insets.right;
                    applyMargins();
                }
            }
            if (paddingChanged) {
                setPadding(this.mLeftInsetMode ? 0 : insets.left, 0, this.mLeftInsetMode ? insets.right : 0, 0);
            }
            insets.left = 0;
            insets.top = 0;
            insets.right = 0;
        } else {
            boolean changed;
            boolean applyMargins = false;
            if (this.mLeftInset != 0) {
                this.mLeftInset = 0;
                applyMargins = true;
            }
            if (this.mRightInset != 0) {
                this.mRightInset = 0;
                applyMargins = true;
            }
            if (applyMargins) {
                applyMargins();
            }
            if (getPaddingLeft() == 0 && getPaddingRight() == 0 && getPaddingTop() == 0 && getPaddingBottom() == 0) {
                changed = false;
            } else {
                changed = true;
            }
            if (changed) {
                setPadding(0, 0, 0, 0);
            }
            insets.top = 0;
        }
        return false;
    }

    private void applyMargins() {
        int N = getChildCount();
        for (int i = 0; i < N; i++) {
            View child = getChildAt(i);
            if (child.getLayoutParams() instanceof InsetLayoutParams) {
                InsetLayoutParams lp = (InsetLayoutParams) child.getLayoutParams();
                if (!lp.ignoreRightInset) {
                    if (this.mLeftInsetMode && lp.leftMargin != this.mLeftInset) {
                        lp.leftMargin = this.mLeftInset;
                        if (lp.rightMargin != 0) {
                            lp.rightMargin = 0;
                        }
                    } else if (lp.rightMargin != this.mRightInset) {
                        lp.rightMargin = this.mRightInset;
                        if (lp.leftMargin != 0) {
                            lp.leftMargin = 0;
                        }
                    }
                    child.requestLayout();
                }
            }
        }
    }

    public LayoutParams generateLayoutParams(AttributeSet attrs) {
        return new InsetLayoutParams(getContext(), attrs);
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new InsetLayoutParams(-1, -1);
    }
}
