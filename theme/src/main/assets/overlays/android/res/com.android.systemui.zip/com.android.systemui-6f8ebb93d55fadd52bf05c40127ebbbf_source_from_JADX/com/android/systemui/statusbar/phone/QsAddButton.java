package com.android.systemui.statusbar.phone;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AnimationUtils;
import com.android.keyguard.AlphaOptimizedImageButton;

public class QsAddButton extends AlphaOptimizedImageButton {
    private ObjectAnimator mRotateAnimator;

    public QsAddButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mRotateAnimator = null;
    }

    public synchronized void rotate(float deg) {
        if (this.mRotateAnimator != null) {
            this.mRotateAnimator.removeAllListeners();
            this.mRotateAnimator.cancel();
        }
        this.mRotateAnimator = ObjectAnimator.ofFloat(this, View.ROTATION, new float[]{getRotation(), deg});
        this.mRotateAnimator.setDuration(350);
        this.mRotateAnimator.setInterpolator(AnimationUtils.loadInterpolator(this.mContext, 17563656));
        this.mRotateAnimator.start();
    }
}
