package com.android.keyguard;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.TypedArray;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.telephony.ServiceState;
import android.telephony.SubscriptionInfo;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.text.method.SingleLineTransformationMethod;
import android.util.AttributeSet;
import android.util.Log;
import android.util.NativeTextHelper;
import android.view.View;
import android.widget.TextView;
import com.android.internal.telephony.IccCardConstants.State;
import com.android.settingslib.WirelessUtils;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class CarrierText extends TextView {
    private static CharSequence mSeparator;
    private KeyguardUpdateMonitorCallback mCallback;
    private final boolean mIsEmergencyCallCapable;
    private KeyguardUpdateMonitor mKeyguardUpdateMonitor;
    private boolean[] mSimErrorState;
    private WifiManager mWifiManager;

    /* renamed from: com.android.keyguard.CarrierText.1 */
    class C00011 extends KeyguardUpdateMonitorCallback {
        C00011() {
        }

        public void onRefreshCarrierInfo() {
            CarrierText.this.updateCarrierText();
        }

        public void onFinishedGoingToSleep(int why) {
            CarrierText.this.setSelected(false);
        }

        public void onStartedWakingUp() {
            CarrierText.this.setSelected(true);
        }

        public void onSimStateChanged(int subId, int slotId, State simState) {
            if (slotId < 0) {
                Log.d("CarrierText", "onSimStateChanged() - slotId invalid: " + slotId);
                return;
            }
            Log.d("CarrierText", "onSimStateChanged: " + CarrierText.this.getStatusForIccState(simState));
            if (CarrierText.this.getStatusForIccState(simState) == StatusMode.SimIoError) {
                CarrierText.this.mSimErrorState[slotId] = true;
                CarrierText.this.updateCarrierText();
            } else if (CarrierText.this.mSimErrorState[slotId]) {
                CarrierText.this.mSimErrorState[slotId] = false;
                CarrierText.this.updateCarrierText();
            }
        }
    }

    /* renamed from: com.android.keyguard.CarrierText.2 */
    static /* synthetic */ class C00022 {
        static final /* synthetic */ int[] $SwitchMap$com$android$internal$telephony$IccCardConstants$State;
        static final /* synthetic */ int[] $SwitchMap$com$android$keyguard$CarrierText$StatusMode;

        static {
            $SwitchMap$com$android$internal$telephony$IccCardConstants$State = new int[State.values().length];
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.ABSENT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.NETWORK_LOCKED.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.NOT_READY.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.PIN_REQUIRED.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.PUK_REQUIRED.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.READY.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.PERM_DISABLED.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.UNKNOWN.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.CARD_IO_ERROR.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
            $SwitchMap$com$android$keyguard$CarrierText$StatusMode = new int[StatusMode.values().length];
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.Normal.ordinal()] = 1;
            } catch (NoSuchFieldError e10) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.SimNotReady.ordinal()] = 2;
            } catch (NoSuchFieldError e11) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.NetworkLocked.ordinal()] = 3;
            } catch (NoSuchFieldError e12) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.SimMissing.ordinal()] = 4;
            } catch (NoSuchFieldError e13) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.SimPermDisabled.ordinal()] = 5;
            } catch (NoSuchFieldError e14) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.SimMissingLocked.ordinal()] = 6;
            } catch (NoSuchFieldError e15) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.SimLocked.ordinal()] = 7;
            } catch (NoSuchFieldError e16) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.SimPukLocked.ordinal()] = 8;
            } catch (NoSuchFieldError e17) {
            }
            try {
                $SwitchMap$com$android$keyguard$CarrierText$StatusMode[StatusMode.SimIoError.ordinal()] = 9;
            } catch (NoSuchFieldError e18) {
            }
        }
    }

    private class CarrierTextTransformationMethod extends SingleLineTransformationMethod {
        private final boolean mAllCaps;
        private final Locale mLocale;

        public CarrierTextTransformationMethod(Context context, boolean allCaps) {
            this.mLocale = context.getResources().getConfiguration().locale;
            this.mAllCaps = allCaps;
        }

        public CharSequence getTransformation(CharSequence source, View view) {
            source = super.getTransformation(source, view);
            if (!this.mAllCaps || source == null) {
                return source;
            }
            return source.toString().toUpperCase(this.mLocale);
        }
    }

    private enum StatusMode {
        Normal,
        NetworkLocked,
        SimMissing,
        SimMissingLocked,
        SimPukLocked,
        SimLocked,
        SimPermDisabled,
        SimNotReady,
        SimIoError
    }

    public CarrierText(Context context) {
        this(context, null);
    }

    public CarrierText(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mSimErrorState = new boolean[TelephonyManager.getDefault().getPhoneCount()];
        this.mCallback = new C00011();
        this.mIsEmergencyCallCapable = context.getResources().getBoolean(17956953);
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, C0065R.styleable.CarrierText, 0, 0);
        try {
            boolean useAllCaps = a.getBoolean(C0065R.styleable.CarrierText_allCaps, false);
            setTransformationMethod(new CarrierTextTransformationMethod(this.mContext, useAllCaps));
            this.mWifiManager = (WifiManager) context.getSystemService("wifi");
        } finally {
            a.recycle();
        }
    }

    private CharSequence updateCarrierTextWithSimIoError(CharSequence text, boolean noSims) {
        CharSequence carrierTextForSimState = getCarrierTextForSimState(State.CARD_IO_ERROR, "");
        for (int index = 0; index < this.mSimErrorState.length; index++) {
            if (this.mSimErrorState[index]) {
                if (noSims) {
                    return concatenate(carrierTextForSimState, getContext().getText(17040028));
                }
                if (index == 0) {
                    text = concatenate(carrierTextForSimState, text);
                } else {
                    text = concatenate(text, carrierTextForSimState);
                }
            }
        }
        return text;
    }

    protected void updateCarrierText() {
        boolean allSimsMissing = true;
        boolean anySimReadyAndInService = false;
        boolean showLocale = getContext().getResources().getBoolean(17957034);
        boolean showRat = getContext().getResources().getBoolean(17957035);
        CharSequence displayText = null;
        List<SubscriptionInfo> subs = this.mKeyguardUpdateMonitor.getSubscriptionInfo(false);
        int N = subs.size();
        for (int i = 0; i < N; i++) {
            ServiceState ss;
            CharSequence networkClass = "";
            int subId = ((SubscriptionInfo) subs.get(i)).getSubscriptionId();
            State simState = this.mKeyguardUpdateMonitor.getSimState(subId);
            if (showRat) {
                ss = (ServiceState) this.mKeyguardUpdateMonitor.mServiceStates.get(Integer.valueOf(subId));
                TelephonyManager tm = new TelephonyManager(getContext());
                if (ss != null && (ss.getDataRegState() == 0 || ss.getVoiceRegState() == 0)) {
                    int networkType = 0;
                    if (ss.getRilDataRadioTechnology() != 0) {
                        networkType = ss.getDataNetworkType();
                    } else if (ss.getRilVoiceRadioTechnology() != 0) {
                        networkType = ss.getVoiceNetworkType();
                    }
                    networkClass = networkClassToString(TelephonyManager.getNetworkClass(networkType));
                }
            }
            CharSequence carrierName = ((SubscriptionInfo) subs.get(i)).getCarrierName();
            if (showLocale || showRat) {
                String[] names = carrierName.toString().split(mSeparator.toString(), 2);
                StringBuilder newCarrierName = new StringBuilder();
                int j = 0;
                while (true) {
                    int length = names.length;
                    if (j >= r0) {
                        break;
                    }
                    if (showLocale) {
                        names[j] = NativeTextHelper.getLocalString(getContext(), names[j], 17236038, 17236039);
                    }
                    if (!TextUtils.isEmpty(names[j])) {
                        if (!TextUtils.isEmpty(networkClass) && showRat) {
                            names[j] = names[j] + " " + networkClass;
                        }
                        if (j <= 0 || !names[j].equals(names[j - 1])) {
                            if (j > 0) {
                                newCarrierName.append(mSeparator);
                            }
                            newCarrierName.append(names[j]);
                        }
                    }
                    j++;
                }
                carrierName = newCarrierName.toString();
            }
            CharSequence carrierTextForSimState = getCarrierTextForSimState(simState, carrierName);
            if (carrierTextForSimState != null) {
                allSimsMissing = false;
                displayText = concatenate(displayText, carrierTextForSimState);
            }
            if (simState == State.READY) {
                ss = (ServiceState) this.mKeyguardUpdateMonitor.mServiceStates.get(Integer.valueOf(subId));
                if (ss != null && ss.getDataRegState() == 0) {
                    if (ss.getRilDataRadioTechnology() == 18) {
                        if (this.mWifiManager.isWifiEnabled()) {
                            if (this.mWifiManager.getConnectionInfo() != null) {
                                if (this.mWifiManager.getConnectionInfo().getBSSID() == null) {
                                }
                            }
                        }
                    }
                    anySimReadyAndInService = true;
                }
            }
        }
        if (N < TelephonyManager.getDefault().getPhoneCount()) {
            if (this.mKeyguardUpdateMonitor.isEmergencyOnly()) {
                int presentSubId = this.mKeyguardUpdateMonitor.getPresentSubId();
                if (presentSubId != -1) {
                    CharSequence emergencyOnlyText = getContext().getText(17040028);
                    displayText = getCarrierTextForSimState(this.mKeyguardUpdateMonitor.getSimState(presentSubId), emergencyOnlyText);
                }
            }
        }
        if (allSimsMissing) {
            if (N != 0) {
                displayText = makeCarrierStringOnEmergencyCapable(getContext().getText(C0065R.string.keyguard_missing_sim_message_short), ((SubscriptionInfo) subs.get(0)).getCarrierName());
            } else {
                CharSequence text = getContext().getText(17040028);
                Intent i2 = getContext().registerReceiver(null, new IntentFilter("android.provider.Telephony.SPN_STRINGS_UPDATED"));
                if (i2 != null) {
                    String spn = "";
                    String plmn = "";
                    if (i2.getBooleanExtra("showSpn", false)) {
                        spn = i2.getStringExtra("spn");
                    }
                    if (i2.getBooleanExtra("showPlmn", false)) {
                        plmn = i2.getStringExtra("plmn");
                    }
                    if (Objects.equals(plmn, spn)) {
                        text = plmn;
                    } else {
                        text = concatenate(plmn, spn);
                    }
                }
                displayText = makeCarrierStringOnEmergencyCapable(getContext().getText(C0065R.string.keyguard_missing_sim_message_short), text);
            }
        }
        displayText = updateCarrierTextWithSimIoError(displayText, allSimsMissing);
        if (!anySimReadyAndInService) {
            if (WirelessUtils.isAirplaneModeOn(this.mContext)) {
                displayText = getContext().getString(C0065R.string.airplane_mode);
            }
        }
        setText(displayText);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        mSeparator = getResources().getString(17040648);
        setSelected(KeyguardUpdateMonitor.getInstance(this.mContext).isDeviceInteractive());
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (ConnectivityManager.from(this.mContext).isNetworkSupported(0)) {
            this.mKeyguardUpdateMonitor = KeyguardUpdateMonitor.getInstance(this.mContext);
            this.mKeyguardUpdateMonitor.registerCallback(this.mCallback);
            return;
        }
        this.mKeyguardUpdateMonitor = null;
        setText("");
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mKeyguardUpdateMonitor != null) {
            this.mKeyguardUpdateMonitor.removeCallback(this.mCallback);
        }
    }

    private CharSequence getCarrierTextForSimState(State simState, CharSequence text) {
        switch (C00022.$SwitchMap$com$android$keyguard$CarrierText$StatusMode[getStatusForIccState(simState).ordinal()]) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return text;
            case 2:
                CharSequence carrierText = "";
                if (TelephonyManager.getDefault().isMultiSimEnabled()) {
                    return text;
                }
                return carrierText;
            case 3:
                return makeCarrierStringOnEmergencyCapable(getContext().getText(C0065R.string.keyguard_perso_locked_message), text);
            case 4:
                return null;
            case 5:
                return getContext().getText(C0065R.string.keyguard_permanent_disabled_sim_message_short);
            case 6:
                return null;
            case 7:
                return makeCarrierStringOnEmergencyCapable(getContext().getText(C0065R.string.keyguard_sim_locked_message), text);
            case 8:
                return makeCarrierStringOnEmergencyCapable(getContext().getText(C0065R.string.keyguard_sim_puk_locked_message), text);
            case 9:
                return makeCarrierStringOnEmergencyCapable(getContext().getText(C0065R.string.lockscreen_sim_error_message_short), text);
            default:
                return null;
        }
    }

    private CharSequence makeCarrierStringOnEmergencyCapable(CharSequence simMessage, CharSequence emergencyCallMessage) {
        if (this.mIsEmergencyCallCapable) {
            return concatenate(simMessage, emergencyCallMessage);
        }
        return simMessage;
    }

    private StatusMode getStatusForIccState(State simState) {
        if (simState == null) {
            return StatusMode.Normal;
        }
        boolean missingAndNotProvisioned = !KeyguardUpdateMonitor.getInstance(this.mContext).isDeviceProvisioned() && (simState == State.ABSENT || simState == State.PERM_DISABLED);
        if (missingAndNotProvisioned) {
            simState = State.NETWORK_LOCKED;
        }
        switch (C00022.$SwitchMap$com$android$internal$telephony$IccCardConstants$State[simState.ordinal()]) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return StatusMode.SimMissing;
            case 2:
                return StatusMode.NetworkLocked;
            case 3:
                return StatusMode.SimNotReady;
            case 4:
                return StatusMode.SimLocked;
            case 5:
                return StatusMode.SimPukLocked;
            case 6:
                return StatusMode.Normal;
            case 7:
                return StatusMode.SimPermDisabled;
            case 8:
                return StatusMode.SimMissing;
            case 9:
                return StatusMode.SimIoError;
            default:
                return StatusMode.SimMissing;
        }
    }

    private static CharSequence concatenate(CharSequence plmn, CharSequence spn) {
        boolean plmnValid;
        boolean spnValid;
        if (TextUtils.isEmpty(plmn)) {
            plmnValid = false;
        } else {
            plmnValid = true;
        }
        if (TextUtils.isEmpty(spn)) {
            spnValid = false;
        } else {
            spnValid = true;
        }
        if (plmnValid && spnValid) {
            return plmn + mSeparator + spn;
        }
        if (plmnValid) {
            return plmn;
        }
        if (spnValid) {
            return spn;
        }
        return "";
    }

    private String networkClassToString(int networkClass) {
        int[] classIds = new int[]{17039446, 17039447, 17039448, 17039449};
        String classString = null;
        if (networkClass < classIds.length) {
            classString = getContext().getResources().getString(classIds[networkClass]);
        }
        return classString == null ? "" : classString;
    }
}
