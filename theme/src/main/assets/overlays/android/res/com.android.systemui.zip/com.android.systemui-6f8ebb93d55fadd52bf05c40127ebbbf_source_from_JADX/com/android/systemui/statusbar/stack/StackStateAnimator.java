package com.android.systemui.statusbar.stack;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.ExpandableNotificationRow;
import com.android.systemui.statusbar.ExpandableView;
import com.android.systemui.statusbar.SpeedBumpView;
import com.android.systemui.statusbar.policy.HeadsUpManager;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;

public class StackStateAnimator {
    private AnimationFilter mAnimationFilter;
    private Stack<AnimatorListenerAdapter> mAnimationListenerPool;
    private HashSet<Animator> mAnimatorSet;
    private ValueAnimator mBottomOverScrollAnimator;
    private ExpandableNotificationRow mChildExpandingView;
    private ArrayList<View> mChildrenToClearFromOverlay;
    private long mCurrentAdditionalDelay;
    private int mCurrentLastNotAddedIndex;
    private long mCurrentLength;
    private final Interpolator mFastOutSlowInInterpolator;
    private final int mGoToFullShadeAppearingTranslation;
    private HashSet<View> mHeadsUpAppearChildren;
    private int mHeadsUpAppearHeightBottom;
    private final Interpolator mHeadsUpAppearInterpolator;
    private HashSet<View> mHeadsUpDisappearChildren;
    public NotificationStackScrollLayout mHostLayout;
    private ArrayList<View> mNewAddChildren;
    private ArrayList<AnimationEvent> mNewEvents;
    private boolean mShadeExpanded;
    private final StackViewState mTmpState;
    private ValueAnimator mTopOverScrollAnimator;

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.10 */
    class AnonymousClass10 implements Runnable {
        final /* synthetic */ ExpandableView val$changingView;

        AnonymousClass10(ExpandableView expandableView) {
            this.val$changingView = expandableView;
        }

        public void run() {
            StackStateAnimator.this.mHostLayout.getOverlay().remove(this.val$changingView);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.11 */
    class AnonymousClass11 implements AnimatorUpdateListener {
        final /* synthetic */ boolean val$isRubberbanded;
        final /* synthetic */ boolean val$onTop;

        AnonymousClass11(boolean z, boolean z2) {
            this.val$onTop = z;
            this.val$isRubberbanded = z2;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            StackStateAnimator.this.mHostLayout.setOverScrollAmount(((Float) animation.getAnimatedValue()).floatValue(), this.val$onTop, false, false, this.val$isRubberbanded);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.12 */
    class AnonymousClass12 extends AnimatorListenerAdapter {
        final /* synthetic */ boolean val$onTop;

        AnonymousClass12(boolean z) {
            this.val$onTop = z;
        }

        public void onAnimationEnd(Animator animation) {
            if (this.val$onTop) {
                StackStateAnimator.this.mTopOverScrollAnimator = null;
            } else {
                StackStateAnimator.this.mBottomOverScrollAnimator = null;
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.1 */
    class C05151 implements AnimatorUpdateListener {
        final /* synthetic */ ExpandableView val$child;

        C05151(ExpandableView expandableView) {
            this.val$child = expandableView;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            this.val$child.setActualHeight(((Integer) animation.getAnimatedValue()).intValue(), false);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.2 */
    class C05162 extends AnimatorListenerAdapter {
        final /* synthetic */ ExpandableView val$child;

        C05162(ExpandableView expandableView) {
            this.val$child = expandableView;
        }

        public void onAnimationEnd(Animator animation) {
            this.val$child.setTag(2131755013, null);
            this.val$child.setTag(2131755025, null);
            this.val$child.setTag(2131755019, null);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.3 */
    class C05173 implements AnimatorUpdateListener {
        final /* synthetic */ ExpandableView val$child;

        C05173(ExpandableView expandableView) {
            this.val$child = expandableView;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            this.val$child.setClipTopAmount(((Integer) animation.getAnimatedValue()).intValue());
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.4 */
    class C05184 extends AnimatorListenerAdapter {
        final /* synthetic */ ExpandableView val$child;

        C05184(ExpandableView expandableView) {
            this.val$child = expandableView;
        }

        public void onAnimationEnd(Animator animation) {
            this.val$child.setTag(2131755012, null);
            this.val$child.setTag(2131755024, null);
            this.val$child.setTag(2131755018, null);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.5 */
    class C05195 extends AnimatorListenerAdapter {
        public boolean mWasCancelled;
        final /* synthetic */ View val$child;
        final /* synthetic */ float val$newEndValue;

        C05195(View view, float f) {
            this.val$child = view;
            this.val$newEndValue = f;
        }

        public void onAnimationEnd(Animator animation) {
            this.val$child.setLayerType(0, null);
            if (this.val$newEndValue == 0.0f && !this.mWasCancelled) {
                this.val$child.setVisibility(4);
            }
            this.val$child.setTag(2131755011, null);
            this.val$child.setTag(2131755023, null);
            this.val$child.setTag(2131755017, null);
        }

        public void onAnimationCancel(Animator animation) {
            this.mWasCancelled = true;
        }

        public void onAnimationStart(Animator animation) {
            this.mWasCancelled = false;
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.6 */
    class C05206 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$child;

        C05206(View view) {
            this.val$child = view;
        }

        public void onAnimationEnd(Animator animation) {
            this.val$child.setTag(2131755009, null);
            this.val$child.setTag(2131755021, null);
            this.val$child.setTag(2131755015, null);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.7 */
    class C05217 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$child;

        C05217(View view) {
            this.val$child = view;
        }

        public void onAnimationEnd(Animator animation) {
            HeadsUpManager.setIsClickedNotification(this.val$child, false);
            this.val$child.setTag(2131755008, null);
            this.val$child.setTag(2131755020, null);
            this.val$child.setTag(2131755014, null);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.8 */
    class C05228 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$child;

        C05228(View view) {
            this.val$child = view;
        }

        public void onAnimationEnd(Animator animation) {
            this.val$child.setTag(2131755010, null);
            this.val$child.setTag(2131755022, null);
            this.val$child.setTag(2131755016, null);
        }
    }

    /* renamed from: com.android.systemui.statusbar.stack.StackStateAnimator.9 */
    class C05239 extends AnimatorListenerAdapter {
        private boolean mWasCancelled;

        C05239() {
        }

        public void onAnimationEnd(Animator animation) {
            StackStateAnimator.this.mAnimatorSet.remove(animation);
            if (StackStateAnimator.this.mAnimatorSet.isEmpty() && !this.mWasCancelled) {
                StackStateAnimator.this.onAnimationFinished();
            }
            StackStateAnimator.this.mAnimationListenerPool.push(this);
        }

        public void onAnimationCancel(Animator animation) {
            this.mWasCancelled = true;
        }

        public void onAnimationStart(Animator animation) {
            this.mWasCancelled = false;
        }
    }

    public StackStateAnimator(NotificationStackScrollLayout hostLayout) {
        this.mTmpState = new StackViewState();
        this.mNewEvents = new ArrayList();
        this.mNewAddChildren = new ArrayList();
        this.mHeadsUpAppearChildren = new HashSet();
        this.mHeadsUpDisappearChildren = new HashSet();
        this.mAnimatorSet = new HashSet();
        this.mAnimationListenerPool = new Stack();
        this.mAnimationFilter = new AnimationFilter();
        this.mChildrenToClearFromOverlay = new ArrayList();
        this.mHostLayout = hostLayout;
        this.mFastOutSlowInInterpolator = AnimationUtils.loadInterpolator(hostLayout.getContext(), 17563661);
        this.mGoToFullShadeAppearingTranslation = hostLayout.getContext().getResources().getDimensionPixelSize(2131296424);
        this.mHeadsUpAppearInterpolator = new HeadsUpAppearInterpolator();
    }

    public boolean isRunning() {
        return !this.mAnimatorSet.isEmpty();
    }

    public void startAnimationForEvents(ArrayList<AnimationEvent> mAnimationEvents, StackScrollState finalState, long additionalDelay) {
        processAnimationEvents(mAnimationEvents, finalState);
        int childCount = this.mHostLayout.getChildCount();
        this.mAnimationFilter.applyCombination(this.mNewEvents);
        this.mCurrentAdditionalDelay = additionalDelay;
        this.mCurrentLength = AnimationEvent.combineLength(this.mNewEvents);
        this.mCurrentLastNotAddedIndex = findLastNotAddedIndex(finalState);
        for (int i = 0; i < childCount; i++) {
            ExpandableView child = (ExpandableView) this.mHostLayout.getChildAt(i);
            StackViewState viewState = finalState.getViewStateForView(child);
            if (!(viewState == null || child.getVisibility() == 8 || applyWithoutAnimation(child, viewState, finalState))) {
                child.setClipTopOptimization(0);
                startStackAnimations(child, viewState, finalState, i, -1);
            }
        }
        if (!isRunning()) {
            onAnimationFinished();
        }
        this.mHeadsUpAppearChildren.clear();
        this.mHeadsUpDisappearChildren.clear();
        this.mNewEvents.clear();
        this.mNewAddChildren.clear();
        this.mChildExpandingView = null;
    }

    private boolean applyWithoutAnimation(ExpandableView child, StackViewState viewState, StackScrollState finalState) {
        if (this.mShadeExpanded || getChildTag(child, 2131755008) != null || this.mHeadsUpDisappearChildren.contains(child) || this.mHeadsUpAppearChildren.contains(child) || NotificationStackScrollLayout.isPinnedHeadsUp(child)) {
            return false;
        }
        finalState.applyState(child, viewState);
        return true;
    }

    private int findLastNotAddedIndex(StackScrollState finalState) {
        for (int i = this.mHostLayout.getChildCount() - 1; i >= 0; i--) {
            ExpandableView child = (ExpandableView) this.mHostLayout.getChildAt(i);
            StackViewState viewState = finalState.getViewStateForView(child);
            if (viewState != null && child.getVisibility() != 8 && !this.mNewAddChildren.contains(child)) {
                return viewState.notGoneIndex;
            }
        }
        return -1;
    }

    public void startStackAnimations(ExpandableView child, StackViewState viewState, StackScrollState finalState, int i, long fixedDelay) {
        float alpha = viewState.alpha;
        boolean wasAdded = this.mNewAddChildren.contains(child);
        long duration = this.mCurrentLength;
        if (wasAdded && this.mAnimationFilter.hasGoToFullShadeEvent) {
            child.setTranslationY(child.getTranslationY() + ((float) this.mGoToFullShadeAppearingTranslation));
            duration = 514 + ((long) (100.0f * ((float) Math.pow((double) ((float) (viewState.notGoneIndex - this.mCurrentLastNotAddedIndex)), 0.699999988079071d))));
        }
        boolean yTranslationChanging = child.getTranslationY() != viewState.yTranslation;
        boolean zTranslationChanging = child.getTranslationZ() != viewState.zTranslation;
        boolean scaleChanging = child.getScaleX() != viewState.scale;
        boolean alphaChanging = alpha != child.getAlpha();
        boolean heightChanging = viewState.height != child.getActualHeight();
        boolean darkChanging = viewState.dark != child.isDark();
        boolean topInsetChanging = viewState.clipTopAmount != child.getClipTopAmount();
        boolean hasDelays = this.mAnimationFilter.hasDelays;
        boolean isDelayRelevant = yTranslationChanging || zTranslationChanging || scaleChanging || alphaChanging || heightChanging || topInsetChanging || darkChanging;
        long delay = 0;
        if (fixedDelay != -1) {
            delay = fixedDelay;
        } else if ((hasDelays && isDelayRelevant) || wasAdded) {
            delay = this.mCurrentAdditionalDelay + calculateChildAnimationDelay(viewState, finalState);
        }
        startViewAnimations(child, viewState, delay, duration);
        if (heightChanging && child.getActualHeight() != 0) {
            startHeightAnimation(child, viewState, duration, delay);
        }
        if (topInsetChanging) {
            startInsetAnimation(child, viewState, duration, delay);
        }
        child.setDimmed(viewState.dimmed, this.mAnimationFilter.animateDimmed);
        child.setBelowSpeedBump(viewState.belowSpeedBump);
        child.setHideSensitive(viewState.hideSensitive, this.mAnimationFilter.animateHideSensitive, delay, duration);
        child.setDark(viewState.dark, this.mAnimationFilter.animateDark, delay);
        if (wasAdded) {
            child.performAddAnimation(delay, this.mCurrentLength);
        }
        if (child instanceof SpeedBumpView) {
            finalState.performSpeedBumpAnimation(i, (SpeedBumpView) child, viewState, delay + duration);
        } else if (child instanceof ExpandableNotificationRow) {
            ((ExpandableNotificationRow) child).startChildAnimation(finalState, this, child == this.mChildExpandingView, delay, duration);
        }
    }

    public void startViewAnimations(View child, ViewState viewState, long delay, long duration) {
        boolean wasVisible = child.getVisibility() == 0;
        float alpha = viewState.alpha;
        if (!(wasVisible || alpha == 0.0f || viewState.gone)) {
            child.setVisibility(0);
        }
        boolean yTranslationChanging = child.getTranslationY() != viewState.yTranslation;
        boolean zTranslationChanging = child.getTranslationZ() != viewState.zTranslation;
        boolean scaleChanging = child.getScaleX() != viewState.scale;
        boolean alphaChanging = viewState.alpha != (child.getVisibility() == 4 ? 0.0f : child.getAlpha());
        if (child instanceof ExpandableView) {
            alphaChanging &= !((ExpandableView) child).willBeGone() ? 1 : 0;
        }
        if (yTranslationChanging) {
            startYTranslationAnimation(child, viewState, duration, delay);
        }
        if (zTranslationChanging) {
            startZTranslationAnimation(child, viewState, duration, delay);
        }
        if (scaleChanging) {
            startScaleAnimation(child, viewState, duration);
        }
        if (alphaChanging && child.getTranslationX() == 0.0f) {
            startAlphaAnimation(child, viewState, duration, delay);
        }
    }

    private long calculateChildAnimationDelay(StackViewState viewState, StackScrollState finalState) {
        if (this.mAnimationFilter.hasDarkEvent) {
            return calculateDelayDark(viewState);
        }
        if (this.mAnimationFilter.hasGoToFullShadeEvent) {
            return calculateDelayGoToFullShade(viewState);
        }
        if (this.mAnimationFilter.hasHeadsUpDisappearClickEvent) {
            return 120;
        }
        long minDelay = 0;
        Iterator i$ = this.mNewEvents.iterator();
        while (i$.hasNext()) {
            AnimationEvent event = (AnimationEvent) i$.next();
            long delayPerElement = 80;
            switch (event.animationType) {
                case C0065R.styleable.NumPadKey_digit /*0*/:
                    minDelay = Math.max(((long) (2 - Math.max(0, Math.min(2, Math.abs(viewState.notGoneIndex - finalState.getViewStateForView(event.changingView).notGoneIndex) - 1)))) * 80, minDelay);
                    continue;
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    break;
                case 2:
                    delayPerElement = 32;
                    break;
                default:
                    continue;
            }
            int ownIndex = viewState.notGoneIndex;
            int nextIndex = finalState.getViewStateForView(event.viewAfterChangingView == null ? this.mHostLayout.getLastChildNotGone() : event.viewAfterChangingView).notGoneIndex;
            if (ownIndex >= nextIndex) {
                ownIndex++;
            }
            minDelay = Math.max(((long) Math.max(0, Math.min(2, Math.abs(ownIndex - nextIndex) - 1))) * delayPerElement, minDelay);
        }
        return minDelay;
    }

    private long calculateDelayDark(StackViewState viewState) {
        int referenceIndex;
        if (this.mAnimationFilter.darkAnimationOriginIndex == -1) {
            referenceIndex = 0;
        } else if (this.mAnimationFilter.darkAnimationOriginIndex == -2) {
            referenceIndex = this.mHostLayout.getNotGoneChildCount() - 1;
        } else {
            referenceIndex = this.mAnimationFilter.darkAnimationOriginIndex;
        }
        return (long) (Math.abs(referenceIndex - viewState.notGoneIndex) * 24);
    }

    private long calculateDelayGoToFullShade(StackViewState viewState) {
        return (long) (48.0f * ((float) Math.pow((double) ((float) viewState.notGoneIndex), 0.699999988079071d)));
    }

    private void startHeightAnimation(ExpandableView child, StackViewState viewState, long duration, long delay) {
        Integer previousStartValue = (Integer) getChildTag(child, 2131755025);
        Integer previousEndValue = (Integer) getChildTag(child, 2131755019);
        int newEndValue = viewState.height;
        if (previousEndValue == null || previousEndValue.intValue() != newEndValue) {
            ValueAnimator previousAnimator = (ValueAnimator) getChildTag(child, 2131755013);
            if (this.mAnimationFilter.animateHeight) {
                ValueAnimator animator = ValueAnimator.ofInt(new int[]{child.getActualHeight(), newEndValue});
                animator.addUpdateListener(new C05151(child));
                animator.setInterpolator(this.mFastOutSlowInInterpolator);
                animator.setDuration(cancelAnimatorAndGetNewDuration(duration, previousAnimator));
                if (delay > 0 && (previousAnimator == null || !previousAnimator.isRunning())) {
                    animator.setStartDelay(delay);
                }
                animator.addListener(getGlobalAnimationFinishedListener());
                animator.addListener(new C05162(child));
                startAnimator(animator);
                child.setTag(2131755013, animator);
                child.setTag(2131755025, Integer.valueOf(child.getActualHeight()));
                child.setTag(2131755019, Integer.valueOf(newEndValue));
            } else if (previousAnimator != null) {
                int newStartValue = previousStartValue.intValue() + (newEndValue - previousEndValue.intValue());
                previousAnimator.getValues()[0].setIntValues(new int[]{newStartValue, newEndValue});
                child.setTag(2131755025, Integer.valueOf(newStartValue));
                child.setTag(2131755019, Integer.valueOf(newEndValue));
                previousAnimator.setCurrentPlayTime(previousAnimator.getCurrentPlayTime());
            } else {
                child.setActualHeight(newEndValue, false);
            }
        }
    }

    private void startInsetAnimation(ExpandableView child, StackViewState viewState, long duration, long delay) {
        Integer previousStartValue = (Integer) getChildTag(child, 2131755024);
        Integer previousEndValue = (Integer) getChildTag(child, 2131755018);
        int newEndValue = viewState.clipTopAmount;
        if (previousEndValue == null || previousEndValue.intValue() != newEndValue) {
            ValueAnimator previousAnimator = (ValueAnimator) getChildTag(child, 2131755012);
            if (this.mAnimationFilter.animateTopInset) {
                ValueAnimator animator = ValueAnimator.ofInt(new int[]{child.getClipTopAmount(), newEndValue});
                animator.addUpdateListener(new C05173(child));
                animator.setInterpolator(this.mFastOutSlowInInterpolator);
                animator.setDuration(cancelAnimatorAndGetNewDuration(duration, previousAnimator));
                if (delay > 0 && (previousAnimator == null || !previousAnimator.isRunning())) {
                    animator.setStartDelay(delay);
                }
                animator.addListener(getGlobalAnimationFinishedListener());
                animator.addListener(new C05184(child));
                startAnimator(animator);
                child.setTag(2131755012, animator);
                child.setTag(2131755024, Integer.valueOf(child.getClipTopAmount()));
                child.setTag(2131755018, Integer.valueOf(newEndValue));
            } else if (previousAnimator != null) {
                int newStartValue = previousStartValue.intValue() + (newEndValue - previousEndValue.intValue());
                previousAnimator.getValues()[0].setIntValues(new int[]{newStartValue, newEndValue});
                child.setTag(2131755024, Integer.valueOf(newStartValue));
                child.setTag(2131755018, Integer.valueOf(newEndValue));
                previousAnimator.setCurrentPlayTime(previousAnimator.getCurrentPlayTime());
            } else {
                child.setClipTopAmount(newEndValue);
            }
        }
    }

    private void startAlphaAnimation(View child, ViewState viewState, long duration, long delay) {
        Float previousStartValue = (Float) getChildTag(child, 2131755023);
        Float previousEndValue = (Float) getChildTag(child, 2131755017);
        float newEndValue = viewState.alpha;
        if (previousEndValue == null || previousEndValue.floatValue() != newEndValue) {
            ObjectAnimator previousAnimator = (ObjectAnimator) getChildTag(child, 2131755011);
            if (!this.mAnimationFilter.animateAlpha) {
                if (previousAnimator != null) {
                    float newStartValue = previousStartValue.floatValue() + (newEndValue - previousEndValue.floatValue());
                    previousAnimator.getValues()[0].setFloatValues(new float[]{newStartValue, newEndValue});
                    child.setTag(2131755023, Float.valueOf(newStartValue));
                    child.setTag(2131755017, Float.valueOf(newEndValue));
                    previousAnimator.setCurrentPlayTime(previousAnimator.getCurrentPlayTime());
                    return;
                }
                child.setAlpha(newEndValue);
                if (newEndValue == 0.0f) {
                    child.setVisibility(4);
                }
            }
            ObjectAnimator animator = ObjectAnimator.ofFloat(child, View.ALPHA, new float[]{child.getAlpha(), newEndValue});
            animator.setInterpolator(this.mFastOutSlowInInterpolator);
            child.setLayerType(2, null);
            animator.addListener(new C05195(child, newEndValue));
            animator.setDuration(cancelAnimatorAndGetNewDuration(duration, previousAnimator));
            if (delay > 0 && (previousAnimator == null || !previousAnimator.isRunning())) {
                animator.setStartDelay(delay);
            }
            animator.addListener(getGlobalAnimationFinishedListener());
            startAnimator(animator);
            child.setTag(2131755011, animator);
            child.setTag(2131755023, Float.valueOf(child.getAlpha()));
            child.setTag(2131755017, Float.valueOf(newEndValue));
        }
    }

    private void startZTranslationAnimation(View child, ViewState viewState, long duration, long delay) {
        Float previousStartValue = (Float) getChildTag(child, 2131755021);
        Float previousEndValue = (Float) getChildTag(child, 2131755015);
        float newEndValue = viewState.zTranslation;
        if (previousEndValue == null || previousEndValue.floatValue() != newEndValue) {
            ObjectAnimator previousAnimator = (ObjectAnimator) getChildTag(child, 2131755009);
            if (!this.mAnimationFilter.animateZ) {
                if (previousAnimator != null) {
                    float newStartValue = previousStartValue.floatValue() + (newEndValue - previousEndValue.floatValue());
                    previousAnimator.getValues()[0].setFloatValues(new float[]{newStartValue, newEndValue});
                    child.setTag(2131755021, Float.valueOf(newStartValue));
                    child.setTag(2131755015, Float.valueOf(newEndValue));
                    previousAnimator.setCurrentPlayTime(previousAnimator.getCurrentPlayTime());
                    return;
                }
                child.setTranslationZ(newEndValue);
            }
            ObjectAnimator animator = ObjectAnimator.ofFloat(child, View.TRANSLATION_Z, new float[]{child.getTranslationZ(), newEndValue});
            animator.setInterpolator(this.mFastOutSlowInInterpolator);
            animator.setDuration(cancelAnimatorAndGetNewDuration(duration, previousAnimator));
            if (delay > 0 && (previousAnimator == null || !previousAnimator.isRunning())) {
                animator.setStartDelay(delay);
            }
            animator.addListener(getGlobalAnimationFinishedListener());
            animator.addListener(new C05206(child));
            startAnimator(animator);
            child.setTag(2131755009, animator);
            child.setTag(2131755021, Float.valueOf(child.getTranslationZ()));
            child.setTag(2131755015, Float.valueOf(newEndValue));
        }
    }

    private void startYTranslationAnimation(View child, ViewState viewState, long duration, long delay) {
        Float previousStartValue = (Float) getChildTag(child, 2131755020);
        Float previousEndValue = (Float) getChildTag(child, 2131755014);
        float newEndValue = viewState.yTranslation;
        if (previousEndValue == null || previousEndValue.floatValue() != newEndValue) {
            ObjectAnimator previousAnimator = (ObjectAnimator) getChildTag(child, 2131755008);
            if (this.mAnimationFilter.animateY) {
                ObjectAnimator animator = ObjectAnimator.ofFloat(child, View.TRANSLATION_Y, new float[]{child.getTranslationY(), newEndValue});
                animator.setInterpolator(this.mHeadsUpAppearChildren.contains(child) ? this.mHeadsUpAppearInterpolator : this.mFastOutSlowInInterpolator);
                animator.setDuration(cancelAnimatorAndGetNewDuration(duration, previousAnimator));
                if (delay > 0 && (previousAnimator == null || !previousAnimator.isRunning())) {
                    animator.setStartDelay(delay);
                }
                animator.addListener(getGlobalAnimationFinishedListener());
                animator.addListener(new C05217(child));
                startAnimator(animator);
                child.setTag(2131755008, animator);
                child.setTag(2131755020, Float.valueOf(child.getTranslationY()));
                child.setTag(2131755014, Float.valueOf(newEndValue));
            } else if (previousAnimator != null) {
                previousAnimator.getValues()[0].setFloatValues(new float[]{previousStartValue.floatValue() + (newEndValue - previousEndValue.floatValue()), newEndValue});
                child.setTag(2131755020, Float.valueOf(newStartValue));
                child.setTag(2131755014, Float.valueOf(newEndValue));
                previousAnimator.setCurrentPlayTime(previousAnimator.getCurrentPlayTime());
            } else {
                child.setTranslationY(newEndValue);
            }
        }
    }

    private void startScaleAnimation(View child, ViewState viewState, long duration) {
        Float previousStartValue = (Float) getChildTag(child, 2131755022);
        Float previousEndValue = (Float) getChildTag(child, 2131755016);
        float newEndValue = viewState.scale;
        if (previousEndValue == null || previousEndValue.floatValue() != newEndValue) {
            ObjectAnimator previousAnimator = (ObjectAnimator) getChildTag(child, 2131755010);
            if (!this.mAnimationFilter.animateScale) {
                if (previousAnimator != null) {
                    PropertyValuesHolder[] values = previousAnimator.getValues();
                    float newStartValue = previousStartValue.floatValue() + (newEndValue - previousEndValue.floatValue());
                    values[0].setFloatValues(new float[]{newStartValue, newEndValue});
                    values[1].setFloatValues(new float[]{newStartValue, newEndValue});
                    child.setTag(2131755022, Float.valueOf(newStartValue));
                    child.setTag(2131755016, Float.valueOf(newEndValue));
                    previousAnimator.setCurrentPlayTime(previousAnimator.getCurrentPlayTime());
                    return;
                }
                child.setScaleX(newEndValue);
                child.setScaleY(newEndValue);
            }
            PropertyValuesHolder holderX = PropertyValuesHolder.ofFloat(View.SCALE_X, new float[]{child.getScaleX(), newEndValue});
            PropertyValuesHolder holderY = PropertyValuesHolder.ofFloat(View.SCALE_Y, new float[]{child.getScaleY(), newEndValue});
            ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(child, new PropertyValuesHolder[]{holderX, holderY});
            animator.setInterpolator(this.mFastOutSlowInInterpolator);
            animator.setDuration(cancelAnimatorAndGetNewDuration(duration, previousAnimator));
            animator.addListener(getGlobalAnimationFinishedListener());
            animator.addListener(new C05228(child));
            startAnimator(animator);
            child.setTag(2131755010, animator);
            child.setTag(2131755022, Float.valueOf(child.getScaleX()));
            child.setTag(2131755016, Float.valueOf(newEndValue));
        }
    }

    private void startAnimator(ValueAnimator animator) {
        this.mAnimatorSet.add(animator);
        animator.start();
    }

    private AnimatorListenerAdapter getGlobalAnimationFinishedListener() {
        if (this.mAnimationListenerPool.empty()) {
            return new C05239();
        }
        return (AnimatorListenerAdapter) this.mAnimationListenerPool.pop();
    }

    public static <T> T getChildTag(View child, int tag) {
        return child.getTag(tag);
    }

    private long cancelAnimatorAndGetNewDuration(long duration, ValueAnimator previousAnimator) {
        long newDuration = duration;
        if (previousAnimator == null) {
            return newDuration;
        }
        newDuration = Math.max(previousAnimator.getDuration() - previousAnimator.getCurrentPlayTime(), newDuration);
        previousAnimator.cancel();
        return newDuration;
    }

    private void onAnimationFinished() {
        this.mHostLayout.onChildAnimationFinished();
        Iterator i$ = this.mChildrenToClearFromOverlay.iterator();
        while (i$.hasNext()) {
            this.mHostLayout.getOverlay().remove((View) i$.next());
        }
        this.mChildrenToClearFromOverlay.clear();
    }

    private void processAnimationEvents(ArrayList<AnimationEvent> animationEvents, StackScrollState finalState) {
        Iterator i$ = animationEvents.iterator();
        while (i$.hasNext()) {
            AnimationEvent event = (AnimationEvent) i$.next();
            ExpandableView changingView = event.changingView;
            StackViewState viewState;
            if (event.animationType == 0) {
                viewState = finalState.getViewStateForView(changingView);
                if (viewState != null) {
                    if (changingView.getVisibility() == 8) {
                        finalState.removeViewStateForView(changingView);
                    } else {
                        finalState.applyState(changingView, viewState);
                        this.mNewAddChildren.add(changingView);
                    }
                }
            } else if (event.animationType == 1) {
                if (changingView.getVisibility() == 8) {
                    this.mHostLayout.getOverlay().remove(changingView);
                } else {
                    viewState = finalState.getViewStateForView(event.viewAfterChangingView);
                    int actualHeight = changingView.getActualHeight();
                    float translationDirection = -1.0f;
                    if (viewState != null) {
                        translationDirection = Math.max(Math.min(((viewState.yTranslation - (changingView.getTranslationY() + (((float) actualHeight) / 2.0f))) * 2.0f) / ((float) actualHeight), 1.0f), -1.0f);
                    }
                    changingView.performRemoveAnimation(464, translationDirection, new AnonymousClass10(changingView));
                }
            } else if (event.animationType == 2) {
                this.mHostLayout.getOverlay().remove(changingView);
            } else if (event.animationType == 13) {
                ExpandableNotificationRow row = event.changingView;
                row.prepareExpansionChanged(finalState);
                this.mChildExpandingView = row;
            } else if (event.animationType == 14) {
                this.mTmpState.copyFrom(finalState.getViewStateForView(changingView));
                if (event.headsUpFromBottom) {
                    this.mTmpState.yTranslation = (float) this.mHeadsUpAppearHeightBottom;
                } else {
                    this.mTmpState.yTranslation = (float) (-this.mTmpState.height);
                }
                this.mHeadsUpAppearChildren.add(changingView);
                finalState.applyState(changingView, this.mTmpState);
            } else if (event.animationType == 15 || event.animationType == 16) {
                this.mHeadsUpDisappearChildren.add(changingView);
                if (this.mHostLayout.indexOfChild(changingView) == -1) {
                    this.mHostLayout.getOverlay().add(changingView);
                    this.mTmpState.initFrom(changingView);
                    this.mTmpState.yTranslation = (float) (-changingView.getActualHeight());
                    this.mAnimationFilter.animateY = true;
                    startViewAnimations(changingView, this.mTmpState, event.animationType == 16 ? 120 : 0, 230);
                    this.mChildrenToClearFromOverlay.add(changingView);
                }
            }
            this.mNewEvents.add(event);
        }
    }

    public void animateOverScrollToAmount(float targetAmount, boolean onTop, boolean isRubberbanded) {
        if (targetAmount != this.mHostLayout.getCurrentOverScrollAmount(onTop)) {
            cancelOverScrollAnimators(onTop);
            ValueAnimator overScrollAnimator = ValueAnimator.ofFloat(new float[]{startOverScrollAmount, targetAmount});
            overScrollAnimator.setDuration(360);
            overScrollAnimator.addUpdateListener(new AnonymousClass11(onTop, isRubberbanded));
            overScrollAnimator.setInterpolator(this.mFastOutSlowInInterpolator);
            overScrollAnimator.addListener(new AnonymousClass12(onTop));
            overScrollAnimator.start();
            if (onTop) {
                this.mTopOverScrollAnimator = overScrollAnimator;
            } else {
                this.mBottomOverScrollAnimator = overScrollAnimator;
            }
        }
    }

    public void cancelOverScrollAnimators(boolean onTop) {
        ValueAnimator currentAnimator = onTop ? this.mTopOverScrollAnimator : this.mBottomOverScrollAnimator;
        if (currentAnimator != null) {
            currentAnimator.cancel();
        }
    }

    public static int getFinalActualHeight(ExpandableView view) {
        if (view == null) {
            return 0;
        }
        if (((ValueAnimator) getChildTag(view, 2131755013)) == null) {
            return view.getActualHeight();
        }
        return ((Integer) getChildTag(view, 2131755019)).intValue();
    }

    public void setHeadsUpAppearHeightBottom(int headsUpAppearHeightBottom) {
        this.mHeadsUpAppearHeightBottom = headsUpAppearHeightBottom;
    }

    public void setShadeExpanded(boolean shadeExpanded) {
        this.mShadeExpanded = shadeExpanded;
    }
}
