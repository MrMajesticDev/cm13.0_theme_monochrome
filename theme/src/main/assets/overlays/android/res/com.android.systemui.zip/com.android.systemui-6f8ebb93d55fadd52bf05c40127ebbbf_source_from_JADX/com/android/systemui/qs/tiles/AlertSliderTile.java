package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings.System;
import android.service.notification.ZenModeConfig;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.Icon;
import com.android.systemui.qs.QSTile.ResourceIcon;
import com.android.systemui.qs.QSTile.State;
import com.android.systemui.statusbar.policy.ZenModeController;
import com.android.systemui.statusbar.policy.ZenModeController.Callback;
import com.android.systemui.volume.SegmentedButtons;

public class AlertSliderTile extends QSTile<State> {
    private static final Icon ALARMS_ONLY;
    private static final Icon TOTAL_SILENCE;
    private static final Intent ZEN_SETTINGS;
    private final ZenModeController mController;
    private final AlertSliderDetailAdapter mDetailAdapter;
    private boolean mListening;
    private final Callback mZenCallback;

    /* renamed from: com.android.systemui.qs.tiles.AlertSliderTile.1 */
    class C01781 extends Callback {
        C01781() {
        }

        public void onZenChanged(int zen) {
            AlertSliderTile.this.refreshState(Integer.valueOf(zen));
        }
    }

    private final class AlertSliderDetailAdapter implements OnItemClickListener, DetailAdapter {
        private SegmentedButtons mButtons;
        private final SegmentedButtons.Callback mButtonsCallback;
        private TextView mMessageText;

        /* renamed from: com.android.systemui.qs.tiles.AlertSliderTile.AlertSliderDetailAdapter.1 */
        class C01791 implements SegmentedButtons.Callback {
            C01791() {
            }

            public void onSelected(Object value, boolean fromClick) {
                if (value != null && AlertSliderDetailAdapter.this.mButtons.isShown()) {
                    int state = ((Integer) value).intValue();
                    if (fromClick) {
                        MetricsLogger.action(AlertSliderTile.this.mContext, 118, state);
                        AlertSliderDetailAdapter.this.setSilentState(state);
                        AlertSliderTile.this.setZenMode(state);
                        AlertSliderTile.this.refreshState(Integer.valueOf(state));
                        AlertSliderTile.this.showDetail(false);
                    }
                }
            }

            public void onInteraction() {
            }
        }

        private AlertSliderDetailAdapter() {
            this.mButtonsCallback = new C01791();
        }

        public int getTitle() {
            return 2131361939;
        }

        public Boolean getToggleState() {
            return null;
        }

        public Intent getSettingsIntent() {
            return AlertSliderTile.ZEN_SETTINGS;
        }

        public void setToggleState(boolean state) {
        }

        public int getMetricsCategory() {
            return 149;
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            LinearLayout details;
            if (convertView != null) {
                details = (LinearLayout) convertView;
            } else {
                details = (LinearLayout) LayoutInflater.from(context).inflate(2130968576, parent, false);
            }
            int state = AlertSliderTile.this.getZenMode();
            if (convertView == null) {
                this.mButtons = (SegmentedButtons) details.findViewById(2131755062);
                this.mMessageText = (TextView) details.findViewById(2131755064);
                this.mButtons.addButton(2131361934, 2131361933, Integer.valueOf(3));
                this.mButtons.addButton(2131361936, 2131361935, Integer.valueOf(2));
                this.mButtons.setCallback(this.mButtonsCallback);
                this.mButtons.setSelectedValue(Integer.valueOf(state), false);
                this.mMessageText.setText(AlertSliderTile.this.mContext.getString(state == 2 ? 2131361938 : 2131361937));
            }
            return details;
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        }

        public void setMessageText(int stringRes) {
            if (this.mMessageText != null) {
                this.mMessageText.setText(AlertSliderTile.this.mContext.getString(stringRes));
            }
        }

        public void setSilentState(int state) {
            System.putIntForUser(AlertSliderTile.this.mContext.getContentResolver(), "alert_slider_silent_mode", state != 3 ? 1 : 0, -2);
        }
    }

    static {
        ZEN_SETTINGS = new Intent("android.settings.ZEN_MODE_SETTINGS");
        TOTAL_SILENCE = ResourceIcon.get(2130837631);
        ALARMS_ONLY = ResourceIcon.get(2130837630);
    }

    public AlertSliderTile(Host host) {
        super(host, "alertslider");
        this.mZenCallback = new C01781();
        this.mController = host.getZenModeController();
        this.mDetailAdapter = new AlertSliderDetailAdapter();
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    protected State newTileState() {
        return new State();
    }

    protected void handleToggleClick() {
        showDetail(true);
    }

    protected void handleDetailClick() {
        showDetail(true);
    }

    protected void handleUpdateState(State state, Object arg) {
        switch (arg instanceof Integer ? ((Integer) arg).intValue() : this.mController.getZen()) {
            case 2:
                state.visible = ZenModeConfig.hasAlertSlider(this.mContext);
                state.icon = TOTAL_SILENCE;
                state.label = this.mContext.getString(2131362170);
                state.contentDescription = this.mContext.getString(2131362115);
                if (this.mDetailAdapter != null) {
                    this.mDetailAdapter.setMessageText(2131361938);
                }
            case 3:
                state.visible = ZenModeConfig.hasAlertSlider(this.mContext);
                state.icon = ALARMS_ONLY;
                state.label = this.mContext.getString(2131362169);
                state.contentDescription = this.mContext.getString(2131362116);
                if (this.mDetailAdapter != null) {
                    this.mDetailAdapter.setMessageText(2131361937);
                }
            default:
                state.visible = false;
        }
    }

    private int getZenMode() {
        return this.mController.getZen();
    }

    private void setZenMode(int mode) {
        this.mController.setZen(mode, null, this.TAG);
    }

    public int getMetricsCategory() {
        return 118;
    }

    protected String composeChangeAnnouncement() {
        return "";
    }

    public void setListening(boolean listening) {
        if (this.mListening != listening) {
            boolean z = listening && ZenModeConfig.hasAlertSlider(this.mContext);
            this.mListening = z;
            if (this.mListening) {
                this.mController.addCallback(this.mZenCallback);
            } else {
                this.mController.removeCallback(this.mZenCallback);
            }
        }
    }
}
