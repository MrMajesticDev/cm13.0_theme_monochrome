package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import com.android.internal.logging.MetricsLogger;
import com.android.settingslib.bluetooth.CachedBluetoothDevice;
import com.android.systemui.qs.QSDetailItems;
import com.android.systemui.qs.QSDetailItems.Item;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.ResourceIcon;
import com.android.systemui.statusbar.policy.BluetoothController;
import com.android.systemui.statusbar.policy.BluetoothController.Callback;
import java.util.Collection;

public class BluetoothTile extends QSTile<BooleanState> {
    private static final Intent BLUETOOTH_SETTINGS;
    private final Callback mCallback;
    private final BluetoothController mController;
    private final BluetoothDetailAdapter mDetailAdapter;

    /* renamed from: com.android.systemui.qs.tiles.BluetoothTile.1 */
    class C01811 implements Callback {

        /* renamed from: com.android.systemui.qs.tiles.BluetoothTile.1.1 */
        class C01801 implements Runnable {
            C01801() {
            }

            public void run() {
                BluetoothTile.this.mDetailAdapter.updateItems();
            }
        }

        C01811() {
        }

        public void onBluetoothStateChange(boolean enabled) {
            BluetoothTile.this.refreshState();
        }

        public void onBluetoothDevicesChanged() {
            BluetoothTile.this.mUiHandler.post(new C01801());
            BluetoothTile.this.refreshState();
        }
    }

    private final class BluetoothDetailAdapter implements QSDetailItems.Callback, DetailAdapter {
        private QSDetailItems mItems;

        private BluetoothDetailAdapter() {
        }

        public int getTitle() {
            return 2131362171;
        }

        public Boolean getToggleState() {
            return Boolean.valueOf(((BooleanState) BluetoothTile.this.mState).value);
        }

        public Intent getSettingsIntent() {
            return BluetoothTile.BLUETOOTH_SETTINGS;
        }

        public void setToggleState(boolean state) {
            MetricsLogger.action(BluetoothTile.this.mContext, 154, state);
            BluetoothTile.this.mController.setBluetoothEnabled(state);
            BluetoothTile.this.showDetail(false);
        }

        public int getMetricsCategory() {
            return 150;
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            this.mItems = QSDetailItems.convertOrInflate(context, convertView, parent);
            this.mItems.setTagSuffix("Bluetooth");
            this.mItems.setEmptyState(2130837618, 2131362174);
            this.mItems.setCallback(this);
            this.mItems.setMinHeightInItems(0);
            updateItems();
            setItemsVisible(((BooleanState) BluetoothTile.this.mState).value);
            return this.mItems;
        }

        public void setItemsVisible(boolean visible) {
            if (this.mItems != null) {
                this.mItems.setItemsVisible(visible);
            }
        }

        private void updateItems() {
            if (this.mItems != null) {
                Item[] items = null;
                Collection<CachedBluetoothDevice> devices = BluetoothTile.this.mController.getDevices();
                if (devices != null) {
                    items = new Item[getBondedCount(devices)];
                    int i = 0;
                    for (CachedBluetoothDevice device : devices) {
                        if (device.getBondState() != 10) {
                            Item item = new Item();
                            item.icon = 2130837620;
                            item.line1 = device.getName();
                            int state = device.getMaxConnectionState();
                            if (state == 2) {
                                item.icon = 2130837616;
                                item.line2 = BluetoothTile.this.mContext.getString(2131362207);
                                item.canDisconnect = true;
                            } else if (state == 1) {
                                item.icon = 2130837617;
                                item.line2 = BluetoothTile.this.mContext.getString(2131362208);
                            }
                            item.tag = device;
                            int i2 = i + 1;
                            items[i] = item;
                            i = i2;
                        }
                    }
                }
                this.mItems.setItems(items);
            }
        }

        private int getBondedCount(Collection<CachedBluetoothDevice> devices) {
            int ct = 0;
            for (CachedBluetoothDevice device : devices) {
                if (device.getBondState() != 10) {
                    ct++;
                }
            }
            return ct;
        }

        public void onDetailItemClick(Item item) {
            if (item != null && item.tag != null) {
                CachedBluetoothDevice device = item.tag;
                if (device != null && device.getMaxConnectionState() == 0) {
                    BluetoothTile.this.mController.connect(device);
                }
            }
        }

        public void onDetailItemDisconnect(Item item) {
            if (item != null && item.tag != null) {
                CachedBluetoothDevice device = item.tag;
                if (device != null) {
                    BluetoothTile.this.mController.disconnect(device);
                }
            }
        }
    }

    static {
        BLUETOOTH_SETTINGS = new Intent("android.settings.BLUETOOTH_SETTINGS");
    }

    public BluetoothTile(Host host) {
        super(host, "bt");
        this.mCallback = new C01811();
        this.mController = host.getBluetoothController();
        this.mDetailAdapter = new BluetoothDetailAdapter();
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void setListening(boolean listening) {
        if (listening) {
            this.mController.addStateChangedCallback(this.mCallback);
        } else {
            this.mController.removeStateChangedCallback(this.mCallback);
        }
    }

    protected void handleToggleClick() {
        boolean z;
        boolean z2 = true;
        boolean isEnabled = ((BooleanState) this.mState).value;
        Context context = this.mContext;
        int metricsCategory = getMetricsCategory();
        if (isEnabled) {
            z = false;
        } else {
            z = true;
        }
        MetricsLogger.action(context, metricsCategory, z);
        BluetoothController bluetoothController = this.mController;
        if (isEnabled) {
            z2 = false;
        }
        bluetoothController.setBluetoothEnabled(z2);
    }

    protected void handleDetailClick() {
        if (!((BooleanState) this.mState).value) {
            ((BooleanState) this.mState).value = true;
            this.mController.setBluetoothEnabled(true);
        }
        showDetail(true);
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        boolean supported = this.mController.isBluetoothSupported();
        boolean enabled = this.mController.isBluetoothEnabled();
        boolean connected = this.mController.isBluetoothConnected();
        boolean connecting = this.mController.isBluetoothConnecting();
        state.visible = supported;
        state.value = enabled;
        state.autoMirrorDrawable = false;
        if (enabled) {
            state.label = null;
            if (connected) {
                state.icon = ResourceIcon.get(2130837616);
                state.contentDescription = this.mContext.getString(2131362123);
                state.label = this.mController.getLastDeviceName();
            } else if (connecting) {
                state.icon = ResourceIcon.get(2130837617);
                state.contentDescription = this.mContext.getString(2131362122);
                state.label = this.mContext.getString(2131362171);
            } else {
                state.icon = ResourceIcon.get(2130837620);
                state.contentDescription = this.mContext.getString(2131362121);
            }
            if (TextUtils.isEmpty(state.label)) {
                state.label = this.mContext.getString(2131362171);
            }
        } else {
            state.icon = ResourceIcon.get(2130837619);
            state.label = this.mContext.getString(2131362171);
            state.contentDescription = this.mContext.getString(2131362120);
        }
        String bluetoothName = state.label;
        if (connected) {
            bluetoothName = this.mContext.getString(2131362041, new Object[]{state.label});
            state.dualLabelContentDescription = bluetoothName;
        }
        state.dualLabelContentDescription = bluetoothName;
    }

    public int getMetricsCategory() {
        return 113;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131362125);
        }
        return this.mContext.getString(2131362124);
    }
}
