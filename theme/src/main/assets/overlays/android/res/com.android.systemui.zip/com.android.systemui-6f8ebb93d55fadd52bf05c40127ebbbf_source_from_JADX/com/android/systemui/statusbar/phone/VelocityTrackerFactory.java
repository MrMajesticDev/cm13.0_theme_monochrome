package com.android.systemui.statusbar.phone;

import android.content.Context;
import com.android.keyguard.C0065R;

public class VelocityTrackerFactory {
    public static VelocityTrackerInterface obtain(Context ctx) {
        String tracker = ctx.getResources().getString(2131361880);
        Object obj = -1;
        switch (tracker.hashCode()) {
            case 104998702:
                if (tracker.equals("noisy")) {
                    obj = null;
                    break;
                }
                break;
            case 1874684019:
                if (tracker.equals("platform")) {
                    obj = 1;
                    break;
                }
                break;
        }
        switch (obj) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                return NoisyVelocityTracker.obtain();
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return PlatformVelocityTracker.obtain();
            default:
                throw new IllegalStateException("Invalid tracker: " + tracker);
        }
    }
}
