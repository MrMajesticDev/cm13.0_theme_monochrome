package com.android.systemui.statusbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewPropertyAnimator;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.systemui.settings.SettingConfirmationHelper.OnSettingChoiceListener;

public class SettingConfirmationSnackbarView extends RelativeLayout {
    private final OnClickListener mButtonListener;
    private OnSettingChoiceListener mCallback;
    private Handler mCallbackHandler;
    private View mConfirmButton;
    private View mDenyButton;
    private TextView mDescription;
    private final Runnable mHideRunnable;
    private final Handler mMainHandler;
    private String mSettingName;

    /* renamed from: com.android.systemui.statusbar.SettingConfirmationSnackbarView.1 */
    class C03411 implements OnClickListener {

        /* renamed from: com.android.systemui.statusbar.SettingConfirmationSnackbarView.1.1 */
        class C03391 implements Runnable {
            C03391() {
            }

            public void run() {
                if (!(SettingConfirmationSnackbarView.this.mCallback == null || SettingConfirmationSnackbarView.this.mSettingName == null)) {
                    SettingConfirmationSnackbarView.this.mCallback.onSettingConfirm(SettingConfirmationSnackbarView.this.mSettingName);
                }
                SettingConfirmationSnackbarView.this.mCallback = null;
                SettingConfirmationSnackbarView.this.mSettingName = null;
            }
        }

        /* renamed from: com.android.systemui.statusbar.SettingConfirmationSnackbarView.1.2 */
        class C03402 implements Runnable {
            C03402() {
            }

            public void run() {
                if (!(SettingConfirmationSnackbarView.this.mCallback == null || SettingConfirmationSnackbarView.this.mSettingName == null)) {
                    SettingConfirmationSnackbarView.this.mCallback.onSettingDeny(SettingConfirmationSnackbarView.this.mSettingName);
                }
                SettingConfirmationSnackbarView.this.mCallback = null;
                SettingConfirmationSnackbarView.this.mSettingName = null;
            }
        }

        C03411() {
        }

        public void onClick(View v) {
            if (v.equals(SettingConfirmationSnackbarView.this.mConfirmButton)) {
                if (SettingConfirmationSnackbarView.this.mCallbackHandler != null) {
                    SettingConfirmationSnackbarView.this.mCallbackHandler.post(new C03391());
                    SettingConfirmationSnackbarView.this.mCallbackHandler = null;
                }
                SettingConfirmationSnackbarView.this.hide();
            }
            if (v.equals(SettingConfirmationSnackbarView.this.mDenyButton)) {
                if (SettingConfirmationSnackbarView.this.mCallbackHandler != null) {
                    SettingConfirmationSnackbarView.this.mCallbackHandler.post(new C03402());
                    SettingConfirmationSnackbarView.this.mCallbackHandler = null;
                }
                SettingConfirmationSnackbarView.this.hide();
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.SettingConfirmationSnackbarView.2 */
    class C03422 implements Runnable {
        C03422() {
        }

        public void run() {
            SettingConfirmationSnackbarView.this.hide();
        }
    }

    /* renamed from: com.android.systemui.statusbar.SettingConfirmationSnackbarView.3 */
    class C03433 extends AnimatorListenerAdapter {
        C03433() {
        }

        public void onAnimationStart(Animator animation) {
            SettingConfirmationSnackbarView.this.setVisibility(0);
        }

        public void onAnimationEnd(Animator animation) {
            SettingConfirmationSnackbarView.this.animate().translationY(0.0f).setInterpolator(AnimationUtils.loadInterpolator(SettingConfirmationSnackbarView.this.getContext(), 17563661)).setDuration(250).start();
        }
    }

    /* renamed from: com.android.systemui.statusbar.SettingConfirmationSnackbarView.4 */
    class C03444 extends AnimatorListenerAdapter {
        C03444() {
        }

        public void onAnimationEnd(Animator animation) {
            SettingConfirmationSnackbarView.this.setVisibility(8);
        }
    }

    public SettingConfirmationSnackbarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mButtonListener = new C03411();
        this.mHideRunnable = new C03422();
        this.mDescription = null;
        this.mConfirmButton = null;
        this.mDenyButton = null;
        this.mSettingName = null;
        this.mCallback = null;
        this.mCallbackHandler = null;
        this.mMainHandler = new Handler(Looper.getMainLooper());
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        setTranslationY((float) getHeight());
        setVisibility(8);
        this.mDescription = (TextView) findViewById(2131755251);
        this.mConfirmButton = findViewById(2131755253);
        this.mConfirmButton.setOnClickListener(this.mButtonListener);
        this.mConfirmButton.setClickable(true);
        this.mDenyButton = findViewById(2131755252);
        this.mDenyButton.setOnClickListener(this.mButtonListener);
        this.mDenyButton.setClickable(true);
    }

    public void show(String settingName, String message, OnSettingChoiceListener callback, Handler handler) {
        if (settingName == null) {
            throw new IllegalArgumentException("settingName == null");
        } else if (message == null) {
            throw new IllegalArgumentException("message == null");
        } else if (callback == null) {
            throw new IllegalArgumentException("callback == null");
        } else {
            if (handler == null) {
                handler = this.mMainHandler;
            }
            this.mSettingName = settingName;
            boolean shouldAnimate = (getTranslationY() == 0.0f && this.mDescription.getText().toString().equals(message)) ? false : true;
            this.mDescription.setText(message);
            this.mCallback = callback;
            this.mCallbackHandler = handler;
            if (shouldAnimate) {
                long j;
                ViewPropertyAnimator interpolator = animate().translationY((float) getHeight()).setInterpolator(AnimationUtils.loadInterpolator(getContext(), 17563661));
                if (getTranslationY() == 0.0f) {
                    j = 0;
                } else {
                    j = 250;
                }
                interpolator.setDuration(j).setListener(new C03433()).start();
            }
            this.mMainHandler.removeCallbacks(this.mHideRunnable);
            this.mMainHandler.postDelayed(this.mHideRunnable, 30000);
        }
    }

    public void hide() {
        animate().translationY((float) getHeight()).setInterpolator(AnimationUtils.loadInterpolator(getContext(), 17563661)).setDuration(250).setListener(new C03444()).start();
    }
}
