package com.android.settingslib.animation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.view.RenderNodeAnimator;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import com.android.settingslib.C0066R;

public class AppearAnimationUtils implements AppearAnimationCreator<View> {
    protected boolean mAppearing;
    protected final float mDelayScale;
    private final long mDuration;
    private final Interpolator mInterpolator;
    private final AppearAnimationProperties mProperties;
    protected RowTranslationScaler mRowTranslationScaler;
    private final float mStartTranslation;

    /* renamed from: com.android.settingslib.animation.AppearAnimationUtils.1 */
    class C00671 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$view;

        C00671(View view) {
            this.val$view = view;
        }

        public void onAnimationEnd(Animator animation) {
            this.val$view.setLayerType(0, null);
        }
    }

    /* renamed from: com.android.settingslib.animation.AppearAnimationUtils.2 */
    class C00682 extends AnimatorListenerAdapter {
        final /* synthetic */ Runnable val$endRunnable;

        C00682(Runnable runnable) {
            this.val$endRunnable = runnable;
        }

        public void onAnimationEnd(Animator animation) {
            this.val$endRunnable.run();
        }
    }

    public class AppearAnimationProperties {
        public long[][] delays;
        public int maxDelayColIndex;
        public int maxDelayRowIndex;
    }

    public interface RowTranslationScaler {
        float getRowTranslationScale(int i, int i2);
    }

    public AppearAnimationUtils(Context ctx) {
        this(ctx, 220, 1.0f, 1.0f, AnimationUtils.loadInterpolator(ctx, 17563662));
    }

    public AppearAnimationUtils(Context ctx, long duration, float translationScaleFactor, float delayScaleFactor, Interpolator interpolator) {
        this.mProperties = new AppearAnimationProperties();
        this.mInterpolator = interpolator;
        this.mStartTranslation = ((float) ctx.getResources().getDimensionPixelOffset(C0066R.dimen.appear_y_translation_start)) * translationScaleFactor;
        this.mDelayScale = delayScaleFactor;
        this.mDuration = duration;
        this.mAppearing = true;
    }

    public void startAnimation2d(View[][] objects, Runnable finishListener) {
        startAnimation2d(objects, finishListener, this);
    }

    public void startAnimation(View[] objects, Runnable finishListener) {
        startAnimation(objects, finishListener, this);
    }

    public <T> void startAnimation2d(T[][] objects, Runnable finishListener, AppearAnimationCreator<T> creator) {
        startAnimations(getDelays((Object[][]) objects), (Object[][]) objects, finishListener, (AppearAnimationCreator) creator);
    }

    public <T> void startAnimation(T[] objects, Runnable finishListener, AppearAnimationCreator<T> creator) {
        startAnimations(getDelays((Object[]) objects), (Object[]) objects, finishListener, (AppearAnimationCreator) creator);
    }

    private <T> void startAnimations(AppearAnimationProperties properties, T[] objects, Runnable finishListener, AppearAnimationCreator<T> creator) {
        if (properties.maxDelayRowIndex == -1 || properties.maxDelayColIndex == -1) {
            finishListener.run();
            return;
        }
        int row = 0;
        while (row < properties.delays.length) {
            float f;
            long delay = properties.delays[row][0];
            Runnable endRunnable = null;
            if (properties.maxDelayRowIndex == row && properties.maxDelayColIndex == 0) {
                endRunnable = finishListener;
            }
            float translation = (this.mRowTranslationScaler != null ? this.mRowTranslationScaler.getRowTranslationScale(row, properties.delays.length) : 1.0f) * this.mStartTranslation;
            Object obj = objects[row];
            long j = this.mDuration;
            if (this.mAppearing) {
                f = translation;
            } else {
                f = -translation;
            }
            creator.createAnimation(obj, delay, j, f, this.mAppearing, this.mInterpolator, endRunnable);
            row++;
        }
    }

    private <T> void startAnimations(AppearAnimationProperties properties, T[][] objects, Runnable finishListener, AppearAnimationCreator<T> creator) {
        if (properties.maxDelayRowIndex == -1 || properties.maxDelayColIndex == -1) {
            finishListener.run();
            return;
        }
        int row = 0;
        while (row < properties.delays.length) {
            long[] columns = properties.delays[row];
            float translation = (this.mRowTranslationScaler != null ? this.mRowTranslationScaler.getRowTranslationScale(row, properties.delays.length) : 1.0f) * this.mStartTranslation;
            int col = 0;
            while (col < columns.length) {
                float f;
                long delay = columns[col];
                Runnable endRunnable = null;
                if (properties.maxDelayRowIndex == row && properties.maxDelayColIndex == col) {
                    endRunnable = finishListener;
                }
                Object obj = objects[row][col];
                long j = this.mDuration;
                if (this.mAppearing) {
                    f = translation;
                } else {
                    f = -translation;
                }
                creator.createAnimation(obj, delay, j, f, this.mAppearing, this.mInterpolator, endRunnable);
                col++;
            }
            row++;
        }
    }

    private <T> AppearAnimationProperties getDelays(T[] items) {
        long maxDelay = -1;
        this.mProperties.maxDelayColIndex = -1;
        this.mProperties.maxDelayRowIndex = -1;
        this.mProperties.delays = new long[items.length][];
        for (int row = 0; row < items.length; row++) {
            this.mProperties.delays[row] = new long[1];
            long delay = calculateDelay(row, 0);
            this.mProperties.delays[row][0] = delay;
            if (items[row] != null && delay > maxDelay) {
                maxDelay = delay;
                this.mProperties.maxDelayColIndex = 0;
                this.mProperties.maxDelayRowIndex = row;
            }
        }
        return this.mProperties;
    }

    private <T> AppearAnimationProperties getDelays(T[][] items) {
        long maxDelay = -1;
        this.mProperties.maxDelayColIndex = -1;
        this.mProperties.maxDelayRowIndex = -1;
        this.mProperties.delays = new long[items.length][];
        for (int row = 0; row < items.length; row++) {
            T[] columns = items[row];
            this.mProperties.delays[row] = new long[columns.length];
            for (int col = 0; col < columns.length; col++) {
                long delay = calculateDelay(row, col);
                this.mProperties.delays[row][col] = delay;
                if (items[row][col] != null && delay > maxDelay) {
                    maxDelay = delay;
                    this.mProperties.maxDelayColIndex = col;
                    this.mProperties.maxDelayRowIndex = row;
                }
            }
        }
        return this.mProperties;
    }

    protected long calculateDelay(int row, int col) {
        return (long) ((((double) (row * 40)) + ((((double) col) * (Math.pow((double) row, 0.4d) + 0.4d)) * 20.0d)) * ((double) this.mDelayScale));
    }

    public Interpolator getInterpolator() {
        return this.mInterpolator;
    }

    public float getStartTranslation() {
        return this.mStartTranslation;
    }

    public void createAnimation(View view, long delay, long duration, float translationY, boolean appearing, Interpolator interpolator, Runnable endRunnable) {
        if (view != null) {
            Animator alphaAnim;
            view.setAlpha(appearing ? 0.0f : 1.0f);
            view.setTranslationY(appearing ? translationY : 0.0f);
            float targetAlpha = appearing ? 1.0f : 0.0f;
            if (view.isHardwareAccelerated()) {
                Animator alphaAnimRt = new RenderNodeAnimator(11, targetAlpha);
                alphaAnimRt.setTarget(view);
                alphaAnim = alphaAnimRt;
            } else {
                alphaAnim = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{view.getAlpha(), targetAlpha});
            }
            alphaAnim.setInterpolator(interpolator);
            alphaAnim.setDuration(duration);
            alphaAnim.setStartDelay(delay);
            if (view.hasOverlappingRendering()) {
                view.setLayerType(2, null);
                alphaAnim.addListener(new C00671(view));
            }
            if (endRunnable != null) {
                alphaAnim.addListener(new C00682(endRunnable));
            }
            alphaAnim.start();
            startTranslationYAnimation(view, delay, duration, appearing ? 0.0f : translationY, interpolator);
        }
    }

    public static void startTranslationYAnimation(View view, long delay, long duration, float endTranslationY, Interpolator interpolator) {
        Animator translationAnim;
        if (view.isHardwareAccelerated()) {
            Animator translationAnimRt = new RenderNodeAnimator(1, endTranslationY);
            translationAnimRt.setTarget(view);
            translationAnim = translationAnimRt;
        } else {
            translationAnim = ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, new float[]{view.getTranslationY(), endTranslationY});
        }
        translationAnim.setInterpolator(interpolator);
        translationAnim.setDuration(duration);
        translationAnim.setStartDelay(delay);
        translationAnim.start();
    }
}
