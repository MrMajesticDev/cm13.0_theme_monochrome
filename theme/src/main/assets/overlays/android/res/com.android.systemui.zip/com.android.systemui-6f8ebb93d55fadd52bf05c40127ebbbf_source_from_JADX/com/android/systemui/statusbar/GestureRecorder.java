package com.android.systemui.statusbar;

import android.os.Handler;
import android.os.SystemClock;
import java.util.HashSet;
import java.util.LinkedList;

public class GestureRecorder {
    public static final String TAG;
    private Gesture mCurrentGesture;
    private LinkedList<Gesture> mGestures;
    private Handler mHandler;

    public class Gesture {
        boolean mComplete;
        long mDownTime;
        private LinkedList<Record> mRecords;
        private HashSet<String> mTags;

        public abstract class Record {
            long time;
        }

        public class TagRecord extends Record {
            public String info;
            public String tag;

            public TagRecord(long when, String tag, String info) {
                super();
                this.time = when;
                this.tag = tag;
                this.info = info;
            }
        }

        public Gesture() {
            this.mRecords = new LinkedList();
            this.mTags = new HashSet();
            this.mDownTime = -1;
            this.mComplete = false;
        }

        public void tag(long when, String tag, String info) {
            this.mRecords.add(new TagRecord(when, tag, info));
            this.mTags.add(tag);
        }
    }

    static {
        TAG = GestureRecorder.class.getSimpleName();
    }

    public void tag(long when, String tag, String info) {
        synchronized (this.mGestures) {
            if (this.mCurrentGesture == null) {
                this.mCurrentGesture = new Gesture();
                this.mGestures.add(this.mCurrentGesture);
            }
            this.mCurrentGesture.tag(when, tag, info);
        }
        saveLater();
    }

    public void tag(String tag, String info) {
        tag(SystemClock.uptimeMillis(), tag, info);
    }

    public void saveLater() {
        this.mHandler.removeMessages(6351);
        this.mHandler.sendEmptyMessageDelayed(6351, 5000);
    }
}
