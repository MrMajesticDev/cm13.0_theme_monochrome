package com.android.keyguard;

/* renamed from: com.android.keyguard.R */
public final class C0065R {

    /* renamed from: com.android.keyguard.R.array */
    public static final class array {
        public static final int lockscreen_num_pad_klondike = 2131230942;
    }

    /* renamed from: com.android.keyguard.R.bool */
    public static final class bool {
        public static final int config_disableMenuKeyInLockScreen = 2131558445;
        public static final int kg_hide_emgcy_btn_when_oos = 2131558443;
        public static final int kg_show_ime_at_screen_on = 2131558441;
    }

    /* renamed from: com.android.keyguard.R.dimen */
    public static final class dimen {
        public static final int disappear_y_translation = 2131296257;
        public static final int password_char_padding = 2131296522;
        public static final int password_dot_size = 2131296521;
        public static final int widget_big_font_size = 2131296520;
        public static final int widget_label_font_size = 2131296519;
    }

    /* renamed from: com.android.keyguard.R.drawable */
    public static final class drawable {
        public static final int ripple_drawable = 2130837807;
    }

    /* renamed from: com.android.keyguard.R.id */
    public static final class id {
        public static final int alarm_status = 2131755135;
        public static final int carrier_text = 2131755091;
        public static final int clock = 2131755127;
        public static final int clock_view = 2131755128;
        public static final int container = 2131755104;
        public static final int date_view = 2131755134;
        public static final int delete_button = 2131755109;
        public static final int digit_text = 2131755097;
        public static final int divider = 2131755110;
        public static final int emergency_call_button = 2131755092;
        public static final int key0 = 2131755124;
        public static final int key1 = 2131755112;
        public static final int key2 = 2131755113;
        public static final int key3 = 2131755114;
        public static final int key4 = 2131755116;
        public static final int key5 = 2131755117;
        public static final int key6 = 2131755118;
        public static final int key7 = 2131755120;
        public static final int key8 = 2131755121;
        public static final int key9 = 2131755122;
        public static final int key_enter = 2131755125;
        public static final int keyguard_message_area = 2131755096;
        public static final int keyguard_password_view = 2131755099;
        public static final int keyguard_pattern_view = 2131755103;
        public static final int keyguard_pin_view = 2131755106;
        public static final int keyguard_security_container = 2131755094;
        public static final int keyguard_selector_fade_container = 2131755102;
        public static final int keyguard_sim = 2131755130;
        public static final int keyguard_sim_pin_view = 2131755129;
        public static final int keyguard_sim_puk_view = 2131755132;
        public static final int klondike_text = 2131755098;
        public static final int lockPatternView = 2131755105;
        public static final int owner_info = 2131755145;
        public static final int passwordEntry = 2131755100;
        public static final int pinEntry = 2131755108;
        public static final int pukEntry = 2131755133;
        public static final int row0 = 2131755107;
        public static final int row1 = 2131755111;
        public static final int row2 = 2131755115;
        public static final int row3 = 2131755119;
        public static final int simPinEntry = 2131755131;
        public static final int switch_ime_button = 2131755101;
        public static final int view_flipper = 2131755095;
    }

    /* renamed from: com.android.keyguard.R.integer */
    public static final class integer {
        public static final int config_max_unlock_countdown_times = 2131623996;
    }

    /* renamed from: com.android.keyguard.R.layout */
    public static final class layout {
        public static final int keyguard_num_pad_key = 2130968588;
        public static final int keyguard_password_view = 2130968589;
        public static final int keyguard_pattern_view = 2130968590;
        public static final int keyguard_pin_view = 2130968591;
        public static final int keyguard_presentation = 2130968592;
        public static final int keyguard_sim_pin_view = 2130968593;
        public static final int keyguard_sim_puk_view = 2130968594;
    }

    /* renamed from: com.android.keyguard.R.plurals */
    public static final class plurals {
        public static final int kg_password_default_pin_message = 2131820550;
        public static final int kg_password_default_puk_message = 2131820551;
        public static final int kg_password_wrong_pin_code = 2131820545;
        public static final int kg_password_wrong_puk_code = 2131820546;
    }

    /* renamed from: com.android.keyguard.R.string */
    public static final class string {
        public static final int abbrev_wday_month_day_no_year = 2131362376;
        public static final int abbrev_wday_month_day_no_year_alarm = 2131362377;
        public static final int airplane_mode = 2131362462;
        public static final int clock_12hr_format = 2131362378;
        public static final int clock_24hr_format = 2131362379;
        public static final int fingerprint_not_recognized = 2131362472;
        public static final int keyguard_accessibility_next_alarm = 2131362417;
        public static final int keyguard_missing_sim_message_short = 2131362398;
        public static final int keyguard_permanent_disabled_sim_message_short = 2131362402;
        public static final int keyguard_perso_locked_message = 2131362397;
        public static final int keyguard_sim_locked_message = 2131362404;
        public static final int keyguard_sim_puk_locked_message = 2131362405;
        public static final int keyguard_sim_unlock_progress_dialog_message = 2131362406;
        public static final int kg_enter_confirm_pin_hint = 2131362433;
        public static final int kg_failed_attempts_almost_at_erase_profile = 2131362447;
        public static final int kg_failed_attempts_almost_at_erase_user = 2131362445;
        public static final int kg_failed_attempts_almost_at_wipe = 2131362443;
        public static final int kg_failed_attempts_now_erasing_profile = 2131362448;
        public static final int kg_failed_attempts_now_erasing_user = 2131362446;
        public static final int kg_failed_attempts_now_wiping = 2131362444;
        public static final int kg_failed_attempts_now_wiping_confirm = 2131362460;
        public static final int kg_failed_password_attempts_now_wiping = 2131362458;
        public static final int kg_failed_pattern_attempts_now_wiping = 2131362459;
        public static final int kg_failed_pin_attempts_now_wiping = 2131362457;
        public static final int kg_invalid_confirm_pin_hint = 2131362438;
        public static final int kg_invalid_sim_pin_hint = 2131362435;
        public static final int kg_invalid_sim_puk_hint = 2131362436;
        public static final int kg_password_instructions = 2131362429;
        public static final int kg_password_pin_failed = 2131362452;
        public static final int kg_password_puk_failed = 2131362453;
        public static final int kg_password_wrong_pin_code_pukked = 2131362450;
        public static final int kg_password_wrong_puk_code_dead = 2131362451;
        public static final int kg_pattern_instructions = 2131362425;
        public static final int kg_pin_instructions = 2131362428;
        public static final int kg_prompt_reason_restart_password = 2131362465;
        public static final int kg_prompt_reason_restart_pattern = 2131362463;
        public static final int kg_prompt_reason_restart_pin = 2131362464;
        public static final int kg_prompt_reason_timeout_password = 2131362468;
        public static final int kg_prompt_reason_timeout_pattern = 2131362466;
        public static final int kg_prompt_reason_timeout_pin = 2131362467;
        public static final int kg_puk_enter_pin_hint = 2131362432;
        public static final int kg_puk_enter_puk_hint = 2131362430;
        public static final int kg_puk_enter_puk_hint_multi = 2131362431;
        public static final int kg_remaining_attempts = 2131362456;
        public static final int kg_sim_pin_instructions = 2131362426;
        public static final int kg_sim_pin_instructions_multi = 2131362427;
        public static final int kg_sim_unlock_progress_dialog_message = 2131362434;
        public static final int kg_too_many_failed_attempts_countdown = 2131362424;
        public static final int kg_too_many_failed_password_attempts_dialog_message = 2131362441;
        public static final int kg_too_many_failed_pattern_attempts_dialog_message = 2131362442;
        public static final int kg_too_many_failed_pin_attempts_dialog_message = 2131362440;
        public static final int kg_wrong_password = 2131362422;
        public static final int kg_wrong_pattern = 2131362421;
        public static final int kg_wrong_pin = 2131362423;
        public static final int lockscreen_sim_error_message_short = 2131362389;
        public static final int ok = 2131362375;
    }

    /* renamed from: com.android.keyguard.R.style */
    public static final class style {
        public static final int keyguard_presentation_theme = 2131492929;
    }

    /* renamed from: com.android.keyguard.R.styleable */
    public static final class styleable {
        public static final int[] AlphaOptimizedImageView;
        public static final int[] BatteryMeterView;
        public static final int[] BatteryMeterViewDrawable;
        public static final int[] CarrierText;
        public static final int CarrierText_allCaps = 0;
        public static final int[] Clock;
        public static final int[] DateView;
        public static final int[] DeadZone;
        public static final int[] KeyButtonView;
        public static final int[] KeyguardSecurityViewFlipper_Layout;
        public static final int KeyguardSecurityViewFlipper_Layout_layout_maxHeight = 1;
        public static final int KeyguardSecurityViewFlipper_Layout_layout_maxWidth = 0;
        public static final int[] NotificationLinearLayout;
        public static final int[] NotificationRowLayout;
        public static final int[] NumPadKey;
        public static final int NumPadKey_digit = 0;
        public static final int NumPadKey_textView = 1;
        public static final int[] PasswordTextView;
        public static final int PasswordTextView_scaledTextSize = 0;
        public static final int[] PseudoGridView;
        public static final int[] RecentsPanelView;
        public static final int[] StatusBarWindowView_Layout;
        public static final int[] ToggleSlider;
        public static final int[] TonedIcon;
        public static final int[] UserAvatarView;
        public static final int[] UserDetailItemView;

        static {
            int[] iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771994;
            AlphaOptimizedImageView = iArr;
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771978;
            BatteryMeterView = iArr;
            BatteryMeterViewDrawable = new int[]{16842927, 2130771995};
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130772001;
            CarrierText = iArr;
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771979;
            Clock = iArr;
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771986;
            DateView = iArr;
            DeadZone = new int[]{2130771974, 2130771975, 2130771976, 2130771977, 2130771980};
            KeyButtonView = new int[]{16843379, 2130771968, 2130771969};
            KeyguardSecurityViewFlipper_Layout = new int[]{2130771996, 2130771997};
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771971;
            NotificationLinearLayout = iArr;
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771972;
            NotificationRowLayout = iArr;
            NumPadKey = new int[]{2130771998, 2130771999};
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130772000;
            PasswordTextView = iArr;
            PseudoGridView = new int[]{2130771987, 2130771988, 2130771989};
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771973;
            RecentsPanelView = iArr;
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771993;
            StatusBarWindowView_Layout = iArr;
            iArr = new int[NumPadKey_textView];
            iArr[NumPadKey_digit] = 2130771970;
            ToggleSlider = iArr;
            TonedIcon = new int[]{2130771990, 2130771991, 2130771992};
            UserAvatarView = new int[]{2130771978, 2130771981, 2130771982, 2130771983};
            UserDetailItemView = new int[]{2130771984, 2130771985};
        }
    }
}
