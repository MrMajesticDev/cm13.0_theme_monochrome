package com.android.systemui.egg;

import android.animation.LayoutTransition;
import android.animation.TimeAnimator;
import android.animation.TimeAnimator.TimeListener;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.media.AudioAttributes;
import android.media.AudioAttributes.Builder;
import android.media.AudioManager;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.util.Log;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import java.util.ArrayList;
import java.util.Iterator;

public class MLand extends FrameLayout {
    static final int[] ANTENNAE;
    static final int[] CACTI;
    public static final boolean DEBUG;
    public static final boolean DEBUG_IDDQD;
    static final int[] EYES;
    static final int[] MOUNTAINS;
    static final int[] MOUTHS;
    private static Params PARAMS;
    private static final int[][] SKIES;
    private static float dp;
    static final float[] hsv;
    static final Rect sTmpRect;
    private float dt;
    private TimeAnimator mAnim;
    private boolean mAnimating;
    private final AudioAttributes mAudioAttrs;
    private AudioManager mAudioManager;
    private int mCountdown;
    private int mCurrentPipeId;
    private boolean mFlipped;
    private boolean mFrozen;
    private ArrayList<Integer> mGameControllers;
    private int mHeight;
    private float mLastPipeTime;
    private ArrayList<Obstacle> mObstaclesInPlay;
    private Paint mPlayerTracePaint;
    private ArrayList<Player> mPlayers;
    private boolean mPlaying;
    private int mScene;
    private ViewGroup mScoreFields;
    private View mSplash;
    private int mTaps;
    private int mTimeOfDay;
    private Paint mTouchPaint;
    private Vibrator mVibrator;
    private int mWidth;
    private float f17t;

    /* renamed from: com.android.systemui.egg.MLand.1 */
    class C01241 implements TimeListener {
        C01241() {
        }

        public void onTimeUpdate(TimeAnimator timeAnimator, long t, long dt) {
            MLand.this.step(t, dt);
        }
    }

    /* renamed from: com.android.systemui.egg.MLand.2 */
    class C01252 implements Runnable {
        final /* synthetic */ TextView val$playText;

        C01252(TextView textView) {
            this.val$playText = textView;
        }

        public void run() {
            if (MLand.this.mCountdown == 0) {
                MLand.this.startPlaying();
            } else {
                MLand.this.postDelayed(this, 500);
            }
            this.val$playText.setText(String.valueOf(MLand.this.mCountdown));
            MLand.this.mCountdown = MLand.this.mCountdown - 1;
        }
    }

    /* renamed from: com.android.systemui.egg.MLand.3 */
    class C01263 implements Runnable {
        C01263() {
        }

        public void run() {
            MLand.this.mSplash.setVisibility(8);
        }
    }

    /* renamed from: com.android.systemui.egg.MLand.4 */
    class C01274 implements Runnable {
        C01274() {
        }

        public void run() {
            MLand.this.mFrozen = false;
        }
    }

    private interface GameView {
        void step(long j, long j2, float f, float f2);
    }

    private class Scenery extends FrameLayout implements GameView {
        public int f10h;
        public float f11v;
        public int f12w;
        public float f13z;

        public Scenery(Context context) {
            super(context);
        }

        public void step(long t_ms, long dt_ms, float t, float dt) {
            setTranslationX(getTranslationX() - ((MLand.PARAMS.TRANSLATION_PER_SEC * dt) * this.f11v));
        }
    }

    private class Building extends Scenery {
        public Building(Context context) {
            super(context);
            this.w = MLand.irand(MLand.PARAMS.BUILDING_WIDTH_MIN, MLand.PARAMS.BUILDING_WIDTH_MAX);
            this.h = 0;
        }
    }

    private class Cactus extends Building {
        public Cactus(Context context) {
            super(context);
            setBackgroundResource(MLand.pick(MLand.CACTI));
            int irand = MLand.irand(MLand.PARAMS.BUILDING_WIDTH_MAX / 4, MLand.PARAMS.BUILDING_WIDTH_MAX / 2);
            this.h = irand;
            this.w = irand;
        }
    }

    private class Cloud extends Scenery {
        public Cloud(Context context) {
            super(context);
            setBackgroundResource(MLand.frand() < 0.01f ? 2130837513 : 2130837512);
            getBackground().setAlpha(64);
            int irand = MLand.irand(MLand.PARAMS.CLOUD_SIZE_MIN, MLand.PARAMS.CLOUD_SIZE_MAX);
            this.h = irand;
            this.w = irand;
            this.z = 0.0f;
            this.v = MLand.frand(0.15f, 0.5f);
        }
    }

    private class Mountain extends Building {
        public Mountain(Context context) {
            super(context);
            setBackgroundResource(MLand.pick(MLand.MOUNTAINS));
            int irand = MLand.irand(MLand.PARAMS.BUILDING_WIDTH_MAX / 2, MLand.PARAMS.BUILDING_WIDTH_MAX);
            this.h = irand;
            this.w = irand;
            this.z = 0.0f;
        }
    }

    private class Obstacle extends View implements GameView {
        public float f14h;
        public final Rect hitRect;

        public Obstacle(Context context, float h) {
            super(context);
            this.hitRect = new Rect();
            setBackgroundColor(-65536);
            this.f14h = h;
        }

        public boolean intersects(Player p) {
            int N = p.corners.length / 2;
            for (int i = 0; i < N; i++) {
                if (this.hitRect.contains((int) p.corners[i * 2], (int) p.corners[(i * 2) + 1])) {
                    return true;
                }
            }
            return false;
        }

        public boolean cleared(Player p) {
            int N = p.corners.length / 2;
            for (int i = 0; i < N; i++) {
                if (this.hitRect.right >= ((int) p.corners[i * 2])) {
                    return false;
                }
            }
            return true;
        }

        public void step(long t_ms, long dt_ms, float t, float dt) {
            setTranslationX(getTranslationX() - (MLand.PARAMS.TRANSLATION_PER_SEC * dt));
            getHitRect(this.hitRect);
        }
    }

    private static class Params {
        public int BOOST_DV;
        public int BUILDING_HEIGHT_MIN;
        public int BUILDING_WIDTH_MAX;
        public int BUILDING_WIDTH_MIN;
        public int CLOUD_SIZE_MAX;
        public int CLOUD_SIZE_MIN;
        public int f15G;
        public float HUD_Z;
        public int MAX_V;
        public int OBSTACLE_GAP;
        public int OBSTACLE_MIN;
        public int OBSTACLE_PERIOD;
        public int OBSTACLE_SPACING;
        public int OBSTACLE_STEM_WIDTH;
        public int OBSTACLE_WIDTH;
        public float OBSTACLE_Z;
        public int PLAYER_HIT_SIZE;
        public int PLAYER_SIZE;
        public float PLAYER_Z;
        public float PLAYER_Z_BOOST;
        public float SCENERY_Z;
        public int STAR_SIZE_MAX;
        public int STAR_SIZE_MIN;
        public float TRANSLATION_PER_SEC;

        public Params(Resources res) {
            this.TRANSLATION_PER_SEC = res.getDimension(2131296488);
            this.OBSTACLE_SPACING = res.getDimensionPixelSize(2131296487);
            this.OBSTACLE_PERIOD = (int) (((float) this.OBSTACLE_SPACING) / this.TRANSLATION_PER_SEC);
            this.BOOST_DV = res.getDimensionPixelSize(2131296489);
            this.PLAYER_HIT_SIZE = res.getDimensionPixelSize(2131296490);
            this.PLAYER_SIZE = res.getDimensionPixelSize(2131296491);
            this.OBSTACLE_WIDTH = res.getDimensionPixelSize(2131296492);
            this.OBSTACLE_STEM_WIDTH = res.getDimensionPixelSize(2131296493);
            this.OBSTACLE_GAP = res.getDimensionPixelSize(2131296494);
            this.OBSTACLE_MIN = res.getDimensionPixelSize(2131296495);
            this.BUILDING_HEIGHT_MIN = res.getDimensionPixelSize(2131296498);
            this.BUILDING_WIDTH_MIN = res.getDimensionPixelSize(2131296496);
            this.BUILDING_WIDTH_MAX = res.getDimensionPixelSize(2131296497);
            this.CLOUD_SIZE_MIN = res.getDimensionPixelSize(2131296499);
            this.CLOUD_SIZE_MAX = res.getDimensionPixelSize(2131296500);
            this.STAR_SIZE_MIN = res.getDimensionPixelSize(2131296503);
            this.STAR_SIZE_MAX = res.getDimensionPixelSize(2131296504);
            this.f15G = res.getDimensionPixelSize(2131296505);
            this.MAX_V = res.getDimensionPixelSize(2131296506);
            this.SCENERY_Z = (float) res.getDimensionPixelSize(2131296507);
            this.OBSTACLE_Z = (float) res.getDimensionPixelSize(2131296508);
            this.PLAYER_Z = (float) res.getDimensionPixelSize(2131296509);
            this.PLAYER_Z_BOOST = (float) res.getDimensionPixelSize(2131296510);
            this.HUD_Z = (float) res.getDimensionPixelSize(2131296511);
            if (this.OBSTACLE_MIN <= this.OBSTACLE_WIDTH / 2) {
                MLand.m0L("error: obstacles might be too short, adjusting", new Object[0]);
                this.OBSTACLE_MIN = (this.OBSTACLE_WIDTH / 2) + 1;
            }
        }
    }

    private static class Player extends ImageView implements GameView {
        static int sNextColor;
        public int color;
        public final float[] corners;
        public float dv;
        private boolean mAlive;
        private boolean mBoosting;
        private MLand mLand;
        private int mScore;
        private TextView mScoreField;
        private float mTouchX;
        private float mTouchY;
        private final int[] sColors;
        private final float[] sHull;

        /* renamed from: com.android.systemui.egg.MLand.Player.1 */
        class C01281 extends ViewOutlineProvider {
            C01281() {
            }

            public void getOutline(View view, Outline outline) {
                int w = view.getWidth();
                int h = view.getHeight();
                int ix = (int) (((float) w) * 0.3f);
                int iy = (int) (((float) h) * 0.2f);
                outline.setRect(ix, iy, w - ix, h - iy);
            }
        }

        static {
            sNextColor = 0;
        }

        public static Player create(MLand land) {
            Player p = new Player(land.getContext());
            p.mLand = land;
            p.reset();
            p.setVisibility(4);
            land.addView(p, new LayoutParams(MLand.PARAMS.PLAYER_SIZE, MLand.PARAMS.PLAYER_SIZE));
            return p;
        }

        private void setScore(int score) {
            this.mScore = score;
            if (this.mScoreField != null) {
                this.mScoreField.setText(MLand.DEBUG_IDDQD ? "??" : String.valueOf(score));
            }
        }

        public int getScore() {
            return this.mScore;
        }

        private void addScore(int incr) {
            setScore(this.mScore + incr);
        }

        public void setScoreField(TextView tv) {
            this.mScoreField = tv;
            if (tv != null) {
                setScore(this.mScore);
                this.mScoreField.getBackground().setColorFilter(this.color, Mode.SRC_ATOP);
                this.mScoreField.setTextColor(MLand.luma(this.color) > 0.7f ? -16777216 : -1);
            }
        }

        public void reset() {
            setY((float) (((this.mLand.mHeight / 2) + ((int) (Math.random() * ((double) MLand.PARAMS.PLAYER_SIZE)))) - (MLand.PARAMS.PLAYER_SIZE / 2)));
            setScore(0);
            setScoreField(this.mScoreField);
            this.mBoosting = false;
            this.dv = 0.0f;
        }

        public Player(Context context) {
            super(context);
            this.mTouchX = -1.0f;
            this.mTouchY = -1.0f;
            this.sColors = new int[]{-2407369, -12879641, -740352, -15753896, -8710016, -6381922};
            this.sHull = new float[]{0.3f, 0.0f, 0.7f, 0.0f, 0.92f, 0.33f, 0.92f, 0.75f, 0.6f, 1.0f, 0.4f, 1.0f, 0.08f, 0.75f, 0.08f, 0.33f};
            this.corners = new float[this.sHull.length];
            setBackgroundResource(2130837504);
            getBackground().setTintMode(Mode.SRC_ATOP);
            int[] iArr = this.sColors;
            int i = sNextColor;
            sNextColor = i + 1;
            this.color = iArr[i % this.sColors.length];
            getBackground().setTint(this.color);
            setOutlineProvider(new C01281());
        }

        public void prepareCheckIntersections() {
            int inset = (MLand.PARAMS.PLAYER_SIZE - MLand.PARAMS.PLAYER_HIT_SIZE) / 2;
            int scale = MLand.PARAMS.PLAYER_HIT_SIZE;
            int N = this.sHull.length / 2;
            for (int i = 0; i < N; i++) {
                this.corners[i * 2] = (((float) scale) * this.sHull[i * 2]) + ((float) inset);
                this.corners[(i * 2) + 1] = (((float) scale) * this.sHull[(i * 2) + 1]) + ((float) inset);
            }
            getMatrix().mapPoints(this.corners);
        }

        public boolean below(int h) {
            int N = this.corners.length / 2;
            for (int i = 0; i < N; i++) {
                if (((int) this.corners[(i * 2) + 1]) >= h) {
                    return true;
                }
            }
            return false;
        }

        public void step(long t_ms, long dt_ms, float t, float dt) {
            if (this.mAlive) {
                if (this.mBoosting) {
                    this.dv = (float) (-MLand.PARAMS.BOOST_DV);
                } else {
                    this.dv += (float) MLand.PARAMS.f15G;
                }
                if (this.dv < ((float) (-MLand.PARAMS.MAX_V))) {
                    this.dv = (float) (-MLand.PARAMS.MAX_V);
                } else if (this.dv > ((float) MLand.PARAMS.MAX_V)) {
                    this.dv = (float) MLand.PARAMS.MAX_V;
                }
                float y = getTranslationY() + (this.dv * dt);
                if (y < 0.0f) {
                    y = 0.0f;
                }
                setTranslationY(y);
                setRotation(MLand.lerp(MLand.clamp(MLand.rlerp(this.dv, (float) MLand.PARAMS.MAX_V, (float) (MLand.PARAMS.MAX_V * -1))), 90.0f, -90.0f) + 90.0f);
                prepareCheckIntersections();
                return;
            }
            setTranslationX(getTranslationX() - (MLand.PARAMS.TRANSLATION_PER_SEC * dt));
        }

        public void boost(float x, float y) {
            this.mTouchX = x;
            this.mTouchY = y;
            boost();
        }

        public void boost() {
            this.mBoosting = true;
            this.dv = (float) (-MLand.PARAMS.BOOST_DV);
            animate().cancel();
            animate().scaleX(1.25f).scaleY(1.25f).translationZ(MLand.PARAMS.PLAYER_Z_BOOST).setDuration(100);
            setScaleX(1.25f);
            setScaleY(1.25f);
        }

        public void unboost() {
            this.mBoosting = false;
            this.mTouchY = -1.0f;
            this.mTouchX = -1.0f;
            animate().cancel();
            animate().scaleX(1.0f).scaleY(1.0f).translationZ(MLand.PARAMS.PLAYER_Z).setDuration(200);
        }

        public void die() {
            this.mAlive = false;
            if (this.mScoreField == null) {
            }
        }

        public void start() {
            this.mAlive = true;
        }
    }

    private class Pop extends Obstacle {
        Drawable antenna;
        int cx;
        int cy;
        Drawable eyes;
        int mRotate;
        Drawable mouth;
        int f16r;

        /* renamed from: com.android.systemui.egg.MLand.Pop.1 */
        class C01291 extends ViewOutlineProvider {
            final /* synthetic */ MLand val$this$0;

            C01291(MLand mLand) {
                this.val$this$0 = mLand;
            }

            public void getOutline(View view, Outline outline) {
                int pad = (int) ((((float) Pop.this.getWidth()) * 1.0f) / 6.0f);
                outline.setOval(pad, pad, Pop.this.getWidth() - pad, Pop.this.getHeight() - pad);
            }
        }

        public Pop(Context context, float h) {
            super(context, h);
            setBackgroundResource(2130837762);
            this.antenna = context.getDrawable(MLand.pick(MLand.ANTENNAE));
            if (MLand.frand() > 0.5f) {
                this.eyes = context.getDrawable(MLand.pick(MLand.EYES));
                if (MLand.frand() > 0.8f) {
                    this.mouth = context.getDrawable(MLand.pick(MLand.MOUTHS));
                }
            }
            setOutlineProvider(new C01291(MLand.this));
        }

        public boolean intersects(Player p) {
            int N = p.corners.length / 2;
            for (int i = 0; i < N; i++) {
                if (Math.hypot((double) (((int) p.corners[i * 2]) - this.cx), (double) (((int) p.corners[(i * 2) + 1]) - this.cy)) <= ((double) this.f16r)) {
                    return true;
                }
            }
            return false;
        }

        public void step(long t_ms, long dt_ms, float t, float dt) {
            super.step(t_ms, dt_ms, t, dt);
            if (this.mRotate != 0) {
                setRotation(getRotation() + ((45.0f * dt) * ((float) this.mRotate)));
            }
            this.cx = (this.hitRect.left + this.hitRect.right) / 2;
            this.cy = (this.hitRect.top + this.hitRect.bottom) / 2;
            this.f16r = getWidth() / 3;
        }

        public void onDraw(Canvas c) {
            super.onDraw(c);
            if (this.antenna != null) {
                this.antenna.setBounds(0, 0, c.getWidth(), c.getHeight());
                this.antenna.draw(c);
            }
            if (this.eyes != null) {
                this.eyes.setBounds(0, 0, c.getWidth(), c.getHeight());
                this.eyes.draw(c);
            }
            if (this.mouth != null) {
                this.mouth.setBounds(0, 0, c.getWidth(), c.getHeight());
                this.mouth.draw(c);
            }
        }
    }

    private class Star extends Scenery {
        public Star(Context context) {
            super(context);
            setBackgroundResource(2130837818);
            int irand = MLand.irand(MLand.PARAMS.STAR_SIZE_MIN, MLand.PARAMS.STAR_SIZE_MAX);
            this.h = irand;
            this.w = irand;
            this.z = 0.0f;
            this.v = 0.0f;
        }
    }

    private class Stem extends Obstacle {
        int id;
        boolean mDrawShadow;
        GradientDrawable mGradient;
        Path mJandystripe;
        Paint mPaint;
        Paint mPaint2;
        Path mShadow;

        /* renamed from: com.android.systemui.egg.MLand.Stem.1 */
        class C01301 extends ViewOutlineProvider {
            C01301() {
            }

            public void getOutline(View view, Outline outline) {
                outline.setRect(0, 0, Stem.this.getWidth(), Stem.this.getHeight());
            }
        }

        public Stem(Context context, float h, boolean drawShadow) {
            super(context, h);
            this.mPaint = new Paint();
            this.mShadow = new Path();
            this.mGradient = new GradientDrawable();
            this.id = MLand.this.mCurrentPipeId;
            this.mDrawShadow = drawShadow;
            setBackground(null);
            this.mGradient.setOrientation(Orientation.LEFT_RIGHT);
            this.mPaint.setColor(-16777216);
            this.mPaint.setColorFilter(new PorterDuffColorFilter(570425344, Mode.MULTIPLY));
            if (MLand.frand() < 0.01f) {
                this.mGradient.setColors(new int[]{-1, -2236963});
                this.mJandystripe = new Path();
                this.mPaint2 = new Paint();
                this.mPaint2.setColor(-65536);
                this.mPaint2.setColorFilter(new PorterDuffColorFilter(-65536, Mode.MULTIPLY));
                return;
            }
            this.mGradient.setColors(new int[]{-4412764, -6190977});
        }

        public void onAttachedToWindow() {
            super.onAttachedToWindow();
            setWillNotDraw(false);
            setOutlineProvider(new C01301());
        }

        public void onDraw(Canvas c) {
            int w = c.getWidth();
            int h = c.getHeight();
            this.mGradient.setGradientCenter(((float) w) * 0.75f, 0.0f);
            this.mGradient.setBounds(0, 0, w, h);
            this.mGradient.draw(c);
            if (this.mJandystripe != null) {
                this.mJandystripe.reset();
                this.mJandystripe.moveTo(0.0f, (float) w);
                this.mJandystripe.lineTo((float) w, 0.0f);
                this.mJandystripe.lineTo((float) w, (float) (w * 2));
                this.mJandystripe.lineTo(0.0f, (float) (w * 3));
                this.mJandystripe.close();
                for (int y = 0; y < h; y += w * 4) {
                    c.drawPath(this.mJandystripe, this.mPaint2);
                    this.mJandystripe.offset(0.0f, (float) (w * 4));
                }
            }
            if (this.mDrawShadow) {
                this.mShadow.reset();
                this.mShadow.moveTo(0.0f, 0.0f);
                this.mShadow.lineTo((float) w, 0.0f);
                this.mShadow.lineTo((float) w, (((float) MLand.PARAMS.OBSTACLE_WIDTH) * 0.4f) + (((float) w) * 1.5f));
                this.mShadow.lineTo(0.0f, ((float) MLand.PARAMS.OBSTACLE_WIDTH) * 0.4f);
                this.mShadow.close();
                c.drawPath(this.mShadow, this.mPaint);
            }
        }
    }

    static {
        DEBUG = Log.isLoggable("MLand", 3);
        DEBUG_IDDQD = Log.isLoggable("MLand.iddqd", 3);
        SKIES = new int[][]{new int[]{-4144897, -6250241}, new int[]{-16777200, -16777216}, new int[]{-16777152, -16777200}, new int[]{-6258656, -14663552}};
        dp = 1.0f;
        hsv = new float[]{0.0f, 0.0f, 0.0f};
        sTmpRect = new Rect();
        ANTENNAE = new int[]{2130837758, 2130837759};
        EYES = new int[]{2130837760, 2130837761};
        MOUTHS = new int[]{2130837763, 2130837764, 2130837765, 2130837766};
        CACTI = new int[]{2130837509, 2130837510, 2130837511};
        MOUNTAINS = new int[]{2130837768, 2130837769, 2130837770};
    }

    public static void m0L(String s, Object... objects) {
        if (DEBUG) {
            String str = "MLand";
            if (objects.length != 0) {
                s = String.format(s, objects);
            }
            Log.d(str, s);
        }
    }

    public MLand(Context context) {
        this(context, null);
    }

    public MLand(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MLand(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mAudioAttrs = new Builder().setUsage(14).build();
        this.mPlayers = new ArrayList();
        this.mObstaclesInPlay = new ArrayList();
        this.mCountdown = 0;
        this.mGameControllers = new ArrayList();
        this.mVibrator = (Vibrator) context.getSystemService("vibrator");
        this.mAudioManager = (AudioManager) context.getSystemService("audio");
        setFocusable(true);
        PARAMS = new Params(getResources());
        this.mTimeOfDay = irand(0, SKIES.length - 1);
        this.mScene = irand(0, 3);
        this.mTouchPaint = new Paint(1);
        this.mTouchPaint.setColor(-2130706433);
        this.mTouchPaint.setStyle(Style.FILL);
        this.mPlayerTracePaint = new Paint(1);
        this.mPlayerTracePaint.setColor(-2130706433);
        this.mPlayerTracePaint.setStyle(Style.STROKE);
        this.mPlayerTracePaint.setStrokeWidth(2.0f * dp);
        setLayoutDirection(0);
        setupPlayers(1);
        MetricsLogger.count(getContext(), "egg_mland_create", 1);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        dp = getResources().getDisplayMetrics().density;
        reset();
        start(false);
    }

    public boolean willNotDraw() {
        return !DEBUG;
    }

    public float getGameTime() {
        return this.f17t;
    }

    public void setScoreFieldHolder(ViewGroup vg) {
        this.mScoreFields = vg;
        if (vg != null) {
            LayoutTransition lt = new LayoutTransition();
            lt.setDuration(250);
            this.mScoreFields.setLayoutTransition(lt);
        }
        Iterator i$ = this.mPlayers.iterator();
        while (i$.hasNext()) {
            this.mScoreFields.addView(((Player) i$.next()).mScoreField, new MarginLayoutParams(-2, -1));
        }
    }

    public void setSplash(View v) {
        this.mSplash = v;
    }

    public static boolean isGamePad(InputDevice dev) {
        int sources = dev.getSources();
        return (sources & 1025) == 1025 || (sources & 16777232) == 16777232;
    }

    public ArrayList getGameControllers() {
        this.mGameControllers.clear();
        for (int deviceId : InputDevice.getDeviceIds()) {
            if (isGamePad(InputDevice.getDevice(deviceId)) && !this.mGameControllers.contains(Integer.valueOf(deviceId))) {
                this.mGameControllers.add(Integer.valueOf(deviceId));
            }
        }
        return this.mGameControllers;
    }

    public int getControllerPlayer(int id) {
        int player = this.mGameControllers.indexOf(Integer.valueOf(id));
        if (player < 0 || player >= this.mPlayers.size()) {
            return 0;
        }
        return player;
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        dp = getResources().getDisplayMetrics().density;
        stop();
        reset();
        start(false);
    }

    private static float luma(int bgcolor) {
        return (((0.2126f * ((float) (16711680 & bgcolor))) / 1.671168E7f) + ((0.7152f * ((float) (65280 & bgcolor))) / 65280.0f)) + ((0.0722f * ((float) (bgcolor & 255))) / 255.0f);
    }

    public Player getPlayer(int i) {
        return i < this.mPlayers.size() ? (Player) this.mPlayers.get(i) : null;
    }

    private int addPlayerInternal(Player p) {
        this.mPlayers.add(p);
        realignPlayers();
        TextView scoreField = (TextView) LayoutInflater.from(getContext()).inflate(2130968602, null);
        if (this.mScoreFields != null) {
            this.mScoreFields.addView(scoreField, new MarginLayoutParams(-2, -1));
        }
        p.setScoreField(scoreField);
        return this.mPlayers.size() - 1;
    }

    private void removePlayerInternal(Player p) {
        if (this.mPlayers.remove(p)) {
            removeView(p);
            this.mScoreFields.removeView(p.mScoreField);
            realignPlayers();
        }
    }

    private void realignPlayers() {
        int N = this.mPlayers.size();
        float x = (float) ((this.mWidth - ((N - 1) * PARAMS.PLAYER_SIZE)) / 2);
        for (int i = 0; i < N; i++) {
            ((Player) this.mPlayers.get(i)).setX(x);
            x += (float) PARAMS.PLAYER_SIZE;
        }
    }

    private void clearPlayers() {
        while (this.mPlayers.size() > 0) {
            removePlayerInternal((Player) this.mPlayers.get(0));
        }
    }

    public void setupPlayers(int num) {
        clearPlayers();
        for (int i = 0; i < num; i++) {
            addPlayerInternal(Player.create(this));
        }
    }

    public void addPlayer() {
        if (getNumPlayers() != 6) {
            addPlayerInternal(Player.create(this));
        }
    }

    public int getNumPlayers() {
        return this.mPlayers.size();
    }

    public void removePlayer() {
        if (getNumPlayers() != 1) {
            removePlayerInternal((Player) this.mPlayers.get(this.mPlayers.size() - 1));
        }
    }

    private void thump(int playerIndex, long ms) {
        if (this.mAudioManager.getRingerMode() != 0) {
            if (playerIndex < this.mGameControllers.size()) {
                InputDevice dev = InputDevice.getDevice(((Integer) this.mGameControllers.get(playerIndex)).intValue());
                if (dev != null && dev.getVibrator().hasVibrator()) {
                    dev.getVibrator().vibrate((long) (((float) ms) * 2.0f), this.mAudioAttrs);
                    return;
                }
            }
            this.mVibrator.vibrate(ms, this.mAudioAttrs);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void reset() {
        /*
        r30 = this;
        r25 = "reset";
        r26 = 0;
        r0 = r26;
        r0 = new java.lang.Object[r0];
        r26 = r0;
        m0L(r25, r26);
        r21 = new android.graphics.drawable.GradientDrawable;
        r25 = android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP;
        r26 = SKIES;
        r0 = r30;
        r0 = r0.mTimeOfDay;
        r27 = r0;
        r26 = r26[r27];
        r0 = r21;
        r1 = r25;
        r2 = r26;
        r0.<init>(r1, r2);
        r25 = 1;
        r0 = r21;
        r1 = r25;
        r0.setDither(r1);
        r0 = r30;
        r1 = r21;
        r0.setBackground(r1);
        r25 = frand();
        r26 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r25 = (r25 > r26 ? 1 : (r25 == r26 ? 0 : -1));
        if (r25 <= 0) goto L_0x0075;
    L_0x003e:
        r25 = 1;
    L_0x0040:
        r0 = r25;
        r1 = r30;
        r1.mFlipped = r0;
        r0 = r30;
        r0 = r0.mFlipped;
        r25 = r0;
        if (r25 == 0) goto L_0x0078;
    L_0x004e:
        r25 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
    L_0x0050:
        r0 = r30;
        r1 = r25;
        r0.setScaleX(r1);
        r10 = r30.getChildCount();
        r11 = r10;
    L_0x005c:
        r10 = r11 + -1;
        if (r11 <= 0) goto L_0x007b;
    L_0x0060:
        r0 = r30;
        r23 = r0.getChildAt(r10);
        r0 = r23;
        r0 = r0 instanceof com.android.systemui.egg.MLand.GameView;
        r25 = r0;
        if (r25 == 0) goto L_0x0073;
    L_0x006e:
        r0 = r30;
        r0.removeViewAt(r10);
    L_0x0073:
        r11 = r10;
        goto L_0x005c;
    L_0x0075:
        r25 = 0;
        goto L_0x0040;
    L_0x0078:
        r25 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        goto L_0x0050;
    L_0x007b:
        r0 = r30;
        r0 = r0.mObstaclesInPlay;
        r25 = r0;
        r25.clear();
        r25 = 0;
        r0 = r25;
        r1 = r30;
        r1.mCurrentPipeId = r0;
        r25 = r30.getWidth();
        r0 = r25;
        r1 = r30;
        r1.mWidth = r0;
        r25 = r30.getHeight();
        r0 = r25;
        r1 = r30;
        r1.mHeight = r0;
        r0 = r30;
        r0 = r0.mTimeOfDay;
        r25 = r0;
        if (r25 == 0) goto L_0x00b6;
    L_0x00a8:
        r0 = r30;
        r0 = r0.mTimeOfDay;
        r25 = r0;
        r26 = 3;
        r0 = r25;
        r1 = r26;
        if (r0 != r1) goto L_0x02c2;
    L_0x00b6:
        r25 = frand();
        r0 = r25;
        r0 = (double) r0;
        r26 = r0;
        r28 = 4598175219545276416; // 0x3fd0000000000000 float:0.0 double:0.25;
        r25 = (r26 > r28 ? 1 : (r26 == r28 ? 0 : -1));
        if (r25 <= 0) goto L_0x02c2;
    L_0x00c5:
        r20 = 1;
    L_0x00c7:
        if (r20 == 0) goto L_0x014f;
    L_0x00c9:
        r22 = new com.android.systemui.egg.MLand$Star;
        r25 = r30.getContext();
        r0 = r22;
        r1 = r30;
        r2 = r25;
        r0.<init>(r2);
        r25 = 2130838157; // 0x7f02028d float:1.7281288E38 double:1.05277393E-314;
        r0 = r22;
        r1 = r25;
        r0.setBackgroundResource(r1);
        r25 = r30.getResources();
        r26 = 2131296501; // 0x7f0900f5 float:1.821092E38 double:1.053000382E-314;
        r24 = r25.getDimensionPixelSize(r26);
        r0 = r24;
        r0 = (float) r0;
        r25 = r0;
        r0 = r30;
        r0 = r0.mWidth;
        r26 = r0;
        r26 = r26 - r24;
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r25 = frand(r25, r26);
        r0 = r22;
        r1 = r25;
        r0.setTranslationX(r1);
        r0 = r30;
        r0 = r0.mTimeOfDay;
        r25 = r0;
        if (r25 != 0) goto L_0x02c6;
    L_0x0112:
        r0 = r24;
        r0 = (float) r0;
        r25 = r0;
        r0 = r30;
        r0 = r0.mHeight;
        r26 = r0;
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r27 = 1059648963; // 0x3f28f5c3 float:0.66 double:5.235361493E-315;
        r26 = r26 * r27;
        r25 = frand(r25, r26);
        r0 = r22;
        r1 = r25;
        r0.setTranslationY(r1);
        r25 = r22.getBackground();
        r26 = 0;
        r25.setTint(r26);
    L_0x013b:
        r25 = new android.widget.FrameLayout$LayoutParams;
        r0 = r25;
        r1 = r24;
        r2 = r24;
        r0.<init>(r1, r2);
        r0 = r30;
        r1 = r22;
        r2 = r25;
        r0.addView(r1, r2);
    L_0x014f:
        if (r20 != 0) goto L_0x0220;
    L_0x0151:
        r0 = r30;
        r0 = r0.mTimeOfDay;
        r25 = r0;
        r26 = 1;
        r0 = r25;
        r1 = r26;
        if (r0 == r1) goto L_0x016d;
    L_0x015f:
        r0 = r30;
        r0 = r0.mTimeOfDay;
        r25 = r0;
        r26 = 2;
        r0 = r25;
        r1 = r26;
        if (r0 != r1) goto L_0x0303;
    L_0x016d:
        r8 = 1;
    L_0x016e:
        r9 = frand();
        if (r8 == 0) goto L_0x017a;
    L_0x0174:
        r25 = 1061158912; // 0x3f400000 float:0.75 double:5.24282163E-315;
        r25 = (r9 > r25 ? 1 : (r9 == r25 ? 0 : -1));
        if (r25 < 0) goto L_0x0180;
    L_0x017a:
        r25 = 1056964608; // 0x3f000000 float:0.5 double:5.222099017E-315;
        r25 = (r9 > r25 ? 1 : (r9 == r25 ? 0 : -1));
        if (r25 >= 0) goto L_0x0220;
    L_0x0180:
        r15 = new com.android.systemui.egg.MLand$Star;
        r25 = r30.getContext();
        r0 = r30;
        r1 = r25;
        r15.<init>(r1);
        r25 = 2130837767; // 0x7f020107 float:1.7280497E38 double:1.0527737375E-314;
        r0 = r25;
        r15.setBackgroundResource(r0);
        r26 = r15.getBackground();
        if (r8 == 0) goto L_0x0306;
    L_0x019b:
        r25 = 255; // 0xff float:3.57E-43 double:1.26E-321;
    L_0x019d:
        r0 = r26;
        r1 = r25;
        r0.setAlpha(r1);
        r25 = frand();
        r0 = r25;
        r0 = (double) r0;
        r26 = r0;
        r28 = 4602678819172646912; // 0x3fe0000000000000 float:0.0 double:0.5;
        r25 = (r26 > r28 ? 1 : (r26 == r28 ? 0 : -1));
        if (r25 <= 0) goto L_0x030a;
    L_0x01b3:
        r25 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
    L_0x01b5:
        r0 = r25;
        r15.setScaleX(r0);
        r25 = r15.getScaleX();
        r26 = 1084227584; // 0x40a00000 float:5.0 double:5.356796015E-315;
        r27 = 1106247680; // 0x41f00000 float:30.0 double:5.465589745E-315;
        r26 = frand(r26, r27);
        r25 = r25 * r26;
        r0 = r25;
        r15.setRotation(r0);
        r25 = r30.getResources();
        r26 = 2131296501; // 0x7f0900f5 float:1.821092E38 double:1.053000382E-314;
        r24 = r25.getDimensionPixelSize(r26);
        r0 = r24;
        r0 = (float) r0;
        r25 = r0;
        r0 = r30;
        r0 = r0.mWidth;
        r26 = r0;
        r26 = r26 - r24;
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r25 = frand(r25, r26);
        r0 = r25;
        r15.setTranslationX(r0);
        r0 = r24;
        r0 = (float) r0;
        r25 = r0;
        r0 = r30;
        r0 = r0.mHeight;
        r26 = r0;
        r26 = r26 - r24;
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r25 = frand(r25, r26);
        r0 = r25;
        r15.setTranslationY(r0);
        r25 = new android.widget.FrameLayout$LayoutParams;
        r0 = r25;
        r1 = r24;
        r2 = r24;
        r0.<init>(r1, r2);
        r0 = r30;
        r1 = r25;
        r0.addView(r15, r1);
    L_0x0220:
        r0 = r30;
        r0 = r0.mHeight;
        r25 = r0;
        r14 = r25 / 6;
        r25 = frand();
        r0 = r25;
        r0 = (double) r0;
        r26 = r0;
        r28 = 4598175219545276416; // 0x3fd0000000000000 float:0.0 double:0.25;
        r25 = (r26 > r28 ? 1 : (r26 == r28 ? 0 : -1));
        if (r25 >= 0) goto L_0x030e;
    L_0x0237:
        r7 = 1;
    L_0x0238:
        r4 = 20;
        r10 = 0;
    L_0x023b:
        r25 = 20;
        r0 = r25;
        if (r10 >= r0) goto L_0x0429;
    L_0x0241:
        r18 = frand();
        r0 = r18;
        r0 = (double) r0;
        r26 = r0;
        r28 = 4599075939470750515; // 0x3fd3333333333333 float:4.172325E-8 double:0.3;
        r25 = (r26 > r28 ? 1 : (r26 == r28 ? 0 : -1));
        if (r25 >= 0) goto L_0x0311;
    L_0x0253:
        r0 = r30;
        r0 = r0.mTimeOfDay;
        r25 = r0;
        if (r25 == 0) goto L_0x0311;
    L_0x025b:
        r19 = new com.android.systemui.egg.MLand$Star;
        r25 = r30.getContext();
        r0 = r19;
        r1 = r30;
        r2 = r25;
        r0.<init>(r2);
    L_0x026a:
        r13 = new android.widget.FrameLayout$LayoutParams;
        r0 = r19;
        r0 = r0.f12w;
        r25 = r0;
        r0 = r19;
        r0 = r0.f10h;
        r26 = r0;
        r0 = r25;
        r1 = r26;
        r13.<init>(r0, r1);
        r0 = r19;
        r0 = r0 instanceof com.android.systemui.egg.MLand.Building;
        r25 = r0;
        if (r25 == 0) goto L_0x03d1;
    L_0x0287:
        r25 = 80;
        r0 = r25;
        r13.gravity = r0;
    L_0x028d:
        r0 = r30;
        r1 = r19;
        r0.addView(r1, r13);
        r0 = r13.width;
        r25 = r0;
        r0 = r25;
        r0 = -r0;
        r25 = r0;
        r0 = r25;
        r0 = (float) r0;
        r25 = r0;
        r0 = r30;
        r0 = r0.mWidth;
        r26 = r0;
        r0 = r13.width;
        r27 = r0;
        r26 = r26 + r27;
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r25 = frand(r25, r26);
        r0 = r19;
        r1 = r25;
        r0.setTranslationX(r1);
        r10 = r10 + 1;
        goto L_0x023b;
    L_0x02c2:
        r20 = 0;
        goto L_0x00c7;
    L_0x02c6:
        r0 = r30;
        r0 = r0.mHeight;
        r25 = r0;
        r0 = r25;
        r0 = (float) r0;
        r25 = r0;
        r26 = 1059648963; // 0x3f28f5c3 float:0.66 double:5.235361493E-315;
        r25 = r25 * r26;
        r0 = r30;
        r0 = r0.mHeight;
        r26 = r0;
        r26 = r26 - r24;
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r25 = frand(r25, r26);
        r0 = r22;
        r1 = r25;
        r0.setTranslationY(r1);
        r25 = r22.getBackground();
        r26 = android.graphics.PorterDuff.Mode.SRC_ATOP;
        r25.setTintMode(r26);
        r25 = r22.getBackground();
        r26 = -1056997376; // 0xffffffffc0ff8000 float:-7.984375 double:NaN;
        r25.setTint(r26);
        goto L_0x013b;
    L_0x0303:
        r8 = 0;
        goto L_0x016e;
    L_0x0306:
        r25 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        goto L_0x019d;
    L_0x030a:
        r25 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        goto L_0x01b5;
    L_0x030e:
        r7 = 0;
        goto L_0x0238;
    L_0x0311:
        r0 = r18;
        r0 = (double) r0;
        r26 = r0;
        r28 = 4603579539098121011; // 0x3fe3333333333333 float:4.172325E-8 double:0.6;
        r25 = (r26 > r28 ? 1 : (r26 == r28 ? 0 : -1));
        if (r25 >= 0) goto L_0x0332;
    L_0x031f:
        if (r7 != 0) goto L_0x0332;
    L_0x0321:
        r19 = new com.android.systemui.egg.MLand$Cloud;
        r25 = r30.getContext();
        r0 = r19;
        r1 = r30;
        r2 = r25;
        r0.<init>(r2);
        goto L_0x026a;
    L_0x0332:
        r0 = r30;
        r0 = r0.mScene;
        r25 = r0;
        switch(r25) {
            case 1: goto L_0x03c0;
            case 2: goto L_0x03b0;
            default: goto L_0x033b;
        };
    L_0x033b:
        r19 = new com.android.systemui.egg.MLand$Building;
        r25 = r30.getContext();
        r0 = r19;
        r1 = r30;
        r2 = r25;
        r0.<init>(r2);
    L_0x034a:
        r0 = (float) r10;
        r25 = r0;
        r26 = 1101004800; // 0x41a00000 float:20.0 double:5.439686476E-315;
        r25 = r25 / r26;
        r0 = r25;
        r1 = r19;
        r1.f13z = r0;
        r25 = 1062836634; // 0x3f59999a float:0.85 double:5.25111068E-315;
        r0 = r19;
        r0 = r0.f13z;
        r26 = r0;
        r25 = r25 * r26;
        r0 = r25;
        r1 = r19;
        r1.f11v = r0;
        r0 = r30;
        r0 = r0.mScene;
        r25 = r0;
        if (r25 != 0) goto L_0x038e;
    L_0x0370:
        r25 = -7829368; // 0xffffffffff888888 float:NaN double:NaN;
        r0 = r19;
        r1 = r25;
        r0.setBackgroundColor(r1);
        r25 = PARAMS;
        r0 = r25;
        r0 = r0.BUILDING_HEIGHT_MIN;
        r25 = r0;
        r0 = r25;
        r25 = irand(r0, r14);
        r0 = r25;
        r1 = r19;
        r1.f10h = r0;
    L_0x038e:
        r25 = 1132396544; // 0x437f0000 float:255.0 double:5.5947823E-315;
        r0 = r19;
        r0 = r0.f13z;
        r26 = r0;
        r25 = r25 * r26;
        r0 = r25;
        r6 = (int) r0;
        r5 = r19.getBackground();
        if (r5 == 0) goto L_0x026a;
    L_0x03a1:
        r25 = android.graphics.Color.rgb(r6, r6, r6);
        r26 = android.graphics.PorterDuff.Mode.MULTIPLY;
        r0 = r25;
        r1 = r26;
        r5.setColorFilter(r0, r1);
        goto L_0x026a;
    L_0x03b0:
        r19 = new com.android.systemui.egg.MLand$Mountain;
        r25 = r30.getContext();
        r0 = r19;
        r1 = r30;
        r2 = r25;
        r0.<init>(r2);
        goto L_0x034a;
    L_0x03c0:
        r19 = new com.android.systemui.egg.MLand$Cactus;
        r25 = r30.getContext();
        r0 = r19;
        r1 = r30;
        r2 = r25;
        r0.<init>(r2);
        goto L_0x034a;
    L_0x03d1:
        r25 = 48;
        r0 = r25;
        r13.gravity = r0;
        r17 = frand();
        r0 = r19;
        r0 = r0 instanceof com.android.systemui.egg.MLand.Star;
        r25 = r0;
        if (r25 == 0) goto L_0x03fd;
    L_0x03e3:
        r25 = r17 * r17;
        r0 = r30;
        r0 = r0.mHeight;
        r26 = r0;
        r0 = r26;
        r0 = (float) r0;
        r26 = r0;
        r25 = r25 * r26;
        r0 = r25;
        r0 = (int) r0;
        r25 = r0;
        r0 = r25;
        r13.topMargin = r0;
        goto L_0x028d;
    L_0x03fd:
        r25 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r26 = r17 * r17;
        r0 = r30;
        r0 = r0.mHeight;
        r27 = r0;
        r0 = r27;
        r0 = (float) r0;
        r27 = r0;
        r26 = r26 * r27;
        r27 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r26 = r26 / r27;
        r25 = r25 - r26;
        r0 = r25;
        r0 = (int) r0;
        r25 = r0;
        r0 = r30;
        r0 = r0.mHeight;
        r26 = r0;
        r26 = r26 / 2;
        r25 = r25 + r26;
        r0 = r25;
        r13.topMargin = r0;
        goto L_0x028d;
    L_0x0429:
        r0 = r30;
        r0 = r0.mPlayers;
        r25 = r0;
        r12 = r25.iterator();
    L_0x0433:
        r25 = r12.hasNext();
        if (r25 == 0) goto L_0x044a;
    L_0x0439:
        r16 = r12.next();
        r16 = (com.android.systemui.egg.MLand.Player) r16;
        r0 = r30;
        r1 = r16;
        r0.addView(r1);
        r16.reset();
        goto L_0x0433;
    L_0x044a:
        r30.realignPlayers();
        r0 = r30;
        r0 = r0.mAnim;
        r25 = r0;
        if (r25 == 0) goto L_0x045e;
    L_0x0455:
        r0 = r30;
        r0 = r0.mAnim;
        r25 = r0;
        r25.cancel();
    L_0x045e:
        r25 = new android.animation.TimeAnimator;
        r25.<init>();
        r0 = r25;
        r1 = r30;
        r1.mAnim = r0;
        r0 = r30;
        r0 = r0.mAnim;
        r25 = r0;
        r26 = new com.android.systemui.egg.MLand$1;
        r0 = r26;
        r1 = r30;
        r0.<init>();
        r25.setTimeListener(r26);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.egg.MLand.reset():void");
    }

    public void start(boolean startPlaying) {
        String str = "start(startPlaying=%s)";
        Object[] objArr = new Object[1];
        objArr[0] = startPlaying ? "true" : "false";
        m0L(str, objArr);
        if (startPlaying && this.mCountdown <= 0) {
            showSplash();
            this.mSplash.findViewById(2131755155).setEnabled(false);
            TextView playText = (TextView) this.mSplash.findViewById(2131755157);
            this.mSplash.findViewById(2131755156).animate().alpha(0.0f);
            playText.animate().alpha(1.0f);
            this.mCountdown = 3;
            post(new C01252(playText));
        }
        Iterator i$ = this.mPlayers.iterator();
        while (i$.hasNext()) {
            ((Player) i$.next()).setVisibility(4);
        }
        if (!this.mAnimating) {
            this.mAnim.start();
            this.mAnimating = true;
        }
    }

    public void hideSplash() {
        if (this.mSplash != null && this.mSplash.getVisibility() == 0) {
            this.mSplash.setClickable(false);
            this.mSplash.animate().alpha(0.0f).translationZ(0.0f).setDuration(300).withEndAction(new C01263());
        }
    }

    public void showSplash() {
        if (this.mSplash != null && this.mSplash.getVisibility() != 0) {
            this.mSplash.setClickable(true);
            this.mSplash.setAlpha(0.0f);
            this.mSplash.setVisibility(0);
            this.mSplash.animate().alpha(1.0f).setDuration(1000);
            this.mSplash.findViewById(2131755156).setAlpha(1.0f);
            this.mSplash.findViewById(2131755157).setAlpha(0.0f);
            this.mSplash.findViewById(2131755155).setEnabled(true);
            this.mSplash.findViewById(2131755155).requestFocus();
        }
    }

    public void startPlaying() {
        this.mPlaying = true;
        this.f17t = 0.0f;
        this.mLastPipeTime = getGameTime() - ((float) PARAMS.OBSTACLE_PERIOD);
        hideSplash();
        realignPlayers();
        this.mTaps = 0;
        int N = this.mPlayers.size();
        MetricsLogger.histogram(getContext(), "egg_mland_players", N);
        for (int i = 0; i < N; i++) {
            Player p = (Player) this.mPlayers.get(i);
            p.setVisibility(0);
            p.reset();
            p.start();
            p.boost(-1.0f, -1.0f);
            p.unboost();
        }
    }

    public void stop() {
        if (this.mAnimating) {
            this.mAnim.cancel();
            this.mAnim = null;
            this.mAnimating = false;
            this.mPlaying = false;
            this.mTimeOfDay = irand(0, SKIES.length - 1);
            this.mScene = irand(0, 3);
            this.mFrozen = true;
            Iterator i$ = this.mPlayers.iterator();
            while (i$.hasNext()) {
                ((Player) i$.next()).die();
            }
            postDelayed(new C01274(), 250);
        }
    }

    public static final float lerp(float x, float a, float b) {
        return ((b - a) * x) + a;
    }

    public static final float rlerp(float v, float a, float b) {
        return (v - a) / (b - a);
    }

    public static final float clamp(float f) {
        if (f < 0.0f) {
            return 0.0f;
        }
        return f > 1.0f ? 1.0f : f;
    }

    public static final float frand() {
        return (float) Math.random();
    }

    public static final float frand(float a, float b) {
        return lerp(frand(), a, b);
    }

    public static final int irand(int a, int b) {
        return Math.round(frand((float) a, (float) b));
    }

    public static int pick(int[] l) {
        return l[irand(0, l.length - 1)];
    }

    private void step(long t_ms, long dt_ms) {
        this.f17t = ((float) t_ms) / 1000.0f;
        this.dt = ((float) dt_ms) / 1000.0f;
        if (DEBUG) {
            this.f17t *= 0.5f;
            this.dt *= 0.5f;
        }
        int N = getChildCount();
        int i = 0;
        while (i < N) {
            View v = getChildAt(i);
            if (v instanceof GameView) {
                ((GameView) v).step(t_ms, dt_ms, this.f17t, this.dt);
            }
            i++;
        }
        if (this.mPlaying) {
            int livingPlayers = 0;
            i = 0;
            while (i < this.mPlayers.size()) {
                Player p = getPlayer(i);
                if (p.mAlive) {
                    if (p.below(this.mHeight)) {
                        if (DEBUG_IDDQD) {
                            poke(i);
                            unpoke(i);
                        } else {
                            m0L("player %d hit the floor", Integer.valueOf(i));
                            thump(i, 80);
                            p.die();
                        }
                    }
                    int maxPassedStem = 0;
                    int j = this.mObstaclesInPlay.size();
                    while (true) {
                        int j2 = j - 1;
                        if (j <= 0) {
                            break;
                        }
                        Obstacle ob = (Obstacle) this.mObstaclesInPlay.get(j2);
                        if (ob.intersects(p) && !DEBUG_IDDQD) {
                            m0L("player hit an obstacle", new Object[0]);
                            thump(i, 80);
                            p.die();
                        } else if (ob.cleared(p) && (ob instanceof Stem)) {
                            maxPassedStem = Math.max(maxPassedStem, ((Stem) ob).id);
                        }
                        j = j2;
                    }
                    if (maxPassedStem > p.mScore) {
                        p.addScore(1);
                    }
                }
                if (p.mAlive) {
                    livingPlayers++;
                }
                i++;
            }
            if (livingPlayers == 0) {
                stop();
                MetricsLogger.count(getContext(), "egg_mland_taps", this.mTaps);
                this.mTaps = 0;
                int playerCount = this.mPlayers.size();
                for (int pi = 0; pi < playerCount; pi++) {
                    MetricsLogger.histogram(getContext(), "egg_mland_score", ((Player) this.mPlayers.get(pi)).getScore());
                }
            }
        }
        int i2 = i;
        while (true) {
            i = i2 - 1;
            if (i2 <= 0) {
                break;
            }
            v = getChildAt(i);
            if (v instanceof Obstacle) {
                if (v.getTranslationX() + ((float) v.getWidth()) < 0.0f) {
                    removeViewAt(i);
                    this.mObstaclesInPlay.remove(v);
                }
            } else if (v instanceof Scenery) {
                if (v.getTranslationX() + ((float) ((Scenery) v).f12w) < 0.0f) {
                    v.setTranslationX((float) getWidth());
                }
            }
            i2 = i;
        }
        if (this.mPlaying && this.f17t - this.mLastPipeTime > ((float) PARAMS.OBSTACLE_PERIOD)) {
            this.mLastPipeTime = this.f17t;
            this.mCurrentPipeId++;
            int obstacley = ((int) (frand() * ((float) ((this.mHeight - (PARAMS.OBSTACLE_MIN * 2)) - PARAMS.OBSTACLE_GAP)))) + PARAMS.OBSTACLE_MIN;
            int inset = (PARAMS.OBSTACLE_WIDTH - PARAMS.OBSTACLE_STEM_WIDTH) / 2;
            int yinset = PARAMS.OBSTACLE_WIDTH / 2;
            int d1 = irand(0, 250);
            View stem = new Stem(getContext(), (float) (obstacley - yinset), false);
            addView(stem, new LayoutParams(PARAMS.OBSTACLE_STEM_WIDTH, (int) stem.f14h, 51));
            stem.setTranslationX((float) (this.mWidth + inset));
            stem.setTranslationY((-stem.f14h) - ((float) yinset));
            stem.setTranslationZ(PARAMS.OBSTACLE_Z * 0.75f);
            stem.animate().translationY(0.0f).setStartDelay((long) d1).setDuration(250);
            this.mObstaclesInPlay.add(stem);
            stem = new Pop(getContext(), (float) PARAMS.OBSTACLE_WIDTH);
            addView(stem, new LayoutParams(PARAMS.OBSTACLE_WIDTH, PARAMS.OBSTACLE_WIDTH, 51));
            stem.setTranslationX((float) this.mWidth);
            stem.setTranslationY((float) (-PARAMS.OBSTACLE_WIDTH));
            stem.setTranslationZ(PARAMS.OBSTACLE_Z);
            stem.setScaleX(0.25f);
            stem.setScaleY(-0.25f);
            stem.animate().translationY(stem.f14h - ((float) inset)).scaleX(1.0f).scaleY(-1.0f).setStartDelay((long) d1).setDuration(250);
            this.mObstaclesInPlay.add(stem);
            int d2 = irand(0, 250);
            stem = new Stem(getContext(), (float) (((this.mHeight - obstacley) - PARAMS.OBSTACLE_GAP) - yinset), true);
            addView(stem, new LayoutParams(PARAMS.OBSTACLE_STEM_WIDTH, (int) stem.f14h, 51));
            stem.setTranslationX((float) (this.mWidth + inset));
            stem.setTranslationY((float) (this.mHeight + yinset));
            stem.setTranslationZ(PARAMS.OBSTACLE_Z * 0.75f);
            stem.animate().translationY(((float) this.mHeight) - stem.f14h).setStartDelay((long) d2).setDuration(400);
            this.mObstaclesInPlay.add(stem);
            stem = new Pop(getContext(), (float) PARAMS.OBSTACLE_WIDTH);
            addView(stem, new LayoutParams(PARAMS.OBSTACLE_WIDTH, PARAMS.OBSTACLE_WIDTH, 51));
            stem.setTranslationX((float) this.mWidth);
            stem.setTranslationY((float) this.mHeight);
            stem.setTranslationZ(PARAMS.OBSTACLE_Z);
            stem.setScaleX(0.25f);
            stem.setScaleY(0.25f);
            stem.animate().translationY((((float) this.mHeight) - stem.f14h) - ((float) yinset)).scaleX(1.0f).scaleY(1.0f).setStartDelay((long) d2).setDuration(400);
            this.mObstaclesInPlay.add(stem);
        }
        invalidate();
    }

    public boolean onTouchEvent(MotionEvent ev) {
        m0L("touch: %s", ev);
        int actionIndex = ev.getActionIndex();
        float x = ev.getX(actionIndex);
        float y = ev.getY(actionIndex);
        int playerIndex = (int) (((float) getNumPlayers()) * (x / ((float) getWidth())));
        if (this.mFlipped) {
            playerIndex = (getNumPlayers() - 1) - playerIndex;
        }
        switch (ev.getActionMasked()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
            case 5:
                poke(playerIndex, x, y);
                return true;
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 6:
                unpoke(playerIndex);
                return true;
            default:
                return false;
        }
    }

    public boolean onTrackballEvent(MotionEvent ev) {
        m0L("trackball: %s", ev);
        switch (ev.getAction()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                poke(0);
                return true;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                unpoke(0);
                return true;
            default:
                return false;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent ev) {
        m0L("keyDown: %d", Integer.valueOf(keyCode));
        switch (keyCode) {
            case 19:
            case 23:
            case 62:
            case 66:
            case 96:
                poke(getControllerPlayer(ev.getDeviceId()));
                return true;
            default:
                return false;
        }
    }

    public boolean onKeyUp(int keyCode, KeyEvent ev) {
        m0L("keyDown: %d", Integer.valueOf(keyCode));
        switch (keyCode) {
            case 19:
            case 23:
            case 62:
            case 66:
            case 96:
                unpoke(getControllerPlayer(ev.getDeviceId()));
                return true;
            default:
                return false;
        }
    }

    public boolean onGenericMotionEvent(MotionEvent ev) {
        m0L("generic: %s", ev);
        return false;
    }

    private void poke(int playerIndex) {
        poke(playerIndex, -1.0f, -1.0f);
    }

    private void poke(int playerIndex, float x, float y) {
        m0L("poke(%d)", Integer.valueOf(playerIndex));
        if (!this.mFrozen) {
            if (!this.mAnimating) {
                reset();
            }
            if (this.mPlaying) {
                Player p = getPlayer(playerIndex);
                if (p != null) {
                    p.boost(x, y);
                    this.mTaps++;
                    if (DEBUG) {
                        p.dv *= 0.5f;
                        p.animate().setDuration(400);
                        return;
                    }
                    return;
                }
                return;
            }
            start(true);
        }
    }

    private void unpoke(int playerIndex) {
        m0L("unboost(%d)", Integer.valueOf(playerIndex));
        if (!this.mFrozen && this.mAnimating && this.mPlaying) {
            Player p = getPlayer(playerIndex);
            if (p != null) {
                p.unboost();
            }
        }
    }

    public void onDraw(Canvas c) {
        super.onDraw(c);
        Iterator i$ = this.mPlayers.iterator();
        while (i$.hasNext()) {
            Player p = (Player) i$.next();
            if (p.mTouchX > 0.0f) {
                this.mTouchPaint.setColor(-2130706433 & p.color);
                this.mPlayerTracePaint.setColor(-2130706433 & p.color);
                float x1 = p.mTouchX;
                float y1 = p.mTouchY;
                c.drawCircle(x1, y1, 100.0f, this.mTouchPaint);
                float x2 = p.getX() + p.getPivotX();
                float y2 = p.getY() + p.getPivotY();
                float angle = 1.5707964f - ((float) Math.atan2((double) (x2 - x1), (double) (y2 - y1)));
                Canvas canvas = c;
                canvas.drawLine((float) (((double) x1) + (100.0d * Math.cos((double) angle))), (float) (((double) y1) + (100.0d * Math.sin((double) angle))), x2, y2, this.mPlayerTracePaint);
            }
        }
    }
}
