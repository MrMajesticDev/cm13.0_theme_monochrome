package com.android.systemui.usb;

import android.app.Notification;
import android.app.Notification.Action;
import android.app.Notification.BigTextStyle;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.MoveCallback;
import android.os.Bundle;
import android.os.Handler;
import android.os.UserHandle;
import android.os.storage.DiskInfo;
import android.os.storage.StorageEventListener;
import android.os.storage.StorageManager;
import android.os.storage.VolumeInfo;
import android.os.storage.VolumeRecord;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.Log;
import android.util.SparseArray;
import com.android.keyguard.C0065R;
import com.android.systemui.SystemUI;

public class StorageNotification extends SystemUI {
    private final BroadcastReceiver mFinishReceiver;
    private final StorageEventListener mListener;
    private final MoveCallback mMoveCallback;
    private final SparseArray<MoveInfo> mMoves;
    private NotificationManager mNotificationManager;
    private final BroadcastReceiver mSnoozeReceiver;
    private StorageManager mStorageManager;

    /* renamed from: com.android.systemui.usb.StorageNotification.1 */
    class C05301 extends StorageEventListener {
        C05301() {
        }

        public void onVolumeStateChanged(VolumeInfo vol, int oldState, int newState) {
            StorageNotification.this.onVolumeStateChangedInternal(vol);
        }

        public void onVolumeRecordChanged(VolumeRecord rec) {
            VolumeInfo vol = StorageNotification.this.mStorageManager.findVolumeByUuid(rec.getFsUuid());
            if (vol != null && vol.isMountedReadable()) {
                StorageNotification.this.onVolumeStateChangedInternal(vol);
            }
        }

        public void onVolumeForgotten(String fsUuid) {
            StorageNotification.this.mNotificationManager.cancelAsUser(fsUuid, 1397772886, UserHandle.ALL);
        }

        public void onDiskScanned(DiskInfo disk, int volumeCount) {
            StorageNotification.this.onDiskScannedInternal(disk, volumeCount);
        }
    }

    /* renamed from: com.android.systemui.usb.StorageNotification.2 */
    class C05312 extends BroadcastReceiver {
        C05312() {
        }

        public void onReceive(Context context, Intent intent) {
            StorageNotification.this.mStorageManager.setVolumeSnoozed(intent.getStringExtra("android.os.storage.extra.FS_UUID"), true);
        }
    }

    /* renamed from: com.android.systemui.usb.StorageNotification.3 */
    class C05323 extends BroadcastReceiver {
        C05323() {
        }

        public void onReceive(Context context, Intent intent) {
            StorageNotification.this.mNotificationManager.cancelAsUser(null, 1397575510, UserHandle.ALL);
        }
    }

    /* renamed from: com.android.systemui.usb.StorageNotification.4 */
    class C05334 extends MoveCallback {
        C05334() {
        }

        public void onCreated(int moveId, Bundle extras) {
            MoveInfo move = new MoveInfo();
            move.moveId = moveId;
            move.extras = extras;
            if (extras != null) {
                move.packageName = extras.getString("android.intent.extra.PACKAGE_NAME");
                move.label = extras.getString("android.intent.extra.TITLE");
                move.volumeUuid = extras.getString("android.os.storage.extra.FS_UUID");
            }
            StorageNotification.this.mMoves.put(moveId, move);
        }

        public void onStatusChanged(int moveId, int status, long estMillis) {
            MoveInfo move = (MoveInfo) StorageNotification.this.mMoves.get(moveId);
            if (move == null) {
                Log.w("StorageNotification", "Ignoring unknown move " + moveId);
            } else if (PackageManager.isMoveStatusFinished(status)) {
                StorageNotification.this.onMoveFinished(move, status);
            } else {
                StorageNotification.this.onMoveProgress(move, status, estMillis);
            }
        }
    }

    private static class MoveInfo {
        public Bundle extras;
        public String label;
        public int moveId;
        public String packageName;
        public String volumeUuid;

        private MoveInfo() {
        }
    }

    public StorageNotification() {
        this.mMoves = new SparseArray();
        this.mListener = new C05301();
        this.mSnoozeReceiver = new C05312();
        this.mFinishReceiver = new C05323();
        this.mMoveCallback = new C05334();
    }

    public void start() {
        this.mNotificationManager = (NotificationManager) this.mContext.getSystemService(NotificationManager.class);
        this.mStorageManager = (StorageManager) this.mContext.getSystemService(StorageManager.class);
        this.mStorageManager.registerListener(this.mListener);
        this.mContext.registerReceiver(this.mSnoozeReceiver, new IntentFilter("com.android.systemui.action.SNOOZE_VOLUME"), "android.permission.MOUNT_UNMOUNT_FILESYSTEMS", null);
        this.mContext.registerReceiver(this.mFinishReceiver, new IntentFilter("com.android.systemui.action.FINISH_WIZARD"), "android.permission.MOUNT_UNMOUNT_FILESYSTEMS", null);
        for (DiskInfo disk : this.mStorageManager.getDisks()) {
            onDiskScannedInternal(disk, disk.volumeCount);
        }
        for (VolumeInfo vol : this.mStorageManager.getVolumes()) {
            onVolumeStateChangedInternal(vol);
        }
        this.mContext.getPackageManager().registerMoveCallback(this.mMoveCallback, new Handler());
        updateMissingPrivateVolumes();
    }

    private void updateMissingPrivateVolumes() {
        for (VolumeRecord rec : this.mStorageManager.getVolumeRecords()) {
            if (rec.getType() == 1) {
                String fsUuid = rec.getFsUuid();
                VolumeInfo info = this.mStorageManager.findVolumeByUuid(fsUuid);
                if ((info == null || !info.isMountedWritable()) && !rec.isSnoozed()) {
                    CharSequence title = this.mContext.getString(17040413, new Object[]{rec.getNickname()});
                    CharSequence text = this.mContext.getString(17040414);
                    this.mNotificationManager.notifyAsUser(fsUuid, 1397772886, new Builder(this.mContext).setSmallIcon(17302552).setColor(this.mContext.getColor(17170521)).setContentTitle(title).setContentText(text).setContentIntent(buildForgetPendingIntent(rec)).setStyle(new BigTextStyle().bigText(text)).setVisibility(1).setLocalOnly(true).setCategory("sys").setDeleteIntent(buildSnoozeIntent(fsUuid)).build(), UserHandle.ALL);
                } else {
                    this.mNotificationManager.cancelAsUser(fsUuid, 1397772886, UserHandle.ALL);
                }
            }
        }
    }

    private void onDiskScannedInternal(DiskInfo disk, int volumeCount) {
        if (volumeCount != 0 || disk.size <= 0) {
            this.mNotificationManager.cancelAsUser(disk.getId(), 1396986699, UserHandle.ALL);
            return;
        }
        CharSequence title = this.mContext.getString(17040402, new Object[]{disk.getDescription()});
        CharSequence text = this.mContext.getString(17040403, new Object[]{disk.getDescription()});
        this.mNotificationManager.notifyAsUser(disk.getId(), 1396986699, new Builder(this.mContext).setSmallIcon(getSmallIcon(disk, 6)).setColor(this.mContext.getColor(17170521)).setContentTitle(title).setContentText(text).setContentIntent(buildInitPendingIntent(disk)).setStyle(new BigTextStyle().bigText(text)).setVisibility(1).setLocalOnly(true).setCategory("err").build(), UserHandle.ALL);
    }

    private void onVolumeStateChangedInternal(VolumeInfo vol) {
        switch (vol.getType()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                onPublicVolumeStateChangedInternal(vol);
            case C0065R.styleable.NumPadKey_textView /*1*/:
                onPrivateVolumeStateChangedInternal(vol);
            default:
        }
    }

    private void onPrivateVolumeStateChangedInternal(VolumeInfo vol) {
        Log.d("StorageNotification", "Notifying about private volume: " + vol.toString());
        updateMissingPrivateVolumes();
    }

    private void onPublicVolumeStateChangedInternal(VolumeInfo vol) {
        Notification notif;
        Log.d("StorageNotification", "Notifying about public volume: " + vol.toString());
        switch (vol.getState()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                notif = onVolumeUnmounted(vol);
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                notif = onVolumeChecking(vol);
                break;
            case 2:
            case 3:
                notif = onVolumeMounted(vol);
                break;
            case 4:
                notif = onVolumeFormatting(vol);
                break;
            case 5:
                notif = onVolumeEjecting(vol);
                break;
            case 6:
                notif = onVolumeUnmountable(vol);
                break;
            case 7:
                notif = onVolumeRemoved(vol);
                break;
            case 8:
                notif = onVolumeBadRemoval(vol);
                break;
            default:
                notif = null;
                break;
        }
        if (notif != null) {
            this.mNotificationManager.notifyAsUser(vol.getId(), 1397773634, notif, UserHandle.ALL);
        } else {
            this.mNotificationManager.cancelAsUser(vol.getId(), 1397773634, UserHandle.ALL);
        }
    }

    private Notification onVolumeUnmounted(VolumeInfo vol) {
        return null;
    }

    private Notification onVolumeChecking(VolumeInfo vol) {
        DiskInfo disk = vol.getDisk();
        return buildNotificationBuilder(vol, this.mContext.getString(17040396, new Object[]{disk.getDescription()}), this.mContext.getString(17040397, new Object[]{disk.getDescription()})).setCategory("progress").setPriority(-1).setOngoing(true).build();
    }

    private Notification onVolumeMounted(VolumeInfo vol) {
        VolumeRecord rec = this.mStorageManager.findRecordByUuid(vol.getFsUuid());
        DiskInfo disk = vol.getDisk();
        if (rec.isSnoozed() && disk.isAdoptable()) {
            return null;
        }
        if (!disk.isAdoptable() || rec.isInited()) {
            CharSequence title = disk.getDescription();
            CharSequence text = this.mContext.getString(17040399, new Object[]{disk.getDescription()});
            PendingIntent browseIntent = buildBrowsePendingIntent(vol);
            Builder builder = buildNotificationBuilder(vol, title, text).addAction(new Action(17302346, this.mContext.getString(17040412), browseIntent)).addAction(new Action(17302334, this.mContext.getString(17040411), buildUnmountPendingIntent(vol))).setContentIntent(browseIntent).setCategory("sys").setPriority(-1);
            if (disk.isAdoptable()) {
                builder.setDeleteIntent(buildSnoozeIntent(vol.getFsUuid()));
            }
            return builder.build();
        }
        title = disk.getDescription();
        text = this.mContext.getString(17040398, new Object[]{disk.getDescription()});
        PendingIntent initIntent = buildInitPendingIntent(vol);
        return buildNotificationBuilder(vol, title, text).addAction(new Action(17302558, this.mContext.getString(17040410), initIntent)).addAction(new Action(17302334, this.mContext.getString(17040411), buildUnmountPendingIntent(vol))).setContentIntent(initIntent).setDeleteIntent(buildSnoozeIntent(vol.getFsUuid())).setCategory("sys").build();
    }

    private Notification onVolumeFormatting(VolumeInfo vol) {
        return null;
    }

    private Notification onVolumeEjecting(VolumeInfo vol) {
        DiskInfo disk = vol.getDisk();
        return buildNotificationBuilder(vol, this.mContext.getString(17040408, new Object[]{disk.getDescription()}), this.mContext.getString(17040409, new Object[]{disk.getDescription()})).setCategory("progress").setPriority(-1).setOngoing(true).build();
    }

    private Notification onVolumeUnmountable(VolumeInfo vol) {
        DiskInfo disk = vol.getDisk();
        return buildNotificationBuilder(vol, this.mContext.getString(17040400, new Object[]{disk.getDescription()}), this.mContext.getString(17040401, new Object[]{disk.getDescription()})).setContentIntent(buildInitPendingIntent(vol)).setCategory("err").build();
    }

    private Notification onVolumeRemoved(VolumeInfo vol) {
        if (!vol.isPrimary()) {
            return null;
        }
        DiskInfo disk = vol.getDisk();
        return buildNotificationBuilder(vol, this.mContext.getString(17040406, new Object[]{disk.getDescription()}), this.mContext.getString(17040407, new Object[]{disk.getDescription()})).setCategory("err").build();
    }

    private Notification onVolumeBadRemoval(VolumeInfo vol) {
        if (!vol.isPrimary()) {
            return null;
        }
        DiskInfo disk = vol.getDisk();
        return buildNotificationBuilder(vol, this.mContext.getString(17040404, new Object[]{disk.getDescription()}), this.mContext.getString(17040405, new Object[]{disk.getDescription()})).setCategory("err").build();
    }

    private void onMoveProgress(MoveInfo move, int status, long estMillis) {
        CharSequence title;
        CharSequence text;
        PendingIntent intent;
        if (TextUtils.isEmpty(move.label)) {
            title = this.mContext.getString(17040416);
        } else {
            title = this.mContext.getString(17040415, new Object[]{move.label});
        }
        if (estMillis < 0) {
            text = null;
        } else {
            text = DateUtils.formatDuration(estMillis);
        }
        if (move.packageName != null) {
            intent = buildWizardMovePendingIntent(move);
        } else {
            intent = buildWizardMigratePendingIntent(move);
        }
        this.mNotificationManager.notifyAsUser(move.packageName, 1397575510, new Builder(this.mContext).setSmallIcon(17302552).setColor(this.mContext.getColor(17170521)).setContentTitle(title).setContentText(text).setContentIntent(intent).setStyle(new BigTextStyle().bigText(text)).setVisibility(1).setLocalOnly(true).setCategory("progress").setPriority(-1).setProgress(100, status, false).setOngoing(true).build(), UserHandle.ALL);
    }

    private void onMoveFinished(MoveInfo move, int status) {
        if (move.packageName != null) {
            this.mNotificationManager.cancelAsUser(move.packageName, 1397575510, UserHandle.ALL);
            return;
        }
        CharSequence title;
        CharSequence text;
        PendingIntent intent;
        VolumeInfo privateVol = this.mContext.getPackageManager().getPrimaryStorageCurrentVolume();
        String descrip = this.mStorageManager.getBestVolumeDescription(privateVol);
        if (status == -100) {
            title = this.mContext.getString(17040417);
            text = this.mContext.getString(17040418, new Object[]{descrip});
        } else {
            title = this.mContext.getString(17040419);
            text = this.mContext.getString(17040420);
        }
        if (privateVol != null && privateVol.getDisk() != null) {
            intent = buildWizardReadyPendingIntent(privateVol.getDisk());
        } else if (privateVol != null) {
            intent = buildVolumeSettingsPendingIntent(privateVol);
        } else {
            intent = null;
        }
        this.mNotificationManager.notifyAsUser(move.packageName, 1397575510, new Builder(this.mContext).setSmallIcon(17302552).setColor(this.mContext.getColor(17170521)).setContentTitle(title).setContentText(text).setContentIntent(intent).setStyle(new BigTextStyle().bigText(text)).setVisibility(1).setLocalOnly(true).setCategory("sys").setPriority(-1).setAutoCancel(true).build(), UserHandle.ALL);
    }

    private int getSmallIcon(DiskInfo disk, int state) {
        if (disk.isSd()) {
            switch (state) {
            }
            return 17302552;
        } else if (disk.isUsb()) {
            return 17302574;
        } else {
            return 17302552;
        }
    }

    private Builder buildNotificationBuilder(VolumeInfo vol, CharSequence title, CharSequence text) {
        return new Builder(this.mContext).setSmallIcon(getSmallIcon(vol.getDisk(), vol.getState())).setColor(this.mContext.getColor(17170521)).setContentTitle(title).setContentText(text).setStyle(new BigTextStyle().bigText(text)).setVisibility(1).setLocalOnly(true);
    }

    private PendingIntent buildInitPendingIntent(DiskInfo disk) {
        Intent intent = new Intent();
        intent.setClassName("com.android.settings", "com.android.settings.deviceinfo.StorageWizardInit");
        intent.putExtra("android.os.storage.extra.DISK_ID", disk.getId());
        return PendingIntent.getActivityAsUser(this.mContext, disk.getId().hashCode(), intent, 268435456, null, UserHandle.CURRENT);
    }

    private PendingIntent buildInitPendingIntent(VolumeInfo vol) {
        Intent intent = new Intent();
        intent.setClassName("com.android.settings", "com.android.settings.deviceinfo.StorageWizardInit");
        intent.putExtra("android.os.storage.extra.VOLUME_ID", vol.getId());
        return PendingIntent.getActivityAsUser(this.mContext, vol.getId().hashCode(), intent, 268435456, null, UserHandle.CURRENT);
    }

    private PendingIntent buildUnmountPendingIntent(VolumeInfo vol) {
        Intent intent = new Intent();
        intent.setClassName("com.android.settings", "com.android.settings.deviceinfo.StorageUnmountReceiver");
        intent.putExtra("android.os.storage.extra.VOLUME_ID", vol.getId());
        return PendingIntent.getBroadcastAsUser(this.mContext, vol.getId().hashCode(), intent, 268435456, UserHandle.CURRENT);
    }

    private PendingIntent buildBrowsePendingIntent(VolumeInfo vol) {
        Intent intent = vol.buildBrowseIntent();
        return PendingIntent.getActivityAsUser(this.mContext, vol.getId().hashCode(), intent, 268435456, null, UserHandle.CURRENT);
    }

    private PendingIntent buildVolumeSettingsPendingIntent(VolumeInfo vol) {
        Intent intent = new Intent();
        switch (vol.getType()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                intent.setClassName("com.android.settings", "com.android.settings.Settings$PublicVolumeSettingsActivity");
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                intent.setClassName("com.android.settings", "com.android.settings.Settings$PrivateVolumeSettingsActivity");
                break;
            default:
                return null;
        }
        intent.putExtra("android.os.storage.extra.VOLUME_ID", vol.getId());
        return PendingIntent.getActivityAsUser(this.mContext, vol.getId().hashCode(), intent, 268435456, null, UserHandle.CURRENT);
    }

    private PendingIntent buildSnoozeIntent(String fsUuid) {
        Intent intent = new Intent("com.android.systemui.action.SNOOZE_VOLUME");
        intent.putExtra("android.os.storage.extra.FS_UUID", fsUuid);
        return PendingIntent.getBroadcastAsUser(this.mContext, fsUuid.hashCode(), intent, 268435456, UserHandle.CURRENT);
    }

    private PendingIntent buildForgetPendingIntent(VolumeRecord rec) {
        Intent intent = new Intent();
        intent.setClassName("com.android.settings", "com.android.settings.Settings$PrivateVolumeForgetActivity");
        intent.putExtra("android.os.storage.extra.FS_UUID", rec.getFsUuid());
        return PendingIntent.getActivityAsUser(this.mContext, rec.getFsUuid().hashCode(), intent, 268435456, null, UserHandle.CURRENT);
    }

    private PendingIntent buildWizardMigratePendingIntent(MoveInfo move) {
        Intent intent = new Intent();
        intent.setClassName("com.android.settings", "com.android.settings.deviceinfo.StorageWizardMigrateProgress");
        intent.putExtra("android.content.pm.extra.MOVE_ID", move.moveId);
        intent.putExtra("android.os.storage.extra.VOLUME_ID", this.mStorageManager.findVolumeByQualifiedUuid(move.volumeUuid).getId());
        return PendingIntent.getActivityAsUser(this.mContext, move.moveId, intent, 268435456, null, UserHandle.CURRENT);
    }

    private PendingIntent buildWizardMovePendingIntent(MoveInfo move) {
        Intent intent = new Intent();
        intent.setClassName("com.android.settings", "com.android.settings.deviceinfo.StorageWizardMoveProgress");
        intent.putExtra("android.content.pm.extra.MOVE_ID", move.moveId);
        return PendingIntent.getActivityAsUser(this.mContext, move.moveId, intent, 268435456, null, UserHandle.CURRENT);
    }

    private PendingIntent buildWizardReadyPendingIntent(DiskInfo disk) {
        Intent intent = new Intent();
        intent.setClassName("com.android.settings", "com.android.settings.deviceinfo.StorageWizardReady");
        intent.putExtra("android.os.storage.extra.DISK_ID", disk.getId());
        return PendingIntent.getActivityAsUser(this.mContext, disk.getId().hashCode(), intent, 268435456, null, UserHandle.CURRENT);
    }
}
