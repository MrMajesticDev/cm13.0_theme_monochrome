package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.systemui.FontSizeUtils;
import com.android.systemui.qs.DataUsageGraph;
import com.android.systemui.statusbar.policy.NetworkController.MobileDataController.DataUsageInfo;
import java.text.DecimalFormat;

public class DataUsageDetailView extends LinearLayout {
    private final DecimalFormat FORMAT;

    public DataUsageDetailView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.FORMAT = new DecimalFormat("#.##");
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        FontSizeUtils.updateFontSize(this, 16908310, 2131296333);
        FontSizeUtils.updateFontSize(this, 2131755069, 2131296334);
        FontSizeUtils.updateFontSize(this, 2131755071, 2131296333);
        FontSizeUtils.updateFontSize(this, 2131755072, 2131296333);
        FontSizeUtils.updateFontSize(this, 2131755073, 2131296333);
        FontSizeUtils.updateFontSize(this, 2131755074, 2131296333);
    }

    public void bind(DataUsageInfo info) {
        int titleId;
        long bytes;
        String top;
        Resources res = this.mContext.getResources();
        int usageColor = 2131427358;
        String bottom = null;
        Object[] objArr;
        if (info.usageLevel < info.warningLevel || info.limitLevel <= 0) {
            titleId = 2131362214;
            bytes = info.usageLevel;
            objArr = new Object[1];
            objArr[0] = formatBytes(info.warningLevel);
            top = res.getString(2131362219, objArr);
        } else if (info.usageLevel <= info.limitLevel) {
            titleId = 2131362215;
            bytes = info.limitLevel - info.usageLevel;
            objArr = new Object[1];
            objArr[0] = formatBytes(info.usageLevel);
            top = res.getString(2131362217, objArr);
            objArr = new Object[1];
            objArr[0] = formatBytes(info.limitLevel);
            bottom = res.getString(2131362218, objArr);
        } else {
            titleId = 2131362216;
            bytes = info.usageLevel - info.limitLevel;
            objArr = new Object[1];
            objArr[0] = formatBytes(info.usageLevel);
            top = res.getString(2131362217, objArr);
            objArr = new Object[1];
            objArr[0] = formatBytes(info.limitLevel);
            bottom = res.getString(2131362218, objArr);
            usageColor = 2131427359;
        }
        ((TextView) findViewById(16908310)).setText(titleId);
        TextView usage = (TextView) findViewById(2131755069);
        usage.setText(formatBytes(bytes));
        usage.setTextColor(this.mContext.getColor(usageColor));
        ((DataUsageGraph) findViewById(2131755070)).setLevels(info.limitLevel, info.warningLevel, info.usageLevel);
        ((TextView) findViewById(2131755071)).setText(info.carrier);
        ((TextView) findViewById(2131755073)).setText(info.period);
        TextView infoTop = (TextView) findViewById(2131755072);
        infoTop.setVisibility(top != null ? 0 : 8);
        infoTop.setText(top);
        TextView infoBottom = (TextView) findViewById(2131755074);
        infoBottom.setVisibility(bottom != null ? 0 : 8);
        infoBottom.setText(bottom);
    }

    private String formatBytes(long bytes) {
        double val;
        String suffix;
        int i;
        long b = Math.abs(bytes);
        if (((double) b) > 1.048576E8d) {
            val = ((double) b) / 1.073741824E9d;
            suffix = "GB";
        } else if (((double) b) > 102400.0d) {
            val = ((double) b) / 1048576.0d;
            suffix = "MB";
        } else {
            val = ((double) b) / 1024.0d;
            suffix = "KB";
        }
        StringBuilder stringBuilder = new StringBuilder();
        DecimalFormat decimalFormat = this.FORMAT;
        if (bytes < 0) {
            i = -1;
        } else {
            i = 1;
        }
        return stringBuilder.append(decimalFormat.format(((double) i) * val)).append(" ").append(suffix).toString();
    }
}
