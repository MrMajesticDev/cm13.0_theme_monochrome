package com.android.systemui.qs.tiles;

import android.app.ActivityManager;
import android.content.Context;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.statusbar.policy.FlashlightController;
import com.android.systemui.statusbar.policy.FlashlightController.FlashlightListener;

public class FlashlightTile extends QSTile<BooleanState> implements FlashlightListener {
    private final AnimationIcon mDisable;
    private final AnimationIcon mEnable;
    private final FlashlightController mFlashlightController;

    public FlashlightTile(Host host) {
        super(host, "flashlight");
        this.mEnable = new AnimationIcon(2130837705);
        this.mDisable = new AnimationIcon(2130837703);
        this.mFlashlightController = host.getFlashlightController();
        this.mFlashlightController.addListener(this);
    }

    protected void handleDestroy() {
        super.handleDestroy();
        this.mFlashlightController.removeListener(this);
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void setListening(boolean listening) {
    }

    protected void handleUserSwitch(int newUserId) {
    }

    protected void handleToggleClick() {
        if (!ActivityManager.isUserAMonkey()) {
            boolean z;
            boolean newState;
            Context context = this.mContext;
            int metricsCategory = getMetricsCategory();
            if (((BooleanState) this.mState).value) {
                z = false;
            } else {
                z = true;
            }
            MetricsLogger.action(context, metricsCategory, z);
            if (((BooleanState) this.mState).value) {
                newState = false;
            } else {
                newState = true;
            }
            refreshState(newState ? UserBoolean.USER_TRUE : UserBoolean.USER_FALSE);
            this.mFlashlightController.setFlashlight(newState);
        }
    }

    protected void handleDetailClick() {
        handleToggleClick();
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        state.visible = this.mFlashlightController.isAvailable();
        state.label = this.mHost.getContext().getString(2131362212);
        if (arg instanceof UserBoolean) {
            boolean value = ((UserBoolean) arg).value;
            if (value != state.value) {
                state.value = value;
            } else {
                return;
            }
        }
        state.value = this.mFlashlightController.isEnabled();
        AnimationIcon icon = state.value ? this.mEnable : this.mDisable;
        boolean z = (arg instanceof UserBoolean) && ((UserBoolean) arg).userInitiated;
        icon.setAllowAnimation(z);
        state.icon = icon;
        state.contentDescription = this.mContext.getString(state.value ? 2131362135 : 2131362134);
    }

    public int getMetricsCategory() {
        return 119;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131362137);
        }
        return this.mContext.getString(2131362136);
    }

    public void onFlashlightChanged(boolean enabled) {
        refreshState(enabled ? UserBoolean.BACKGROUND_TRUE : UserBoolean.BACKGROUND_FALSE);
    }

    public void onFlashlightError() {
        refreshState(UserBoolean.BACKGROUND_FALSE);
    }

    public void onFlashlightAvailabilityChanged(boolean available) {
        refreshState();
    }
}
