package com.android.systemui.statusbar.phone;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.ActivityManager;
import android.app.AlarmManager.AlarmClockInfo;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.graphics.Outline;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Handler;
import android.provider.CalendarContract;
import android.provider.Settings.System;
import android.util.AttributeSet;
import android.util.MathUtils;
import android.view.DragEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewOutlineProvider;
import android.view.ViewPropertyAnimator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.android.keyguard.C0065R;
import com.android.keyguard.KeyguardStatusView;
import com.android.systemui.BatteryLevelTextView;
import com.android.systemui.BatteryMeterView;
import com.android.systemui.FontSizeUtils;
import com.android.systemui.qs.QSPanel;
import com.android.systemui.qs.QSPanel.Callback;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.statusbar.policy.BatteryController;
import com.android.systemui.statusbar.policy.NetworkControllerImpl.EmergencyListener;
import com.android.systemui.statusbar.policy.NextAlarmController;
import com.android.systemui.statusbar.policy.NextAlarmController.NextAlarmChangeCallback;
import com.android.systemui.statusbar.policy.UserInfoController;
import com.android.systemui.statusbar.policy.UserInfoController.OnUserInfoChangedListener;
import com.android.systemui.tuner.TunerService;

public class StatusBarHeaderView extends RelativeLayout implements OnClickListener, EmergencyListener, NextAlarmChangeCallback {
    private ActivityStarter mActivityStarter;
    private boolean mAlarmShowing;
    private TextView mAlarmStatus;
    private TextView mAmPm;
    private float mAvatarCollapsedScaleFactor;
    private BatteryController mBatteryController;
    private BatteryLevelTextView mBatteryLevel;
    private BatteryMeterView mBatteryMeterView;
    private boolean mCaptureValues;
    private final Rect mClipBounds;
    private View mClock;
    private float mClockCollapsedScaleFactor;
    private int mClockCollapsedSize;
    private int mClockExpandedSize;
    private int mClockMarginBottomCollapsed;
    private int mClockMarginBottomExpanded;
    private int mCollapsedHeight;
    private final LayoutValues mCollapsedValues;
    private float mCurrentT;
    private final LayoutValues mCurrentValues;
    private TextView mDateCollapsed;
    private TextView mDateExpanded;
    private View mDateGroup;
    private boolean mDetailTransitioning;
    private TextView mEmergencyCallsOnly;
    private boolean mExpanded;
    private int mExpandedHeight;
    private final LayoutValues mExpandedValues;
    private boolean mListening;
    private ImageView mMultiUserAvatar;
    private int mMultiUserCollapsedMargin;
    private int mMultiUserExpandedMargin;
    private MultiUserSwitch mMultiUserSwitch;
    private int mMultiUserSwitchWidthCollapsed;
    private int mMultiUserSwitchWidthExpanded;
    private AlarmClockInfo mNextAlarm;
    private NextAlarmController mNextAlarmController;
    private QSPanel mQSPanel;
    private boolean mQsAbleToShowHidden;
    private QsAddButton mQsAddButton;
    private ImageView mQsDeleteHeader;
    private View mQsDetailHeader;
    private ImageView mQsDetailHeaderProgress;
    private Switch mQsDetailHeaderSwitch;
    private TextView mQsDetailHeaderTitle;
    private boolean mQsInReorderMode;
    private final Callback mQsPanelCallback;
    private boolean mQsShowingHidden;
    private SettingsButton mSettingsButton;
    private View mSettingsContainer;
    private SettingsObserver mSettingsObserver;
    private boolean mShowBatteryTextExpanded;
    private boolean mShowEmergencyCallsOnly;
    private boolean mShowingDetail;
    private View mSignalCluster;
    private boolean mSignalClusterDetached;
    private LinearLayout mSystemIcons;
    private ViewGroup mSystemIconsContainer;
    private View mSystemIconsSuperContainer;
    private TextView mTime;
    private OnUserInfoChangedListener mUserInfoChangedListener;
    private UserInfoController mUserInfoController;

    /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.1 */
    class C04291 implements OnLayoutChangeListener {
        C04291() {
        }

        public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
            boolean rtl = true;
            if (right - left != oldRight - oldLeft) {
                StatusBarHeaderView.this.setClipping((float) StatusBarHeaderView.this.getHeight());
            }
            if (StatusBarHeaderView.this.getLayoutDirection() != 1) {
                rtl = false;
            }
            StatusBarHeaderView.this.mTime.setPivotX(rtl ? (float) StatusBarHeaderView.this.mTime.getWidth() : 0.0f);
            StatusBarHeaderView.this.mTime.setPivotY((float) StatusBarHeaderView.this.mTime.getBaseline());
            StatusBarHeaderView.this.updateAmPmTranslation();
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.2 */
    class C04302 extends ViewOutlineProvider {
        C04302() {
        }

        public void getOutline(View view, Outline outline) {
            outline.setRect(StatusBarHeaderView.this.mClipBounds);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.3 */
    class C04323 implements OnDragListener {

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.3.1 */
        class C04311 implements AnimatorUpdateListener {
            final /* synthetic */ Drawable val$draw;

            C04311(Drawable drawable) {
                this.val$draw = drawable;
            }

            public void onAnimationUpdate(ValueAnimator animation) {
                this.val$draw.setAlpha(((Integer) animation.getAnimatedValue()).intValue());
            }
        }

        C04323() {
        }

        public boolean onDrag(View v, DragEvent event) {
            int i = 77;
            if (!StatusBarHeaderView.this.mQsInReorderMode && event.getAction() != 1) {
                return false;
            }
            switch (event.getAction()) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                case 2:
                case 4:
                    return true;
                case 3:
                    if (StatusBarHeaderView.this.mQSPanel == null) {
                        return true;
                    }
                    StatusBarHeaderView.this.mQSPanel.hideTile(event.getLocalState());
                    return true;
                case 5:
                case 6:
                    boolean dragEnter;
                    int i2;
                    if (event.getAction() == 5) {
                        dragEnter = true;
                    } else {
                        dragEnter = false;
                    }
                    int[] iArr = new int[2];
                    if (dragEnter) {
                        i2 = 255;
                    } else {
                        i2 = 77;
                    }
                    iArr[0] = i2;
                    if (!dragEnter) {
                        i = 255;
                    }
                    iArr[1] = i;
                    ValueAnimator anim = ValueAnimator.ofInt(iArr);
                    anim.setDuration(200);
                    anim.addUpdateListener(new C04311(StatusBarHeaderView.this.mQsDeleteHeader.getDrawable()));
                    anim.start();
                    return true;
                default:
                    return false;
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.4 */
    class C04334 implements OnUserInfoChangedListener {
        C04334() {
        }

        public void onUserInfoChanged(String name, Drawable picture) {
            StatusBarHeaderView.this.mMultiUserAvatar.setImageDrawable(picture);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.5 */
    class C04345 implements Runnable {
        C04345() {
        }

        public void run() {
            StatusBarHeaderView.this.startSettingsActivity();
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6 */
    class C04436 implements Callback {
        private boolean mScanState;

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.1 */
        class C04351 implements Runnable {
            final /* synthetic */ boolean val$state;

            C04351(boolean z) {
                this.val$state = z;
            }

            public void run() {
                C04436.this.handleToggleStateChanged(this.val$state);
            }
        }

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.2 */
        class C04362 implements Runnable {
            final /* synthetic */ DetailAdapter val$detail;

            C04362(DetailAdapter detailAdapter) {
                this.val$detail = detailAdapter;
            }

            public void run() {
                C04436.this.handleShowingDetail(this.val$detail);
            }
        }

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.3 */
        class C04373 implements Runnable {
            final /* synthetic */ boolean val$isAbleToShow;

            C04373(boolean z) {
                this.val$isAbleToShow = z;
            }

            public void run() {
                C04436.this.handleQsAbleToShowHidden(this.val$isAbleToShow);
            }
        }

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.4 */
        class C04384 implements Runnable {
            final /* synthetic */ boolean val$isShowingHidden;

            C04384(boolean z) {
                this.val$isShowingHidden = z;
            }

            public void run() {
                C04436.this.handleQsShowingHidden(this.val$isShowingHidden);
            }
        }

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.5 */
        class C04395 implements Runnable {
            final /* synthetic */ boolean val$isInReorderMode;

            C04395(boolean z) {
                this.val$isInReorderMode = z;
            }

            public void run() {
                C04436.this.handleQsReorderMode(this.val$isInReorderMode);
            }
        }

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.6 */
        class C04406 implements Runnable {
            final /* synthetic */ boolean val$state;

            C04406(boolean z) {
                this.val$state = z;
            }

            public void run() {
                C04436.this.handleScanStateChanged(this.val$state);
            }
        }

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.7 */
        class C04417 implements OnClickListener {
            final /* synthetic */ DetailAdapter val$detail;

            C04417(DetailAdapter detailAdapter) {
                this.val$detail = detailAdapter;
            }

            public void onClick(View v) {
                boolean checked = !StatusBarHeaderView.this.mQsDetailHeaderSwitch.isChecked();
                StatusBarHeaderView.this.mQsDetailHeaderSwitch.setChecked(checked);
                this.val$detail.setToggleState(checked);
            }
        }

        /* renamed from: com.android.systemui.statusbar.phone.StatusBarHeaderView.6.8 */
        class C04428 implements Runnable {
            final /* synthetic */ boolean val$in;
            final /* synthetic */ View val$v;

            C04428(boolean z, View view) {
                this.val$in = z;
                this.val$v = view;
            }

            public void run() {
                if (!this.val$in) {
                    this.val$v.setVisibility(4);
                }
                StatusBarHeaderView.this.mDetailTransitioning = false;
            }
        }

        C04436() {
        }

        public void onToggleStateChanged(boolean state) {
            StatusBarHeaderView.this.post(new C04351(state));
        }

        public void onShowingDetail(DetailAdapter detail) {
            StatusBarHeaderView.this.mDetailTransitioning = true;
            StatusBarHeaderView.this.post(new C04362(detail));
        }

        public void onAbleToShowHidden(boolean isAbleToShow) {
            StatusBarHeaderView.this.post(new C04373(isAbleToShow));
        }

        public void onShowingHidden(boolean isShowingHidden) {
            StatusBarHeaderView.this.post(new C04384(isShowingHidden));
        }

        public void onReorderMode(boolean isInReorderMode) {
            StatusBarHeaderView.this.post(new C04395(isInReorderMode));
        }

        public void onScanStateChanged(boolean state) {
            StatusBarHeaderView.this.post(new C04406(state));
        }

        private void handleToggleStateChanged(boolean state) {
            StatusBarHeaderView.this.mQsDetailHeaderSwitch.setChecked(state);
        }

        private void handleScanStateChanged(boolean state) {
            if (this.mScanState != state) {
                this.mScanState = state;
                Animatable anim = (Animatable) StatusBarHeaderView.this.mQsDetailHeaderProgress.getDrawable();
                if (state) {
                    StatusBarHeaderView.this.mQsDetailHeaderProgress.animate().alpha(1.0f);
                    anim.start();
                    return;
                }
                StatusBarHeaderView.this.mQsDetailHeaderProgress.animate().alpha(0.0f);
                anim.stop();
            }
        }

        private void handleShowingDetail(DetailAdapter detail) {
            boolean showingDetail;
            boolean z;
            if (detail != null) {
                showingDetail = true;
            } else {
                showingDetail = false;
            }
            View access$1900 = StatusBarHeaderView.this.mClock;
            if (showingDetail || StatusBarHeaderView.this.mQsInReorderMode) {
                z = false;
            } else {
                z = true;
            }
            transition(access$1900, z);
            access$1900 = StatusBarHeaderView.this.mDateGroup;
            if (showingDetail || StatusBarHeaderView.this.mQsInReorderMode) {
                z = false;
            } else {
                z = true;
            }
            transition(access$1900, z);
            if (StatusBarHeaderView.this.mAlarmShowing) {
                access$1900 = StatusBarHeaderView.this.mAlarmStatus;
                if (showingDetail || StatusBarHeaderView.this.mQsInReorderMode) {
                    z = false;
                } else {
                    z = true;
                }
                transition(access$1900, z);
            }
            transition(StatusBarHeaderView.this.mQsDetailHeader, showingDetail);
            StatusBarHeaderView.this.mShowingDetail = showingDetail;
            if (showingDetail) {
                StatusBarHeaderView.this.mQsDetailHeaderTitle.setText(detail.getTitle());
                Boolean toggleState = detail.getToggleState();
                if (toggleState == null) {
                    StatusBarHeaderView.this.mQsDetailHeaderSwitch.setVisibility(4);
                    StatusBarHeaderView.this.mQsDetailHeader.setClickable(false);
                    return;
                }
                StatusBarHeaderView.this.mQsDetailHeaderSwitch.setVisibility(0);
                StatusBarHeaderView.this.mQsDetailHeaderSwitch.setChecked(toggleState.booleanValue());
                StatusBarHeaderView.this.mQsDetailHeader.setClickable(true);
                StatusBarHeaderView.this.mQsDetailHeader.setOnClickListener(new C04417(detail));
                return;
            }
            StatusBarHeaderView.this.mQsDetailHeader.setClickable(false);
        }

        private void handleQsAbleToShowHidden(boolean isAbleToShow) {
            if (StatusBarHeaderView.this.mQsAbleToShowHidden != isAbleToShow) {
                StatusBarHeaderView.this.mQsAbleToShowHidden = isAbleToShow;
                QsAddButton access$2800 = StatusBarHeaderView.this.mQsAddButton;
                int i = (StatusBarHeaderView.this.mExpanded && isAbleToShow) ? 0 : 4;
                access$2800.setVisibility(i);
                StatusBarHeaderView.this.mExpandedValues.qsAddAlpha = isAbleToShow ? 1.0f : 0.0f;
                StatusBarHeaderView.this.updateSystemIconsLayoutParams();
                StatusBarHeaderView.this.requestCaptureValues();
            }
        }

        private void handleQsShowingHidden(boolean isShowingHidden) {
            if (StatusBarHeaderView.this.mQsShowingHidden != isShowingHidden) {
                StatusBarHeaderView.this.mQsShowingHidden = isShowingHidden;
                float degRotation = isShowingHidden ? -135.0f : 0.0f;
                StatusBarHeaderView.this.mExpandedValues.qsAddRotation = degRotation;
                if (StatusBarHeaderView.this.mExpanded) {
                    StatusBarHeaderView.this.mQsAddButton.rotate(degRotation);
                } else {
                    StatusBarHeaderView.this.updateLayoutValues(StatusBarHeaderView.this.mCurrentT);
                }
            }
        }

        private void handleQsReorderMode(boolean isInReorderMode) {
            boolean z = true;
            View access$1900 = StatusBarHeaderView.this.mClock;
            boolean z2 = (isInReorderMode || StatusBarHeaderView.this.mShowingDetail) ? false : true;
            transition(access$1900, z2);
            access$1900 = StatusBarHeaderView.this.mDateGroup;
            if (isInReorderMode || StatusBarHeaderView.this.mShowingDetail) {
                z2 = false;
            } else {
                z2 = true;
            }
            transition(access$1900, z2);
            if (StatusBarHeaderView.this.mAlarmShowing) {
                access$1900 = StatusBarHeaderView.this.mAlarmStatus;
                if (isInReorderMode || StatusBarHeaderView.this.mShowingDetail) {
                    z2 = false;
                } else {
                    z2 = true;
                }
                transition(access$1900, z2);
            }
            access$1900 = StatusBarHeaderView.this.mMultiUserSwitch;
            if (isInReorderMode) {
                z2 = false;
            } else {
                z2 = true;
            }
            transition(access$1900, z2);
            access$1900 = StatusBarHeaderView.this.mSettingsContainer;
            if (isInReorderMode) {
                z2 = false;
            } else {
                z2 = true;
            }
            transition(access$1900, z2);
            access$1900 = StatusBarHeaderView.this.mEmergencyCallsOnly;
            if (isInReorderMode || !StatusBarHeaderView.this.mShowEmergencyCallsOnly) {
                z2 = false;
            } else {
                z2 = true;
            }
            transition(access$1900, z2);
            access$1900 = StatusBarHeaderView.this.mQsAddButton;
            if (isInReorderMode || !StatusBarHeaderView.this.mQsAbleToShowHidden) {
                z2 = false;
            } else {
                z2 = true;
            }
            transition(access$1900, z2);
            access$1900 = StatusBarHeaderView.this.mBatteryMeterView;
            if (isInReorderMode) {
                z2 = false;
            } else {
                z2 = true;
            }
            transition(access$1900, z2);
            View access$4000 = StatusBarHeaderView.this.mBatteryLevel;
            if (isInReorderMode) {
                z = false;
            }
            transition(access$4000, z);
            transition(StatusBarHeaderView.this.mQsDeleteHeader, isInReorderMode);
            if (isInReorderMode) {
                StatusBarHeaderView.this.mQsDeleteHeader.getDrawable().setAlpha(255);
            }
            StatusBarHeaderView.this.mQsInReorderMode = isInReorderMode;
        }

        private void transition(View v, boolean in) {
            float f;
            if (in) {
                v.bringToFront();
                v.setVisibility(0);
            }
            if (v.hasOverlappingRendering()) {
                v.animate().withLayer();
            }
            ViewPropertyAnimator animate = v.animate();
            if (in) {
                f = 1.0f;
            } else {
                f = 0.0f;
            }
            animate.alpha(f).withEndAction(new C04428(in, v)).start();
        }
    }

    private static final class LayoutValues {
        float alarmStatusAlpha;
        float avatarScale;
        float avatarX;
        float avatarY;
        float batteryLevelAlpha;
        float batteryLevelExpandedAlpha;
        float batteryX;
        float batteryY;
        float clockY;
        float dateCollapsedAlpha;
        float dateExpandedAlpha;
        float dateY;
        float emergencyCallsOnlyAlpha;
        float qsAddAlpha;
        float qsAddRotation;
        float qsAddTranslation;
        float settingsAlpha;
        float settingsRotation;
        float settingsTranslation;
        float signalClusterAlpha;
        float timeScale;

        private LayoutValues() {
            this.timeScale = 1.0f;
        }

        public void interpoloate(LayoutValues v1, LayoutValues v2, float t) {
            this.timeScale = (v1.timeScale * (1.0f - t)) + (v2.timeScale * t);
            this.clockY = (v1.clockY * (1.0f - t)) + (v2.clockY * t);
            this.dateY = (v1.dateY * (1.0f - t)) + (v2.dateY * t);
            this.avatarScale = (v1.avatarScale * (1.0f - t)) + (v2.avatarScale * t);
            this.avatarX = (v1.avatarX * (1.0f - t)) + (v2.avatarX * t);
            this.avatarY = (v1.avatarY * (1.0f - t)) + (v2.avatarY * t);
            this.batteryX = (v1.batteryX * (1.0f - t)) + (v2.batteryX * t);
            this.batteryY = (v1.batteryY * (1.0f - t)) + (v2.batteryY * t);
            this.settingsTranslation = (v1.settingsTranslation * (1.0f - t)) + (v2.settingsTranslation * t);
            this.qsAddTranslation = (v1.qsAddTranslation * (1.0f - t)) + (v2.qsAddTranslation * t);
            float t1 = Math.max(0.0f, t - 0.5f) * 2.0f;
            this.settingsRotation = (v1.settingsRotation * (1.0f - t1)) + (v2.settingsRotation * t1);
            this.qsAddRotation = (v1.qsAddRotation * (1.0f - t1)) + (v2.qsAddRotation * t1);
            this.emergencyCallsOnlyAlpha = (v1.emergencyCallsOnlyAlpha * (1.0f - t1)) + (v2.emergencyCallsOnlyAlpha * t1);
            float t2 = Math.min(1.0f, 2.0f * t);
            this.signalClusterAlpha = (v1.signalClusterAlpha * (1.0f - t2)) + (v2.signalClusterAlpha * t2);
            float t3 = Math.max(0.0f, t - 0.7f) / 0.3f;
            this.batteryLevelAlpha = (v1.batteryLevelAlpha * (1.0f - t3)) + (v2.batteryLevelAlpha * t3);
            this.settingsAlpha = (v1.settingsAlpha * (1.0f - t3)) + (v2.settingsAlpha * t3);
            this.qsAddAlpha = (v1.qsAddAlpha * (1.0f - t3)) + (v2.qsAddAlpha * t3);
            this.dateExpandedAlpha = (v1.dateExpandedAlpha * (1.0f - t3)) + (v2.dateExpandedAlpha * t3);
            this.dateCollapsedAlpha = (v1.dateCollapsedAlpha * (1.0f - t3)) + (v2.dateCollapsedAlpha * t3);
            this.alarmStatusAlpha = (v1.alarmStatusAlpha * (1.0f - t3)) + (v2.alarmStatusAlpha * t3);
            this.batteryLevelExpandedAlpha = (v1.batteryLevelExpandedAlpha * (1.0f - t3)) + (v2.batteryLevelExpandedAlpha * t3);
        }
    }

    class SettingsObserver extends ContentObserver {
        SettingsObserver(Handler handler) {
            super(handler);
        }

        void observe() {
            ContentResolver resolver = StatusBarHeaderView.this.mContext.getContentResolver();
            resolver.registerContentObserver(System.getUriFor("status_bar_battery_style"), false, this);
            resolver.registerContentObserver(System.getUriFor("status_bar_show_battery_percent"), false, this);
            update();
        }

        void unobserve() {
            StatusBarHeaderView.this.mContext.getContentResolver().unregisterContentObserver(this);
        }

        public void onChange(boolean selfChange, Uri uri) {
            update();
        }

        public void update() {
            boolean z = false;
            ContentResolver resolver = StatusBarHeaderView.this.mContext.getContentResolver();
            int currentUserId = ActivityManager.getCurrentUser();
            int batteryStyle = System.getIntForUser(resolver, "status_bar_battery_style", 0, currentUserId);
            if (System.getIntForUser(resolver, "status_bar_show_battery_percent", 0, currentUserId) == 0) {
                z = true;
            }
            switch (batteryStyle) {
                case 4:
                case 6:
                    z = false;
                    break;
            }
            StatusBarHeaderView.this.mShowBatteryTextExpanded = z;
            StatusBarHeaderView.this.updateVisibilities();
            StatusBarHeaderView.this.requestCaptureValues();
        }
    }

    public StatusBarHeaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mClipBounds = new Rect();
        this.mCollapsedValues = new LayoutValues();
        this.mExpandedValues = new LayoutValues();
        this.mCurrentValues = new LayoutValues();
        this.mQsInReorderMode = false;
        this.mQsAbleToShowHidden = false;
        this.mQsShowingHidden = false;
        this.mUserInfoChangedListener = new C04334();
        this.mQsPanelCallback = new C04436();
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mSystemIconsSuperContainer = findViewById(2131755139);
        this.mSystemIconsContainer = (ViewGroup) findViewById(2131755140);
        this.mSystemIconsSuperContainer.setOnClickListener(this);
        this.mDateGroup = findViewById(2131755296);
        this.mDateGroup.setOnClickListener(this);
        this.mClock = findViewById(C0065R.id.clock);
        this.mClock.setOnClickListener(this);
        this.mTime = (TextView) findViewById(2131755269);
        this.mAmPm = (TextView) findViewById(2131755270);
        this.mMultiUserSwitch = (MultiUserSwitch) findViewById(2131755137);
        this.mMultiUserAvatar = (ImageView) findViewById(2131755138);
        this.mDateCollapsed = (TextView) findViewById(2131755297);
        this.mDateExpanded = (TextView) findViewById(2131755298);
        this.mSettingsButton = (SettingsButton) findViewById(2131755292);
        this.mSettingsContainer = findViewById(2131755291);
        this.mSettingsButton.setOnClickListener(this);
        this.mQsAddButton = (QsAddButton) findViewById(2131755294);
        this.mQsAddButton.setOnClickListener(this);
        this.mQsDetailHeader = findViewById(2131755299);
        this.mQsDetailHeader.setAlpha(0.0f);
        this.mQsDetailHeaderTitle = (TextView) this.mQsDetailHeader.findViewById(16908310);
        this.mQsDetailHeaderSwitch = (Switch) this.mQsDetailHeader.findViewById(16908311);
        this.mQsDetailHeaderProgress = (ImageView) findViewById(2131755300);
        this.mQsDeleteHeader = (ImageView) findViewById(2131755301);
        this.mEmergencyCallsOnly = (TextView) findViewById(2131755295);
        this.mBatteryLevel = (BatteryLevelTextView) findViewById(2131755141);
        this.mAlarmStatus = (TextView) findViewById(C0065R.id.alarm_status);
        this.mAlarmStatus.setOnClickListener(this);
        this.mBatteryMeterView = (BatteryMeterView) findViewById(2131755334);
        this.mSignalCluster = findViewById(2131755333);
        this.mSystemIcons = (LinearLayout) findViewById(2131755331);
        this.mSettingsObserver = new SettingsObserver(new Handler());
        loadDimens();
        updateVisibilities();
        updateClockScale();
        updateAvatarScale();
        addOnLayoutChangeListener(new C04291());
        setOutlineProvider(new C04302());
        requestCaptureValues();
        setOnDragListener(new C04323());
        Drawable d = getBackground();
        if (d instanceof RippleDrawable) {
            ((RippleDrawable) d).setForceSoftware(true);
        }
        d = this.mSettingsButton.getBackground();
        if (d instanceof RippleDrawable) {
            ((RippleDrawable) d).setForceSoftware(true);
        }
        d = this.mSystemIconsSuperContainer.getBackground();
        if (d instanceof RippleDrawable) {
            ((RippleDrawable) d).setForceSoftware(true);
        }
        d = this.mQsAddButton.getBackground();
        if (d instanceof RippleDrawable) {
            ((RippleDrawable) d).setForceSoftware(true);
        }
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if (this.mCaptureValues) {
            if (this.mExpanded) {
                captureLayoutValues(this.mExpandedValues);
            } else {
                captureLayoutValues(this.mCollapsedValues);
            }
            this.mCaptureValues = false;
            updateLayoutValues(this.mCurrentT);
        }
        this.mAlarmStatus.setX((float) (this.mDateGroup.getLeft() + this.mDateCollapsed.getRight()));
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        FontSizeUtils.updateFontSize(this.mEmergencyCallsOnly, 2131296415);
        FontSizeUtils.updateFontSize(this.mDateCollapsed, 2131296416);
        FontSizeUtils.updateFontSize(this.mDateExpanded, 2131296416);
        FontSizeUtils.updateFontSize(this.mAlarmStatus, 2131296416);
        FontSizeUtils.updateFontSize(this, 16908310, 2131296328);
        FontSizeUtils.updateFontSize(this, 16908311, 2131296328);
        FontSizeUtils.updateFontSize(this.mAmPm, 2131296413);
        FontSizeUtils.updateFontSize(this, 2131755271, 2131296414);
        this.mEmergencyCallsOnly.setText(17040028);
        this.mClockCollapsedSize = getResources().getDimensionPixelSize(2131296413);
        this.mClockExpandedSize = getResources().getDimensionPixelSize(2131296414);
        this.mClockCollapsedScaleFactor = ((float) this.mClockCollapsedSize) / ((float) this.mClockExpandedSize);
        updateClockScale();
        updateClockCollapsedMargin();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mUserInfoController != null) {
            this.mUserInfoController.removeListener(this.mUserInfoChangedListener);
        }
        setListening(false);
    }

    private void updateClockCollapsedMargin() {
        Resources res = getResources();
        float largeFactor = (MathUtils.constrain(getResources().getConfiguration().fontScale, 1.0f, 1.3f) - 1.0f) / 0.29999995f;
        this.mClockMarginBottomCollapsed = Math.round(((1.0f - largeFactor) * ((float) res.getDimensionPixelSize(2131296405))) + (((float) res.getDimensionPixelSize(2131296406)) * largeFactor));
        requestLayout();
    }

    private void requestCaptureValues() {
        this.mCaptureValues = true;
        requestLayout();
    }

    private void loadDimens() {
        this.mCollapsedHeight = getResources().getDimensionPixelSize(2131296301);
        this.mExpandedHeight = getResources().getDimensionPixelSize(2131296302);
        this.mMultiUserExpandedMargin = getResources().getDimensionPixelSize(2131296398);
        this.mMultiUserCollapsedMargin = getResources().getDimensionPixelSize(2131296399);
        this.mClockMarginBottomExpanded = getResources().getDimensionPixelSize(2131296404);
        updateClockCollapsedMargin();
        this.mMultiUserSwitchWidthCollapsed = getResources().getDimensionPixelSize(2131296407);
        this.mMultiUserSwitchWidthExpanded = getResources().getDimensionPixelSize(2131296408);
        this.mAvatarCollapsedScaleFactor = ((float) getResources().getDimensionPixelSize(2131296410)) / ((float) this.mMultiUserAvatar.getLayoutParams().width);
        this.mClockCollapsedSize = getResources().getDimensionPixelSize(2131296413);
        this.mClockExpandedSize = getResources().getDimensionPixelSize(2131296414);
        this.mClockCollapsedScaleFactor = ((float) this.mClockCollapsedSize) / ((float) this.mClockExpandedSize);
    }

    public void setActivityStarter(ActivityStarter activityStarter) {
        this.mActivityStarter = activityStarter;
    }

    public void setBatteryController(BatteryController batteryController) {
        this.mBatteryController = batteryController;
        this.mBatteryMeterView.setBatteryController(batteryController);
        this.mBatteryLevel.setBatteryController(batteryController);
    }

    public void setNextAlarmController(NextAlarmController nextAlarmController) {
        this.mNextAlarmController = nextAlarmController;
    }

    public int getCollapsedHeight() {
        return this.mCollapsedHeight;
    }

    public int getExpandedHeight() {
        return this.mExpandedHeight;
    }

    public void setListening(boolean listening) {
        if (listening != this.mListening) {
            this.mListening = listening;
            updateListeners();
        }
    }

    public void setExpanded(boolean expanded) {
        boolean changed = expanded != this.mExpanded;
        this.mExpanded = expanded;
        if (changed) {
            updateEverything();
        }
    }

    public void updateEverything() {
        updateHeights();
        updateVisibilities();
        updateSystemIconsLayoutParams();
        updateClickTargets();
        updateMultiUserSwitch();
        updateClockScale();
        updateAvatarScale();
        updateClockLp();
        requestCaptureValues();
    }

    private void updateHeights() {
        int height = this.mExpanded ? this.mExpandedHeight : this.mCollapsedHeight;
        LayoutParams lp = getLayoutParams();
        if (lp.height != height) {
            lp.height = height;
            setLayoutParams(lp);
        }
    }

    private void updateVisibilities() {
        boolean z;
        int i = 0;
        TextView textView = this.mDateCollapsed;
        int i2 = (this.mExpanded && this.mAlarmShowing) ? 0 : 4;
        textView.setVisibility(i2);
        textView = this.mDateExpanded;
        if (this.mExpanded && this.mAlarmShowing) {
            i2 = 4;
        } else {
            i2 = 0;
        }
        textView.setVisibility(i2);
        textView = this.mAlarmStatus;
        if (this.mExpanded && this.mAlarmShowing) {
            i2 = 0;
        } else {
            i2 = 4;
        }
        textView.setVisibility(i2);
        View view = this.mSettingsContainer;
        if (this.mExpanded) {
            i2 = 0;
        } else {
            i2 = 4;
        }
        view.setVisibility(i2);
        QsAddButton qsAddButton = this.mQsAddButton;
        if (this.mExpanded && this.mQsAbleToShowHidden) {
            i2 = 0;
        } else {
            i2 = 4;
        }
        qsAddButton.setVisibility(i2);
        view = this.mQsDetailHeader;
        if (this.mExpanded && this.mShowingDetail) {
            i2 = 0;
        } else {
            i2 = 4;
        }
        view.setVisibility(i2);
        ImageView imageView = this.mQsDeleteHeader;
        if (this.mExpanded && this.mQsInReorderMode) {
            i2 = 0;
        } else {
            i2 = 4;
        }
        imageView.setVisibility(i2);
        if (this.mSignalCluster != null) {
            updateSignalClusterDetachment();
        }
        textView = this.mEmergencyCallsOnly;
        i2 = (this.mExpanded && this.mShowEmergencyCallsOnly) ? 0 : 8;
        textView.setVisibility(i2);
        BatteryLevelTextView batteryLevelTextView = this.mBatteryLevel;
        if (this.mExpanded && this.mShowBatteryTextExpanded) {
            z = true;
        } else {
            z = false;
        }
        batteryLevelTextView.setForceShown(z);
        this.mBatteryLevel.setVisibility(0);
        View findViewById = this.mSettingsContainer.findViewById(2131755293);
        if (!TunerService.isTunerEnabled(this.mContext)) {
            i = 4;
        }
        findViewById.setVisibility(i);
    }

    private void updateSignalClusterDetachment() {
        boolean detached = this.mExpanded;
        if (detached != this.mSignalClusterDetached) {
            if (detached) {
                getOverlay().add(this.mSignalCluster);
            } else {
                reattachSignalCluster();
            }
        }
        this.mSignalClusterDetached = detached;
    }

    private void reattachSignalCluster() {
        getOverlay().remove(this.mSignalCluster);
        this.mSystemIcons.addView(this.mSignalCluster, 1);
    }

    private void updateSystemIconsLayoutParams() {
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) this.mSystemIconsSuperContainer.getLayoutParams();
        int rule = this.mExpanded ? this.mQsAbleToShowHidden ? this.mQsAddButton.getId() : this.mSettingsContainer.getId() : this.mMultiUserSwitch.getId();
        if (rule != lp.getRules()[16]) {
            lp.addRule(16, rule);
            this.mSystemIconsSuperContainer.setLayoutParams(lp);
        }
    }

    private void updateListeners() {
        if (this.mListening) {
            this.mSettingsObserver.observe();
            this.mNextAlarmController.addStateChangedCallback(this);
            return;
        }
        this.mNextAlarmController.removeStateChangedCallback(this);
        this.mSettingsObserver.unobserve();
    }

    private void updateAvatarScale() {
        if (this.mExpanded) {
            this.mMultiUserAvatar.setScaleX(1.0f);
            this.mMultiUserAvatar.setScaleY(1.0f);
            return;
        }
        this.mMultiUserAvatar.setScaleX(this.mAvatarCollapsedScaleFactor);
        this.mMultiUserAvatar.setScaleY(this.mAvatarCollapsedScaleFactor);
    }

    private void updateClockScale() {
        this.mTime.setTextSize(0, this.mExpanded ? (float) this.mClockExpandedSize : (float) this.mClockCollapsedSize);
        this.mTime.setScaleX(1.0f);
        this.mTime.setScaleY(1.0f);
        updateAmPmTranslation();
    }

    private void updateAmPmTranslation() {
        int i = 1;
        boolean rtl = getLayoutDirection() == 1;
        TextView textView = this.mAmPm;
        if (!rtl) {
            i = -1;
        }
        textView.setTranslationX(((float) (i * this.mTime.getWidth())) * (1.0f - this.mTime.getScaleX()));
    }

    public void onNextAlarmChanged(AlarmClockInfo nextAlarm) {
        this.mNextAlarm = nextAlarm;
        if (nextAlarm != null) {
            this.mAlarmStatus.setText(KeyguardStatusView.formatNextAlarm(getContext(), nextAlarm));
        }
        this.mAlarmShowing = nextAlarm != null;
        updateEverything();
        requestCaptureValues();
    }

    private void updateClickTargets() {
        this.mMultiUserSwitch.setClickable(this.mExpanded);
        this.mMultiUserSwitch.setFocusable(this.mExpanded);
        this.mSystemIconsSuperContainer.setClickable(this.mExpanded);
        this.mSystemIconsSuperContainer.setFocusable(this.mExpanded);
        TextView textView = this.mAlarmStatus;
        boolean z = (this.mNextAlarm == null || this.mNextAlarm.getShowIntent() == null) ? false : true;
        textView.setClickable(z);
    }

    private void updateClockLp() {
        int marginBottom = this.mExpanded ? this.mClockMarginBottomExpanded : this.mClockMarginBottomCollapsed;
        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) this.mDateGroup.getLayoutParams();
        if (marginBottom != lp.bottomMargin) {
            lp.bottomMargin = marginBottom;
            this.mDateGroup.setLayoutParams(lp);
        }
    }

    private void updateMultiUserSwitch() {
        int marginEnd;
        int width;
        if (this.mExpanded) {
            marginEnd = this.mMultiUserExpandedMargin;
            width = this.mMultiUserSwitchWidthExpanded;
        } else {
            marginEnd = this.mMultiUserCollapsedMargin;
            width = this.mMultiUserSwitchWidthCollapsed;
        }
        MarginLayoutParams lp = (MarginLayoutParams) this.mMultiUserSwitch.getLayoutParams();
        if (marginEnd != lp.getMarginEnd() || lp.width != width) {
            lp.setMarginEnd(marginEnd);
            lp.width = width;
            this.mMultiUserSwitch.setLayoutParams(lp);
        }
    }

    public void setExpansion(float t) {
        if (!this.mExpanded) {
            t = 0.0f;
        }
        this.mCurrentT = t;
        float height = ((float) this.mCollapsedHeight) + (((float) (this.mExpandedHeight - this.mCollapsedHeight)) * t);
        if (height < ((float) this.mCollapsedHeight)) {
            height = (float) this.mCollapsedHeight;
        }
        if (height > ((float) this.mExpandedHeight)) {
            height = (float) this.mExpandedHeight;
        }
        setClipping(height);
        updateLayoutValues(t);
    }

    private void updateLayoutValues(float t) {
        if (!this.mCaptureValues) {
            this.mCurrentValues.interpoloate(this.mCollapsedValues, this.mExpandedValues, t);
            applyLayoutValues(this.mCurrentValues);
        }
    }

    private void setClipping(float height) {
        this.mClipBounds.set(getPaddingLeft(), 0, getWidth() - getPaddingRight(), (int) height);
        setClipBounds(this.mClipBounds);
        invalidateOutline();
    }

    public void setUserInfoController(UserInfoController userInfoController) {
        this.mUserInfoController = userInfoController;
        userInfoController.addListener(this.mUserInfoChangedListener);
    }

    public void onClick(View v) {
        boolean z = true;
        if (v == this.mSettingsButton) {
            if (this.mSettingsButton.isTunerClick()) {
                if (TunerService.isTunerEnabled(this.mContext)) {
                    TunerService.showResetRequest(this.mContext, new C04345());
                } else {
                    Toast.makeText(getContext(), 2131362365, 1).show();
                    TunerService.setTunerEnabled(this.mContext, true);
                }
            }
            startSettingsActivity();
        } else if (v == this.mQsAddButton) {
            if (this.mQSPanel != null) {
                QSPanel qSPanel = this.mQSPanel;
                if (this.mQsShowingHidden) {
                    z = false;
                }
                qSPanel.showHidden(z);
            }
        } else if (v == this.mSystemIconsSuperContainer) {
            startBatteryActivity();
        } else if (v == this.mAlarmStatus && this.mNextAlarm != null) {
            PendingIntent showIntent = this.mNextAlarm.getShowIntent();
            if (showIntent != null) {
                this.mActivityStarter.startPendingIntentDismissingKeyguard(showIntent);
            }
        } else if (v == this.mClock) {
            startClockActivity();
        } else if (v == this.mDateGroup) {
            startDateActivity();
        }
    }

    private void startSettingsActivity() {
        this.mActivityStarter.startActivity(new Intent("android.settings.SETTINGS"), true);
    }

    private void startBatteryActivity() {
        this.mActivityStarter.startActivity(new Intent("android.intent.action.POWER_USAGE_SUMMARY"), true);
    }

    private void startClockActivity() {
        this.mActivityStarter.startActivity(new Intent("android.intent.action.SHOW_ALARMS"), true);
    }

    private void startDateActivity() {
        Builder builder = CalendarContract.CONTENT_URI.buildUpon();
        builder.appendPath("time");
        ContentUris.appendId(builder, System.currentTimeMillis());
        this.mActivityStarter.startActivity(new Intent("android.intent.action.VIEW").setData(builder.build()), true);
    }

    public void setQSPanel(QSPanel qsp) {
        this.mQSPanel = qsp;
        if (this.mQSPanel != null) {
            this.mQSPanel.setCallback(this.mQsPanelCallback);
        }
        this.mMultiUserSwitch.setQsPanel(qsp);
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public void setEmergencyCallsOnly(boolean show) {
        if (show != this.mShowEmergencyCallsOnly) {
            this.mShowEmergencyCallsOnly = show;
            if (this.mExpanded) {
                updateEverything();
                requestCaptureValues();
            }
        }
    }

    protected void dispatchSetPressed(boolean pressed) {
    }

    private void captureLayoutValues(LayoutValues target) {
        float f;
        float f2 = 90.0f;
        float f3 = 1.0f;
        target.timeScale = this.mExpanded ? 1.0f : this.mClockCollapsedScaleFactor;
        target.clockY = (float) this.mClock.getBottom();
        target.dateY = (float) this.mDateGroup.getTop();
        target.emergencyCallsOnlyAlpha = getAlphaForVisibility(this.mEmergencyCallsOnly);
        target.alarmStatusAlpha = getAlphaForVisibility(this.mAlarmStatus);
        target.dateCollapsedAlpha = getAlphaForVisibility(this.mDateCollapsed);
        target.dateExpandedAlpha = getAlphaForVisibility(this.mDateExpanded);
        target.avatarScale = this.mMultiUserAvatar.getScaleX();
        target.avatarX = (float) (this.mMultiUserSwitch.getLeft() + this.mMultiUserAvatar.getLeft());
        target.avatarY = (float) (this.mMultiUserSwitch.getTop() + this.mMultiUserAvatar.getTop());
        if (getLayoutDirection() == 0) {
            target.batteryX = (float) (this.mSystemIconsSuperContainer.getLeft() + this.mSystemIconsContainer.getRight());
        } else {
            target.batteryX = (float) (this.mSystemIconsSuperContainer.getLeft() + this.mSystemIconsContainer.getLeft());
        }
        target.batteryY = (float) (this.mSystemIconsSuperContainer.getTop() + this.mSystemIconsContainer.getTop());
        target.batteryLevelAlpha = getAlphaForVisibility(this.mBatteryLevel);
        target.settingsAlpha = getAlphaForVisibility(this.mSettingsContainer);
        target.settingsTranslation = this.mExpanded ? 0.0f : (float) (this.mMultiUserSwitch.getLeft() - this.mSettingsContainer.getLeft());
        target.qsAddAlpha = getAlphaForVisibility(this.mQsAddButton);
        target.qsAddTranslation = this.mExpanded ? 0.0f : (float) (this.mMultiUserSwitch.getLeft() - this.mQsAddButton.getLeft());
        if (this.mSignalClusterDetached) {
            f3 = 0.0f;
        }
        target.signalClusterAlpha = f3;
        if (this.mExpanded) {
            f = 0.0f;
        } else {
            f = 90.0f;
        }
        target.settingsRotation = f;
        if (this.mExpanded) {
            f2 = this.mQsShowingHidden ? -135.0f : 0.0f;
        }
        target.qsAddRotation = f2;
    }

    private float getAlphaForVisibility(View v) {
        return (v == null || v.getVisibility() == 0) ? 1.0f : 0.0f;
    }

    private void applyAlpha(View v, float alpha) {
        if (v != null && v.getVisibility() != 8) {
            if (alpha == 0.0f) {
                v.setVisibility(4);
                return;
            }
            v.setVisibility(0);
            v.setAlpha(alpha);
        }
    }

    private void applyLayoutValues(LayoutValues values) {
        this.mTime.setScaleX(values.timeScale);
        this.mTime.setScaleY(values.timeScale);
        this.mClock.setY(values.clockY - ((float) this.mClock.getHeight()));
        this.mDateGroup.setY(values.dateY);
        this.mAlarmStatus.setY(values.dateY - ((float) this.mAlarmStatus.getPaddingTop()));
        this.mMultiUserAvatar.setScaleX(values.avatarScale);
        this.mMultiUserAvatar.setScaleY(values.avatarScale);
        this.mMultiUserAvatar.setX(values.avatarX - ((float) this.mMultiUserSwitch.getLeft()));
        this.mMultiUserAvatar.setY(values.avatarY - ((float) this.mMultiUserSwitch.getTop()));
        if (getLayoutDirection() == 0) {
            this.mSystemIconsSuperContainer.setX(values.batteryX - ((float) this.mSystemIconsContainer.getRight()));
        } else {
            this.mSystemIconsSuperContainer.setX(values.batteryX - ((float) this.mSystemIconsContainer.getLeft()));
        }
        this.mSystemIconsSuperContainer.setY(values.batteryY - ((float) this.mSystemIconsContainer.getTop()));
        if (this.mSignalCluster != null && this.mExpanded) {
            if (getLayoutDirection() == 0) {
                this.mSignalCluster.setX(this.mSystemIconsSuperContainer.getX() - ((float) this.mSignalCluster.getWidth()));
            } else {
                this.mSignalCluster.setX(this.mSystemIconsSuperContainer.getX() + ((float) this.mSystemIconsSuperContainer.getWidth()));
            }
            this.mSignalCluster.setY((this.mSystemIconsSuperContainer.getY() + ((float) (this.mSystemIconsSuperContainer.getHeight() / 2))) - ((float) (this.mSignalCluster.getHeight() / 2)));
        } else if (this.mSignalCluster != null) {
            this.mSignalCluster.setTranslationX(0.0f);
            this.mSignalCluster.setTranslationY(0.0f);
        }
        if (!this.mSettingsButton.isAnimating()) {
            this.mSettingsContainer.setTranslationY(this.mSystemIconsSuperContainer.getTranslationY());
            this.mSettingsContainer.setTranslationX(values.settingsTranslation);
            this.mSettingsButton.setRotation(values.settingsRotation);
        }
        this.mQsAddButton.setTranslationY(this.mSystemIconsSuperContainer.getTranslationY());
        this.mQsAddButton.setTranslationX(values.qsAddTranslation);
        this.mQsAddButton.setRotation(values.qsAddRotation);
        applyAlpha(this.mEmergencyCallsOnly, values.emergencyCallsOnlyAlpha);
        if (!(this.mShowingDetail || this.mDetailTransitioning)) {
            applyAlpha(this.mAlarmStatus, values.alarmStatusAlpha);
        }
        applyAlpha(this.mDateCollapsed, values.dateCollapsedAlpha);
        applyAlpha(this.mDateExpanded, values.dateExpandedAlpha);
        applyAlpha(this.mBatteryLevel, values.batteryLevelAlpha);
        applyAlpha(this.mSettingsContainer, values.settingsAlpha);
        applyAlpha(this.mQsAddButton, values.qsAddAlpha);
        applyAlpha(this.mSignalCluster, values.signalClusterAlpha);
        if (!this.mExpanded) {
            this.mTime.setScaleX(1.0f);
            this.mTime.setScaleY(1.0f);
        }
        updateAmPmTranslation();
    }
}
