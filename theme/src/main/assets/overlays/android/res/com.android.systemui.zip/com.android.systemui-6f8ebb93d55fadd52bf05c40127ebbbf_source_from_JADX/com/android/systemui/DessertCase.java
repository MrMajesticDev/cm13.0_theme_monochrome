package com.android.systemui;

import android.app.Activity;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.util.Slog;
import com.android.systemui.DessertCaseView.RescalingContainer;

public class DessertCase extends Activity {
    DessertCaseView mView;

    /* renamed from: com.android.systemui.DessertCase.1 */
    class C00851 implements Runnable {
        C00851() {
        }

        public void run() {
            DessertCase.this.mView.start();
        }
    }

    public void onStart() {
        super.onStart();
        PackageManager pm = getPackageManager();
        ComponentName cn = new ComponentName(this, DessertCaseDream.class);
        if (pm.getComponentEnabledSetting(cn) != 1) {
            Slog.v("DessertCase", "ACHIEVEMENT UNLOCKED");
            pm.setComponentEnabledSetting(cn, 1, 1);
        }
        this.mView = new DessertCaseView(this);
        RescalingContainer container = new RescalingContainer(this);
        container.setView(this.mView);
        setContentView(container);
    }

    public void onResume() {
        super.onResume();
        this.mView.postDelayed(new C00851(), 1000);
    }

    public void onPause() {
        super.onPause();
        this.mView.stop();
    }
}
