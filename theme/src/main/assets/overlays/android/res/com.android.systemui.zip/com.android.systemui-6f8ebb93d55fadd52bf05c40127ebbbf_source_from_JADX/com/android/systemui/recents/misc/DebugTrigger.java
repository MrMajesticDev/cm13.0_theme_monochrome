package com.android.systemui.recents.misc;

import android.os.Handler;

public class DebugTrigger {
    Handler mHandler;
    Runnable mTriggeredRunnable;

    public DebugTrigger(Runnable triggeredRunnable) {
        this.mHandler = new Handler();
        this.mTriggeredRunnable = triggeredRunnable;
    }

    public void onKeyEvent(int keyCode) {
    }
}
