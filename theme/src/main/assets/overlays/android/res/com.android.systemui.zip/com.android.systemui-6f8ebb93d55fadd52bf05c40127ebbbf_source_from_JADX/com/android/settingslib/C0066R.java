package com.android.settingslib;

/* renamed from: com.android.settingslib.R */
public final class C0066R {

    /* renamed from: com.android.settingslib.R.array */
    public static final class array {
        public static final int wifi_status = 2131230720;
        public static final int wifi_status_with_ssid = 2131230721;
    }

    /* renamed from: com.android.settingslib.R.dimen */
    public static final class dimen {
        public static final int appear_y_translation_start = 2131296256;
    }

    /* renamed from: com.android.settingslib.R.string */
    public static final class string {
        public static final int available_via_passpoint = 2131361817;
        public static final int bluetooth_pairing_device_down_error_message = 2131361865;
        public static final int bluetooth_pairing_error_message = 2131361863;
        public static final int bluetooth_pairing_pin_error_message = 2131361864;
        public static final int bluetooth_pairing_rejected_error_message = 2131361866;
        public static final int connected_via_passpoint = 2131361816;
        public static final int connected_via_wfa = 2131361815;
        public static final int wifi_connected_no_internet = 2131361820;
        public static final int wifi_disabled_generic = 2131361808;
        public static final int wifi_disabled_network_failure = 2131361809;
        public static final int wifi_disabled_password_failure = 2131361811;
        public static final int wifi_disabled_wifi_failure = 2131361810;
        public static final int wifi_fail_to_scan = 2131361792;
        public static final int wifi_no_internet = 2131361813;
        public static final int wifi_not_in_range = 2131361812;
        public static final int wifi_remembered = 2131361807;
    }
}
