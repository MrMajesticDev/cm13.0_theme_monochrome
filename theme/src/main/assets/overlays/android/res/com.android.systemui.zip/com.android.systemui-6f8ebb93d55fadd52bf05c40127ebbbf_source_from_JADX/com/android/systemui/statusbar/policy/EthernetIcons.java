package com.android.systemui.statusbar.policy;

class EthernetIcons {
    static final int[][] ETHERNET_ICONS;

    static {
        r0 = new int[2][];
        r0[0] = new int[]{2130837867};
        r0[1] = new int[]{2130837868};
        ETHERNET_ICONS = r0;
    }
}
