package com.android.systemui.statusbar.phone;

import android.app.ActivityManagerNative;
import android.app.AlarmManager;
import android.app.AlarmManager.AlarmClockInfo;
import android.app.IUserSwitchObserver.Stub;
import android.app.StatusBarManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.UserInfo;
import android.media.AudioManager;
import android.os.Handler;
import android.os.IRemoteCallback;
import android.os.RemoteException;
import android.os.UserManager;
import android.provider.Settings.Secure;
import android.util.Log;
import com.android.internal.telephony.IccCardConstants.State;
import com.android.systemui.qs.tiles.DndTile;
import com.android.systemui.statusbar.policy.BluetoothController;
import com.android.systemui.statusbar.policy.BluetoothController.Callback;
import com.android.systemui.statusbar.policy.CastController;
import com.android.systemui.statusbar.policy.CastController.CastDevice;
import com.android.systemui.statusbar.policy.HotspotController;
import com.android.systemui.statusbar.policy.UserInfoController;

public class PhoneStatusBarPolicy implements Callback {
    private static final boolean DEBUG;
    private final AlarmManager mAlarmManager;
    private BluetoothController mBluetooth;
    private final CastController mCast;
    private final CastController.Callback mCastCallback;
    private final Context mContext;
    private boolean mCurrentUserSetup;
    private final Handler mHandler;
    private final HotspotController mHotspot;
    private final HotspotController.Callback mHotspotCallback;
    private BroadcastReceiver mIntentReceiver;
    private boolean mKeyguardVisible;
    private boolean mManagedProfileFocused;
    private boolean mManagedProfileIconVisible;
    private Runnable mRemoveCastIconRunnable;
    private final StatusBarManager mService;
    State mSimState;
    private final UserInfoController mUserInfoController;
    private final Stub mUserSwitchListener;
    private boolean mVolumeVisible;
    private int mZen;
    private boolean mZenVisible;

    /* renamed from: com.android.systemui.statusbar.phone.PhoneStatusBarPolicy.1 */
    class C04171 extends BroadcastReceiver {
        C04171() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals("android.app.action.NEXT_ALARM_CLOCK_CHANGED")) {
                PhoneStatusBarPolicy.this.updateAlarm();
            } else if (action.equals("android.media.RINGER_MODE_CHANGED") || action.equals("android.media.INTERNAL_RINGER_MODE_CHANGED_ACTION")) {
                PhoneStatusBarPolicy.this.updateVolumeZen();
            } else if (action.equals("android.intent.action.SIM_STATE_CHANGED")) {
                PhoneStatusBarPolicy.this.updateSimState(intent);
            } else if (action.equals("android.telecom.action.CURRENT_TTY_MODE_CHANGED")) {
                PhoneStatusBarPolicy.this.updateTTY(intent);
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PhoneStatusBarPolicy.2 */
    class C04182 implements Runnable {
        C04182() {
        }

        public void run() {
            if (PhoneStatusBarPolicy.DEBUG) {
                Log.v("PhoneStatusBarPolicy", "updateCast: hiding icon NOW");
            }
            PhoneStatusBarPolicy.this.mService.setIconVisibility("cast", false);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PhoneStatusBarPolicy.3 */
    class C04193 extends Stub {
        C04193() {
        }

        public void onUserSwitching(int newUserId, IRemoteCallback reply) {
            PhoneStatusBarPolicy.this.mUserInfoController.reloadUserInfo();
        }

        public void onUserSwitchComplete(int newUserId) throws RemoteException {
            PhoneStatusBarPolicy.this.updateAlarm();
            PhoneStatusBarPolicy.this.profileChanged(newUserId);
        }

        public void onForegroundProfileSwitch(int newProfileId) {
            PhoneStatusBarPolicy.this.profileChanged(newProfileId);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PhoneStatusBarPolicy.4 */
    class C04204 implements HotspotController.Callback {
        C04204() {
        }

        public void onHotspotChanged(boolean enabled) {
            PhoneStatusBarPolicy.this.mService.setIconVisibility("hotspot", enabled);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.PhoneStatusBarPolicy.5 */
    class C04215 implements CastController.Callback {
        C04215() {
        }

        public void onCastDevicesChanged() {
            PhoneStatusBarPolicy.this.updateCast();
        }
    }

    static {
        DEBUG = Log.isLoggable("PhoneStatusBarPolicy", 3);
    }

    public PhoneStatusBarPolicy(Context context, CastController cast, HotspotController hotspot, UserInfoController userInfoController, BluetoothController bluetooth) {
        this.mHandler = new Handler();
        this.mSimState = State.READY;
        this.mManagedProfileFocused = false;
        this.mManagedProfileIconVisible = true;
        this.mKeyguardVisible = true;
        this.mIntentReceiver = new C04171();
        this.mRemoveCastIconRunnable = new C04182();
        this.mUserSwitchListener = new C04193();
        this.mHotspotCallback = new C04204();
        this.mCastCallback = new C04215();
        this.mContext = context;
        this.mCast = cast;
        this.mHotspot = hotspot;
        this.mBluetooth = bluetooth;
        this.mBluetooth.addStateChangedCallback(this);
        this.mService = (StatusBarManager) context.getSystemService("statusbar");
        this.mAlarmManager = (AlarmManager) context.getSystemService("alarm");
        this.mUserInfoController = userInfoController;
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.app.action.NEXT_ALARM_CLOCK_CHANGED");
        filter.addAction("android.media.RINGER_MODE_CHANGED");
        filter.addAction("android.media.INTERNAL_RINGER_MODE_CHANGED_ACTION");
        filter.addAction("android.intent.action.SIM_STATE_CHANGED");
        filter.addAction("android.telecom.action.CURRENT_TTY_MODE_CHANGED");
        this.mContext.registerReceiver(this.mIntentReceiver, filter, null, this.mHandler);
        try {
            ActivityManagerNative.getDefault().registerUserSwitchObserver(this.mUserSwitchListener);
        } catch (RemoteException e) {
        }
        this.mService.setIcon("tty", 2130838138, 0, null);
        this.mService.setIconVisibility("tty", false);
        updateBluetooth();
        updateTTYMode();
        this.mService.setIcon("alarm_clock", 2130837823, 0, null);
        this.mService.setIconVisibility("alarm_clock", false);
        this.mService.setIcon("zen", 2130838154, 0, null);
        this.mService.setIconVisibility("zen", false);
        this.mService.setIcon("volume", 2130837915, 0, null);
        this.mService.setIconVisibility("volume", false);
        updateVolumeZen();
        this.mService.setIcon("cast", 2130837825, 0, null);
        this.mService.setIconVisibility("cast", false);
        this.mCast.addCallback(this.mCastCallback);
        this.mService.setIcon("hotspot", 2130837869, 0, this.mContext.getString(2131362359));
        this.mService.setIconVisibility("hotspot", this.mHotspot.isHotspotEnabled());
        this.mHotspot.addCallback(this.mHotspotCallback);
        this.mService.setIcon("managed_profile", 2130837871, 0, this.mContext.getString(2131362360));
        this.mService.setIconVisibility("managed_profile", false);
    }

    public void setZenMode(int zen) {
        this.mZen = zen;
        updateVolumeZen();
    }

    private void updateAlarm() {
        boolean zenNone;
        boolean z = true;
        AlarmClockInfo alarm = this.mAlarmManager.getNextAlarmClock(-2);
        boolean hasAlarm;
        if (alarm == null || alarm.getTriggerTime() <= 0) {
            hasAlarm = false;
        } else {
            hasAlarm = true;
        }
        if (this.mZen == 2) {
            zenNone = true;
        } else {
            zenNone = false;
        }
        this.mService.setIcon("alarm_clock", zenNone ? 2130837824 : 2130837823, 0, null);
        StatusBarManager statusBarManager = this.mService;
        String str = "alarm_clock";
        if (!(this.mCurrentUserSetup && hasAlarm)) {
            z = false;
        }
        statusBarManager.setIconVisibility(str, z);
    }

    private final void updateSimState(Intent intent) {
        String stateExtra = intent.getStringExtra("ss");
        if ("ABSENT".equals(stateExtra)) {
            this.mSimState = State.ABSENT;
        } else if ("CARD_IO_ERROR".equals(stateExtra)) {
            this.mSimState = State.CARD_IO_ERROR;
        } else if ("READY".equals(stateExtra)) {
            this.mSimState = State.READY;
        } else if ("LOCKED".equals(stateExtra)) {
            String lockedReason = intent.getStringExtra("reason");
            if ("PIN".equals(lockedReason)) {
                this.mSimState = State.PIN_REQUIRED;
            } else if ("PUK".equals(lockedReason)) {
                this.mSimState = State.PUK_REQUIRED;
            } else {
                this.mSimState = State.NETWORK_LOCKED;
            }
        } else {
            this.mSimState = State.UNKNOWN;
        }
    }

    private final void updateVolumeZen() {
        AudioManager audioManager = (AudioManager) this.mContext.getSystemService("audio");
        boolean zenVisible = false;
        int zenIconId = 0;
        String zenDescription = null;
        boolean volumeVisible = false;
        int volumeIconId = 0;
        String volumeDescription = null;
        if (DndTile.isVisible(this.mContext) || DndTile.isCombinedIcon(this.mContext)) {
            zenVisible = this.mZen != 0;
            zenIconId = this.mZen == 2 ? 2130837866 : 2130837865;
            zenDescription = this.mContext.getString(2131362167);
        } else if (this.mZen == 2) {
            zenVisible = true;
            zenIconId = 2130838155;
            zenDescription = this.mContext.getString(2131362251);
        } else if (this.mZen == 1) {
            zenVisible = true;
            zenIconId = 2130838154;
            zenDescription = this.mContext.getString(2131362252);
        }
        if (DndTile.isVisible(this.mContext) && !DndTile.isCombinedIcon(this.mContext) && audioManager.getRingerModeInternal() == 0) {
            volumeVisible = true;
            volumeIconId = 2130837914;
            volumeDescription = this.mContext.getString(2131362089);
        } else if (!(this.mZen == 2 || this.mZen == 3 || audioManager.getRingerModeInternal() != 1)) {
            volumeVisible = true;
            volumeIconId = 2130837915;
            volumeDescription = this.mContext.getString(2131362088);
        }
        if (zenVisible) {
            this.mService.setIcon("zen", zenIconId, 0, zenDescription);
        }
        if (zenVisible != this.mZenVisible) {
            this.mService.setIconVisibility("zen", zenVisible);
            this.mZenVisible = zenVisible;
        }
        if (volumeVisible) {
            this.mService.setIcon("volume", volumeIconId, 0, volumeDescription);
        }
        if (volumeVisible != this.mVolumeVisible) {
            this.mService.setIconVisibility("volume", volumeVisible);
            this.mVolumeVisible = volumeVisible;
        }
        updateAlarm();
    }

    public void onBluetoothDevicesChanged() {
        updateBluetooth();
    }

    public void onBluetoothStateChange(boolean enabled) {
        updateBluetooth();
    }

    private final void updateBluetooth() {
        int iconId = 2130837826;
        String contentDescription = this.mContext.getString(2131362121);
        boolean bluetoothEnabled = false;
        if (this.mBluetooth != null) {
            bluetoothEnabled = this.mBluetooth.isBluetoothEnabled();
            if (this.mBluetooth.isBluetoothConnected()) {
                iconId = 2130837827;
                contentDescription = this.mContext.getString(2131362023);
            }
        }
        this.mService.setIcon("bluetooth", iconId, 0, contentDescription);
        this.mService.setIconVisibility("bluetooth", bluetoothEnabled);
    }

    private final void updateTTY(Intent intent) {
        boolean enabled;
        if (intent.getIntExtra("android.telecom.intent.extra.CURRENT_TTY_MODE", 0) != 0) {
            enabled = true;
        } else {
            enabled = false;
        }
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "updateTTY: enabled: " + enabled);
        }
        if (enabled) {
            if (DEBUG) {
                Log.v("PhoneStatusBarPolicy", "updateTTY: set TTY on");
            }
            this.mService.setIcon("tty", 2130838138, 0, this.mContext.getString(2131362087));
            this.mService.setIconVisibility("tty", true);
            return;
        }
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "updateTTY: set TTY off");
        }
        this.mService.setIconVisibility("tty", false);
    }

    private boolean isWiredHeadsetOn() {
        return ((AudioManager) this.mContext.getSystemService("audio")).isWiredHeadsetOn();
    }

    private final void updateTTYMode() {
        boolean enabled;
        if (Secure.getInt(this.mContext.getContentResolver(), "preferred_tty_mode", 0) != 0) {
            enabled = true;
        } else {
            enabled = false;
        }
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "updateTTYMode: enabled: " + enabled);
        }
        if (enabled && isWiredHeadsetOn()) {
            if (DEBUG) {
                Log.v("PhoneStatusBarPolicy", "updateTTYMode: set TTY on");
            }
            this.mService.setIcon("tty", 2130838138, 0, this.mContext.getString(2131362087));
            this.mService.setIconVisibility("tty", true);
            return;
        }
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "updateTTYMode: set TTY off");
        }
        this.mService.setIconVisibility("tty", false);
    }

    private void updateCast() {
        boolean isCasting = false;
        for (CastDevice device : this.mCast.getCastDevices()) {
            if (device.state != 1) {
                if (device.state == 2) {
                }
            }
            isCasting = true;
            break;
        }
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "updateCast: isCasting: " + isCasting);
        }
        this.mHandler.removeCallbacks(this.mRemoveCastIconRunnable);
        if (isCasting) {
            this.mService.setIcon("cast", 2130837825, 0, this.mContext.getString(2131362090));
            this.mService.setIconVisibility("cast", true);
            return;
        }
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "updateCast: hiding icon in 3 sec...");
        }
        this.mHandler.postDelayed(this.mRemoveCastIconRunnable, 3000);
    }

    private void profileChanged(int userId) {
        UserManager userManager = (UserManager) this.mContext.getSystemService("user");
        UserInfo user = null;
        if (userId == -2) {
            try {
                user = ActivityManagerNative.getDefault().getCurrentUser();
            } catch (RemoteException e) {
            }
        } else {
            user = userManager.getUserInfo(userId);
        }
        boolean z = user != null && user.isManagedProfile();
        this.mManagedProfileFocused = z;
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "profileChanged: mManagedProfileFocused: " + this.mManagedProfileFocused);
        }
    }

    private void updateManagedProfile() {
        if (DEBUG) {
            Log.v("PhoneStatusBarPolicy", "updateManagedProfile: mManagedProfileFocused: " + this.mManagedProfileFocused + " mKeyguardVisible: " + this.mKeyguardVisible);
        }
        boolean showIcon = this.mManagedProfileFocused && !this.mKeyguardVisible;
        if (this.mManagedProfileIconVisible != showIcon) {
            this.mService.setIconVisibility("managed_profile", showIcon);
            this.mManagedProfileIconVisible = showIcon;
        }
    }

    public void appTransitionStarting(long startTime, long duration) {
        updateManagedProfile();
    }

    public void setKeyguardShowing(boolean visible) {
        this.mKeyguardVisible = visible;
        updateManagedProfile();
    }

    public void setCurrentUserSetup(boolean userSetup) {
        if (this.mCurrentUserSetup != userSetup) {
            this.mCurrentUserSetup = userSetup;
            updateAlarm();
        }
    }
}
