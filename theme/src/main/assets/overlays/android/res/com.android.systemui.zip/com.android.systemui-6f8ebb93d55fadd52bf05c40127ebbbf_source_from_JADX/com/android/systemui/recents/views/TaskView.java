package com.android.systemui.recents.views;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Region.Op;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewOutlineProvider;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.recents.RecentsConfiguration;
import com.android.systemui.recents.misc.Utilities;
import com.android.systemui.recents.model.Task;
import com.android.systemui.recents.model.Task.TaskCallbacks;
import com.android.systemui.recents.views.ViewAnimation.TaskViewEnterContext;
import com.android.systemui.recents.views.ViewAnimation.TaskViewExitContext;
import com.android.systemui.statusbar.phone.PhoneStatusBar;

public class TaskView extends FrameLayout implements OnClickListener, OnLongClickListener, TaskCallbacks {
    static long sFocusInDurationMs;
    static Interpolator sFocusInInterpolator;
    static Interpolator sFocusInRadiusInterpolator;
    static long sFocusOutDurationMs;
    static Interpolator sFocusOutInterpolator;
    float mActionButtonTranslationZ;
    View mActionButtonView;
    TaskViewCallbacks mCb;
    boolean mClipViewInStack;
    RecentsConfiguration mConfig;
    View mContent;
    int mDimAlpha;
    PorterDuffColorFilter mDimColorFilter;
    AccelerateInterpolator mDimInterpolator;
    Paint mDimLayerPaint;
    int mFocusAlpha;
    boolean mFocusAnimationsEnabled;
    ObjectAnimator mFocusAnimator;
    boolean mFocusAnimatorWasTriggered;
    int mFocusBorderAlpha;
    int mFocusBorderSize;
    int mFocusColor;
    int mFocusInCircleAlpha;
    float mFocusInCircleRadiusProgress;
    int mFocusInFillAlpha;
    int mFocusOutFillAlpha;
    Paint mFocusPaint;
    float mFocusProgress;
    TaskViewHeader mHeaderView;
    boolean mIsFocused;
    float mMaxDimScale;
    Task mTask;
    boolean mTaskDataLoaded;
    float mTaskProgress;
    ObjectAnimator mTaskProgressAnimator;
    TaskViewThumbnail mThumbnailView;
    AnimatorUpdateListener mUpdateDimListener;
    AnimateableViewBounds mViewBounds;

    interface TaskViewCallbacks {
        void onTaskFloatClicked(TaskView taskView);

        void onTaskResize(TaskView taskView);

        void onTaskViewAppInfoClicked(TaskView taskView);

        void onTaskViewClicked(TaskView taskView, Task task, boolean z);

        void onTaskViewClipStateChanged(TaskView taskView);

        void onTaskViewDismissed(TaskView taskView);

        void onTaskViewFocusChanged(TaskView taskView, boolean z);
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.10 */
    class AnonymousClass10 implements Runnable {
        final /* synthetic */ TaskView val$tv;
        final /* synthetic */ View val$v;

        AnonymousClass10(View view, TaskView taskView) {
            this.val$v = view;
            this.val$tv = taskView;
        }

        public void run() {
            if (this.val$v == TaskView.this.mHeaderView.mApplicationIcon) {
                AccessibilityManager am = (AccessibilityManager) TaskView.this.getContext().getSystemService("accessibility");
                if (am != null && am.isEnabled() && TaskView.this.mCb != null) {
                    TaskView.this.mCb.onTaskViewAppInfoClicked(this.val$tv);
                }
            } else if (this.val$v == TaskView.this.mHeaderView.mDismissButton) {
                TaskView.this.dismissTask();
                MetricsLogger.histogram(TaskView.this.getContext(), "overview_task_dismissed_source", 2);
            } else if (this.val$v == TaskView.this.mHeaderView.mFloatButton) {
                if (TaskView.this.mCb != null) {
                    TaskView.this.mCb.onTaskFloatClicked(this.val$tv);
                }
            } else if (this.val$v == TaskView.this.mHeaderView.mMoveTaskButton && TaskView.this.mCb != null) {
                TaskView.this.mCb.onTaskResize(this.val$tv);
            }
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.1 */
    class C02431 implements AnimatorUpdateListener {
        C02431() {
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            TaskView.this.setTaskProgress(((Float) animation.getAnimatedValue()).floatValue());
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.2 */
    class C02442 extends AnimatorListenerAdapter {
        C02442() {
        }

        public void onAnimationStart(Animator animator) {
            TaskView.this.mFocusAnimatorWasTriggered = true;
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.3 */
    class C02453 extends ViewOutlineProvider {
        C02453() {
        }

        public void getOutline(View view, Outline outline) {
            outline.setOval(0, 0, TaskView.this.mActionButtonView.getWidth(), TaskView.this.mActionButtonView.getHeight());
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.5 */
    class C02465 implements Runnable {
        final /* synthetic */ TaskViewEnterContext val$ctx;

        C02465(TaskViewEnterContext taskViewEnterContext) {
            this.val$ctx = taskViewEnterContext;
        }

        public void run() {
            this.val$ctx.postAnimationTrigger.decrement();
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.6 */
    class C02476 implements Runnable {
        final /* synthetic */ TaskViewEnterContext val$ctx;

        C02476(TaskViewEnterContext taskViewEnterContext) {
            this.val$ctx = taskViewEnterContext;
        }

        public void run() {
            this.val$ctx.postAnimationTrigger.decrement();
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.7 */
    class C02487 implements Runnable {
        C02487() {
        }

        public void run() {
            TaskView.this.enableFocusAnimations();
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.8 */
    class C02498 implements Runnable {
        final /* synthetic */ Runnable val$r;

        C02498(Runnable runnable) {
            this.val$r = runnable;
        }

        public void run() {
            if (this.val$r != null) {
                this.val$r.run();
            }
            TaskView.this.setClipViewInStack(true);
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskView.9 */
    class C02509 implements Runnable {
        final /* synthetic */ TaskView val$tv;

        C02509(TaskView taskView) {
            this.val$tv = taskView;
        }

        public void run() {
            if (TaskView.this.mCb != null) {
                TaskView.this.mCb.onTaskViewDismissed(this.val$tv);
            }
        }
    }

    static {
        sFocusInInterpolator = new DecelerateInterpolator(3.0f);
        sFocusInRadiusInterpolator = new DecelerateInterpolator();
        sFocusOutInterpolator = new DecelerateInterpolator();
        sFocusInDurationMs = 350;
        sFocusOutDurationMs = 200;
    }

    public TaskView(Context context) {
        this(context, null);
    }

    public TaskView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TaskView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public TaskView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        this.mDimInterpolator = new AccelerateInterpolator(1.0f);
        this.mDimColorFilter = new PorterDuffColorFilter(0, Mode.SRC_ATOP);
        this.mDimLayerPaint = new Paint();
        this.mFocusPaint = new Paint();
        this.mFocusColor = -16738680;
        this.mFocusAlpha = 64;
        this.mUpdateDimListener = new C02431();
        this.mConfig = RecentsConfiguration.getInstance();
        this.mMaxDimScale = ((float) this.mConfig.taskStackMaxDim) / 255.0f;
        this.mClipViewInStack = true;
        this.mViewBounds = new AnimateableViewBounds(this, this.mConfig.taskViewRoundedCornerRadiusPx);
        setTaskProgress(getTaskProgress());
        setDim(getDim());
        if (this.mConfig.fakeShadows) {
            setBackground(new FakeShadowDrawable(context.getResources(), this.mConfig));
        }
        setOutlineProvider(this.mViewBounds);
        this.mFocusAnimator = ObjectAnimator.ofFloat(this, "focusProgress", new float[]{1.0f});
        this.mFocusAnimator.addListener(new C02442());
        this.mFocusColor = context.getResources().getColor(2131427375);
        this.mFocusPaint.setColor(this.mFocusColor);
        this.mFocusBorderSize = context.getResources().getDimensionPixelSize(2131296355);
    }

    void setCallbacks(TaskViewCallbacks cb) {
        this.mCb = cb;
    }

    void reset() {
        resetViewProperties();
        resetNoUserInteractionState();
        setClipViewInStack(false);
        setCallbacks(null);
        disableFocusAnimations();
    }

    Task getTask() {
        return this.mTask;
    }

    AnimateableViewBounds getViewBounds() {
        return this.mViewBounds;
    }

    protected void onFinishInflate() {
        this.mContent = findViewById(2131755226);
        this.mHeaderView = (TaskViewHeader) findViewById(2131755229);
        this.mThumbnailView = (TaskViewThumbnail) findViewById(2131755227);
        this.mThumbnailView.updateClipToTaskBar(this.mHeaderView);
        this.mActionButtonView = findViewById(2131755228);
        this.mActionButtonView.setOutlineProvider(new C02453());
        this.mActionButtonTranslationZ = this.mActionButtonView.getTranslationZ();
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int widthWithoutPadding = (width - this.mPaddingLeft) - this.mPaddingRight;
        int heightWithoutPadding = (height - this.mPaddingTop) - this.mPaddingBottom;
        this.mContent.measure(MeasureSpec.makeMeasureSpec(widthWithoutPadding, 1073741824), MeasureSpec.makeMeasureSpec(widthWithoutPadding, 1073741824));
        this.mHeaderView.measure(MeasureSpec.makeMeasureSpec(widthWithoutPadding, 1073741824), MeasureSpec.makeMeasureSpec(this.mConfig.taskBarHeight, 1073741824));
        this.mActionButtonView.measure(MeasureSpec.makeMeasureSpec(widthWithoutPadding, Integer.MIN_VALUE), MeasureSpec.makeMeasureSpec(heightWithoutPadding, Integer.MIN_VALUE));
        this.mThumbnailView.measure(MeasureSpec.makeMeasureSpec(widthWithoutPadding, 1073741824), MeasureSpec.makeMeasureSpec(widthWithoutPadding, 1073741824));
        setMeasuredDimension(width, height);
        invalidateOutline();
    }

    void updateViewPropertiesToTaskTransform(TaskViewTransform toTransform, int duration) {
        updateViewPropertiesToTaskTransform(toTransform, duration, null);
    }

    void updateViewPropertiesToTaskTransform(TaskViewTransform toTransform, int duration, AnimatorUpdateListener updateCallback) {
        toTransform.applyToTaskView(this, duration, this.mConfig.fastOutSlowInInterpolator, false, !this.mConfig.fakeShadows, updateCallback);
        Utilities.cancelAnimationWithoutCallbacks(this.mTaskProgressAnimator);
        if (duration <= 0) {
            setTaskProgress(toTransform.f20p);
            return;
        }
        this.mTaskProgressAnimator = ObjectAnimator.ofFloat(this, "taskProgress", new float[]{toTransform.f20p});
        this.mTaskProgressAnimator.setDuration((long) duration);
        this.mTaskProgressAnimator.addUpdateListener(this.mUpdateDimListener);
        this.mTaskProgressAnimator.start();
    }

    void resetViewProperties() {
        unsetFocusedTask();
        setDim(0);
        setLayerType(0, null);
        TaskViewTransform.reset(this);
        if (this.mActionButtonView != null) {
            this.mActionButtonView.setScaleX(1.0f);
            this.mActionButtonView.setScaleY(1.0f);
            this.mActionButtonView.setAlpha(1.0f);
            this.mActionButtonView.setTranslationZ(this.mActionButtonTranslationZ);
        }
    }

    void prepareEnterRecentsAnimation(boolean isTaskViewLaunchTargetTask, boolean occludesLaunchTarget, int offscreenY) {
        int initialDim = getDim();
        if (!this.mConfig.launchedHasConfigurationChanged) {
            if (this.mConfig.launchedFromAppWithThumbnail) {
                if (isTaskViewLaunchTargetTask) {
                    initialDim = 0;
                    this.mActionButtonView.setAlpha(0.0f);
                } else if (occludesLaunchTarget) {
                    setTranslationY((float) offscreenY);
                }
            } else if (this.mConfig.launchedFromHome) {
                setTranslationY((float) offscreenY);
                setTranslationZ(0.0f);
                setScaleX(1.0f);
                setScaleY(1.0f);
            }
        }
        setDim(initialDim);
        this.mThumbnailView.prepareEnterRecentsAnimation(isTaskViewLaunchTargetTask);
    }

    void startEnterRecentsAnimation(TaskViewEnterContext ctx) {
        TaskViewTransform transform = ctx.currentTaskTransform;
        int startDelay = 0;
        if (this.mConfig.launchedFromAppWithThumbnail) {
            if (this.mTask.isLaunchTarget) {
                animateDimToProgress(this.mConfig.transitionEnterFromAppDelay, this.mConfig.taskViewEnterFromAppDuration, ctx.postAnimationTrigger.decrementOnAnimationEnd());
                ctx.postAnimationTrigger.increment();
                fadeInActionButton(this.mConfig.transitionEnterFromAppDelay, this.mConfig.taskViewEnterFromAppDuration);
            } else if (ctx.currentTaskOccludesLaunchTarget) {
                setTranslationY((float) (transform.translationY + this.mConfig.taskViewAffiliateGroupEnterOffsetPx));
                setAlpha(0.0f);
                animate().alpha(1.0f).translationY((float) transform.translationY).setStartDelay((long) this.mConfig.transitionEnterFromAppDelay).setUpdateListener(null).setInterpolator(this.mConfig.fastOutSlowInInterpolator).setDuration((long) this.mConfig.taskViewEnterFromHomeDuration).withEndAction(new C02465(ctx)).start();
                ctx.postAnimationTrigger.increment();
            }
            startDelay = this.mConfig.transitionEnterFromAppDelay;
        } else if (this.mConfig.launchedFromHome) {
            int frontIndex = (ctx.currentStackViewCount - ctx.currentStackViewIndex) - 1;
            int delay = this.mConfig.transitionEnterFromHomeDelay + (this.mConfig.taskViewEnterFromHomeStaggerDelay * frontIndex);
            setScaleX(transform.scale);
            setScaleY(transform.scale);
            if (!this.mConfig.fakeShadows) {
                animate().translationZ(transform.translationZ);
            }
            animate().translationY((float) transform.translationY).setStartDelay((long) delay).setUpdateListener(ctx.updateListener).setInterpolator(this.mConfig.quintOutInterpolator).setDuration((long) (this.mConfig.taskViewEnterFromHomeDuration + (this.mConfig.taskViewEnterFromHomeStaggerDelay * frontIndex))).withEndAction(new C02476(ctx)).start();
            ctx.postAnimationTrigger.increment();
            startDelay = delay;
        }
        postDelayed(new C02487(), (long) startDelay);
    }

    public void fadeInActionButton(int delay, int duration) {
        this.mActionButtonView.setAlpha(0.0f);
        this.mActionButtonView.animate().alpha(1.0f).setStartDelay((long) delay).setDuration((long) duration).setInterpolator(PhoneStatusBar.ALPHA_IN).start();
    }

    void startExitToHomeAnimation(TaskViewExitContext ctx) {
        animate().translationY((float) ctx.offscreenTranslationY).setStartDelay(0).setUpdateListener(null).setInterpolator(this.mConfig.fastOutLinearInInterpolator).setDuration((long) this.mConfig.taskViewExitToHomeDuration).withEndAction(ctx.postAnimationTrigger.decrementAsRunnable()).start();
        ctx.postAnimationTrigger.increment();
    }

    void startLaunchTaskAnimation(Runnable postAnimRunnable, boolean isLaunchingTask, boolean occludesLaunchTarget, boolean lockToTask) {
        if (isLaunchingTask) {
            this.mThumbnailView.startLaunchTaskAnimation(postAnimRunnable);
            if (this.mDimAlpha > 0) {
                ObjectAnimator anim = ObjectAnimator.ofInt(this, "dim", new int[]{0});
                anim.setDuration((long) this.mConfig.taskViewExitToAppDuration);
                anim.setInterpolator(this.mConfig.fastOutLinearInInterpolator);
                anim.start();
            }
            if (!lockToTask) {
                this.mActionButtonView.animate().scaleX(0.9f).scaleY(0.9f);
            }
            this.mActionButtonView.animate().alpha(0.0f).setStartDelay(0).setDuration((long) this.mConfig.taskViewExitToAppDuration).setInterpolator(this.mConfig.fastOutLinearInInterpolator).start();
            return;
        }
        this.mHeaderView.startLaunchTaskDismissAnimation();
        this.mHeaderView.startLaunchFloatButtonAnimation();
        if (occludesLaunchTarget) {
            animate().alpha(0.0f).translationY(getTranslationY() + ((float) this.mConfig.taskViewAffiliateGroupEnterOffsetPx)).setStartDelay(0).setUpdateListener(null).setInterpolator(this.mConfig.fastOutLinearInInterpolator).setDuration((long) this.mConfig.taskViewExitToAppDuration).start();
        }
    }

    void startDeleteTaskAnimation(Runnable r, int delay) {
        setClipViewInStack(false);
        animate().translationX((float) this.mConfig.taskViewRemoveAnimTranslationXPx).alpha(0.0f).setStartDelay((long) delay).setUpdateListener(null).setInterpolator(this.mConfig.fastOutSlowInInterpolator).setDuration((long) this.mConfig.taskViewRemoveAnimDuration).withEndAction(new C02498(r)).start();
    }

    void setTouchEnabled(boolean enabled) {
        setOnClickListener(enabled ? this : null);
    }

    void startNoUserInteractionAnimation() {
        this.mHeaderView.startNoUserInteractionAnimation();
    }

    void setNoUserInteractionState() {
        this.mHeaderView.setNoUserInteractionState();
    }

    void resetNoUserInteractionState() {
        this.mHeaderView.resetNoUserInteractionState();
    }

    void dismissTask() {
        startDeleteTaskAnimation(new C02509(this), 0);
    }

    boolean shouldClipViewInStack() {
        return this.mClipViewInStack && getVisibility() == 0;
    }

    void setClipViewInStack(boolean clip) {
        if (clip != this.mClipViewInStack) {
            this.mClipViewInStack = clip;
            if (this.mCb != null) {
                this.mCb.onTaskViewClipStateChanged(this);
            }
        }
    }

    public void dispatchDraw(Canvas canvas) {
        if (this.mFocusAnimatorWasTriggered) {
            canvas.save(2);
            this.mFocusPaint.setAlpha(this.mFocusBorderAlpha);
            canvas.clipRect((float) (-this.mFocusBorderSize), (float) (-this.mFocusBorderSize), (float) (getWidth() + this.mFocusBorderSize), (float) (getHeight() + this.mFocusBorderSize), Op.REPLACE);
            canvas.drawRoundRect((float) (-this.mFocusBorderSize), (float) (-this.mFocusBorderSize), (float) (getWidth() + this.mFocusBorderSize), (float) (getHeight() + this.mFocusBorderSize), (float) this.mConfig.taskViewRoundedCornerRadiusPx, (float) this.mConfig.taskViewRoundedCornerRadiusPx, this.mFocusPaint);
            canvas.restore();
        }
        super.dispatchDraw(canvas);
        if (!this.mFocusAnimatorWasTriggered) {
            return;
        }
        if (this.mIsFocused) {
            int x = getWidth() / 2;
            int y = getHeight() / 2;
            float radius = ((float) Math.hypot((double) x, (double) y)) * this.mFocusInCircleRadiusProgress;
            this.mFocusPaint.setAlpha(this.mFocusInFillAlpha);
            canvas.drawRect(0.0f, 0.0f, (float) getWidth(), (float) getHeight(), this.mFocusPaint);
            this.mFocusPaint.setAlpha(this.mFocusInCircleAlpha);
            canvas.drawCircle((float) x, (float) y, radius, this.mFocusPaint);
            return;
        }
        this.mFocusPaint.setAlpha(this.mFocusOutFillAlpha);
        canvas.drawRect(0.0f, 0.0f, (float) getWidth(), (float) getHeight(), this.mFocusPaint);
    }

    public void setFocusProgress(float progress) {
        this.mFocusProgress = progress;
        float interpolatedProgress;
        if (this.mIsFocused) {
            interpolatedProgress = sFocusInInterpolator.getInterpolation(progress);
            this.mFocusInCircleRadiusProgress = 0.5f + sFocusInRadiusInterpolator.getInterpolation(progress);
            this.mFocusInCircleAlpha = (int) (((float) this.mFocusAlpha) * interpolatedProgress);
            this.mFocusInFillAlpha = Math.min((this.mFocusAlpha / 4) + ((int) (((float) (this.mFocusAlpha / 2)) * interpolatedProgress)), 255);
            this.mFocusBorderAlpha = Math.min(this.mFocusAlpha + ((int) ((((float) this.mFocusAlpha) * 3.0f) * interpolatedProgress)), 255);
        } else {
            interpolatedProgress = sFocusOutInterpolator.getInterpolation(progress);
            this.mFocusOutFillAlpha = (int) (((float) this.mFocusAlpha) * (1.0f - interpolatedProgress));
            this.mFocusBorderAlpha = Math.min((int) ((((float) this.mFocusAlpha) * 4.0f) * (1.0f - interpolatedProgress)), 255);
        }
        invalidate();
    }

    public float getFocusProgress() {
        return this.mFocusProgress;
    }

    public void setTaskProgress(float p) {
        this.mTaskProgress = p;
        this.mViewBounds.setAlpha(p);
        updateDimFromTaskProgress();
    }

    public float getTaskProgress() {
        return this.mTaskProgress;
    }

    public void setDim(int dim) {
        this.mDimAlpha = dim;
        if (!this.mConfig.useHardwareLayers) {
            float dimAlpha = ((float) this.mDimAlpha) / 255.0f;
            if (this.mThumbnailView != null) {
                this.mThumbnailView.setDimAlpha(dimAlpha);
            }
            if (this.mHeaderView != null) {
                this.mHeaderView.setDimAlpha(dim);
            }
        } else if (getMeasuredWidth() > 0 && getMeasuredHeight() > 0) {
            this.mDimColorFilter.setColor(Color.argb(this.mDimAlpha, 0, 0, 0));
            this.mDimLayerPaint.setColorFilter(this.mDimColorFilter);
            this.mContent.setLayerType(2, this.mDimLayerPaint);
        }
    }

    public int getDim() {
        return this.mDimAlpha;
    }

    void animateDimToProgress(int delay, int duration, AnimatorListener postAnimRunnable) {
        if (getDimFromTaskProgress() != getDim()) {
            ObjectAnimator anim = ObjectAnimator.ofInt(this, "dim", new int[]{getDimFromTaskProgress()});
            anim.setStartDelay((long) delay);
            anim.setDuration((long) duration);
            if (postAnimRunnable != null) {
                anim.addListener(postAnimRunnable);
            }
            anim.start();
        }
    }

    int getDimFromTaskProgress() {
        return (int) (255.0f * (this.mMaxDimScale * this.mDimInterpolator.getInterpolation(1.0f - this.mTaskProgress)));
    }

    void updateDimFromTaskProgress() {
        setDim(getDimFromTaskProgress());
    }

    public void setFocusedTask() {
        if (!this.mIsFocused) {
            this.mIsFocused = true;
            performFocusAnimation();
            this.mThumbnailView.onFocusChanged(true);
            if (this.mCb != null) {
                this.mCb.onTaskViewFocusChanged(this, true);
            }
            setFocusableInTouchMode(true);
            requestFocus();
            setFocusableInTouchMode(false);
            invalidate();
        }
    }

    private void performFocusAnimation() {
        if (this.mFocusAnimationsEnabled) {
            this.mHeaderView.onTaskViewFocusChanged(true);
            this.mFocusAnimator.setDuration(sFocusInDurationMs);
            this.mFocusAnimator.start();
        }
    }

    void unsetFocusedTask() {
        if (this.mIsFocused) {
            this.mIsFocused = false;
            if (this.mFocusAnimationsEnabled) {
                this.mHeaderView.onTaskViewFocusChanged(false);
                this.mFocusAnimator.setDuration(sFocusOutDurationMs);
                this.mFocusAnimator.start();
            }
            this.mThumbnailView.onFocusChanged(false);
            if (this.mCb != null) {
                this.mCb.onTaskViewFocusChanged(this, false);
            }
            invalidate();
        }
    }

    protected void onFocusChanged(boolean gainFocus, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
        if (!gainFocus) {
            unsetFocusedTask();
        }
    }

    public boolean isFocusedTask() {
        return this.mIsFocused;
    }

    void enableFocusAnimations() {
        boolean wasFocusAnimationsEnabled = this.mFocusAnimationsEnabled;
        this.mFocusAnimationsEnabled = true;
        if (this.mIsFocused && !wasFocusAnimationsEnabled) {
            performFocusAnimation();
        }
    }

    void disableFocusAnimations() {
        this.mFocusAnimationsEnabled = false;
        this.mIsFocused = false;
        this.mFocusAnimatorWasTriggered = false;
    }

    public void disableLayersForOneFrame() {
        this.mHeaderView.disableLayersForOneFrame();
    }

    public void onTaskBound(Task t) {
        this.mTask = t;
        this.mTask.setCallbacks(this);
        int lockButtonVisibility = (t.lockToTaskEnabled && t.lockToThisTask) ? 0 : 8;
        if (this.mActionButtonView.getVisibility() != lockButtonVisibility) {
            this.mActionButtonView.setVisibility(lockButtonVisibility);
            requestLayout();
        }
    }

    public void onTaskDataLoaded() {
        if (!(this.mThumbnailView == null || this.mHeaderView == null)) {
            this.mThumbnailView.rebindToTask(this.mTask);
            this.mHeaderView.rebindToTask(this.mTask);
            AccessibilityManager am = (AccessibilityManager) getContext().getSystemService("accessibility");
            if (am != null && am.isEnabled()) {
                this.mHeaderView.mApplicationIcon.setOnClickListener(this);
            }
            this.mHeaderView.mDismissButton.setOnClickListener(this);
            if (this.mConfig.multiStackEnabled) {
                this.mHeaderView.mMoveTaskButton.setOnClickListener(this);
            }
            this.mHeaderView.mFloatButton.setOnClickListener(this);
            this.mActionButtonView.setOnClickListener(this);
            this.mHeaderView.mApplicationIcon.setOnLongClickListener(this);
        }
        this.mTaskDataLoaded = true;
    }

    public void onTaskDataUnloaded() {
        if (!(this.mThumbnailView == null || this.mHeaderView == null)) {
            this.mTask.setCallbacks(null);
            this.mThumbnailView.unbindFromTask();
            this.mHeaderView.unbindFromTask();
            this.mHeaderView.mApplicationIcon.setOnClickListener(null);
            this.mHeaderView.mDismissButton.setOnClickListener(null);
            this.mHeaderView.mFloatButton.setOnClickListener(null);
            if (this.mConfig.multiStackEnabled) {
                this.mHeaderView.mMoveTaskButton.setOnClickListener(null);
            }
            this.mActionButtonView.setOnClickListener(null);
            this.mHeaderView.mApplicationIcon.setOnLongClickListener(null);
        }
        this.mTaskDataLoaded = false;
    }

    public void onClick(View v) {
        boolean delayViewClick;
        boolean z = true;
        TaskView tv = this;
        if (v == this || v == this.mActionButtonView) {
            delayViewClick = false;
        } else {
            delayViewClick = true;
        }
        if (delayViewClick) {
            postDelayed(new AnonymousClass10(v, tv), 125);
            return;
        }
        if (v == this.mActionButtonView) {
            this.mActionButtonView.setTranslationZ(0.0f);
        }
        if (this.mCb != null) {
            TaskViewCallbacks taskViewCallbacks = this.mCb;
            Task task = getTask();
            if (v != this.mActionButtonView) {
                z = false;
            }
            taskViewCallbacks.onTaskViewClicked(tv, task, z);
        }
    }

    public boolean onLongClick(View v) {
        if (v != this.mHeaderView.mApplicationIcon || this.mCb == null) {
            return false;
        }
        this.mCb.onTaskViewAppInfoClicked(this);
        return true;
    }
}
