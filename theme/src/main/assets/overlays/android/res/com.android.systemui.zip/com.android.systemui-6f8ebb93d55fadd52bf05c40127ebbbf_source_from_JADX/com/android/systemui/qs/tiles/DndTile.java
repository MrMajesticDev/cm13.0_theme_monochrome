package com.android.systemui.qs.tiles;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.service.notification.ZenModeConfig;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewGroup;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import com.android.systemui.Prefs;
import com.android.systemui.SysUIToast;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.Icon;
import com.android.systemui.qs.QSTile.ResourceIcon;
import com.android.systemui.statusbar.policy.ZenModeController;
import com.android.systemui.statusbar.policy.ZenModeController.Callback;
import com.android.systemui.volume.ZenModePanel;

public class DndTile extends QSTile<BooleanState> {
    private static final Icon TOTAL_SILENCE;
    private static final Intent ZEN_PRIORITY_SETTINGS;
    private static final Intent ZEN_SETTINGS;
    private final ZenModeController mController;
    private final DndDetailAdapter mDetailAdapter;
    private final AnimationIcon mDisable;
    private final AnimationIcon mDisableTotalSilence;
    private boolean mListening;
    private final OnSharedPreferenceChangeListener mPrefListener;
    private final BroadcastReceiver mReceiver;
    private boolean mShowingDetail;
    private final Callback mZenCallback;
    private final ZenModePanel.Callback mZenModePanelCallback;

    /* renamed from: com.android.systemui.qs.tiles.DndTile.1 */
    class C01871 implements OnSharedPreferenceChangeListener {
        C01871() {
        }

        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            if ("DndTileCombinedIcon".equals(key) || "DndTileVisible".equals(key)) {
                DndTile.this.refreshState();
            }
        }
    }

    /* renamed from: com.android.systemui.qs.tiles.DndTile.2 */
    class C01882 extends Callback {
        C01882() {
        }

        public void onZenChanged(int zen) {
            DndTile.this.refreshState(Integer.valueOf(zen));
        }
    }

    /* renamed from: com.android.systemui.qs.tiles.DndTile.3 */
    class C01893 extends BroadcastReceiver {
        C01893() {
        }

        public void onReceive(Context context, Intent intent) {
            DndTile.setVisible(DndTile.this.mContext, intent.getBooleanExtra("visible", false));
            DndTile.this.refreshState();
        }
    }

    /* renamed from: com.android.systemui.qs.tiles.DndTile.4 */
    class C01904 implements ZenModePanel.Callback {
        C01904() {
        }

        public void onPrioritySettings() {
            DndTile.this.mHost.startActivityDismissingKeyguard(DndTile.ZEN_PRIORITY_SETTINGS);
        }

        public void onInteraction() {
        }

        public void onExpanded(boolean expanded) {
        }
    }

    private final class DndDetailAdapter implements OnAttachStateChangeListener, DetailAdapter {
        private DndDetailAdapter() {
        }

        public int getTitle() {
            return 2131362167;
        }

        public Boolean getToggleState() {
            return Boolean.valueOf(((BooleanState) DndTile.this.mState).value);
        }

        public Intent getSettingsIntent() {
            return DndTile.ZEN_SETTINGS;
        }

        public void setToggleState(boolean state) {
            MetricsLogger.action(DndTile.this.mContext, 166, state);
            if (!state) {
                DndTile.this.mController.setZen(0, null, DndTile.this.TAG);
                DndTile.this.showDetail(false);
            }
        }

        public int getMetricsCategory() {
            return 149;
        }

        public View createDetailView(Context context, View convertView, ViewGroup parent) {
            ZenModePanel zmp = convertView != null ? (ZenModePanel) convertView : (ZenModePanel) LayoutInflater.from(context).inflate(2130968657, parent, false);
            if (convertView == null) {
                zmp.init(DndTile.this.mController);
                zmp.addOnAttachStateChangeListener(this);
                zmp.setCallback(DndTile.this.mZenModePanelCallback);
            }
            return zmp;
        }

        public void onViewAttachedToWindow(View v) {
            DndTile.this.mShowingDetail = true;
        }

        public void onViewDetachedFromWindow(View v) {
            DndTile.this.mShowingDetail = false;
        }
    }

    static {
        ZEN_SETTINGS = new Intent("android.settings.ZEN_MODE_SETTINGS");
        ZEN_PRIORITY_SETTINGS = new Intent("android.settings.ZEN_MODE_PRIORITY_SETTINGS");
        TOTAL_SILENCE = ResourceIcon.get(2130837631);
    }

    public DndTile(Host host) {
        super(host, "dnd");
        this.mDisable = new AnimationIcon(2130837565);
        this.mDisableTotalSilence = new AnimationIcon(2130837568);
        this.mPrefListener = new C01871();
        this.mZenCallback = new C01882();
        this.mReceiver = new C01893();
        this.mZenModePanelCallback = new C01904();
        this.mController = host.getZenModeController();
        this.mDetailAdapter = new DndDetailAdapter();
        this.mContext.registerReceiver(this.mReceiver, new IntentFilter("com.android.systemui.dndtile.SET_VISIBLE"));
    }

    public static void setVisible(Context context, boolean visible) {
        Prefs.putBoolean(context, "DndTileVisible", visible);
    }

    public static boolean isVisible(Context context) {
        return Prefs.getBoolean(context, "DndTileVisible", false);
    }

    public static void setCombinedIcon(Context context, boolean combined) {
        Prefs.putBoolean(context, "DndTileCombinedIcon", combined);
    }

    public static boolean isCombinedIcon(Context context) {
        return Prefs.getBoolean(context, "DndTileCombinedIcon", false);
    }

    public DetailAdapter getDetailAdapter() {
        return this.mDetailAdapter;
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    protected void handleToggleClick() {
        if (this.mController.isVolumeRestricted()) {
            this.mHost.collapsePanels();
            SysUIToast.makeText(this.mContext, this.mContext.getString(17040658), 1).show();
            return;
        }
        boolean z;
        this.mDisable.setAllowAnimation(true);
        this.mDisableTotalSilence.setAllowAnimation(true);
        Context context = this.mContext;
        int metricsCategory = getMetricsCategory();
        if (((BooleanState) this.mState).value) {
            z = false;
        } else {
            z = true;
        }
        MetricsLogger.action(context, metricsCategory, z);
        if (((BooleanState) this.mState).value) {
            this.mController.setZen(0, null, this.TAG);
            return;
        }
        this.mController.setZen(Prefs.getInt(this.mContext, "DndFavoriteZen", 3), null, this.TAG);
        showDetail(true);
    }

    protected void handleDetailClick() {
        showDetail(true);
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        if (ZenModeConfig.hasAlertSlider(this.mContext)) {
            state.visible = false;
            return;
        }
        boolean newValue;
        boolean valueChanged;
        int zen = arg instanceof Integer ? ((Integer) arg).intValue() : this.mController.getZen();
        if (zen != 0) {
            newValue = true;
        } else {
            newValue = false;
        }
        if (state.value != newValue) {
            valueChanged = true;
        } else {
            valueChanged = false;
        }
        state.value = newValue;
        state.visible = isVisible(this.mContext);
        switch (zen) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                state.icon = ResourceIcon.get(2130837630);
                state.label = this.mContext.getString(2131362168);
                state.contentDescription = this.mContext.getString(2131362114);
                break;
            case 2:
                state.icon = TOTAL_SILENCE;
                state.label = this.mContext.getString(2131362170);
                state.contentDescription = this.mContext.getString(2131362115);
                break;
            case 3:
                state.icon = ResourceIcon.get(2130837630);
                state.label = this.mContext.getString(2131362169);
                state.contentDescription = this.mContext.getString(2131362116);
                break;
            default:
                state.icon = TOTAL_SILENCE.equals(state.icon) ? this.mDisableTotalSilence : this.mDisable;
                state.label = this.mContext.getString(2131362167);
                state.contentDescription = this.mContext.getString(2131362117);
                break;
        }
        if (this.mShowingDetail && !state.value) {
            showDetail(false);
        }
        if (valueChanged) {
            fireToggleStateChanged(state.value);
        }
    }

    public int getMetricsCategory() {
        return 118;
    }

    protected String composeChangeAnnouncement() {
        if (((BooleanState) this.mState).value) {
            return this.mContext.getString(2131362119);
        }
        return this.mContext.getString(2131362118);
    }

    public void setListening(boolean listening) {
        if (this.mListening != listening) {
            boolean z = listening && !ZenModeConfig.hasAlertSlider(this.mContext);
            this.mListening = z;
            if (this.mListening) {
                this.mController.addCallback(this.mZenCallback);
                Prefs.registerListener(this.mContext, this.mPrefListener);
                return;
            }
            this.mController.removeCallback(this.mZenCallback);
            Prefs.unregisterListener(this.mContext, this.mPrefListener);
        }
    }
}
