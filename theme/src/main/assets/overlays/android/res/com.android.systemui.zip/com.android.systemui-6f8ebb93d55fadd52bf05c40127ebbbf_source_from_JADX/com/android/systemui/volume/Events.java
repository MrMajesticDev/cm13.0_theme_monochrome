package com.android.systemui.volume;

import com.android.keyguard.C0065R;
import com.android.systemui.volume.VolumeDialogController.State;

public class Events {
    public static final String[] DISMISS_REASONS;
    private static final String[] EVENT_TAGS;
    public static final String[] SHOW_REASONS;
    private static final String TAG;
    public static Callback sCallback;

    public interface Callback {
        void writeEvent(long j, int i, Object[] objArr);

        void writeState(long j, State state);
    }

    static {
        TAG = Util.logTag(Events.class);
        EVENT_TAGS = new String[]{"show_dialog", "dismiss_dialog", "active_stream_changed", "expand", "key", "collection_started", "collection_stopped", "icon_click", "settings_click", "touch_level_changed", "level_changed", "internal_ringer_mode_changed", "external_ringer_mode_changed", "zen_mode_changed", "suppressor_changed", "mute_changed", "touch_level_done"};
        DISMISS_REASONS = new String[]{"unknown", "touch_outside", "volume_controller", "timeout", "screen_off", "settings_clicked", "done_clicked"};
        SHOW_REASONS = new String[]{"unknown", "volume_changed", "remote_volume_changed"};
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void writeEvent(android.content.Context r9, int r10, java.lang.Object... r11) {
        /*
        r8 = 207; // 0xcf float:2.9E-43 double:1.023E-321;
        r7 = 32;
        r4 = 1;
        r5 = 0;
        r2 = java.lang.System.currentTimeMillis();
        r1 = new java.lang.StringBuilder;
        r6 = "writeEvent ";
        r1.<init>(r6);
        r6 = EVENT_TAGS;
        r6 = r6[r10];
        r0 = r1.append(r6);
        if (r11 == 0) goto L_0x002d;
    L_0x001b:
        r1 = r11.length;
        if (r1 <= 0) goto L_0x002d;
    L_0x001e:
        r1 = " ";
        r0.append(r1);
        switch(r10) {
            case 0: goto L_0x0040;
            case 1: goto L_0x0084;
            case 2: goto L_0x0097;
            case 3: goto L_0x0071;
            case 4: goto L_0x010f;
            case 5: goto L_0x0026;
            case 6: goto L_0x0026;
            case 7: goto L_0x00b5;
            case 8: goto L_0x0026;
            case 9: goto L_0x00f4;
            case 10: goto L_0x00f4;
            case 11: goto L_0x0144;
            case 12: goto L_0x0137;
            case 13: goto L_0x0155;
            case 14: goto L_0x0166;
            case 15: goto L_0x00f4;
            case 16: goto L_0x00e7;
            default: goto L_0x0026;
        };
    L_0x0026:
        r1 = java.util.Arrays.asList(r11);
        r0.append(r1);
    L_0x002d:
        r1 = TAG;
        r4 = r0.toString();
        android.util.Log.i(r1, r4);
        r1 = sCallback;
        if (r1 == 0) goto L_0x003f;
    L_0x003a:
        r1 = sCallback;
        r1.writeEvent(r2, r10, r11);
    L_0x003f:
        return;
    L_0x0040:
        com.android.internal.logging.MetricsLogger.visible(r9, r8);
        r6 = "volume_from_keyguard";
        r1 = r11[r4];
        r1 = (java.lang.Boolean) r1;
        r1 = r1.booleanValue();
        if (r1 == 0) goto L_0x006f;
    L_0x004f:
        r1 = r4;
    L_0x0050:
        com.android.internal.logging.MetricsLogger.histogram(r9, r6, r1);
        r6 = SHOW_REASONS;
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = r6[r1];
        r1 = r0.append(r1);
        r5 = " keyguard=";
        r1 = r1.append(r5);
        r4 = r11[r4];
        r1.append(r4);
        goto L_0x002d;
    L_0x006f:
        r1 = r5;
        goto L_0x0050;
    L_0x0071:
        r4 = 208; // 0xd0 float:2.91E-43 double:1.03E-321;
        r1 = r11[r5];
        r1 = (java.lang.Boolean) r1;
        r1 = r1.booleanValue();
        com.android.internal.logging.MetricsLogger.visibility(r9, r4, r1);
        r1 = r11[r5];
        r0.append(r1);
        goto L_0x002d;
    L_0x0084:
        com.android.internal.logging.MetricsLogger.hidden(r9, r8);
        r4 = DISMISS_REASONS;
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = r4[r1];
        r0.append(r1);
        goto L_0x002d;
    L_0x0097:
        r4 = 210; // 0xd2 float:2.94E-43 double:1.04E-321;
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        com.android.internal.logging.MetricsLogger.action(r9, r4, r1);
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = android.media.AudioSystem.streamToString(r1);
        r0.append(r1);
        goto L_0x002d;
    L_0x00b5:
        r6 = 212; // 0xd4 float:2.97E-43 double:1.047E-321;
        r1 = r11[r4];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        com.android.internal.logging.MetricsLogger.action(r9, r6, r1);
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = android.media.AudioSystem.streamToString(r1);
        r1 = r0.append(r1);
        r5 = r1.append(r7);
        r1 = r11[r4];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = iconStateToString(r1);
        r5.append(r1);
        goto L_0x002d;
    L_0x00e7:
        r6 = 209; // 0xd1 float:2.93E-43 double:1.033E-321;
        r1 = r11[r4];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        com.android.internal.logging.MetricsLogger.action(r9, r6, r1);
    L_0x00f4:
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = android.media.AudioSystem.streamToString(r1);
        r1 = r0.append(r1);
        r1 = r1.append(r7);
        r4 = r11[r4];
        r1.append(r4);
        goto L_0x002d;
    L_0x010f:
        r6 = 211; // 0xd3 float:2.96E-43 double:1.042E-321;
        r1 = r11[r4];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        com.android.internal.logging.MetricsLogger.action(r9, r6, r1);
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = android.media.AudioSystem.streamToString(r1);
        r1 = r0.append(r1);
        r1 = r1.append(r7);
        r4 = r11[r4];
        r1.append(r4);
        goto L_0x002d;
    L_0x0137:
        r4 = 213; // 0xd5 float:2.98E-43 double:1.05E-321;
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        com.android.internal.logging.MetricsLogger.action(r9, r4, r1);
    L_0x0144:
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = ringerModeToString(r1);
        r0.append(r1);
        goto L_0x002d;
    L_0x0155:
        r1 = r11[r5];
        r1 = (java.lang.Integer) r1;
        r1 = r1.intValue();
        r1 = zenModeToString(r1);
        r0.append(r1);
        goto L_0x002d;
    L_0x0166:
        r1 = r11[r5];
        r1 = r0.append(r1);
        r1 = r1.append(r7);
        r4 = r11[r4];
        r1.append(r4);
        goto L_0x002d;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.volume.Events.writeEvent(android.content.Context, int, java.lang.Object[]):void");
    }

    public static void writeState(long time, State state) {
        if (sCallback != null) {
            sCallback.writeState(time, state);
        }
    }

    private static String iconStateToString(int iconState) {
        switch (iconState) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return "unmute";
            case 2:
                return "mute";
            case 3:
                return "vibrate";
            default:
                return "unknown_state_" + iconState;
        }
    }

    private static String ringerModeToString(int ringerMode) {
        switch (ringerMode) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                return "silent";
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return "vibrate";
            case 2:
                return "normal";
            default:
                return "unknown";
        }
    }

    private static String zenModeToString(int zenMode) {
        switch (zenMode) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                return "off";
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return "important_interruptions";
            case 2:
                return "no_interruptions";
            case 3:
                return "alarms";
            default:
                return "unknown";
        }
    }
}
