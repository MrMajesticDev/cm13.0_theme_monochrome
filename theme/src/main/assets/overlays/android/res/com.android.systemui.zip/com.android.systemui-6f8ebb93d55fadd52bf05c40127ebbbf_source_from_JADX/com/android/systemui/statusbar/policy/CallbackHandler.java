package com.android.systemui.statusbar.policy;

import android.os.Handler;
import android.os.Message;
import android.telephony.SubscriptionInfo;
import com.android.keyguard.C0065R;
import com.android.systemui.statusbar.policy.NetworkController.IconState;
import com.android.systemui.statusbar.policy.NetworkController.SignalCallback;
import com.android.systemui.statusbar.policy.NetworkControllerImpl.EmergencyListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CallbackHandler extends Handler implements SignalCallback, EmergencyListener {
    private final ArrayList<EmergencyListener> mEmergencyListeners;
    private final ArrayList<SignalCallback> mSignalCallbacks;

    /* renamed from: com.android.systemui.statusbar.policy.CallbackHandler.1 */
    class C04621 implements Runnable {
        final /* synthetic */ boolean val$activityIn;
        final /* synthetic */ boolean val$activityOut;
        final /* synthetic */ String val$description;
        final /* synthetic */ boolean val$enabled;
        final /* synthetic */ IconState val$qsIcon;
        final /* synthetic */ IconState val$statusIcon;

        C04621(boolean z, IconState iconState, IconState iconState2, boolean z2, boolean z3, String str) {
            this.val$enabled = z;
            this.val$statusIcon = iconState;
            this.val$qsIcon = iconState2;
            this.val$activityIn = z2;
            this.val$activityOut = z3;
            this.val$description = str;
        }

        public void run() {
            Iterator i$ = CallbackHandler.this.mSignalCallbacks.iterator();
            while (i$.hasNext()) {
                ((SignalCallback) i$.next()).setWifiIndicators(this.val$enabled, this.val$statusIcon, this.val$qsIcon, this.val$activityIn, this.val$activityOut, this.val$description);
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.CallbackHandler.2 */
    class C04632 implements Runnable {
        final /* synthetic */ boolean val$activityIn;
        final /* synthetic */ boolean val$activityOut;
        final /* synthetic */ int val$dataActivityId;
        final /* synthetic */ String val$description;
        final /* synthetic */ boolean val$isWide;
        final /* synthetic */ int val$mobileActivityId;
        final /* synthetic */ IconState val$qsIcon;
        final /* synthetic */ int val$qsType;
        final /* synthetic */ int val$stackedDataIcon;
        final /* synthetic */ int val$stackedVoiceIcon;
        final /* synthetic */ IconState val$statusIcon;
        final /* synthetic */ int val$statusType;
        final /* synthetic */ int val$subId;
        final /* synthetic */ String val$typeContentDescription;

        C04632(IconState iconState, IconState iconState2, int i, int i2, boolean z, boolean z2, int i3, int i4, int i5, int i6, String str, String str2, boolean z3, int i7) {
            this.val$statusIcon = iconState;
            this.val$qsIcon = iconState2;
            this.val$statusType = i;
            this.val$qsType = i2;
            this.val$activityIn = z;
            this.val$activityOut = z2;
            this.val$dataActivityId = i3;
            this.val$mobileActivityId = i4;
            this.val$stackedDataIcon = i5;
            this.val$stackedVoiceIcon = i6;
            this.val$typeContentDescription = str;
            this.val$description = str2;
            this.val$isWide = z3;
            this.val$subId = i7;
        }

        public void run() {
            Iterator i$ = CallbackHandler.this.mSignalCallbacks.iterator();
            while (i$.hasNext()) {
                ((SignalCallback) i$.next()).setMobileDataIndicators(this.val$statusIcon, this.val$qsIcon, this.val$statusType, this.val$qsType, this.val$activityIn, this.val$activityOut, this.val$dataActivityId, this.val$mobileActivityId, this.val$stackedDataIcon, this.val$stackedVoiceIcon, this.val$typeContentDescription, this.val$description, this.val$isWide, this.val$subId);
            }
        }
    }

    public CallbackHandler() {
        this.mEmergencyListeners = new ArrayList();
        this.mSignalCallbacks = new ArrayList();
    }

    public void handleMessage(Message msg) {
        Iterator i$;
        switch (msg.what) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                i$ = this.mEmergencyListeners.iterator();
                while (i$.hasNext()) {
                    ((EmergencyListener) i$.next()).setEmergencyCallsOnly(msg.arg1 != 0);
                }
            case C0065R.styleable.NumPadKey_textView /*1*/:
                i$ = this.mSignalCallbacks.iterator();
                while (i$.hasNext()) {
                    ((SignalCallback) i$.next()).setSubs((List) msg.obj);
                }
            case 2:
                i$ = this.mSignalCallbacks.iterator();
                while (i$.hasNext()) {
                    ((SignalCallback) i$.next()).setNoSims(msg.arg1 != 0);
                }
            case 3:
                i$ = this.mSignalCallbacks.iterator();
                while (i$.hasNext()) {
                    ((SignalCallback) i$.next()).setEthernetIndicators((IconState) msg.obj);
                }
            case 4:
                i$ = this.mSignalCallbacks.iterator();
                while (i$.hasNext()) {
                    ((SignalCallback) i$.next()).setIsAirplaneMode((IconState) msg.obj);
                }
            case 5:
                i$ = this.mSignalCallbacks.iterator();
                while (i$.hasNext()) {
                    ((SignalCallback) i$.next()).setMobileDataEnabled(msg.arg1 != 0);
                }
            case 6:
                if (msg.arg1 != 0) {
                    this.mEmergencyListeners.add((EmergencyListener) msg.obj);
                } else {
                    this.mEmergencyListeners.remove((EmergencyListener) msg.obj);
                }
            case 7:
                if (msg.arg1 != 0) {
                    this.mSignalCallbacks.add((SignalCallback) msg.obj);
                } else {
                    this.mSignalCallbacks.remove((SignalCallback) msg.obj);
                }
            default:
        }
    }

    public void setWifiIndicators(boolean enabled, IconState statusIcon, IconState qsIcon, boolean activityIn, boolean activityOut, String description) {
        post(new C04621(enabled, statusIcon, qsIcon, activityIn, activityOut, description));
    }

    public void setMobileDataIndicators(IconState statusIcon, IconState qsIcon, int statusType, int qsType, boolean activityIn, boolean activityOut, int dataActivityId, int mobileActivityId, int stackedDataIcon, int stackedVoiceIcon, String typeContentDescription, String description, boolean isWide, int subId) {
        post(new C04632(statusIcon, qsIcon, statusType, qsType, activityIn, activityOut, dataActivityId, mobileActivityId, stackedDataIcon, stackedVoiceIcon, typeContentDescription, description, isWide, subId));
    }

    public void setSubs(List<SubscriptionInfo> subs) {
        obtainMessage(1, subs).sendToTarget();
    }

    public void setNoSims(boolean show) {
        int i;
        if (show) {
            i = 1;
        } else {
            i = 0;
        }
        obtainMessage(2, i, 0).sendToTarget();
    }

    public void setMobileDataEnabled(boolean enabled) {
        int i;
        if (enabled) {
            i = 1;
        } else {
            i = 0;
        }
        obtainMessage(5, i, 0).sendToTarget();
    }

    public void setEmergencyCallsOnly(boolean emergencyOnly) {
        int i;
        if (emergencyOnly) {
            i = 1;
        } else {
            i = 0;
        }
        obtainMessage(0, i, 0).sendToTarget();
    }

    public void setEthernetIndicators(IconState icon) {
        obtainMessage(3, icon).sendToTarget();
    }

    public void setIsAirplaneMode(IconState icon) {
        obtainMessage(4, icon).sendToTarget();
    }

    public void setListening(EmergencyListener listener, boolean listening) {
        int i;
        if (listening) {
            i = 1;
        } else {
            i = 0;
        }
        obtainMessage(6, i, 0, listener).sendToTarget();
    }

    public void setListening(SignalCallback listener, boolean listening) {
        int i;
        if (listening) {
            i = 1;
        } else {
            i = 0;
        }
        obtainMessage(7, i, 0, listener).sendToTarget();
    }
}
