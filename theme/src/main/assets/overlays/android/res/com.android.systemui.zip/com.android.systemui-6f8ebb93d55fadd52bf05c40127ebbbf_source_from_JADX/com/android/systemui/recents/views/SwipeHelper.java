package com.android.systemui.recents.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.annotation.TargetApi;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.animation.LinearInterpolator;
import com.android.keyguard.C0065R;
import com.android.systemui.recents.RecentsConfiguration;

public class SwipeHelper {
    public static float ALPHA_FADE_START;
    private static LinearInterpolator sLinearInterpolator;
    private int DEFAULT_ESCAPE_ANIMATION_DURATION;
    private int MAX_ESCAPE_ANIMATION_DURATION;
    private float SWIPE_ESCAPE_VELOCITY;
    public boolean mAllowSwipeTowardsEnd;
    public boolean mAllowSwipeTowardsStart;
    Callback mCallback;
    private boolean mCanCurrViewBeDimissed;
    private View mCurrView;
    private float mDensityScale;
    private boolean mDragging;
    private float mInitialTouchPos;
    private float mMinAlpha;
    private float mPagingTouchSlop;
    private boolean mRtl;
    private int mSwipeDirection;
    private VelocityTracker mVelocityTracker;

    /* renamed from: com.android.systemui.recents.views.SwipeHelper.1 */
    class C02261 extends AnimatorListenerAdapter {
        final /* synthetic */ boolean val$canAnimViewBeDismissed;
        final /* synthetic */ View val$view;

        C02261(View view, boolean z) {
            this.val$view = view;
            this.val$canAnimViewBeDismissed = z;
        }

        public void onAnimationEnd(Animator animation) {
            SwipeHelper.this.mCallback.onChildDismissed(this.val$view);
            if (this.val$canAnimViewBeDismissed) {
                this.val$view.setAlpha(1.0f);
            }
        }
    }

    /* renamed from: com.android.systemui.recents.views.SwipeHelper.2 */
    class C02272 implements AnimatorUpdateListener {
        final /* synthetic */ boolean val$canAnimViewBeDismissed;
        final /* synthetic */ View val$view;

        C02272(boolean z, View view) {
            this.val$canAnimViewBeDismissed = z;
            this.val$view = view;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            if (this.val$canAnimViewBeDismissed) {
                this.val$view.setAlpha(SwipeHelper.this.getAlphaForOffset(this.val$view));
            }
        }
    }

    /* renamed from: com.android.systemui.recents.views.SwipeHelper.3 */
    class C02283 implements AnimatorUpdateListener {
        final /* synthetic */ boolean val$canAnimViewBeDismissed;
        final /* synthetic */ View val$view;

        C02283(boolean z, View view) {
            this.val$canAnimViewBeDismissed = z;
            this.val$view = view;
        }

        public void onAnimationUpdate(ValueAnimator animation) {
            if (this.val$canAnimViewBeDismissed) {
                this.val$view.setAlpha(SwipeHelper.this.getAlphaForOffset(this.val$view));
            }
            SwipeHelper.this.mCallback.onSwipeChanged(SwipeHelper.this.mCurrView, this.val$view.getTranslationX());
        }
    }

    /* renamed from: com.android.systemui.recents.views.SwipeHelper.4 */
    class C02294 extends AnimatorListenerAdapter {
        final /* synthetic */ boolean val$canAnimViewBeDismissed;
        final /* synthetic */ View val$view;

        C02294(boolean z, View view) {
            this.val$canAnimViewBeDismissed = z;
            this.val$view = view;
        }

        public void onAnimationEnd(Animator animation) {
            if (this.val$canAnimViewBeDismissed) {
                this.val$view.setAlpha(1.0f);
            }
            SwipeHelper.this.mCallback.onSnapBackCompleted(this.val$view);
        }
    }

    public interface Callback {
        boolean canChildBeDismissed(View view);

        View getChildAtPosition(MotionEvent motionEvent);

        void onBeginDrag(View view);

        void onChildDismissed(View view);

        void onDragCancelled(View view);

        void onSnapBackCompleted(View view);

        void onSwipeChanged(View view, float f);
    }

    static {
        sLinearInterpolator = new LinearInterpolator();
        ALPHA_FADE_START = 0.15f;
    }

    public SwipeHelper(int swipeDirection, Callback callback, float densityScale, float pagingTouchSlop) {
        this.SWIPE_ESCAPE_VELOCITY = 100.0f;
        this.DEFAULT_ESCAPE_ANIMATION_DURATION = 75;
        this.MAX_ESCAPE_ANIMATION_DURATION = 150;
        this.mMinAlpha = 0.0f;
        this.mAllowSwipeTowardsStart = true;
        this.mAllowSwipeTowardsEnd = true;
        this.mCallback = callback;
        this.mSwipeDirection = swipeDirection;
        this.mVelocityTracker = VelocityTracker.obtain();
        this.mDensityScale = densityScale;
        this.mPagingTouchSlop = pagingTouchSlop;
    }

    private float getPos(MotionEvent ev) {
        return this.mSwipeDirection == 0 ? ev.getX() : ev.getY();
    }

    private float getTranslation(View v) {
        return this.mSwipeDirection == 0 ? v.getTranslationX() : v.getTranslationY();
    }

    private float getVelocity(VelocityTracker vt) {
        return this.mSwipeDirection == 0 ? vt.getXVelocity() : vt.getYVelocity();
    }

    private ObjectAnimator createTranslationAnimation(View v, float newPos) {
        return ObjectAnimator.ofFloat(v, this.mSwipeDirection == 0 ? View.TRANSLATION_X : View.TRANSLATION_Y, new float[]{newPos});
    }

    private float getPerpendicularVelocity(VelocityTracker vt) {
        return this.mSwipeDirection == 0 ? vt.getYVelocity() : vt.getXVelocity();
    }

    private void setTranslation(View v, float translate) {
        if (this.mSwipeDirection == 0) {
            v.setTranslationX(translate);
        } else {
            v.setTranslationY(translate);
        }
    }

    private float getSize(View v) {
        DisplayMetrics dm = v.getContext().getResources().getDisplayMetrics();
        return this.mSwipeDirection == 0 ? (float) dm.widthPixels : (float) dm.heightPixels;
    }

    public void setMinAlpha(float minAlpha) {
        this.mMinAlpha = minAlpha;
    }

    float getAlphaForOffset(View view) {
        float viewSize = getSize(view);
        float fadeSize = 0.65f * viewSize;
        float result = 1.0f;
        float pos = getTranslation(view);
        if (pos >= ALPHA_FADE_START * viewSize) {
            result = 1.0f - ((pos - (ALPHA_FADE_START * viewSize)) / fadeSize);
        } else if (pos < (1.0f - ALPHA_FADE_START) * viewSize) {
            result = 1.0f + (((ALPHA_FADE_START * viewSize) + pos) / fadeSize);
        }
        return Math.max(this.mMinAlpha, Math.max(Math.min(result, 1.0f), 0.0f));
    }

    @TargetApi(17)
    public static boolean isLayoutRtl(View view) {
        if (VERSION.SDK_INT < 17) {
            return false;
        }
        if (1 == view.getLayoutDirection()) {
            return true;
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                this.mDragging = false;
                this.mCurrView = this.mCallback.getChildAtPosition(ev);
                this.mVelocityTracker.clear();
                if (this.mCurrView == null) {
                    this.mCanCurrViewBeDimissed = false;
                    break;
                }
                this.mRtl = isLayoutRtl(this.mCurrView);
                this.mCanCurrViewBeDimissed = this.mCallback.canChildBeDismissed(this.mCurrView);
                this.mVelocityTracker.addMovement(ev);
                this.mInitialTouchPos = getPos(ev);
                break;
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 3:
                this.mDragging = false;
                this.mCurrView = null;
                break;
            case 2:
                if (this.mCurrView != null) {
                    this.mVelocityTracker.addMovement(ev);
                    float pos = getPos(ev);
                    if (Math.abs(pos - this.mInitialTouchPos) > this.mPagingTouchSlop) {
                        this.mCallback.onBeginDrag(this.mCurrView);
                        this.mDragging = true;
                        this.mInitialTouchPos = pos - getTranslation(this.mCurrView);
                        break;
                    }
                }
                break;
        }
        return this.mDragging;
    }

    private void dismissChild(View view, float velocity) {
        float newPos;
        boolean canAnimViewBeDismissed = this.mCallback.canChildBeDismissed(view);
        if (velocity < 0.0f || ((velocity == 0.0f && getTranslation(view) < 0.0f) || (velocity == 0.0f && getTranslation(view) == 0.0f && this.mSwipeDirection == 1))) {
            newPos = -getSize(view);
        } else {
            newPos = getSize(view);
        }
        int duration = this.MAX_ESCAPE_ANIMATION_DURATION;
        if (velocity != 0.0f) {
            duration = Math.min(duration, (int) ((Math.abs(newPos - getTranslation(view)) * 1000.0f) / Math.abs(velocity)));
        } else {
            duration = this.DEFAULT_ESCAPE_ANIMATION_DURATION;
        }
        ValueAnimator anim = createTranslationAnimation(view, newPos);
        anim.setInterpolator(sLinearInterpolator);
        anim.setDuration((long) duration);
        anim.addListener(new C02261(view, canAnimViewBeDismissed));
        anim.addUpdateListener(new C02272(canAnimViewBeDismissed, view));
        anim.start();
    }

    private void snapChild(View view, float velocity) {
        boolean canAnimViewBeDismissed = this.mCallback.canChildBeDismissed(view);
        ValueAnimator anim = createTranslationAnimation(view, 0.0f);
        anim.setDuration((long) 250);
        anim.setInterpolator(RecentsConfiguration.getInstance().linearOutSlowInInterpolator);
        anim.addUpdateListener(new C02283(canAnimViewBeDismissed, view));
        anim.addListener(new C02294(canAnimViewBeDismissed, view));
        anim.start();
    }

    public boolean onTouchEvent(MotionEvent ev) {
        if (!this.mDragging && !onInterceptTouchEvent(ev)) {
            return this.mCanCurrViewBeDimissed;
        }
        this.mVelocityTracker.addMovement(ev);
        switch (ev.getAction()) {
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 3:
                if (this.mCurrView != null) {
                    endSwipe(this.mVelocityTracker);
                    break;
                }
                break;
            case 2:
            case 4:
                if (this.mCurrView != null) {
                    float delta = getPos(ev) - this.mInitialTouchPos;
                    setSwipeAmount(delta);
                    this.mCallback.onSwipeChanged(this.mCurrView, delta);
                    break;
                }
                break;
        }
        return true;
    }

    private void setSwipeAmount(float amount) {
        if (!(isValidSwipeDirection(amount) && this.mCallback.canChildBeDismissed(this.mCurrView))) {
            float size = getSize(this.mCurrView);
            float maxScrollDistance = 0.15f * size;
            amount = Math.abs(amount) >= size ? amount > 0.0f ? maxScrollDistance : -maxScrollDistance : maxScrollDistance * ((float) Math.sin(((double) (amount / size)) * 1.5707963267948966d));
        }
        setTranslation(this.mCurrView, amount);
        if (this.mCanCurrViewBeDimissed) {
            this.mCurrView.setAlpha(getAlphaForOffset(this.mCurrView));
        }
    }

    private boolean isValidSwipeDirection(float amount) {
        if (this.mSwipeDirection == 0) {
            return this.mRtl ? amount <= 0.0f ? this.mAllowSwipeTowardsEnd : this.mAllowSwipeTowardsStart : amount <= 0.0f ? this.mAllowSwipeTowardsStart : this.mAllowSwipeTowardsEnd;
        } else {
            return true;
        }
    }

    private void endSwipe(VelocityTracker velocityTracker) {
        boolean childSwipedFastEnough;
        boolean dismissChild;
        velocityTracker.computeCurrentVelocity(1000);
        float velocity = getVelocity(velocityTracker);
        float perpendicularVelocity = getPerpendicularVelocity(velocityTracker);
        float escapeVelocity = this.SWIPE_ESCAPE_VELOCITY * this.mDensityScale;
        float translation = getTranslation(this.mCurrView);
        boolean childSwipedFarEnough = ((double) Math.abs(translation)) > 0.6d * ((double) getSize(this.mCurrView));
        if (Math.abs(velocity) > escapeVelocity && Math.abs(velocity) > Math.abs(perpendicularVelocity)) {
            if ((velocity > 0.0f ? 1 : null) == (translation > 0.0f ? 1 : null)) {
                childSwipedFastEnough = true;
                dismissChild = this.mCallback.canChildBeDismissed(this.mCurrView) && isValidSwipeDirection(translation) && (childSwipedFastEnough || childSwipedFarEnough);
                if (dismissChild) {
                    this.mCallback.onDragCancelled(this.mCurrView);
                    snapChild(this.mCurrView, velocity);
                    return;
                }
                View view = this.mCurrView;
                if (!childSwipedFastEnough) {
                    velocity = 0.0f;
                }
                dismissChild(view, velocity);
            }
        }
        childSwipedFastEnough = false;
        if (!this.mCallback.canChildBeDismissed(this.mCurrView)) {
        }
        if (dismissChild) {
            this.mCallback.onDragCancelled(this.mCurrView);
            snapChild(this.mCurrView, velocity);
            return;
        }
        View view2 = this.mCurrView;
        if (childSwipedFastEnough) {
            velocity = 0.0f;
        }
        dismissChild(view2, velocity);
    }
}
