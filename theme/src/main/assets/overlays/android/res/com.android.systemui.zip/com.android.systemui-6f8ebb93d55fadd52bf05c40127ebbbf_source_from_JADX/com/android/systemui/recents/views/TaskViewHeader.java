package com.android.systemui.recents.views;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.systemui.recents.RecentsConfiguration;
import com.android.systemui.recents.misc.SystemServicesProxy;
import com.android.systemui.recents.model.RecentsTaskLoader;
import com.android.systemui.recents.model.Task;

public class TaskViewHeader extends FrameLayout {
    static Paint sHighlightPaint;
    TextView mActivityDescription;
    ImageView mApplicationIcon;
    RippleDrawable mBackground;
    int mBackgroundColor;
    GradientDrawable mBackgroundColorDrawable;
    RecentsConfiguration mConfig;
    int mCurrentPrimaryColor;
    boolean mCurrentPrimaryColorIsDark;
    Drawable mDarkDismissDrawable;
    Drawable mDarkFloatButtonDrawable;
    PorterDuffColorFilter mDimColorFilter;
    Paint mDimLayerPaint;
    ImageView mDismissButton;
    String mDismissContentDescription;
    ImageView mFloatButton;
    ValueAnimator mFocusAnimator;
    float mFocusProgress;
    boolean mIsFocused;
    boolean mLayersDisabled;
    Drawable mLightDismissDrawable;
    Drawable mLightFloatButtonDrawable;
    ImageView mMoveTaskButton;
    private SystemServicesProxy mSsp;
    Task mTask;

    /* renamed from: com.android.systemui.recents.views.TaskViewHeader.1 */
    class C02511 extends ViewOutlineProvider {
        C02511() {
        }

        public void getOutline(View view, Outline outline) {
            outline.setRect(0, 0, TaskViewHeader.this.getMeasuredWidth(), TaskViewHeader.this.getMeasuredHeight());
        }
    }

    /* renamed from: com.android.systemui.recents.views.TaskViewHeader.2 */
    class C02522 implements Runnable {
        C02522() {
        }

        public void run() {
            TaskViewHeader.this.mLayersDisabled = false;
            TaskViewHeader.this.setLayerType(2, TaskViewHeader.this.mDimLayerPaint);
        }
    }

    public TaskViewHeader(Context context) {
        this(context, null);
    }

    public TaskViewHeader(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TaskViewHeader(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public TaskViewHeader(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        this.mDimLayerPaint = new Paint();
        this.mDimColorFilter = new PorterDuffColorFilter(0, Mode.SRC_ATOP);
        this.mConfig = RecentsConfiguration.getInstance();
        this.mSsp = RecentsTaskLoader.getInstance().getSystemServicesProxy();
        setWillNotDraw(false);
        setClipToOutline(true);
        setOutlineProvider(new C02511());
        this.mLightDismissDrawable = context.getDrawable(2130837799);
        this.mDarkDismissDrawable = context.getDrawable(2130837798);
        this.mDismissContentDescription = context.getString(2131362091);
        this.mLightFloatButtonDrawable = context.getDrawable(2130837694);
        this.mDarkFloatButtonDrawable = context.getDrawable(2130837693);
        if (sHighlightPaint == null) {
            sHighlightPaint = new Paint();
            sHighlightPaint.setStyle(Style.STROKE);
            sHighlightPaint.setStrokeWidth((float) this.mConfig.taskViewHighlightPx);
            sHighlightPaint.setColor(this.mConfig.taskBarViewHighlightColor);
            sHighlightPaint.setXfermode(new PorterDuffXfermode(Mode.ADD));
            sHighlightPaint.setAntiAlias(true);
        }
        this.mFocusAnimator = ObjectAnimator.ofFloat(this, "focusProgress", new float[]{1.0f});
    }

    protected void onFinishInflate() {
        this.mApplicationIcon = (ImageView) findViewById(2131755230);
        this.mActivityDescription = (TextView) findViewById(2131755231);
        this.mDismissButton = (ImageView) findViewById(2131755233);
        this.mFloatButton = (ImageView) findViewById(2131755234);
        this.mMoveTaskButton = (ImageView) findViewById(2131755232);
        if (this.mApplicationIcon.getBackground() instanceof RippleDrawable) {
            this.mApplicationIcon.setBackground(null);
        }
        this.mBackgroundColorDrawable = (GradientDrawable) getContext().getDrawable(2130837806);
        this.mBackground = (RippleDrawable) getContext().getDrawable(2130837805);
        this.mBackground = (RippleDrawable) this.mBackground.mutate().getConstantState().newDrawable();
        this.mBackground.setColor(ColorStateList.valueOf(0));
        this.mBackground.setDrawableByLayerId(this.mBackground.getId(0), this.mBackgroundColorDrawable);
        setBackground(this.mBackground);
    }

    protected void onDraw(Canvas canvas) {
        float offset = (float) Math.ceil((double) (((float) this.mConfig.taskViewHighlightPx) / 2.0f));
        float radius = (float) this.mConfig.taskViewRoundedCornerRadiusPx;
        int count = canvas.save(2);
        canvas.clipRect(0, 0, getMeasuredWidth(), getMeasuredHeight());
        canvas.drawRoundRect(-offset, 0.0f, ((float) getMeasuredWidth()) + offset, ((float) getMeasuredHeight()) + radius, radius, radius, sHighlightPaint);
        canvas.restoreToCount(count);
    }

    public boolean hasOverlappingRendering() {
        return false;
    }

    void setDimAlpha(int alpha) {
        this.mDimColorFilter.setColor(Color.argb(alpha, 0, 0, 0));
        this.mDimLayerPaint.setColorFilter(this.mDimColorFilter);
        if (!this.mLayersDisabled) {
            setLayerType(2, this.mDimLayerPaint);
        }
    }

    public void rebindToTask(Task t) {
        int existingBgColor;
        int i = 0;
        this.mTask = t;
        if (t.activityIcon != null) {
            this.mApplicationIcon.setImageDrawable(t.activityIcon);
        } else if (t.applicationIcon != null) {
            this.mApplicationIcon.setImageDrawable(t.applicationIcon);
        }
        if (!this.mActivityDescription.getText().toString().equals(t.activityLabel)) {
            this.mActivityDescription.setText(t.activityLabel);
        }
        this.mActivityDescription.setContentDescription(t.contentDescription);
        if (getBackground() instanceof ColorDrawable) {
            existingBgColor = ((ColorDrawable) getBackground()).getColor();
        } else {
            existingBgColor = 0;
        }
        if (existingBgColor != t.colorPrimary) {
            this.mBackgroundColorDrawable.setColor(t.colorPrimary);
            this.mBackgroundColor = t.colorPrimary;
        }
        this.mCurrentPrimaryColor = t.colorPrimary;
        this.mCurrentPrimaryColorIsDark = t.useLightOnPrimaryColor;
        this.mActivityDescription.setTextColor(t.useLightOnPrimaryColor ? this.mConfig.taskBarViewLightTextColor : this.mConfig.taskBarViewDarkTextColor);
        this.mFloatButton.setImageDrawable(t.useLightOnPrimaryColor ? this.mLightFloatButtonDrawable : this.mDarkFloatButtonDrawable);
        this.mDismissButton.setImageDrawable(t.useLightOnPrimaryColor ? this.mLightDismissDrawable : this.mDarkDismissDrawable);
        this.mDismissButton.setContentDescription(String.format(this.mDismissContentDescription, new Object[]{t.contentDescription}));
        ImageView imageView = this.mMoveTaskButton;
        if (!this.mConfig.multiStackEnabled) {
            i = 4;
        }
        imageView.setVisibility(i);
        if (this.mConfig.multiStackEnabled) {
            updateResizeTaskBarIcon(t);
        }
    }

    void updateResizeTaskBarIcon(Task t) {
        Rect display = this.mSsp.getWindowRect();
        Rect taskRect = this.mSsp.getTaskBounds(t.key.stackId);
        int resId = 2130837818;
        if (display.equals(taskRect) || taskRect.isEmpty()) {
            resId = 2130838165;
        } else {
            boolean top;
            boolean bottom;
            if (display.top == taskRect.top) {
                top = true;
            } else {
                top = false;
            }
            if (display.bottom == taskRect.bottom) {
                bottom = true;
            } else {
                bottom = false;
            }
            boolean left;
            if (display.left == taskRect.left) {
                left = true;
            } else {
                left = false;
            }
            boolean right;
            if (display.right == taskRect.right) {
                right = true;
            } else {
                right = false;
            }
            if (top && bottom && left) {
                resId = 2130838166;
            } else if (top && bottom && right) {
                resId = 2130838167;
            } else if (top && left && right) {
                resId = 2130838168;
            } else if (bottom && left && right) {
                resId = 2130838162;
            } else if (top && right) {
                resId = 2130838170;
            } else if (top && left) {
                resId = 2130838169;
            } else if (bottom && right) {
                resId = 2130838164;
            } else if (bottom && left) {
                resId = 2130838163;
            }
        }
        this.mMoveTaskButton.setImageResource(resId);
    }

    void unbindFromTask() {
        this.mBackground.jumpToCurrentState();
        if (this.mFocusAnimator != null) {
            this.mFocusAnimator.cancel();
        }
        this.mApplicationIcon.setImageDrawable(null);
    }

    void startLaunchTaskDismissAnimation() {
        if (this.mDismissButton.getVisibility() == 0) {
            this.mDismissButton.animate().cancel();
            this.mDismissButton.animate().alpha(0.0f).setStartDelay(0).setInterpolator(this.mConfig.fastOutSlowInInterpolator).setDuration((long) this.mConfig.taskViewExitToAppDuration).start();
        }
    }

    void startLaunchFloatButtonAnimation() {
        if (this.mFloatButton.getVisibility() == 0) {
            this.mFloatButton.animate().cancel();
            this.mFloatButton.animate().alpha(0.0f).setStartDelay(0).setInterpolator(this.mConfig.fastOutSlowInInterpolator).setDuration((long) this.mConfig.taskViewExitToAppDuration).start();
        }
    }

    void startNoUserInteractionAnimation() {
        if (this.mDismissButton.getVisibility() != 0) {
            this.mDismissButton.setVisibility(0);
            this.mDismissButton.setAlpha(0.0f);
            this.mDismissButton.animate().alpha(1.0f).setStartDelay(0).setInterpolator(this.mConfig.fastOutLinearInInterpolator).setDuration((long) this.mConfig.taskViewEnterFromAppDuration).start();
        }
        if (this.mFloatButton.getVisibility() != 0) {
            this.mFloatButton.setVisibility(0);
            this.mFloatButton.setAlpha(0.0f);
            this.mFloatButton.animate().alpha(1.0f).setStartDelay(0).setInterpolator(this.mConfig.fastOutLinearInInterpolator).setDuration((long) this.mConfig.taskViewEnterFromAppDuration).start();
        }
    }

    void setNoUserInteractionState() {
        if (this.mDismissButton.getVisibility() != 0) {
            this.mDismissButton.animate().cancel();
            this.mDismissButton.setVisibility(0);
            this.mDismissButton.setAlpha(1.0f);
        }
        if (this.mFloatButton.getVisibility() != 0) {
            this.mFloatButton.animate().cancel();
            this.mFloatButton.setVisibility(0);
            this.mFloatButton.setAlpha(1.0f);
        }
    }

    void resetNoUserInteractionState() {
        this.mDismissButton.setVisibility(4);
        this.mFloatButton.setVisibility(4);
    }

    protected int[] onCreateDrawableState(int extraSpace) {
        return new int[0];
    }

    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (this.mLayersDisabled) {
            this.mLayersDisabled = false;
            postOnAnimation(new C02522());
        }
    }

    public void disableLayersForOneFrame() {
        this.mLayersDisabled = true;
        setLayerType(0, null);
    }

    public void setFocusProgress(float progress) {
        this.mFocusProgress = progress;
        ArgbEvaluator colorEvaluator = new ArgbEvaluator();
        int desaturatedColor = calculateDesauratedColor(this.mBackgroundColor);
        Integer valueOf = Integer.valueOf(this.mBackgroundColor);
        if (!this.mIsFocused) {
            desaturatedColor = this.mTask.colorPrimary;
        }
        int color = ((Integer) colorEvaluator.evaluate(progress, valueOf, Integer.valueOf(desaturatedColor))).intValue();
        this.mBackgroundColorDrawable.setColor(color);
        this.mBackgroundColor = color;
        if (!this.mIsFocused) {
            progress = 1.0f - progress;
        }
        setTranslationZ(progress * 1.0f);
    }

    public float getFocusProgress() {
        return this.mFocusProgress;
    }

    private int calculateDesauratedColor(int saturatedColor) {
        int sum = (int) (((0.2126f * ((float) Color.red(saturatedColor))) + (0.7152f * ((float) Color.green(saturatedColor)))) + (0.0722f * ((float) Color.blue(saturatedColor))));
        return Color.argb(255, sum, sum, sum);
    }

    void onTaskViewFocusChanged(boolean focused) {
        this.mIsFocused = focused;
        this.mFocusAnimator.setDuration(this.mIsFocused ? TaskView.sFocusInDurationMs : TaskView.sFocusOutDurationMs);
        this.mFocusAnimator.setInterpolator(this.mIsFocused ? TaskView.sFocusInRadiusInterpolator : TaskView.sFocusOutInterpolator);
        this.mFocusAnimator.start();
    }
}
