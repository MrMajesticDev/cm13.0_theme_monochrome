package com.android.systemui;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.ThemeConfig;
import android.os.SystemProperties;
import android.util.Log;
import com.android.systemui.keyboard.KeyboardUI;
import com.android.systemui.keyguard.KeyguardViewMediator;
import com.android.systemui.media.RingtonePlayer;
import com.android.systemui.power.PowerUI;
import com.android.systemui.recents.Recents;
import com.android.systemui.statusbar.SystemBars;
import com.android.systemui.tuner.TunerService;
import com.android.systemui.usb.StorageNotification;
import com.android.systemui.volume.VolumeUI;
import java.util.HashMap;
import java.util.Map;

public class SystemUIApplication extends Application {
    private final Class<?>[] SERVICES;
    private boolean mBootCompleted;
    private final Map<Class<?>, Object> mComponents;
    private Configuration mConfig;
    private final SystemUI[] mServices;
    private boolean mServicesStarted;

    /* renamed from: com.android.systemui.SystemUIApplication.1 */
    class C01011 extends BroadcastReceiver {
        C01011() {
        }

        public void onReceive(Context context, Intent intent) {
            if (!SystemUIApplication.this.mBootCompleted) {
                SystemUIApplication.this.unregisterReceiver(this);
                SystemUIApplication.this.mBootCompleted = true;
                if (SystemUIApplication.this.mServicesStarted) {
                    for (SystemUI onBootCompleted : SystemUIApplication.this.mServices) {
                        onBootCompleted.onBootCompleted();
                    }
                }
            }
        }
    }

    public SystemUIApplication() {
        this.SERVICES = new Class[]{TunerService.class, KeyguardViewMediator.class, Recents.class, VolumeUI.class, SystemBars.class, StorageNotification.class, PowerUI.class, RingtonePlayer.class, KeyboardUI.class};
        this.mServices = new SystemUI[this.SERVICES.length];
        this.mComponents = new HashMap();
    }

    public void onCreate() {
        super.onCreate();
        setTheme(2131492907);
        IntentFilter filter = new IntentFilter("android.intent.action.BOOT_COMPLETED");
        filter.setPriority(1000);
        registerReceiver(new C01011(), filter);
        this.mConfig = new Configuration(getResources().getConfiguration());
    }

    public void startServicesIfNeeded() {
        if (!this.mServicesStarted) {
            if (!this.mBootCompleted && "1".equals(SystemProperties.get("sys.boot_completed"))) {
                this.mBootCompleted = true;
            }
            Log.v("SystemUIService", "Starting SystemUI services.");
            int N = this.SERVICES.length;
            int i = 0;
            while (i < N) {
                try {
                    this.mServices[i] = (SystemUI) this.SERVICES[i].newInstance();
                    this.mServices[i].mContext = this;
                    this.mServices[i].mComponents = this.mComponents;
                    this.mServices[i].start();
                    if (this.mBootCompleted) {
                        this.mServices[i].onBootCompleted();
                    }
                    i++;
                } catch (IllegalAccessException ex) {
                    throw new RuntimeException(ex);
                } catch (InstantiationException ex2) {
                    throw new RuntimeException(ex2);
                }
            }
            this.mServicesStarted = true;
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        if (isThemeChange(this.mConfig, newConfig)) {
            recreateTheme();
        }
        this.mConfig.setTo(newConfig);
        if (this.mServicesStarted) {
            for (SystemUI onConfigurationChanged : this.mServices) {
                onConfigurationChanged.onConfigurationChanged(newConfig);
            }
        }
    }

    public <T> T getComponent(Class<T> interfaceType) {
        return this.mComponents.get(interfaceType);
    }

    public SystemUI[] getServices() {
        return this.mServices;
    }

    private static boolean isThemeChange(Configuration oldConfig, Configuration newConfig) {
        ThemeConfig oldThemeConfig;
        ThemeConfig newThemeConfig = null;
        if (oldConfig != null) {
            oldThemeConfig = oldConfig.themeConfig;
        } else {
            oldThemeConfig = null;
        }
        if (newConfig != null) {
            newThemeConfig = newConfig.themeConfig;
        }
        return (newThemeConfig == null || newThemeConfig.equals(oldThemeConfig)) ? false : true;
    }
}
