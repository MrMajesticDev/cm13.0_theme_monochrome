package com.android.systemui.qs;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class QSDetailItemsList extends LinearLayout {
    private View mEmpty;
    private ImageView mEmptyIcon;
    private TextView mEmptyText;
    private ListView mListView;

    /* renamed from: com.android.systemui.qs.QSDetailItemsList.1 */
    class C01531 implements OnTouchListener {
        C01531() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            return false;
        }
    }

    public QSDetailItemsList(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        this.mTag = "QSDetailItemsList";
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mListView = (ListView) findViewById(16908298);
        this.mListView.setOnTouchListener(new C01531());
        this.mEmpty = findViewById(16908292);
        this.mEmpty.setVisibility(8);
        this.mEmptyText = (TextView) this.mEmpty.findViewById(16908310);
        this.mEmptyIcon = (ImageView) this.mEmpty.findViewById(16908294);
        this.mListView.setEmptyView(this.mEmpty);
    }
}
