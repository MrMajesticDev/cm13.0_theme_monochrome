package com.android.systemui.statusbar.policy;

public interface Listenable {
    void setListening(boolean z);
}
