package com.android.systemui.recents.model;

/* compiled from: TaskStack */
interface TaskFilter {
    boolean acceptTask(Task task, int i);
}
