package com.android.systemui.statusbar.phone;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.HandlerThread;
import android.os.Looper;
import android.provider.Settings.Secure;
import android.util.Log;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.qs.QSTile.Host.Callback;
import com.android.systemui.qs.tiles.AirplaneModeTile;
import com.android.systemui.qs.tiles.AlertSliderTile;
import com.android.systemui.qs.tiles.BluetoothTile;
import com.android.systemui.qs.tiles.CastTile;
import com.android.systemui.qs.tiles.CellularTile;
import com.android.systemui.qs.tiles.ColorInversionTile;
import com.android.systemui.qs.tiles.DndTile;
import com.android.systemui.qs.tiles.FlashlightTile;
import com.android.systemui.qs.tiles.FloatingTile;
import com.android.systemui.qs.tiles.HotspotTile;
import com.android.systemui.qs.tiles.ImmersiveTile;
import com.android.systemui.qs.tiles.IntentTile;
import com.android.systemui.qs.tiles.LocationTile;
import com.android.systemui.qs.tiles.RotationLockTile;
import com.android.systemui.qs.tiles.WifiTile;
import com.android.systemui.statusbar.policy.BluetoothController;
import com.android.systemui.statusbar.policy.CastController;
import com.android.systemui.statusbar.policy.FlashlightController;
import com.android.systemui.statusbar.policy.HotspotController;
import com.android.systemui.statusbar.policy.KeyguardMonitor;
import com.android.systemui.statusbar.policy.LocationController;
import com.android.systemui.statusbar.policy.NetworkController;
import com.android.systemui.statusbar.policy.RotationLockController;
import com.android.systemui.statusbar.policy.SecurityController;
import com.android.systemui.statusbar.policy.UserSwitcherController;
import com.android.systemui.statusbar.policy.ZenModeController;
import com.android.systemui.tuner.TunerService;
import com.android.systemui.tuner.TunerService.Tunable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class QSTileHost implements Host, Tunable {
    private static final boolean DEBUG;
    private final BluetoothController mBluetooth;
    private Callback mCallback;
    private final CastController mCast;
    private final Context mContext;
    private final FlashlightController mFlashlight;
    private final LinkedHashMap<String, QSTile<?>> mHiddenTiles;
    private final HotspotController mHotspot;
    private final KeyguardMonitor mKeyguard;
    private final LocationController mLocation;
    private final Looper mLooper;
    private final NetworkController mNetwork;
    private final RotationLockController mRotation;
    private final SecurityController mSecurity;
    private final PhoneStatusBar mStatusBar;
    private final LinkedHashMap<String, QSTile<?>> mTiles;
    private final UserSwitcherController mUserSwitcherController;
    private final ZenModeController mZen;

    private final class TileSpecsWrapper {
        public final ArrayList<String> hiddenList;
        public final ArrayList<String> list;

        public TileSpecsWrapper() {
            this.list = new ArrayList();
            this.hiddenList = new ArrayList();
        }

        public void add(String tile) {
            if (!tile.isEmpty()) {
                synchronized (this.list) {
                    this.list.add(tile);
                }
            }
        }

        public void addHidden(String hiddenTile) {
            if (!hiddenTile.isEmpty()) {
                synchronized (this.hiddenList) {
                    this.hiddenList.add(hiddenTile);
                }
            }
        }

        public boolean contains(String tile) {
            if (tile.isEmpty()) {
                return true;
            }
            boolean contains;
            synchronized (this.list) {
                contains = this.list.contains(tile);
            }
            return contains;
        }

        public boolean containsHidden(String hiddenTile) {
            if (hiddenTile.isEmpty()) {
                return true;
            }
            boolean contains;
            synchronized (this.hiddenList) {
                contains = this.hiddenList.contains(hiddenTile);
            }
            return contains;
        }

        public String[] get() {
            String[] strArr;
            synchronized (this.list) {
                strArr = (String[]) this.list.toArray(new String[this.list.size()]);
            }
            return strArr;
        }

        public String[] getHidden() {
            String[] strArr;
            synchronized (this.hiddenList) {
                strArr = (String[]) this.hiddenList.toArray(new String[this.hiddenList.size()]);
            }
            return strArr;
        }
    }

    static {
        DEBUG = Log.isLoggable("QSTileHost", 3);
    }

    public QSTileHost(Context context, PhoneStatusBar statusBar, BluetoothController bluetooth, LocationController location, RotationLockController rotation, NetworkController network, ZenModeController zen, HotspotController hotspot, CastController cast, FlashlightController flashlight, UserSwitcherController userSwitcher, KeyguardMonitor keyguard, SecurityController security) {
        this.mTiles = new LinkedHashMap();
        this.mHiddenTiles = new LinkedHashMap();
        this.mContext = context;
        this.mStatusBar = statusBar;
        this.mBluetooth = bluetooth;
        this.mLocation = location;
        this.mRotation = rotation;
        this.mNetwork = network;
        this.mZen = zen;
        this.mHotspot = hotspot;
        this.mCast = cast;
        this.mFlashlight = flashlight;
        this.mUserSwitcherController = userSwitcher;
        this.mKeyguard = keyguard;
        this.mSecurity = security;
        HandlerThread ht = new HandlerThread(QSTileHost.class.getSimpleName(), 10);
        ht.start();
        this.mLooper = ht.getLooper();
        TunerService.get(this.mContext).addTunable((Tunable) this, "sysui_qs_tiles");
    }

    public void destroy() {
        TunerService.get(this.mContext).removeTunable(this);
    }

    public void setCallback(Callback callback) {
        this.mCallback = callback;
    }

    public QSTile<?>[] getTiles() {
        Collection<QSTile<?>> col = this.mTiles.values();
        return (QSTile[]) col.toArray(new QSTile[col.size()]);
    }

    public QSTile<?>[] getHiddenTiles() {
        Collection<QSTile<?>> col = this.mHiddenTiles.values();
        return (QSTile[]) col.toArray(new QSTile[col.size()]);
    }

    public void startActivityDismissingKeyguard(Intent intent) {
        this.mStatusBar.postStartActivityDismissingKeyguard(intent, 0);
    }

    public void startActivityDismissingKeyguard(PendingIntent intent) {
        this.mStatusBar.postStartActivityDismissingKeyguard(intent);
    }

    public void warn(String message, Throwable t) {
    }

    public void collapsePanels() {
        this.mStatusBar.postAnimateCollapsePanels();
    }

    public Looper getLooper() {
        return this.mLooper;
    }

    public Context getContext() {
        return this.mContext;
    }

    public BluetoothController getBluetoothController() {
        return this.mBluetooth;
    }

    public LocationController getLocationController() {
        return this.mLocation;
    }

    public RotationLockController getRotationLockController() {
        return this.mRotation;
    }

    public NetworkController getNetworkController() {
        return this.mNetwork;
    }

    public ZenModeController getZenModeController() {
        return this.mZen;
    }

    public HotspotController getHotspotController() {
        return this.mHotspot;
    }

    public CastController getCastController() {
        return this.mCast;
    }

    public FlashlightController getFlashlightController() {
        return this.mFlashlight;
    }

    public KeyguardMonitor getKeyguardMonitor() {
        return this.mKeyguard;
    }

    public UserSwitcherController getUserSwitcherController() {
        return this.mUserSwitcherController;
    }

    public SecurityController getSecurityController() {
        return this.mSecurity;
    }

    private void destroySpareTiles(LinkedHashMap<String, QSTile<?>> map, TileSpecsWrapper newTileSpecs) {
        for (Entry<String, QSTile<?>> tile : map.entrySet()) {
            if (!(newTileSpecs.contains((String) tile.getKey()) || newTileSpecs.containsHidden((String) tile.getKey()))) {
                if (DEBUG) {
                    Log.d("QSTileHost", "Destroying tile: " + ((String) tile.getKey()));
                }
                ((QSTile) tile.getValue()).destroy();
            }
        }
    }

    private LinkedHashMap<String, QSTile<?>> buildTiles(String[] newTileSpecsList) {
        LinkedHashMap<String, QSTile<?>> newTiles = new LinkedHashMap();
        for (String tileSpec : newTileSpecsList) {
            if (this.mTiles.containsKey(tileSpec)) {
                newTiles.put(tileSpec, this.mTiles.get(tileSpec));
            } else if (this.mHiddenTiles.containsKey(tileSpec)) {
                newTiles.put(tileSpec, this.mHiddenTiles.get(tileSpec));
            } else {
                if (DEBUG) {
                    Log.d("QSTileHost", "Creating tile: " + tileSpec);
                }
                try {
                    newTiles.put(tileSpec, createTile(tileSpec));
                } catch (Throwable t) {
                    Log.w("QSTileHost", "Error creating tile for spec: " + tileSpec, t);
                }
            }
        }
        return newTiles;
    }

    public void onTuningChanged(String key, String newValue) {
        if ("sysui_qs_tiles".equals(key)) {
            boolean tilesChanged;
            if (DEBUG) {
                Log.d("QSTileHost", "Recreating tiles");
            }
            TileSpecsWrapper tileSpecs = loadTileSpecs();
            destroySpareTiles(this.mTiles, tileSpecs);
            destroySpareTiles(this.mHiddenTiles, tileSpecs);
            LinkedHashMap<String, QSTile<?>> newTiles = buildTiles(tileSpecs.get());
            LinkedHashMap<String, QSTile<?>> newHiddenTiles = buildTiles(tileSpecs.getHidden());
            if (Arrays.equals(this.mTiles.keySet().toArray(), newTiles.keySet().toArray())) {
                tilesChanged = false;
            } else {
                tilesChanged = true;
            }
            boolean hiddenTilesChanged;
            if (Arrays.equals(this.mHiddenTiles.keySet().toArray(), newHiddenTiles.keySet().toArray())) {
                hiddenTilesChanged = false;
            } else {
                hiddenTilesChanged = true;
            }
            if (tilesChanged || hiddenTilesChanged) {
                this.mTiles.clear();
                this.mTiles.putAll(newTiles);
                this.mHiddenTiles.clear();
                this.mHiddenTiles.putAll(newHiddenTiles);
                if (this.mCallback != null) {
                    this.mCallback.onTilesChanged();
                }
            }
        }
    }

    private QSTile<?> createTile(String tileSpec) {
        if (tileSpec.equals("wifi")) {
            return new WifiTile(this);
        }
        if (tileSpec.equals("bt")) {
            return new BluetoothTile(this);
        }
        if (tileSpec.equals("inversion")) {
            return new ColorInversionTile(this);
        }
        if (tileSpec.equals("cell")) {
            return new CellularTile(this);
        }
        if (tileSpec.equals("airplane")) {
            return new AirplaneModeTile(this);
        }
        if (tileSpec.equals("dnd")) {
            return new DndTile(this);
        }
        if (tileSpec.equals("rotation")) {
            return new RotationLockTile(this);
        }
        if (tileSpec.equals("flashlight")) {
            return new FlashlightTile(this);
        }
        if (tileSpec.equals("location")) {
            return new LocationTile(this);
        }
        if (tileSpec.equals("cast")) {
            return new CastTile(this);
        }
        if (tileSpec.equals("hotspot")) {
            return new HotspotTile(this);
        }
        if (tileSpec.equals("immersive")) {
            return new ImmersiveTile(this);
        }
        if (tileSpec.equals("floating")) {
            return new FloatingTile(this);
        }
        if (tileSpec.equals("alertslider")) {
            return new AlertSliderTile(this);
        }
        if (tileSpec.startsWith("intent(")) {
            return IntentTile.create(this, tileSpec);
        }
        throw new IllegalArgumentException("Bad tile spec: " + tileSpec);
    }

    public TileSpecsWrapper loadTileSpecs() {
        TileSpecsWrapper tileSpecsWrapper = new TileSpecsWrapper();
        String[] defaultParts = this.mContext.getResources().getString(2131361879).split(",,");
        String defaultTiles = defaultParts[0];
        int length = defaultParts.length;
        String defaultHiddenTiles = r0 > 1 ? defaultParts[1] : "";
        if (DEBUG) {
            Log.d("QSTileHost", "Loaded default tile specs: [" + defaultTiles + "]" + "[" + defaultHiddenTiles + "]");
        }
        String setting = Secure.getStringForUser(this.mContext.getContentResolver(), "sysui_qs_tiles", ActivityManager.getCurrentUser());
        String tiles;
        String hiddenTiles;
        if (setting != null) {
            String[] settingParts = setting.split(",,");
            tiles = settingParts[0];
            length = settingParts.length;
            hiddenTiles = r0 > 1 ? settingParts[1] : "";
            if (DEBUG) {
                Log.d("QSTileHost", "Using pre-existing tile specs: [" + tiles + "]" + "[" + hiddenTiles + "]");
            }
        } else {
            tiles = "default";
            hiddenTiles = "";
            if (DEBUG) {
                Log.d("QSTileHost", "No pre-existing tile specs found. Using defaults.");
            }
        }
        for (String tile : tiles.split(",")) {
            tileSpecsWrapper.add(tile.trim());
        }
        for (String hiddenTile : hiddenTiles.split(",")) {
            tileSpecsWrapper.addHidden(hiddenTile.trim());
        }
        for (String defaultTile : defaultTiles.split(",")) {
            String defaultTile2 = defaultTile2.trim();
            if (!(tileSpecsWrapper.contains(defaultTile2) || tileSpecsWrapper.containsHidden(defaultTile2))) {
                tileSpecsWrapper.add(defaultTile2);
            }
        }
        for (String defaultHiddenTile : defaultHiddenTiles.split(",")) {
            String defaultHiddenTile2 = defaultHiddenTile2.trim();
            if (!(tileSpecsWrapper.contains(defaultHiddenTile2) || tileSpecsWrapper.containsHidden(defaultHiddenTile2))) {
                tileSpecsWrapper.addHidden(defaultHiddenTile2);
            }
        }
        return tileSpecsWrapper;
    }
}
