package com.android.systemui;

import android.service.dreams.DreamService;
import com.android.systemui.DessertCaseView.RescalingContainer;

public class DessertCaseDream extends DreamService {
    private RescalingContainer mContainer;
    private DessertCaseView mView;

    /* renamed from: com.android.systemui.DessertCaseDream.1 */
    class C00861 implements Runnable {
        C00861() {
        }

        public void run() {
            DessertCaseDream.this.mView.start();
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        this.mView = new DessertCaseView(this);
        this.mContainer = new RescalingContainer(this);
        this.mContainer.setView(this.mView);
        setContentView(this.mContainer);
    }

    public void onDreamingStarted() {
        super.onDreamingStarted();
        this.mView.postDelayed(new C00861(), 1000);
    }

    public void onDreamingStopped() {
        super.onDreamingStopped();
        this.mView.stop();
    }
}
