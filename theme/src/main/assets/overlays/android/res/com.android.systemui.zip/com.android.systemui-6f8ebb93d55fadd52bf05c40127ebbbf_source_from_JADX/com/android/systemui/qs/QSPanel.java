package com.android.systemui.qs;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.internal.logging.MetricsLogger;
import com.android.keyguard.C0065R;
import com.android.systemui.FontSizeUtils;
import com.android.systemui.qs.QSTile.DetailAdapter;
import com.android.systemui.qs.QSTile.State;
import com.android.systemui.settings.BrightnessController;
import com.android.systemui.settings.CurrentUserTracker;
import com.android.systemui.settings.ToggleSlider;
import com.android.systemui.statusbar.phone.QSTileHost;
import com.android.systemui.statusbar.policy.BrightnessMirrorController;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class QSPanel extends ViewGroup {
    private BrightnessController mBrightnessController;
    private int mBrightnessPaddingTop;
    private final View mBrightnessView;
    private Callback mCallback;
    private int mCellHeight;
    private int mCellWidth;
    private final QSDetailClipper mClipper;
    private boolean mClosingDetail;
    private int mColumns;
    private final Context mContext;
    private final View mDetail;
    private final ViewGroup mDetailContent;
    private final TextView mDetailDoneButton;
    private Record mDetailRecord;
    private final TextView mDetailSettingsButton;
    private int mDualCount;
    private int mDualTileUnderlap;
    private boolean mExpanded;
    private QSFooter mFooter;
    private boolean mGridContentVisible;
    private int mGridHeight;
    private final C0167H mHandler;
    private int mHiddenRowCount;
    private final TextView mHiddenTilesInfo;
    private final AnimatorListenerAdapter mHideGridContentWhenDone;
    private QSTileHost mHost;
    private int mLargeCellHeight;
    private int mLargeCellWidth;
    private boolean mListening;
    private int mPanelPaddingBottom;
    private final ArrayList<TileRecord> mRecords;
    private int mRowCount;
    private boolean mShowingHidden;
    private final AnimatorListenerAdapter mTeardownDetailWhenDone;
    private final CurrentUserTracker mUserTracker;

    /* renamed from: com.android.systemui.qs.QSPanel.10 */
    class AnonymousClass10 implements OnClickListener {
        final /* synthetic */ Intent val$settingsIntent;

        AnonymousClass10(Intent intent) {
            this.val$settingsIntent = intent;
        }

        public void onClick(View v) {
            QSPanel.this.mHost.startActivityDismissingKeyguard(this.val$settingsIntent);
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.1 */
    class C01581 implements OnClickListener {
        C01581() {
        }

        public void onClick(View v) {
            QSPanel.this.announceForAccessibility(QSPanel.this.mContext.getString(2131362098));
            QSPanel.this.closeDetail();
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.2 */
    class C01592 extends CurrentUserTracker {
        C01592(Context x0) {
            super(x0);
        }

        public void onUserSwitched(int newUserId) {
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.3 */
    class C01603 implements OnDragListener {
        C01603() {
        }

        public boolean onDrag(View v, DragEvent event) {
            TileRecord localState = event.getLocalState();
            if (!(localState instanceof TileRecord)) {
                return false;
            }
            TileRecord r = localState;
            switch (event.getAction()) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    return true;
                case 2:
                    float x = event.getX();
                    float y = event.getY();
                    if (QSPanel.this.getLayoutDirection() == 1) {
                    }
                    int w = QSPanel.this.getWidth();
                    int row = 0;
                    while (row < QSPanel.this.mRowCount) {
                        int top = QSPanel.this.getRowTop(row, false);
                        int ch = (row != 0 || r.hidden) ? QSPanel.this.mCellHeight : QSPanel.this.mLargeCellHeight;
                        if (y > ((float) top) && y < ((float) (top + ch))) {
                            int cols = QSPanel.this.getPlannedColumnCount(row, false);
                            int cw = (row != 0 || r.hidden) ? QSPanel.this.mCellWidth : QSPanel.this.mLargeCellWidth;
                            int col = 0;
                            while (col < cols) {
                                int left = QSPanel.this.getColLeft(row, col, false);
                                if (x <= ((float) left) || x >= ((float) (left + cw))) {
                                    col++;
                                } else {
                                    if (!(r.row == row && r.col == col)) {
                                        QSPanel.this.setTilePosition(r, row, col);
                                    }
                                    return true;
                                }
                            }
                            continue;
                        }
                        row++;
                    }
                    return true;
                case 3:
                case 5:
                case 6:
                    return true;
                case 4:
                    QSPanel.this.mCallback.onReorderMode(false);
                    if (r.hidden == QSPanel.this.mShowingHidden) {
                        r.anim.drop();
                    }
                    QSPanel.this.setTileInteractive(r, r.hidden == QSPanel.this.mShowingHidden);
                    return true;
                default:
                    return false;
            }
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.4 */
    class C01614 implements com.android.systemui.qs.QSTile.Host.Callback {
        C01614() {
        }

        public void onTilesChanged() {
            QSPanel.this.setTiles();
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.5 */
    class C01625 implements Runnable {
        final /* synthetic */ View val$hidingTopView;

        C01625(View view) {
            this.val$hidingTopView = view;
        }

        public void run() {
            this.val$hidingTopView.setVisibility(4);
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.6 */
    class C01636 implements com.android.systemui.qs.QSTile.Callback {
        final /* synthetic */ TileRecord val$r;

        C01636(TileRecord tileRecord) {
            this.val$r = tileRecord;
        }

        public void onStateChanged(State state) {
            if (!this.val$r.openingDetail) {
                QSPanel.this.drawTile(this.val$r, state);
            }
        }

        public void onShowDetail(boolean show) {
            QSPanel.this.showDetail(show, this.val$r);
        }

        public void onToggleStateChanged(boolean state) {
            if (QSPanel.this.mDetailRecord == this.val$r) {
                QSPanel.this.fireToggleStateChanged(state);
            }
        }

        public void onScanStateChanged(boolean state) {
            this.val$r.scanState = state;
            if (QSPanel.this.mDetailRecord == this.val$r) {
                QSPanel.this.fireScanStateChanged(this.val$r.scanState);
            }
        }

        public void onAnnouncementRequested(CharSequence announcement) {
            QSPanel.this.announceForAccessibility(announcement);
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.7 */
    class C01647 implements OnClickListener {
        final /* synthetic */ TileRecord val$r;

        C01647(TileRecord tileRecord) {
            this.val$r = tileRecord;
        }

        public void onClick(View v) {
            this.val$r.tile.click(this.val$r.tileView.isDual());
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.8 */
    class C01658 implements OnClickListener {
        final /* synthetic */ TileRecord val$r;

        C01658(TileRecord tileRecord) {
            this.val$r = tileRecord;
        }

        public void onClick(View v) {
            this.val$r.tile.secondaryClick();
        }
    }

    /* renamed from: com.android.systemui.qs.QSPanel.9 */
    class C01669 implements OnLongClickListener {
        final /* synthetic */ TileRecord val$r;

        C01669(TileRecord tileRecord) {
            this.val$r = tileRecord;
        }

        public boolean onLongClick(View v) {
            QSPanel.this.showHidden(false);
            if (this.val$r.hidden) {
                this.val$r.hidden = false;
                QSPanel.this.setTileInteractive(this.val$r, true);
                TileRecord tileRecord = this.val$r;
                this.val$r.col = -1;
                tileRecord.row = -1;
                int newRow = QSPanel.this.countRows() - 1;
                if (newRow < 0) {
                    newRow = 0;
                }
                QSPanel.this.setTilePosition(this.val$r, newRow, QSPanel.this.getPlannedColumnCount(newRow, false) - 1);
            }
            this.val$r.anim.lift();
            String tileName = this.val$r.tile.getClass().getSimpleName();
            this.val$r.tileView.startDrag(ClipData.newPlainText("QSTile." + tileName, tileName), this.val$r.tileView.getDragShadowBuilder(), this.val$r, 0);
            QSPanel.this.mCallback.onReorderMode(true);
            return true;
        }
    }

    public interface Callback {
        void onAbleToShowHidden(boolean z);

        void onReorderMode(boolean z);

        void onScanStateChanged(boolean z);

        void onShowingDetail(DetailAdapter detailAdapter);

        void onShowingHidden(boolean z);

        void onToggleStateChanged(boolean z);
    }

    /* renamed from: com.android.systemui.qs.QSPanel.H */
    private class C0167H extends Handler {
        private C0167H() {
        }

        public void handleMessage(Message msg) {
            boolean z = true;
            if (msg.what == 1) {
                QSPanel qSPanel = QSPanel.this;
                Record record = (Record) msg.obj;
                if (msg.arg1 == 0) {
                    z = false;
                }
                qSPanel.handleShowDetail(record, z);
            } else if (msg.what == 2) {
                QSPanel.this.handleSetTileVisibility((View) msg.obj, msg.arg1);
            }
        }
    }

    private static class Record {
        DetailAdapter detailAdapter;
        View detailView;
        int f18x;
        int f19y;

        private Record() {
        }
    }

    private final class TileAnimator {
        private final LinkedList<TileAnimationAction> mAnimations;
        private boolean mLiftOngoing;
        private final AnimatorListenerAdapter mListener;
        private final WeakReference<TileRecord> mRecordRef;
        private final Object mSync;

        /* renamed from: com.android.systemui.qs.QSPanel.TileAnimator.1 */
        class C01681 extends AnimatorListenerAdapter {
            C01681() {
            }

            private void onQueueEnd() {
                synchronized (TileAnimator.this.mSync) {
                    TileAnimator.this.getRecord().tileView.setAlpha(TileAnimator.this.mLiftOngoing ? 0.0f : 1.0f);
                }
            }

            public void onAnimationEnd(Animator animation) {
                synchronized (TileAnimator.this.mSync) {
                    TileRecord record = TileAnimator.this.getRecord();
                    TileAnimationAction head = (TileAnimationAction) TileAnimator.this.mAnimations.peek();
                    if (head == null) {
                        onQueueEnd();
                        return;
                    }
                    if (animation.equals(head.getAnimation())) {
                        TileAnimator.this.mAnimations.poll();
                    }
                    if (TileAnimator.this.mAnimations.peek() == null) {
                        onQueueEnd();
                        return;
                    }
                    LinkedList<TileAnimationAction> taas = new LinkedList();
                    TileAnimationAction lastTaa = (TileAnimationAction) TileAnimator.this.mAnimations.poll();
                    while (lastTaa != null) {
                        TileAnimationAction taa = (TileAnimationAction) TileAnimator.this.mAnimations.poll();
                        if (taa == null) {
                            taas.add(lastTaa);
                        } else if (lastTaa.actionId != taa.actionId) {
                            taas.add(lastTaa);
                        }
                        lastTaa = taa;
                    }
                    TileAnimator.this.mAnimations.addAll(taas);
                    TileAnimator.this.startNext();
                }
            }
        }

        private final class TileAnimationAction {
            public final int actionId;
            private Animator animation;
            private boolean instant;
            private boolean ksed;
            public final int tgtCol;
            public final int tgtRow;

            /* renamed from: com.android.systemui.qs.QSPanel.TileAnimator.TileAnimationAction.1 */
            class C01691 implements AnimatorUpdateListener {
                final /* synthetic */ int val$rowCellHeight;
                final /* synthetic */ int val$rowCellWidth;
                final /* synthetic */ boolean val$rowDual;
                final /* synthetic */ int val$srcTop;
                final /* synthetic */ QSTileView val$view;

                C01691(QSTileView qSTileView, boolean z, int i, int i2, int i3) {
                    this.val$view = qSTileView;
                    this.val$rowDual = z;
                    this.val$rowCellWidth = i;
                    this.val$rowCellHeight = i2;
                    this.val$srcTop = i3;
                }

                public void onAnimationUpdate(ValueAnimator animation) {
                    synchronized (this.val$view) {
                        this.val$view.setDual(this.val$rowDual);
                        this.val$view.measure(QSPanel.exactly(this.val$rowCellWidth), QSPanel.exactly(this.val$rowCellHeight));
                        int left = ((Integer) animation.getAnimatedValue()).intValue();
                        this.val$view.layout(left, this.val$srcTop, this.val$rowCellWidth + left, this.val$srcTop + this.val$rowCellHeight);
                    }
                }
            }

            /* renamed from: com.android.systemui.qs.QSPanel.TileAnimator.TileAnimationAction.2 */
            class C01702 implements AnimatorUpdateListener {
                final /* synthetic */ int val$ndRowCellHeight;
                final /* synthetic */ int val$ndRowCellWidth;
                final /* synthetic */ boolean val$ndRowDual;
                final /* synthetic */ int val$tgtTop;
                final /* synthetic */ QSTileView val$view;

                C01702(QSTileView qSTileView, boolean z, int i, int i2, int i3) {
                    this.val$view = qSTileView;
                    this.val$ndRowDual = z;
                    this.val$ndRowCellWidth = i;
                    this.val$ndRowCellHeight = i2;
                    this.val$tgtTop = i3;
                }

                public void onAnimationUpdate(ValueAnimator animation) {
                    synchronized (this.val$view) {
                        this.val$view.setDual(this.val$ndRowDual);
                        this.val$view.measure(QSPanel.exactly(this.val$ndRowCellWidth), QSPanel.exactly(this.val$ndRowCellHeight));
                        int left = ((Integer) animation.getAnimatedValue()).intValue();
                        this.val$view.layout(left, this.val$tgtTop, this.val$ndRowCellWidth + left, this.val$tgtTop + this.val$ndRowCellHeight);
                    }
                }
            }

            public TileAnimationAction(int actionId, int tgtRow, int tgtCol) {
                this.animation = null;
                this.ksed = false;
                this.instant = false;
                this.actionId = actionId;
                this.tgtRow = tgtRow;
                this.tgtCol = tgtCol;
            }

            private ObjectAnimator in(View view, long dur) {
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{0.0f, 1.0f});
                if (this.instant) {
                    dur = 0;
                }
                return ofFloat.setDuration(dur);
            }

            private ObjectAnimator out(View view, long dur) {
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{1.0f, 0.0f});
                if (this.instant) {
                    dur = 0;
                }
                return ofFloat.setDuration(dur);
            }

            public Animator getAnimation() {
                return this.animation;
            }

            public void kickstart() {
                synchronized (TileAnimator.this.mSync) {
                    if (this.ksed) {
                        throw new IllegalStateException("ksed == true");
                    }
                    TileRecord record = TileAnimator.this.getRecord();
                    if (this.actionId == 2) {
                        if (record.row == -1 || record.col == -1) {
                            this.instant = true;
                        }
                        record.row = this.tgtRow;
                        record.col = this.tgtCol;
                    }
                    TileAnimationAction runningTaa = TileAnimator.this.getRunning();
                    TileAnimator.this.mAnimations.add(this);
                    if (runningTaa == null) {
                        TileAnimator.this.startNext();
                    } else if (runningTaa.actionId == 2) {
                        runningTaa.animation.cancel();
                        TileAnimator.this.startNext();
                    }
                    this.ksed = true;
                }
            }

            /* JADX WARNING: inconsistent code. */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public boolean start() {
                /*
                r37 = this;
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;
                r36 = r4.mSync;
                monitor-enter(r36);
                r0 = r37;
                r4 = r0.animation;	 Catch:{ all -> 0x0017 }
                if (r4 == 0) goto L_0x001a;
            L_0x000f:
                r4 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x0017 }
                r5 = "animation != null";
                r4.<init>(r5);	 Catch:{ all -> 0x0017 }
                throw r4;	 Catch:{ all -> 0x0017 }
            L_0x0017:
                r4 = move-exception;
                monitor-exit(r36);	 Catch:{ all -> 0x0017 }
                throw r4;
            L_0x001a:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r26 = r4.getRecord();	 Catch:{ all -> 0x0017 }
                r0 = r26;
                r6 = r0.tileView;	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r4 = r0.actionId;	 Catch:{ all -> 0x0017 }
                switch(r4) {
                    case 0: goto L_0x0050;
                    case 1: goto L_0x0072;
                    case 2: goto L_0x0094;
                    default: goto L_0x002d;
                };	 Catch:{ all -> 0x0017 }
            L_0x002d:
                r0 = r37;
                r4 = r0.animation;	 Catch:{ all -> 0x0017 }
                if (r4 != 0) goto L_0x02dd;
            L_0x0033:
                r4 = new java.lang.IllegalStateException;	 Catch:{ all -> 0x0017 }
                r5 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0017 }
                r5.<init>();	 Catch:{ all -> 0x0017 }
                r11 = "animation == null for actionId=";
                r5 = r5.append(r11);	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r11 = r0.actionId;	 Catch:{ all -> 0x0017 }
                r5 = r5.append(r11);	 Catch:{ all -> 0x0017 }
                r5 = r5.toString();	 Catch:{ all -> 0x0017 }
                r4.<init>(r5);	 Catch:{ all -> 0x0017 }
                throw r4;	 Catch:{ all -> 0x0017 }
            L_0x0050:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.mLiftOngoing;	 Catch:{ all -> 0x0017 }
                if (r4 == 0) goto L_0x006f;
            L_0x005a:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r5 = 0;
                r4.mLiftOngoing = r5;	 Catch:{ all -> 0x0017 }
                r4 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
                r0 = r37;
                r4 = r0.in(r6, r4);	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r0.animation = r4;	 Catch:{ all -> 0x0017 }
                goto L_0x002d;
            L_0x006f:
                r4 = 0;
                monitor-exit(r36);	 Catch:{ all -> 0x0017 }
            L_0x0071:
                return r4;
            L_0x0072:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.mLiftOngoing;	 Catch:{ all -> 0x0017 }
                if (r4 == 0) goto L_0x007f;
            L_0x007c:
                r4 = 0;
                monitor-exit(r36);	 Catch:{ all -> 0x0017 }
                goto L_0x0071;
            L_0x007f:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r5 = 1;
                r4.mLiftOngoing = r5;	 Catch:{ all -> 0x0017 }
                r4 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
                r0 = r37;
                r4 = r0.out(r6, r4);	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r0.animation = r4;	 Catch:{ all -> 0x0017 }
                goto L_0x002d;
            L_0x0094:
                r0 = r26;
                r0 = r0.hidden;	 Catch:{ all -> 0x0017 }
                r20 = r0;
                r10 = r6.getTop();	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r5 = r0.tgtRow;	 Catch:{ all -> 0x0017 }
                r0 = r20;
                r17 = r4.getRowTop(r5, r0);	 Catch:{ all -> 0x0017 }
                r33 = -1;
                if (r20 == 0) goto L_0x01a7;
            L_0x00b2:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r27 = r4.mHiddenRowCount;	 Catch:{ all -> 0x0017 }
            L_0x00bc:
                if (r27 < 0) goto L_0x00d0;
            L_0x00be:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r0 = r27;
                r1 = r20;
                r4 = r4.getRowTop(r0, r1);	 Catch:{ all -> 0x0017 }
                if (r4 != r10) goto L_0x01b3;
            L_0x00ce:
                r33 = r27;
            L_0x00d0:
                r32 = r6.getLeft();	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r5 = r0.tgtRow;	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r11 = r0.tgtCol;	 Catch:{ all -> 0x0017 }
                r0 = r20;
                r34 = r4.getColLeft(r5, r11, r0);	 Catch:{ all -> 0x0017 }
                r31 = -1;
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r0 = r33;
                r1 = r20;
                r18 = r4.getPlannedColumnCount(r0, r1);	 Catch:{ all -> 0x0017 }
            L_0x00f8:
                if (r18 < 0) goto L_0x0110;
            L_0x00fa:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r0 = r33;
                r1 = r18;
                r2 = r20;
                r4 = r4.getColLeft(r0, r1, r2);	 Catch:{ all -> 0x0017 }
                r0 = r32;
                if (r4 != r0) goto L_0x01b7;
            L_0x010e:
                r31 = r18;
            L_0x0110:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r35 = r4.getWidth();	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.getLayoutDirection();	 Catch:{ all -> 0x0017 }
                r5 = 1;
                if (r4 != r5) goto L_0x01bb;
            L_0x0127:
                r22 = 1;
            L_0x0129:
                r0 = r17;
                if (r10 <= r0) goto L_0x01bf;
            L_0x012d:
                r21 = 1;
            L_0x012f:
                if (r20 != 0) goto L_0x01c3;
            L_0x0131:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r5 = 0;
                r11 = 0;
                r4 = r4.getRowTop(r5, r11);	 Catch:{ all -> 0x0017 }
                if (r4 != r10) goto L_0x01c3;
            L_0x013f:
                r7 = 1;
            L_0x0140:
                r29 = r32;
                r0 = r17;
                if (r10 != r0) goto L_0x01c6;
            L_0x0146:
                r30 = r34;
            L_0x0148:
                if (r7 == 0) goto L_0x01f1;
            L_0x014a:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r8 = r4.mLargeCellWidth;	 Catch:{ all -> 0x0017 }
            L_0x0154:
                if (r7 == 0) goto L_0x01fd;
            L_0x0156:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r9 = r4.mLargeCellHeight;	 Catch:{ all -> 0x0017 }
            L_0x0160:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.mLiftOngoing;	 Catch:{ all -> 0x0017 }
                if (r4 != 0) goto L_0x0170;
            L_0x016a:
                r4 = r6.getVisibility();	 Catch:{ all -> 0x0017 }
                if (r4 == 0) goto L_0x0175;
            L_0x0170:
                r4 = 1;
                r0 = r37;
                r0.instant = r4;	 Catch:{ all -> 0x0017 }
            L_0x0175:
                r4 = 2;
                r4 = new int[r4];	 Catch:{ all -> 0x0017 }
                r5 = 0;
                r4[r5] = r29;	 Catch:{ all -> 0x0017 }
                r5 = 1;
                r4[r5] = r30;	 Catch:{ all -> 0x0017 }
                r28 = android.animation.ValueAnimator.ofInt(r4);	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r4 = r0.instant;	 Catch:{ all -> 0x0017 }
                if (r4 == 0) goto L_0x0209;
            L_0x0188:
                r4 = 0;
            L_0x018a:
                r0 = r28;
                r0.setDuration(r4);	 Catch:{ all -> 0x0017 }
                r4 = new com.android.systemui.qs.QSPanel$TileAnimator$TileAnimationAction$1;	 Catch:{ all -> 0x0017 }
                r5 = r37;
                r4.<init>(r6, r7, r8, r9, r10);	 Catch:{ all -> 0x0017 }
                r0 = r28;
                r0.addUpdateListener(r4);	 Catch:{ all -> 0x0017 }
                r0 = r17;
                if (r10 != r0) goto L_0x0217;
            L_0x019f:
                r0 = r28;
                r1 = r37;
                r1.animation = r0;	 Catch:{ all -> 0x0017 }
                goto L_0x002d;
            L_0x01a7:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r27 = r4.mRowCount;	 Catch:{ all -> 0x0017 }
                goto L_0x00bc;
            L_0x01b3:
                r27 = r27 + -1;
                goto L_0x00bc;
            L_0x01b7:
                r18 = r18 + -1;
                goto L_0x00f8;
            L_0x01bb:
                r22 = 0;
                goto L_0x0129;
            L_0x01bf:
                r21 = 0;
                goto L_0x012f;
            L_0x01c3:
                r7 = 0;
                goto L_0x0140;
            L_0x01c6:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r5 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                if (r21 == 0) goto L_0x01d9;
            L_0x01ce:
                r4 = -1;
            L_0x01cf:
                r0 = r33;
                r1 = r20;
                r30 = r5.getColLeft(r0, r4, r1);	 Catch:{ all -> 0x0017 }
                goto L_0x0148;
            L_0x01d9:
                if (r7 == 0) goto L_0x01e6;
            L_0x01db:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.mDualCount;	 Catch:{ all -> 0x0017 }
                goto L_0x01cf;
            L_0x01e6:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.mColumns;	 Catch:{ all -> 0x0017 }
                goto L_0x01cf;
            L_0x01f1:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r8 = r4.mCellWidth;	 Catch:{ all -> 0x0017 }
                goto L_0x0154;
            L_0x01fd:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r9 = r4.mCellHeight;	 Catch:{ all -> 0x0017 }
                goto L_0x0160;
            L_0x0209:
                r4 = r29 - r30;
                r4 = java.lang.Math.abs(r4);	 Catch:{ all -> 0x0017 }
                r4 = (long) r4;	 Catch:{ all -> 0x0017 }
                r12 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
                r4 = r4 * r12;
                r12 = (long) r8;	 Catch:{ all -> 0x0017 }
                r4 = r4 / r12;
                goto L_0x018a;
            L_0x0217:
                if (r20 != 0) goto L_0x02aa;
            L_0x0219:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r5 = 0;
                r11 = 0;
                r4 = r4.getRowTop(r5, r11);	 Catch:{ all -> 0x0017 }
                r0 = r17;
                if (r4 != r0) goto L_0x02aa;
            L_0x0229:
                r14 = 1;
            L_0x022a:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r5 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r11 = r0.tgtRow;	 Catch:{ all -> 0x0017 }
                if (r21 == 0) goto L_0x02b8;
            L_0x0236:
                if (r14 == 0) goto L_0x02ad;
            L_0x0238:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.mDualCount;	 Catch:{ all -> 0x0017 }
            L_0x0242:
                r0 = r20;
                r24 = r5.getColLeft(r11, r4, r0);	 Catch:{ all -> 0x0017 }
                r25 = r34;
                if (r14 == 0) goto L_0x02ba;
            L_0x024c:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r15 = r4.mLargeCellWidth;	 Catch:{ all -> 0x0017 }
            L_0x0256:
                if (r14 == 0) goto L_0x02c5;
            L_0x0258:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r16 = r4.mLargeCellHeight;	 Catch:{ all -> 0x0017 }
            L_0x0262:
                r4 = 2;
                r4 = new int[r4];	 Catch:{ all -> 0x0017 }
                r5 = 0;
                r4[r5] = r24;	 Catch:{ all -> 0x0017 }
                r5 = 1;
                r4[r5] = r25;	 Catch:{ all -> 0x0017 }
                r23 = android.animation.ValueAnimator.ofInt(r4);	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r4 = r0.instant;	 Catch:{ all -> 0x0017 }
                if (r4 == 0) goto L_0x02d0;
            L_0x0275:
                r4 = 0;
            L_0x0277:
                r0 = r23;
                r0.setDuration(r4);	 Catch:{ all -> 0x0017 }
                r11 = new com.android.systemui.qs.QSPanel$TileAnimator$TileAnimationAction$2;	 Catch:{ all -> 0x0017 }
                r12 = r37;
                r13 = r6;
                r11.<init>(r13, r14, r15, r16, r17);	 Catch:{ all -> 0x0017 }
                r0 = r23;
                r0.addUpdateListener(r11);	 Catch:{ all -> 0x0017 }
                r19 = new android.animation.AnimatorSet;	 Catch:{ all -> 0x0017 }
                r19.<init>();	 Catch:{ all -> 0x0017 }
                r0 = r19;
                r1 = r28;
                r0.play(r1);	 Catch:{ all -> 0x0017 }
                r0 = r19;
                r1 = r23;
                r4 = r0.play(r1);	 Catch:{ all -> 0x0017 }
                r0 = r28;
                r4.after(r0);	 Catch:{ all -> 0x0017 }
                r0 = r19;
                r1 = r37;
                r1.animation = r0;	 Catch:{ all -> 0x0017 }
                goto L_0x002d;
            L_0x02aa:
                r14 = 0;
                goto L_0x022a;
            L_0x02ad:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r4 = r4.mColumns;	 Catch:{ all -> 0x0017 }
                goto L_0x0242;
            L_0x02b8:
                r4 = -1;
                goto L_0x0242;
            L_0x02ba:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r15 = r4.mCellWidth;	 Catch:{ all -> 0x0017 }
                goto L_0x0256;
            L_0x02c5:
                r0 = r37;
                r4 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r4 = com.android.systemui.qs.QSPanel.this;	 Catch:{ all -> 0x0017 }
                r16 = r4.mCellHeight;	 Catch:{ all -> 0x0017 }
                goto L_0x0262;
            L_0x02d0:
                r4 = r24 - r25;
                r4 = java.lang.Math.abs(r4);	 Catch:{ all -> 0x0017 }
                r4 = (long) r4;	 Catch:{ all -> 0x0017 }
                r12 = 300; // 0x12c float:4.2E-43 double:1.48E-321;
                r4 = r4 * r12;
                r12 = (long) r15;	 Catch:{ all -> 0x0017 }
                r4 = r4 / r12;
                goto L_0x0277;
            L_0x02dd:
                r0 = r37;
                r4 = r0.animation;	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r5 = com.android.systemui.qs.QSPanel.TileAnimator.this;	 Catch:{ all -> 0x0017 }
                r5 = r5.mListener;	 Catch:{ all -> 0x0017 }
                r4.addListener(r5);	 Catch:{ all -> 0x0017 }
                r0 = r37;
                r4 = r0.animation;	 Catch:{ all -> 0x0017 }
                r4.start();	 Catch:{ all -> 0x0017 }
                r4 = 1;
                monitor-exit(r36);	 Catch:{ all -> 0x0017 }
                goto L_0x0071;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.qs.QSPanel.TileAnimator.TileAnimationAction.start():boolean");
            }
        }

        public TileAnimator(TileRecord record, boolean liftOngoing) {
            this.mAnimations = new LinkedList();
            this.mListener = new C01681();
            this.mSync = new Object();
            this.mLiftOngoing = false;
            this.mRecordRef = new WeakReference(record);
            this.mLiftOngoing = liftOngoing;
        }

        private TileRecord getRecord() {
            TileRecord record = (TileRecord) this.mRecordRef.get();
            if (record == null) {
                throw new IllegalStateException("This tile reference has been cleared.");
            } else if (record.anim == this) {
                return record;
            } else {
                throw new IllegalStateException("This tile animator has been dereferenced.");
            }
        }

        public TileAnimationAction getRunning() {
            TileAnimationAction q;
            synchronized (this.mSync) {
                q = (TileAnimationAction) this.mAnimations.peek();
                if (q == null) {
                    q = null;
                } else if (q.getAnimation() != null) {
                } else {
                    startNext();
                    q = getRunning();
                }
            }
            return q;
        }

        private void startNext() {
            synchronized (this.mSync) {
                TileAnimationAction head = (TileAnimationAction) this.mAnimations.peek();
                if (head == null) {
                } else if (head.getAnimation() != null) {
                } else {
                    if (!head.start()) {
                        this.mAnimations.poll();
                        startNext();
                    }
                }
            }
        }

        public void lift() {
            new TileAnimationAction(1, -1, -1).kickstart();
        }

        public void drop() {
            new TileAnimationAction(0, -1, -1).kickstart();
        }

        public void move(int tgtRow, int tgtCol) {
            new TileAnimationAction(2, tgtRow, tgtCol).kickstart();
        }
    }

    private static final class TileRecord extends Record {
        TileAnimator anim;
        int col;
        boolean hidden;
        boolean openingDetail;
        int row;
        boolean scanState;
        QSTile<?> tile;
        QSTileView tileView;

        private TileRecord() {
            super();
            this.row = -1;
            this.col = -1;
        }
    }

    public QSPanel(Context context) {
        this(context, null);
    }

    public QSPanel(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mRecords = new ArrayList();
        this.mHandler = new C0167H();
        this.mRowCount = 0;
        this.mHiddenRowCount = 0;
        this.mDualCount = 0;
        this.mShowingHidden = false;
        this.mGridContentVisible = true;
        this.mTeardownDetailWhenDone = new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator animation) {
                QSPanel.this.mDetailContent.removeAllViews();
                QSPanel.this.setDetailRecord(null);
                QSPanel.this.mClosingDetail = false;
            }
        };
        this.mHideGridContentWhenDone = new AnimatorListenerAdapter() {
            public void onAnimationCancel(Animator animation) {
                animation.removeListener(this);
                redrawTile();
            }

            public void onAnimationEnd(Animator animation) {
                if (QSPanel.this.mDetailRecord != null) {
                    QSPanel.this.setGridContentVisibility(true);
                    redrawTile();
                }
            }

            private void redrawTile() {
                if (QSPanel.this.mDetailRecord instanceof TileRecord) {
                    TileRecord tileRecord = (TileRecord) QSPanel.this.mDetailRecord;
                    tileRecord.openingDetail = false;
                    QSPanel.this.drawTile(tileRecord, tileRecord.tile.getState());
                }
            }
        };
        this.mContext = context;
        this.mDetail = LayoutInflater.from(context).inflate(2130968611, this, false);
        this.mDetailContent = (ViewGroup) this.mDetail.findViewById(16908290);
        this.mDetailSettingsButton = (TextView) this.mDetail.findViewById(16908314);
        this.mDetailDoneButton = (TextView) this.mDetail.findViewById(16908313);
        updateDetailText();
        this.mDetail.setVisibility(8);
        this.mDetail.setClickable(true);
        this.mBrightnessView = LayoutInflater.from(context).inflate(2130968619, this, false);
        this.mHiddenTilesInfo = (TextView) LayoutInflater.from(context).inflate(2130968621, this, false);
        this.mHiddenTilesInfo.setAlpha(0.0f);
        this.mHiddenTilesInfo.setVisibility(4);
        this.mFooter = new QSFooter(this, context);
        addView(this.mDetail);
        addView(this.mBrightnessView);
        addView(this.mHiddenTilesInfo);
        addView(this.mFooter.getView());
        this.mClipper = new QSDetailClipper(this.mDetail);
        updateResources();
        this.mBrightnessController = new BrightnessController(getContext(), (ImageView) findViewById(2131755205), (ToggleSlider) findViewById(2131755206));
        this.mDetailDoneButton.setOnClickListener(new C01581());
        CurrentUserTracker c01592 = new C01592(this.mContext);
        this.mUserTracker = c01592;
        c01592.startTracking();
        setOnDragListener(new C01603());
    }

    private void updateDetailText() {
        this.mDetailDoneButton.setText(2131362206);
        this.mDetailSettingsButton.setText(2131362205);
    }

    public void setBrightnessMirror(BrightnessMirrorController c) {
        super.onFinishInflate();
        ToggleSlider brightnessSlider = (ToggleSlider) findViewById(2131755206);
        brightnessSlider.setMirror((ToggleSlider) c.getMirror().findViewById(2131755206));
        brightnessSlider.setMirrorController(c);
    }

    public void setCallback(Callback callback) {
        this.mCallback = callback;
        if (callback != null) {
            callback.onAbleToShowHidden(this.mHiddenRowCount != 0);
        }
    }

    public synchronized void setHost(QSTileHost host) {
        if (this.mHost != null) {
            host.setCallback(null);
        }
        this.mHost = host;
        this.mFooter.setHost(host);
        host.setCallback(new C01614());
        setTiles();
    }

    public QSTileHost getHost() {
        return this.mHost;
    }

    public void updateResources() {
        Resources res = this.mContext.getResources();
        int columns = Math.max(1, res.getInteger(2131623946));
        int dualCount = Math.max(0, res.getInteger(2131623947));
        this.mCellHeight = res.getDimensionPixelSize(2131296312);
        this.mCellWidth = (int) (((float) this.mCellHeight) * 1.2f);
        this.mLargeCellHeight = res.getDimensionPixelSize(2131296317);
        this.mLargeCellWidth = (int) (((float) this.mLargeCellHeight) * 1.2f);
        this.mPanelPaddingBottom = res.getDimensionPixelSize(2131296325);
        this.mDualTileUnderlap = res.getDimensionPixelSize(2131296318);
        this.mBrightnessPaddingTop = res.getDimensionPixelSize(2131296327);
        if (this.mColumns != columns) {
            this.mColumns = columns;
            postInvalidate();
        }
        if (this.mDualCount != dualCount) {
            this.mDualCount = dualCount;
            postInvalidate();
        }
        Iterator i$ = this.mRecords.iterator();
        while (i$.hasNext()) {
            ((TileRecord) i$.next()).tile.clearState();
        }
        if (this.mListening) {
            refreshAllTiles();
        }
        updateDetailText();
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        FontSizeUtils.updateFontSize(this.mDetailDoneButton, 2131296329);
        FontSizeUtils.updateFontSize(this.mDetailSettingsButton, 2131296329);
        synchronized (this.mRecords) {
            int count = this.mRecords.size();
            for (int i = 0; i < count; i++) {
                View detailView = ((TileRecord) this.mRecords.get(i)).detailView;
                if (detailView != null) {
                    detailView.dispatchConfigurationChanged(newConfig);
                }
            }
        }
        this.mFooter.onConfigurationChanged();
    }

    public void setExpanded(boolean expanded) {
        if (this.mExpanded != expanded) {
            this.mExpanded = expanded;
            MetricsLogger.visibility(this.mContext, 111, this.mExpanded);
            if (this.mExpanded) {
                logTiles();
                return;
            }
            closeDetail();
            showHidden(false);
        }
    }

    public void setListening(boolean listening) {
        if (this.mListening != listening) {
            this.mListening = listening;
            synchronized (this.mRecords) {
                Iterator i$ = this.mRecords.iterator();
                while (i$.hasNext()) {
                    ((TileRecord) i$.next()).tile.setListening(this.mListening);
                }
            }
            this.mFooter.setListening(this.mListening);
            if (this.mListening) {
                refreshAllTiles();
            }
            if (listening) {
                this.mBrightnessController.registerCallbacks();
            } else {
                this.mBrightnessController.unregisterCallbacks();
            }
        }
    }

    public void refreshAllTiles() {
        synchronized (this.mRecords) {
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                ((TileRecord) i$.next()).tile.refreshState();
            }
        }
        this.mFooter.refreshState();
    }

    public void showDetailAdapter(boolean show, DetailAdapter adapter, int[] locationInWindow) {
        int xInWindow = locationInWindow[0];
        int yInWindow = locationInWindow[1];
        this.mDetail.getLocationInWindow(locationInWindow);
        Record r = new Record();
        r.detailAdapter = adapter;
        r.f18x = xInWindow - locationInWindow[0];
        r.f19y = yInWindow - locationInWindow[1];
        locationInWindow[0] = xInWindow;
        locationInWindow[1] = yInWindow;
        showDetail(show, r);
    }

    private void showDetail(boolean show, Record r) {
        int i;
        C0167H c0167h = this.mHandler;
        if (show) {
            i = 1;
        } else {
            i = 0;
        }
        c0167h.obtainMessage(1, i, 0, r).sendToTarget();
    }

    private void setTileVisibility(View v, int visibility) {
        this.mHandler.obtainMessage(2, visibility, 0, v).sendToTarget();
    }

    private void handleSetTileVisibility(View v, int visibility) {
        if (visibility == 0 && !this.mGridContentVisible) {
            visibility = 4;
        }
        if (visibility != v.getVisibility()) {
            v.setVisibility(visibility);
        }
    }

    public void setTiles() {
        synchronized (this.mRecords) {
            TileRecord[] oldTileRecords = (TileRecord[]) this.mRecords.toArray(new TileRecord[this.mRecords.size()]);
            QSTile<?>[] newTiles = this.mHost.getTiles();
            QSTile<?>[] newHiddenTiles = this.mHost.getHiddenTiles();
            if (oldTileRecords.length == newTiles.length + newHiddenTiles.length) {
                boolean allMatch = true;
                int i = 0;
                while (i < oldTileRecords.length) {
                    if (oldTileRecords[i].hidden != (i >= newTiles.length)) {
                        allMatch = false;
                        break;
                    }
                    if (i >= newTiles.length) {
                        boolean matchFound = false;
                        for (QSTile<?> t : newHiddenTiles) {
                            if (oldTileRecords[i].tile.equals(t)) {
                                matchFound = true;
                                break;
                            }
                        }
                        if (!matchFound) {
                            allMatch = false;
                            break;
                        }
                    } else if (!oldTileRecords[i].tile.equals(newTiles[i])) {
                        allMatch = false;
                        break;
                    }
                    i++;
                }
                if (allMatch) {
                    return;
                }
            }
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                removeView(((TileRecord) i$.next()).tileView);
            }
            this.mRecords.clear();
            for (QSTile<?> tile : newTiles) {
                addTile(tile, false);
            }
            for (QSTile<?> tile2 : newHiddenTiles) {
                addTile(tile2, true);
            }
            if (isShowingDetail()) {
                this.mDetail.bringToFront();
            }
        }
    }

    public void hideTile(Object o) {
        if (o instanceof TileRecord) {
            synchronized (this.mRecords) {
                TileRecord r = (TileRecord) o;
                int oldLastRow = this.mRowCount - 1;
                setTilePosition(r, oldLastRow, getPlannedColumnCount(oldLastRow, false));
                int oldRowCount = this.mRowCount;
                this.mCallback.onReorderMode(false);
                r.hidden = true;
                setTileInteractive(r, this.mShowingHidden);
                int lastRow = countRows() - 1;
                if (r.row >= lastRow) {
                    int orc = -1;
                    Iterator i$ = this.mRecords.iterator();
                    while (i$.hasNext()) {
                        TileRecord or = (TileRecord) i$.next();
                        if (or.row == lastRow && !or.hidden) {
                            if (or.tileView.getVisibility() != 8) {
                                orc++;
                            }
                            or.anim.move(lastRow, orc);
                        }
                    }
                }
                if (this.mRowCount != oldRowCount) {
                    requestLayout();
                    postInvalidate();
                }
                r.col = -1;
                r.row = -1;
                setHiddenTilePositions();
                int newRow = this.mHiddenRowCount - 1;
                if (newRow < 0) {
                    newRow = 0;
                }
                setTilePosition(r, newRow, getPlannedColumnCount(newRow, true) - 1);
            }
        }
    }

    public void showHidden(boolean show) {
        if (this.mShowingHidden == show) {
            return;
        }
        if (!show || this.mHiddenRowCount != 0) {
            synchronized (this.mRecords) {
                if (this.mShowingHidden == show) {
                    return;
                }
                this.mShowingHidden = show;
                if (isShowingDetail()) {
                    closeDetail();
                }
                if (this.mShowingHidden) {
                    setHiddenTilePositions();
                }
                View showingTopView = this.mShowingHidden ? this.mHiddenTilesInfo : this.mBrightnessView;
                View hidingTopView = this.mShowingHidden ? this.mBrightnessView : this.mHiddenTilesInfo;
                showingTopView.bringToFront();
                showingTopView.setVisibility(0);
                if (showingTopView.hasOverlappingRendering()) {
                    showingTopView.animate().withLayer();
                }
                showingTopView.animate().alpha(1.0f).setDuration(300).start();
                if (hidingTopView.hasOverlappingRendering()) {
                    hidingTopView.animate().withLayer();
                }
                hidingTopView.animate().alpha(0.0f).setDuration(300).withEndAction(new C01625(hidingTopView)).start();
                Iterator i$ = this.mRecords.iterator();
                while (i$.hasNext()) {
                    boolean z;
                    TileRecord r = (TileRecord) i$.next();
                    if (r.hidden && r.tile.getState().visible) {
                    }
                    if (r.hidden == this.mShowingHidden) {
                        r.anim.drop();
                    } else {
                        r.anim.lift();
                    }
                    if (r.hidden == this.mShowingHidden) {
                        z = true;
                    } else {
                        z = false;
                    }
                    setTileInteractive(r, z);
                }
                requestLayout();
                postInvalidate();
                this.mCallback.onShowingHidden(this.mShowingHidden);
            }
        }
    }

    private void drawTile(TileRecord r, State state) {
        setTileVisibility(r.tileView, state.visible ? 0 : 8);
        r.tileView.onStateChanged(state);
    }

    private void addTile(QSTile<?> tile, boolean hidden) {
        boolean visibleNow;
        boolean z = true;
        TileRecord r = new TileRecord();
        if (hidden == this.mShowingHidden) {
            visibleNow = true;
        } else {
            visibleNow = false;
        }
        r.tile = tile;
        r.tileView = tile.createTileView(this.mContext);
        if (visibleNow) {
            z = false;
        }
        r.anim = new TileAnimator(r, z);
        r.hidden = hidden;
        r.tileView.setVisibility(8);
        com.android.systemui.qs.QSTile.Callback callback = new C01636(r);
        r.tile.setCallback(callback);
        r.tile.setListening(this.mListening);
        callback.onStateChanged(r.tile.getState());
        r.tile.refreshState();
        synchronized (this.mRecords) {
            this.mRecords.add(r);
        }
        addView(r.tileView);
        setTileInteractive(r, visibleNow);
    }

    private void setTileInteractive(TileRecord r, boolean interactive) {
        OnClickListener click;
        OnClickListener clickSecondary;
        OnLongClickListener longClick;
        if (interactive) {
            click = new C01647(r);
            clickSecondary = new C01658(r);
            longClick = new C01669(r);
        } else {
            click = null;
            clickSecondary = null;
            longClick = null;
        }
        r.tileView.setAlpha(interactive ? 1.0f : 0.0f);
        r.tileView.init(click, clickSecondary, longClick);
    }

    public boolean isShowingDetail() {
        return this.mDetailRecord != null;
    }

    public void closeDetail() {
        showDetail(false, this.mDetailRecord);
    }

    public boolean isClosingDetail() {
        return this.mClosingDetail;
    }

    public int getGridHeight() {
        return this.mGridHeight;
    }

    private void handleShowDetail(Record r, boolean show) {
        if (r instanceof TileRecord) {
            handleShowDetailTile((TileRecord) r, show);
            return;
        }
        int x = 0;
        int y = 0;
        if (r != null) {
            x = r.f18x;
            y = r.f19y;
        }
        handleShowDetailImpl(r, show, x, y);
    }

    private void handleShowDetailTile(TileRecord r, boolean show) {
        if ((this.mDetailRecord != null) != show || this.mDetailRecord != r) {
            if (show) {
                r.detailAdapter = r.tile.getDetailAdapter();
                if (r.detailAdapter == null) {
                    return;
                }
            }
            r.tile.setDetailListening(show);
            handleShowDetailImpl(r, show, r.tileView.getLeft() + (r.tileView.getWidth() / 2), r.tileView.getTop() + (r.tileView.getHeight() / 2));
        }
    }

    private void handleShowDetailImpl(Record r, boolean show, int x, int y) {
        boolean z;
        if (this.mDetailRecord != null) {
            z = true;
        } else {
            z = false;
        }
        boolean visibleDiff = z != show;
        if (visibleDiff || this.mDetailRecord != r) {
            AnimatorListener listener;
            DetailAdapter detailAdapter = null;
            if (show) {
                detailAdapter = r.detailAdapter;
                r.detailView = detailAdapter.createDetailView(this.mContext, r.detailView, this.mDetailContent);
                if (r.detailView == null) {
                    throw new IllegalStateException("Must return detail view");
                }
                Intent settingsIntent = detailAdapter.getSettingsIntent();
                this.mDetailSettingsButton.setVisibility(settingsIntent != null ? 0 : 8);
                this.mDetailSettingsButton.setOnClickListener(new AnonymousClass10(settingsIntent));
                this.mDetailContent.removeAllViews();
                this.mDetail.bringToFront();
                this.mDetailContent.addView(r.detailView);
                MetricsLogger.visible(this.mContext, detailAdapter.getMetricsCategory());
                announceForAccessibility(this.mContext.getString(2131362358, new Object[]{this.mContext.getString(detailAdapter.getTitle())}));
                setDetailRecord(r);
                listener = this.mHideGridContentWhenDone;
                if ((r instanceof TileRecord) && visibleDiff) {
                    ((TileRecord) r).openingDetail = true;
                }
            } else {
                if (this.mDetailRecord != null) {
                    MetricsLogger.hidden(this.mContext, this.mDetailRecord.detailAdapter.getMetricsCategory());
                }
                this.mClosingDetail = true;
                setGridContentVisibility(true);
                listener = this.mTeardownDetailWhenDone;
                fireScanStateChanged(false);
            }
            sendAccessibilityEvent(32);
            if (!show) {
                detailAdapter = null;
            }
            fireShowingDetail(detailAdapter);
            if (visibleDiff) {
                this.mClipper.animateCircularClip(x, y, show, listener);
            }
        }
    }

    private void setGridContentVisibility(boolean visible) {
        this.mGridContentVisible = visible;
        int newVis = visible ? 0 : 4;
        synchronized (this.mRecords) {
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                TileRecord tileRecord = (TileRecord) i$.next();
                if (tileRecord.tileView.getVisibility() != 8) {
                    tileRecord.tileView.setVisibility(newVis);
                }
            }
        }
        this.mBrightnessView.setVisibility(newVis);
        this.mHiddenTilesInfo.setVisibility(newVis);
        if (this.mGridContentVisible != visible) {
            MetricsLogger.visibility(this.mContext, 111, newVis);
        }
        this.mGridContentVisible = visible;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void setTilePosition(com.android.systemui.qs.QSPanel.TileRecord r17, int r18, int r19) {
        /*
        r16 = this;
        r11 = new java.util.ArrayList;
        r11.<init>();
        r12 = "";
        r3 = "";
        r0 = r16;
        r14 = r0.mRecords;
        monitor-enter(r14);
        r16.countRows();	 Catch:{ all -> 0x00d2 }
        if (r18 >= 0) goto L_0x0015;
    L_0x0013:
        r18 = 0;
    L_0x0015:
        if (r19 >= 0) goto L_0x0019;
    L_0x0017:
        r19 = 0;
    L_0x0019:
        r0 = r16;
        r13 = r0.mColumns;	 Catch:{ all -> 0x00d2 }
        r0 = r19;
        if (r0 >= r13) goto L_0x0031;
    L_0x0021:
        if (r18 != 0) goto L_0x0035;
    L_0x0023:
        r0 = r16;
        r13 = r0.mDualCount;	 Catch:{ all -> 0x00d2 }
        r0 = r19;
        if (r0 < r13) goto L_0x0035;
    L_0x002b:
        r0 = r17;
        r13 = r0.hidden;	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x0035;
    L_0x0031:
        r18 = r18 + 1;
        r19 = 0;
    L_0x0035:
        r0 = r17;
        r13 = r0.anim;	 Catch:{ all -> 0x00d2 }
        r0 = r18;
        r1 = r19;
        r13.move(r0, r1);	 Catch:{ all -> 0x00d2 }
        r9 = 0;
    L_0x0041:
        r0 = r18;
        if (r9 > r0) goto L_0x00ed;
    L_0x0045:
        r2 = 0;
    L_0x0046:
        r0 = r18;
        if (r9 != r0) goto L_0x00d5;
    L_0x004a:
        r13 = r19 + 1;
    L_0x004c:
        if (r2 >= r13) goto L_0x00e9;
    L_0x004e:
        r5 = 0;
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r4 = r13.iterator();	 Catch:{ all -> 0x00d2 }
    L_0x0057:
        r13 = r4.hasNext();	 Catch:{ all -> 0x00d2 }
        if (r13 == 0) goto L_0x007a;
    L_0x005d:
        r10 = r4.next();	 Catch:{ all -> 0x00d2 }
        r10 = (com.android.systemui.qs.QSPanel.TileRecord) r10;	 Catch:{ all -> 0x00d2 }
        r13 = r10.tileView;	 Catch:{ all -> 0x00d2 }
        r13 = r13.getVisibility();	 Catch:{ all -> 0x00d2 }
        r15 = 8;
        if (r13 == r15) goto L_0x0057;
    L_0x006d:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        if (r13 != r9) goto L_0x0057;
    L_0x0071:
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        if (r13 != r2) goto L_0x0057;
    L_0x0075:
        r13 = r10.hidden;	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x0057;
    L_0x0079:
        r5 = 1;
    L_0x007a:
        if (r5 != 0) goto L_0x00e5;
    L_0x007c:
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r4 = r13.iterator();	 Catch:{ all -> 0x00d2 }
    L_0x0084:
        r13 = r4.hasNext();	 Catch:{ all -> 0x00d2 }
        if (r13 == 0) goto L_0x00e5;
    L_0x008a:
        r10 = r4.next();	 Catch:{ all -> 0x00d2 }
        r10 = (com.android.systemui.qs.QSPanel.TileRecord) r10;	 Catch:{ all -> 0x00d2 }
        r0 = r17;
        r13 = r10.equals(r0);	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x0084;
    L_0x0098:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        if (r13 < r9) goto L_0x0084;
    L_0x009c:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        if (r13 != r9) goto L_0x00a4;
    L_0x00a0:
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        if (r13 < r2) goto L_0x0084;
    L_0x00a4:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        r0 = r18;
        if (r13 > r0) goto L_0x0084;
    L_0x00aa:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        r0 = r18;
        if (r13 != r0) goto L_0x00b6;
    L_0x00b0:
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        r0 = r19;
        if (r13 > r0) goto L_0x0084;
    L_0x00b6:
        r13 = r10.hidden;	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x0084;
    L_0x00ba:
        r8 = r10.row;	 Catch:{ all -> 0x00d2 }
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        r7 = r13 + -1;
        if (r7 >= 0) goto L_0x00cc;
    L_0x00c2:
        r8 = r8 + -1;
        if (r8 != 0) goto L_0x00de;
    L_0x00c6:
        r0 = r16;
        r13 = r0.mDualCount;	 Catch:{ all -> 0x00d2 }
        r7 = r13 + -1;
    L_0x00cc:
        r13 = r10.anim;	 Catch:{ all -> 0x00d2 }
        r13.move(r8, r7);	 Catch:{ all -> 0x00d2 }
        goto L_0x0084;
    L_0x00d2:
        r13 = move-exception;
        monitor-exit(r14);	 Catch:{ all -> 0x00d2 }
        throw r13;
    L_0x00d5:
        r13 = 0;
        r0 = r16;
        r13 = r0.getPlannedColumnCount(r9, r13);	 Catch:{ all -> 0x00d2 }
        goto L_0x004c;
    L_0x00de:
        r0 = r16;
        r13 = r0.mColumns;	 Catch:{ all -> 0x00d2 }
        r7 = r13 + -1;
        goto L_0x00cc;
    L_0x00e5:
        r2 = r2 + 1;
        goto L_0x0046;
    L_0x00e9:
        r9 = r9 + 1;
        goto L_0x0041;
    L_0x00ed:
        r0 = r16;
        r13 = r0.mRowCount;	 Catch:{ all -> 0x00d2 }
        r9 = r13 + -1;
    L_0x00f3:
        r0 = r18;
        if (r9 < r0) goto L_0x019c;
    L_0x00f7:
        r13 = 0;
        r0 = r16;
        r13 = r0.getPlannedColumnCount(r9, r13);	 Catch:{ all -> 0x00d2 }
        r2 = r13 + -1;
    L_0x0100:
        r0 = r18;
        if (r9 != r0) goto L_0x0191;
    L_0x0104:
        r13 = r19;
    L_0x0106:
        if (r2 < r13) goto L_0x0198;
    L_0x0108:
        r5 = 0;
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r4 = r13.iterator();	 Catch:{ all -> 0x00d2 }
    L_0x0111:
        r13 = r4.hasNext();	 Catch:{ all -> 0x00d2 }
        if (r13 == 0) goto L_0x0134;
    L_0x0117:
        r10 = r4.next();	 Catch:{ all -> 0x00d2 }
        r10 = (com.android.systemui.qs.QSPanel.TileRecord) r10;	 Catch:{ all -> 0x00d2 }
        r13 = r10.tileView;	 Catch:{ all -> 0x00d2 }
        r13 = r13.getVisibility();	 Catch:{ all -> 0x00d2 }
        r15 = 8;
        if (r13 == r15) goto L_0x0111;
    L_0x0127:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        if (r13 != r9) goto L_0x0111;
    L_0x012b:
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        if (r13 != r2) goto L_0x0111;
    L_0x012f:
        r13 = r10.hidden;	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x0111;
    L_0x0133:
        r5 = 1;
    L_0x0134:
        if (r5 != 0) goto L_0x0194;
    L_0x0136:
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r4 = r13.iterator();	 Catch:{ all -> 0x00d2 }
    L_0x013e:
        r13 = r4.hasNext();	 Catch:{ all -> 0x00d2 }
        if (r13 == 0) goto L_0x0194;
    L_0x0144:
        r10 = r4.next();	 Catch:{ all -> 0x00d2 }
        r10 = (com.android.systemui.qs.QSPanel.TileRecord) r10;	 Catch:{ all -> 0x00d2 }
        r0 = r17;
        r13 = r10.equals(r0);	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x013e;
    L_0x0152:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        if (r13 > r9) goto L_0x013e;
    L_0x0156:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        if (r13 != r9) goto L_0x015e;
    L_0x015a:
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        if (r13 > r2) goto L_0x013e;
    L_0x015e:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        r0 = r18;
        if (r13 < r0) goto L_0x013e;
    L_0x0164:
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        r0 = r18;
        if (r13 != r0) goto L_0x0170;
    L_0x016a:
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        r0 = r19;
        if (r13 < r0) goto L_0x013e;
    L_0x0170:
        r13 = r10.hidden;	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x013e;
    L_0x0174:
        r8 = r10.row;	 Catch:{ all -> 0x00d2 }
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        r7 = r13 + 1;
        r0 = r16;
        r13 = r0.mColumns;	 Catch:{ all -> 0x00d2 }
        if (r7 >= r13) goto L_0x0188;
    L_0x0180:
        if (r8 != 0) goto L_0x018b;
    L_0x0182:
        r0 = r16;
        r13 = r0.mDualCount;	 Catch:{ all -> 0x00d2 }
        if (r7 < r13) goto L_0x018b;
    L_0x0188:
        r8 = r8 + 1;
        r7 = 0;
    L_0x018b:
        r13 = r10.anim;	 Catch:{ all -> 0x00d2 }
        r13.move(r8, r7);	 Catch:{ all -> 0x00d2 }
        goto L_0x013e;
    L_0x0191:
        r13 = 0;
        goto L_0x0106;
    L_0x0194:
        r2 = r2 + -1;
        goto L_0x0100;
    L_0x0198:
        r9 = r9 + -1;
        goto L_0x00f3;
    L_0x019c:
        r9 = 0;
    L_0x019d:
        r0 = r16;
        r13 = r0.mRowCount;	 Catch:{ all -> 0x00d2 }
        if (r9 >= r13) goto L_0x01f8;
    L_0x01a3:
        r2 = 0;
    L_0x01a4:
        if (r9 != 0) goto L_0x01ed;
    L_0x01a6:
        r0 = r16;
        r13 = r0.mDualCount;	 Catch:{ all -> 0x00d2 }
    L_0x01aa:
        if (r2 >= r13) goto L_0x01f5;
    L_0x01ac:
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r4 = r13.iterator();	 Catch:{ all -> 0x00d2 }
    L_0x01b4:
        r13 = r4.hasNext();	 Catch:{ all -> 0x00d2 }
        if (r13 == 0) goto L_0x01f2;
    L_0x01ba:
        r10 = r4.next();	 Catch:{ all -> 0x00d2 }
        r10 = (com.android.systemui.qs.QSPanel.TileRecord) r10;	 Catch:{ all -> 0x00d2 }
        r13 = r10.row;	 Catch:{ all -> 0x00d2 }
        if (r13 != r9) goto L_0x01b4;
    L_0x01c4:
        r13 = r10.col;	 Catch:{ all -> 0x00d2 }
        if (r13 != r2) goto L_0x01b4;
    L_0x01c8:
        r13 = r10.hidden;	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x01b4;
    L_0x01cc:
        r11.add(r10);	 Catch:{ all -> 0x00d2 }
        r13 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00d2 }
        r13.<init>();	 Catch:{ all -> 0x00d2 }
        r13 = r13.append(r12);	 Catch:{ all -> 0x00d2 }
        r15 = r10.tile;	 Catch:{ all -> 0x00d2 }
        r15 = r15.getSpec();	 Catch:{ all -> 0x00d2 }
        r13 = r13.append(r15);	 Catch:{ all -> 0x00d2 }
        r15 = ",";
        r13 = r13.append(r15);	 Catch:{ all -> 0x00d2 }
        r12 = r13.toString();	 Catch:{ all -> 0x00d2 }
        goto L_0x01b4;
    L_0x01ed:
        r0 = r16;
        r13 = r0.mColumns;	 Catch:{ all -> 0x00d2 }
        goto L_0x01aa;
    L_0x01f2:
        r2 = r2 + 1;
        goto L_0x01a4;
    L_0x01f5:
        r9 = r9 + 1;
        goto L_0x019d;
    L_0x01f8:
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r4 = r13.iterator();	 Catch:{ all -> 0x00d2 }
    L_0x0200:
        r13 = r4.hasNext();	 Catch:{ all -> 0x00d2 }
        if (r13 == 0) goto L_0x0262;
    L_0x0206:
        r10 = r4.next();	 Catch:{ all -> 0x00d2 }
        r10 = (com.android.systemui.qs.QSPanel.TileRecord) r10;	 Catch:{ all -> 0x00d2 }
        r13 = r11.contains(r10);	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x0200;
    L_0x0212:
        r11.add(r10);	 Catch:{ all -> 0x00d2 }
        r13 = r10.hidden;	 Catch:{ all -> 0x00d2 }
        if (r13 != 0) goto L_0x0244;
    L_0x0219:
        r13 = 1;
        r10.hidden = r13;	 Catch:{ all -> 0x00d2 }
        r0 = r16;
        r13 = r0.mShowingHidden;	 Catch:{ all -> 0x00d2 }
        r0 = r16;
        r0.setTileInteractive(r10, r13);	 Catch:{ all -> 0x00d2 }
        r13 = -1;
        r10.col = r13;	 Catch:{ all -> 0x00d2 }
        r10.row = r13;	 Catch:{ all -> 0x00d2 }
        r13 = r16.countHiddenRows();	 Catch:{ all -> 0x00d2 }
        r6 = r13 + -1;
        if (r6 >= 0) goto L_0x0233;
    L_0x0232:
        r6 = 0;
    L_0x0233:
        r13 = r10.anim;	 Catch:{ all -> 0x00d2 }
        r15 = 1;
        r0 = r16;
        r15 = r0.getPlannedColumnCount(r6, r15);	 Catch:{ all -> 0x00d2 }
        r15 = r15 + -1;
        r13.move(r6, r15);	 Catch:{ all -> 0x00d2 }
        r16.countRows();	 Catch:{ all -> 0x00d2 }
    L_0x0244:
        r13 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00d2 }
        r13.<init>();	 Catch:{ all -> 0x00d2 }
        r13 = r13.append(r3);	 Catch:{ all -> 0x00d2 }
        r15 = r10.tile;	 Catch:{ all -> 0x00d2 }
        r15 = r15.getSpec();	 Catch:{ all -> 0x00d2 }
        r13 = r13.append(r15);	 Catch:{ all -> 0x00d2 }
        r15 = ",";
        r13 = r13.append(r15);	 Catch:{ all -> 0x00d2 }
        r3 = r13.toString();	 Catch:{ all -> 0x00d2 }
        goto L_0x0200;
    L_0x0262:
        r13 = r12.length();	 Catch:{ all -> 0x00d2 }
        if (r13 <= 0) goto L_0x0273;
    L_0x0268:
        r13 = 0;
        r15 = r12.length();	 Catch:{ all -> 0x00d2 }
        r15 = r15 + -1;
        r12 = r12.substring(r13, r15);	 Catch:{ all -> 0x00d2 }
    L_0x0273:
        r13 = r3.length();	 Catch:{ all -> 0x00d2 }
        if (r13 <= 0) goto L_0x029b;
    L_0x0279:
        r13 = 0;
        r15 = r3.length();	 Catch:{ all -> 0x00d2 }
        r15 = r15 + -1;
        r3 = r3.substring(r13, r15);	 Catch:{ all -> 0x00d2 }
        r13 = new java.lang.StringBuilder;	 Catch:{ all -> 0x00d2 }
        r13.<init>();	 Catch:{ all -> 0x00d2 }
        r13 = r13.append(r12);	 Catch:{ all -> 0x00d2 }
        r15 = ",,";
        r13 = r13.append(r15);	 Catch:{ all -> 0x00d2 }
        r13 = r13.append(r3);	 Catch:{ all -> 0x00d2 }
        r12 = r13.toString();	 Catch:{ all -> 0x00d2 }
    L_0x029b:
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r13.clear();	 Catch:{ all -> 0x00d2 }
        r0 = r16;
        r13 = r0.mRecords;	 Catch:{ all -> 0x00d2 }
        r13.addAll(r11);	 Catch:{ all -> 0x00d2 }
        monitor-exit(r14);	 Catch:{ all -> 0x00d2 }
        r0 = r16;
        r13 = r0.mContext;
        r13 = r13.getContentResolver();
        r14 = "sysui_qs_tiles";
        r0 = r16;
        r15 = r0.mUserTracker;
        r15 = r15.getCurrentUserId();
        android.provider.Settings.Secure.putStringForUser(r13, r14, r12, r15);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.qs.QSPanel.setTilePosition(com.android.systemui.qs.QSPanel$TileRecord, int, int):void");
    }

    private int countHiddenRows() {
        int hiddenRowCount;
        boolean z = true;
        synchronized (this.mRecords) {
            boolean z2;
            hiddenRowCount = 0;
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                TileRecord record = (TileRecord) i$.next();
                if (record.tileView.getVisibility() != 8 && record.hidden && hiddenRowCount < record.row + 1) {
                    hiddenRowCount = record.row + 1;
                }
            }
            if (this.mHiddenRowCount == 0) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (!(z2 == (hiddenRowCount == 0) || this.mCallback == null)) {
                Callback callback = this.mCallback;
                if (hiddenRowCount == 0) {
                    z = false;
                }
                callback.onAbleToShowHidden(z);
            }
            this.mHiddenRowCount = hiddenRowCount;
        }
        return hiddenRowCount;
    }

    private int countRows() {
        int rowCount;
        synchronized (this.mRecords) {
            countHiddenRows();
            rowCount = 0;
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                TileRecord record = (TileRecord) i$.next();
                if (!(record.tileView.getVisibility() == 8 || record.hidden || rowCount >= record.row + 1)) {
                    rowCount = record.row + 1;
                }
            }
            this.mRowCount = rowCount;
        }
        return rowCount;
    }

    private void logTiles() {
        for (int i = 0; i < this.mRecords.size(); i++) {
            TileRecord tileRecord = (TileRecord) this.mRecords.get(i);
            if (tileRecord.tile.getState().visible) {
                MetricsLogger.visible(this.mContext, tileRecord.tile.getMetricsCategory());
            }
        }
    }

    private void setHiddenTilePositions() {
        synchronized (this.mRecords) {
            int hr = 0;
            int hc = -1;
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                TileRecord record = (TileRecord) i$.next();
                if (record.hidden) {
                    if (record.tileView.getVisibility() != 8) {
                        hc++;
                        if (hc >= this.mColumns) {
                            hr++;
                            hc = 0;
                        }
                    }
                    record.anim.move(hr, hc);
                }
            }
            countHiddenRows();
        }
    }

    private void setTilePositions() {
        synchronized (this.mRecords) {
            setHiddenTilePositions();
            int r = 0;
            int c = -1;
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                TileRecord record = (TileRecord) i$.next();
                if (!record.hidden) {
                    if (record.tileView.getVisibility() != 8) {
                        c++;
                        if (c >= this.mColumns || (r == 0 && c >= this.mDualCount)) {
                            r++;
                            c = 0;
                        }
                    }
                    record.anim.move(r, c);
                }
            }
            countRows();
        }
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int i;
        setTilePositions();
        int rowCount = this.mShowingHidden ? countHiddenRows() : countRows();
        int rowTop = getRowTop(rowCount, this.mShowingHidden);
        if (rowCount > 0) {
            i = this.mPanelPaddingBottom;
        } else {
            i = 0;
        }
        this.mGridHeight = (this.mFooter.hasFooter() ? this.mFooter.getView().getMeasuredHeight() : 0) + (rowTop + i);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        this.mBrightnessView.measure(exactly(width), 0);
        this.mHiddenTilesInfo.measure(exactly(width), 0);
        int topHeight = this.mBrightnessView.getMeasuredHeight();
        if (this.mHiddenTilesInfo.getMeasuredHeight() < topHeight) {
            this.mHiddenTilesInfo.measure(exactly(width), exactly(topHeight));
        }
        this.mFooter.getView().measure(exactly(width), 0);
        this.mDetail.measure(exactly(width), 0);
        if (this.mDetail.getMeasuredHeight() < this.mGridHeight) {
            this.mDetail.measure(exactly(width), exactly(this.mGridHeight));
        }
        setMeasuredDimension(width, Math.max(this.mGridHeight, this.mDetail.getMeasuredHeight()));
    }

    private static int exactly(int size) {
        return MeasureSpec.makeMeasureSpec(size, 1073741824);
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = getWidth();
        this.mBrightnessView.layout(0, this.mBrightnessPaddingTop, this.mBrightnessView.getMeasuredWidth(), this.mBrightnessPaddingTop + this.mBrightnessView.getMeasuredHeight());
        this.mHiddenTilesInfo.layout(0, this.mBrightnessPaddingTop, this.mHiddenTilesInfo.getMeasuredWidth(), this.mBrightnessPaddingTop + this.mHiddenTilesInfo.getMeasuredHeight());
        synchronized (this.mRecords) {
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                TileRecord record = (TileRecord) i$.next();
                record.anim.move(record.row, record.col);
            }
        }
        this.mDetail.layout(0, 0, this.mDetail.getMeasuredWidth(), Math.max(this.mDetail.getMeasuredHeight(), getMeasuredHeight()));
        if (this.mFooter.hasFooter()) {
            View footer = this.mFooter.getView();
            footer.layout(0, getMeasuredHeight() - footer.getMeasuredHeight(), footer.getMeasuredWidth(), getMeasuredHeight());
        }
    }

    private int getRowTop(int row, boolean hidden) {
        View topView = hidden ? this.mHiddenTilesInfo : this.mBrightnessView;
        if (row <= 0) {
            return topView.getMeasuredHeight() + this.mBrightnessPaddingTop;
        }
        int i;
        int measuredHeight = this.mBrightnessPaddingTop + topView.getMeasuredHeight();
        if (hidden) {
            i = this.mCellHeight * row;
        } else {
            i = (this.mDualCount > 0 ? this.mLargeCellHeight - this.mDualTileUnderlap : 0) + ((row - 1) * this.mCellHeight);
        }
        return i + measuredHeight;
    }

    private int getColLeft(int row, int col, boolean hidden) {
        int cols = getPlannedColumnCount(row, hidden);
        int w = getWidth();
        int cw = (row != 0 || hidden) ? this.mCellWidth : this.mLargeCellWidth;
        int left = (col * cw) + ((col + 1) * ((w - (cw * cols)) / (cols + 1)));
        return getLayoutDirection() == 1 ? (w - left) - cw : left;
    }

    private int getPlannedColumnCount(int row, boolean hidden) {
        if (row < 0) {
            return 0;
        }
        int cols = 0;
        synchronized (this.mRecords) {
            Iterator i$ = this.mRecords.iterator();
            while (i$.hasNext()) {
                TileRecord record = (TileRecord) i$.next();
                if (record.tileView.getVisibility() != 8 && record.hidden == hidden) {
                    cols++;
                }
            }
        }
        int r = 0;
        while (r < row) {
            int i = (r != 0 || hidden) ? this.mColumns : this.mDualCount;
            cols -= i;
            if (cols < 0) {
                return 0;
            }
            r++;
        }
        int maxCols = (row != 0 || hidden) ? this.mColumns : this.mDualCount;
        return cols <= maxCols ? cols : maxCols;
    }

    private void fireShowingDetail(DetailAdapter detail) {
        if (this.mCallback != null) {
            this.mCallback.onShowingDetail(detail);
        }
    }

    private void fireToggleStateChanged(boolean state) {
        if (this.mCallback != null) {
            this.mCallback.onToggleStateChanged(state);
        }
    }

    private void fireScanStateChanged(boolean state) {
        if (this.mCallback != null) {
            this.mCallback.onScanStateChanged(state);
        }
    }

    private void setDetailRecord(Record r) {
        if (r != this.mDetailRecord) {
            this.mDetailRecord = r;
            boolean scanState = (this.mDetailRecord instanceof TileRecord) && ((TileRecord) this.mDetailRecord).scanState;
            fireScanStateChanged(scanState);
        }
    }
}
