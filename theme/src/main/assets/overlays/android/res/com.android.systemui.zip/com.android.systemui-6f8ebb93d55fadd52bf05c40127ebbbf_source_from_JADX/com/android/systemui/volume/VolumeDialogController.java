package com.android.systemui.volume;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.ContentObserver;
import android.media.AudioManager;
import android.media.AudioSystem;
import android.media.IVolumeController.Stub;
import android.media.VolumePolicy;
import android.media.session.MediaController.PlaybackInfo;
import android.media.session.MediaSession.Token;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.os.Vibrator;
import android.provider.Settings.Global;
import android.provider.Settings.Secure;
import android.service.notification.Condition;
import android.service.notification.ZenModeConfig;
import android.util.Log;
import android.util.SparseArray;
import com.android.keyguard.C0065R;
import com.android.systemui.qs.tiles.DndTile;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Objects;

public class VolumeDialogController {
    private static final int[] STREAMS;
    private static final String TAG;
    private final AudioManager mAudio;
    private final C0578C mCallbacks;
    private final ComponentName mComponent;
    private final Context mContext;
    private boolean mDestroyed;
    private boolean mEnabled;
    private final boolean mHasVibrator;
    private final MediaSessions mMediaSessions;
    private final MediaSessionsCallbacks mMediaSessionsCallbacksW;
    private final NotificationManager mNoMan;
    private final SettingObserver mObserver;
    private final Receiver mReceiver;
    private boolean mShowDndTile;
    private final State mState;
    private final String[] mStreamTitles;
    private final Vibrator mVibrator;
    private final VC mVolumeController;
    private VolumePolicy mVolumePolicy;
    private final C0579W mWorker;
    private final HandlerThread mWorkerThread;

    public interface Callbacks {
        void onConfigurationChanged();

        void onDismissRequested(int i);

        void onLayoutDirectionChanged(int i);

        void onScreenOff();

        void onShowRequested(int i);

        void onShowSafetyWarning(int i);

        void onShowSilentHint();

        void onShowVibrateHint();

        void onStateChanged(State state);
    }

    /* renamed from: com.android.systemui.volume.VolumeDialogController.C */
    private final class C0578C implements Callbacks {
        private final HashMap<Callbacks, Handler> mCallbackMap;

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.1 */
        class C05691 implements Runnable {
            final /* synthetic */ Entry val$entry;
            final /* synthetic */ int val$reason;

            C05691(Entry entry, int i) {
                this.val$entry = entry;
                this.val$reason = i;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onShowRequested(this.val$reason);
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.2 */
        class C05702 implements Runnable {
            final /* synthetic */ Entry val$entry;
            final /* synthetic */ int val$reason;

            C05702(Entry entry, int i) {
                this.val$entry = entry;
                this.val$reason = i;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onDismissRequested(this.val$reason);
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.3 */
        class C05713 implements Runnable {
            final /* synthetic */ State val$copy;
            final /* synthetic */ Entry val$entry;

            C05713(Entry entry, State state) {
                this.val$entry = entry;
                this.val$copy = state;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onStateChanged(this.val$copy);
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.4 */
        class C05724 implements Runnable {
            final /* synthetic */ Entry val$entry;
            final /* synthetic */ int val$layoutDirection;

            C05724(Entry entry, int i) {
                this.val$entry = entry;
                this.val$layoutDirection = i;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onLayoutDirectionChanged(this.val$layoutDirection);
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.5 */
        class C05735 implements Runnable {
            final /* synthetic */ Entry val$entry;

            C05735(Entry entry) {
                this.val$entry = entry;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onConfigurationChanged();
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.6 */
        class C05746 implements Runnable {
            final /* synthetic */ Entry val$entry;

            C05746(Entry entry) {
                this.val$entry = entry;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onShowVibrateHint();
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.7 */
        class C05757 implements Runnable {
            final /* synthetic */ Entry val$entry;

            C05757(Entry entry) {
                this.val$entry = entry;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onShowSilentHint();
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.8 */
        class C05768 implements Runnable {
            final /* synthetic */ Entry val$entry;

            C05768(Entry entry) {
                this.val$entry = entry;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onScreenOff();
            }
        }

        /* renamed from: com.android.systemui.volume.VolumeDialogController.C.9 */
        class C05779 implements Runnable {
            final /* synthetic */ Entry val$entry;
            final /* synthetic */ int val$flags;

            C05779(Entry entry, int i) {
                this.val$entry = entry;
                this.val$flags = i;
            }

            public void run() {
                ((Callbacks) this.val$entry.getKey()).onShowSafetyWarning(this.val$flags);
            }
        }

        private C0578C() {
            this.mCallbackMap = new HashMap();
        }

        public void add(Callbacks callback, Handler handler) {
            if (callback == null || handler == null) {
                throw new IllegalArgumentException();
            }
            this.mCallbackMap.put(callback, handler);
        }

        public void remove(Callbacks callback) {
            this.mCallbackMap.remove(callback);
        }

        public void onShowRequested(int reason) {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05691(entry, reason));
            }
        }

        public void onDismissRequested(int reason) {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05702(entry, reason));
            }
        }

        public void onStateChanged(State state) {
            long time = System.currentTimeMillis();
            State copy = state.copy();
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05713(entry, copy));
            }
            Events.writeState(time, copy);
        }

        public void onLayoutDirectionChanged(int layoutDirection) {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05724(entry, layoutDirection));
            }
        }

        public void onConfigurationChanged() {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05735(entry));
            }
        }

        public void onShowVibrateHint() {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05746(entry));
            }
        }

        public void onShowSilentHint() {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05757(entry));
            }
        }

        public void onScreenOff() {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05768(entry));
            }
        }

        public void onShowSafetyWarning(int flags) {
            for (Entry<Callbacks, Handler> entry : this.mCallbackMap.entrySet()) {
                ((Handler) entry.getValue()).post(new C05779(entry, flags));
            }
        }
    }

    private final class MediaSessionsCallbacks implements com.android.systemui.volume.MediaSessions.Callbacks {
        private int mNextStream;
        private final HashMap<Token, Integer> mRemoteStreams;

        private MediaSessionsCallbacks() {
            this.mRemoteStreams = new HashMap();
            this.mNextStream = 100;
        }

        public void onRemoteUpdate(Token token, String name, PlaybackInfo pi) {
            boolean changed;
            if (!this.mRemoteStreams.containsKey(token)) {
                this.mRemoteStreams.put(token, Integer.valueOf(this.mNextStream));
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onRemoteUpdate: " + name + " is stream " + this.mNextStream);
                }
                this.mNextStream++;
            }
            int stream = ((Integer) this.mRemoteStreams.get(token)).intValue();
            if (VolumeDialogController.this.mState.states.indexOfKey(stream) < 0) {
                changed = true;
            } else {
                changed = false;
            }
            StreamState ss = VolumeDialogController.this.streamStateW(stream);
            ss.dynamic = true;
            ss.levelMin = 0;
            ss.levelMax = pi.getMaxVolume();
            if (ss.level != pi.getCurrentVolume()) {
                ss.level = pi.getCurrentVolume();
                changed = true;
            }
            if (!Objects.equals(ss.name, name)) {
                ss.name = name;
                changed = true;
            }
            if (changed) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onRemoteUpdate: " + name + ": " + ss.level + " of " + ss.levelMax);
                }
                VolumeDialogController.this.mCallbacks.onStateChanged(VolumeDialogController.this.mState);
            }
        }

        public void onRemoteVolumeChanged(Token token, int flags) {
            int stream = ((Integer) this.mRemoteStreams.get(token)).intValue();
            boolean showUI = (flags & 1) != 0;
            boolean changed = VolumeDialogController.this.updateActiveStreamW(stream);
            if (showUI) {
                changed |= VolumeDialogController.this.checkRoutedToBluetoothW(3);
            }
            if (changed) {
                VolumeDialogController.this.mCallbacks.onStateChanged(VolumeDialogController.this.mState);
            }
            if (showUI) {
                VolumeDialogController.this.mCallbacks.onShowRequested(2);
            }
        }

        public void onRemoteRemoved(Token token) {
            int stream = ((Integer) this.mRemoteStreams.get(token)).intValue();
            VolumeDialogController.this.mState.states.remove(stream);
            if (VolumeDialogController.this.mState.activeStream == stream) {
                VolumeDialogController.this.updateActiveStreamW(-1);
            }
            VolumeDialogController.this.mCallbacks.onStateChanged(VolumeDialogController.this.mState);
        }

        public void setStreamVolume(int stream, int level) {
            Token t = findToken(stream);
            if (t == null) {
                Log.w(VolumeDialogController.TAG, "setStreamVolume: No token found for stream: " + stream);
            } else {
                VolumeDialogController.this.mMediaSessions.setVolume(t, level);
            }
        }

        private Token findToken(int stream) {
            for (Entry<Token, Integer> entry : this.mRemoteStreams.entrySet()) {
                if (((Integer) entry.getValue()).equals(Integer.valueOf(stream))) {
                    return (Token) entry.getKey();
                }
            }
            return null;
        }
    }

    private final class Receiver extends BroadcastReceiver {
        private Receiver() {
        }

        public void init() {
            IntentFilter filter = new IntentFilter();
            filter.addAction("android.media.VOLUME_CHANGED_ACTION");
            filter.addAction("android.media.STREAM_DEVICES_CHANGED_ACTION");
            filter.addAction("android.media.RINGER_MODE_CHANGED");
            filter.addAction("android.media.INTERNAL_RINGER_MODE_CHANGED_ACTION");
            filter.addAction("android.media.STREAM_MUTE_CHANGED_ACTION");
            filter.addAction("android.os.action.ACTION_EFFECTS_SUPPRESSOR_CHANGED");
            filter.addAction("android.intent.action.CONFIGURATION_CHANGED");
            filter.addAction("android.intent.action.SCREEN_OFF");
            filter.addAction("android.intent.action.CLOSE_SYSTEM_DIALOGS");
            VolumeDialogController.this.mContext.registerReceiver(this, filter, null, VolumeDialogController.this.mWorker);
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            boolean changed = false;
            int stream;
            if (action.equals("android.media.VOLUME_CHANGED_ACTION")) {
                stream = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1);
                int level = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1);
                int oldLevel = intent.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_VALUE", -1);
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive VOLUME_CHANGED_ACTION stream=" + stream + " level=" + level + " oldLevel=" + oldLevel);
                }
                changed = VolumeDialogController.this.updateStreamLevelW(stream, level);
            } else if (action.equals("android.media.STREAM_DEVICES_CHANGED_ACTION")) {
                stream = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1);
                int devices = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_DEVICES", -1);
                int oldDevices = intent.getIntExtra("android.media.EXTRA_PREV_VOLUME_STREAM_DEVICES", -1);
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive STREAM_DEVICES_CHANGED_ACTION stream=" + stream + " devices=" + devices + " oldDevices=" + oldDevices);
                }
                changed = VolumeDialogController.this.checkRoutedToBluetoothW(stream);
            } else if (action.equals("android.media.RINGER_MODE_CHANGED")) {
                rm = intent.getIntExtra("android.media.EXTRA_RINGER_MODE", -1);
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive RINGER_MODE_CHANGED_ACTION rm=" + Util.ringerModeToString(rm));
                }
                changed = VolumeDialogController.this.updateRingerModeExternalW(rm);
            } else if (action.equals("android.media.INTERNAL_RINGER_MODE_CHANGED_ACTION")) {
                rm = intent.getIntExtra("android.media.EXTRA_RINGER_MODE", -1);
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive INTERNAL_RINGER_MODE_CHANGED_ACTION rm=" + Util.ringerModeToString(rm));
                }
                changed = VolumeDialogController.this.updateRingerModeInternalW(rm);
            } else if (action.equals("android.media.STREAM_MUTE_CHANGED_ACTION")) {
                stream = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1);
                boolean muted = intent.getBooleanExtra("android.media.EXTRA_STREAM_VOLUME_MUTED", false);
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive STREAM_MUTE_CHANGED_ACTION stream=" + stream + " muted=" + muted);
                }
                changed = VolumeDialogController.this.updateStreamMuteW(stream, muted);
            } else if (action.equals("android.os.action.ACTION_EFFECTS_SUPPRESSOR_CHANGED")) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive ACTION_EFFECTS_SUPPRESSOR_CHANGED");
                }
                changed = VolumeDialogController.this.updateEffectsSuppressorW(VolumeDialogController.this.mNoMan.getEffectsSuppressor());
            } else if (action.equals("android.intent.action.CONFIGURATION_CHANGED")) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive ACTION_CONFIGURATION_CHANGED");
                }
                VolumeDialogController.this.mCallbacks.onConfigurationChanged();
            } else if (action.equals("android.intent.action.SCREEN_OFF")) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive ACTION_SCREEN_OFF");
                }
                VolumeDialogController.this.mCallbacks.onScreenOff();
            } else if (action.equals("android.intent.action.CLOSE_SYSTEM_DIALOGS")) {
                if (C0543D.BUG) {
                    Log.d(VolumeDialogController.TAG, "onReceive ACTION_CLOSE_SYSTEM_DIALOGS");
                }
                VolumeDialogController.this.dismiss();
            }
            if (changed) {
                VolumeDialogController.this.mCallbacks.onStateChanged(VolumeDialogController.this.mState);
            }
        }
    }

    private final class SettingObserver extends ContentObserver {
        private final Uri SERVICE_URI;
        private final Uri ZEN_MODE_CONFIG_URI;
        private final Uri ZEN_MODE_URI;

        public SettingObserver(Handler handler) {
            super(handler);
            this.SERVICE_URI = Secure.getUriFor("volume_controller_service_component");
            this.ZEN_MODE_URI = Global.getUriFor("zen_mode");
            this.ZEN_MODE_CONFIG_URI = Global.getUriFor("zen_mode_config_etag");
        }

        public void init() {
            VolumeDialogController.this.mContext.getContentResolver().registerContentObserver(this.SERVICE_URI, false, this);
            VolumeDialogController.this.mContext.getContentResolver().registerContentObserver(this.ZEN_MODE_URI, false, this);
            VolumeDialogController.this.mContext.getContentResolver().registerContentObserver(this.ZEN_MODE_CONFIG_URI, false, this);
            onChange(true, this.SERVICE_URI);
        }

        public void onChange(boolean selfChange, Uri uri) {
            boolean changed = false;
            if (this.SERVICE_URI.equals(uri)) {
                String setting = Secure.getString(VolumeDialogController.this.mContext.getContentResolver(), "volume_controller_service_component");
                boolean enabled = (setting == null || VolumeDialogController.this.mComponent == null || !VolumeDialogController.this.mComponent.equals(ComponentName.unflattenFromString(setting))) ? false : true;
                if (enabled != VolumeDialogController.this.mEnabled) {
                    if (enabled) {
                        VolumeDialogController.this.register();
                    }
                    VolumeDialogController.this.mEnabled = enabled;
                } else {
                    return;
                }
            }
            if (this.ZEN_MODE_URI.equals(uri)) {
                changed = VolumeDialogController.this.updateZenModeW();
            }
            if (this.ZEN_MODE_CONFIG_URI.equals(uri)) {
                changed = VolumeDialogController.this.updateZenModeConfigW();
            }
            if (changed) {
                VolumeDialogController.this.mCallbacks.onStateChanged(VolumeDialogController.this.mState);
            }
        }
    }

    public static final class State {
        public static int NO_ACTIVE_STREAM;
        public int activeStream;
        public ComponentName effectsSuppressor;
        public String effectsSuppressorName;
        public int ringerModeExternal;
        public int ringerModeInternal;
        public final SparseArray<StreamState> states;
        public int zenMode;
        public ZenModeConfig zenModeConfig;

        public State() {
            this.states = new SparseArray();
            this.activeStream = NO_ACTIVE_STREAM;
        }

        static {
            NO_ACTIVE_STREAM = -1;
        }

        public State copy() {
            State rt = new State();
            for (int i = 0; i < this.states.size(); i++) {
                rt.states.put(this.states.keyAt(i), ((StreamState) this.states.valueAt(i)).copy());
            }
            rt.ringerModeExternal = this.ringerModeExternal;
            rt.ringerModeInternal = this.ringerModeInternal;
            rt.zenMode = this.zenMode;
            if (this.effectsSuppressor != null) {
                rt.effectsSuppressor = this.effectsSuppressor.clone();
            }
            rt.effectsSuppressorName = this.effectsSuppressorName;
            if (this.zenModeConfig != null) {
                rt.zenModeConfig = this.zenModeConfig.copy();
            }
            rt.activeStream = this.activeStream;
            return rt;
        }

        public String toString() {
            return toString(0);
        }

        public String toString(int indent) {
            StringBuilder sb = new StringBuilder("{");
            if (indent > 0) {
                sep(sb, indent);
            }
            for (int i = 0; i < this.states.size(); i++) {
                if (i > 0) {
                    sep(sb, indent);
                }
                StreamState ss = (StreamState) this.states.valueAt(i);
                sb.append(AudioSystem.streamToString(this.states.keyAt(i))).append(":").append(ss.level).append('[').append(ss.levelMin).append("..").append(ss.levelMax).append(']');
                if (ss.muted) {
                    sb.append(" [MUTED]");
                }
            }
            sep(sb, indent);
            sb.append("ringerModeExternal:").append(this.ringerModeExternal);
            sep(sb, indent);
            sb.append("ringerModeInternal:").append(this.ringerModeInternal);
            sep(sb, indent);
            sb.append("zenMode:").append(this.zenMode);
            sep(sb, indent);
            sb.append("effectsSuppressor:").append(this.effectsSuppressor);
            sep(sb, indent);
            sb.append("effectsSuppressorName:").append(this.effectsSuppressorName);
            sep(sb, indent);
            sb.append("zenModeConfig:").append(this.zenModeConfig);
            sep(sb, indent);
            sb.append("activeStream:").append(this.activeStream);
            if (indent > 0) {
                sep(sb, indent);
            }
            return sb.append('}').toString();
        }

        private static void sep(StringBuilder sb, int indent) {
            if (indent > 0) {
                sb.append('\n');
                for (int i = 0; i < indent; i++) {
                    sb.append(' ');
                }
                return;
            }
            sb.append(',');
        }
    }

    public static final class StreamState {
        public boolean dynamic;
        public int level;
        public int levelMax;
        public int levelMin;
        public boolean muteSupported;
        public boolean muted;
        public String name;
        public boolean routedToBluetooth;

        public StreamState copy() {
            StreamState rt = new StreamState();
            rt.dynamic = this.dynamic;
            rt.level = this.level;
            rt.levelMin = this.levelMin;
            rt.levelMax = this.levelMax;
            rt.muted = this.muted;
            rt.muteSupported = this.muteSupported;
            rt.name = this.name;
            rt.routedToBluetooth = this.routedToBluetooth;
            return rt;
        }
    }

    private final class VC extends Stub {
        private final String TAG;

        private VC() {
            this.TAG = VolumeDialogController.TAG + ".VC";
        }

        public void displaySafeVolumeWarning(int flags) throws RemoteException {
            if (C0543D.BUG) {
                Log.d(this.TAG, "displaySafeVolumeWarning " + Util.audioManagerFlagsToString(flags));
            }
            if (!VolumeDialogController.this.mDestroyed) {
                VolumeDialogController.this.mWorker.obtainMessage(14, flags, 0).sendToTarget();
            }
        }

        public void volumeChanged(int streamType, int flags) throws RemoteException {
            if (C0543D.BUG) {
                Log.d(this.TAG, "volumeChanged " + AudioSystem.streamToString(streamType) + " " + Util.audioManagerFlagsToString(flags));
            }
            if (!VolumeDialogController.this.mDestroyed) {
                VolumeDialogController.this.mWorker.obtainMessage(1, streamType, flags).sendToTarget();
            }
        }

        public void masterMuteChanged(int flags) throws RemoteException {
            if (C0543D.BUG) {
                Log.d(this.TAG, "masterMuteChanged");
            }
        }

        public void setLayoutDirection(int layoutDirection) throws RemoteException {
            if (C0543D.BUG) {
                Log.d(this.TAG, "setLayoutDirection");
            }
            if (!VolumeDialogController.this.mDestroyed) {
                VolumeDialogController.this.mWorker.obtainMessage(8, layoutDirection, 0).sendToTarget();
            }
        }

        public void dismiss() throws RemoteException {
            if (C0543D.BUG) {
                Log.d(this.TAG, "dismiss requested");
            }
            if (!VolumeDialogController.this.mDestroyed) {
                VolumeDialogController.this.mWorker.obtainMessage(2, 2, 0).sendToTarget();
                VolumeDialogController.this.mWorker.sendEmptyMessage(2);
            }
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialogController.W */
    private final class C0579W extends Handler {
        C0579W(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message msg) {
            boolean z = true;
            VolumeDialogController volumeDialogController;
            int i;
            switch (msg.what) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    VolumeDialogController.this.onVolumeChangedW(msg.arg1, msg.arg2);
                case 2:
                    VolumeDialogController.this.onDismissRequestedW(msg.arg1);
                case 3:
                    VolumeDialogController.this.onGetStateW();
                case 4:
                    volumeDialogController = VolumeDialogController.this;
                    i = msg.arg1;
                    if (msg.arg2 == 0) {
                        z = false;
                    }
                    volumeDialogController.onSetRingerModeW(i, z);
                case 5:
                    VolumeDialogController.this.onSetZenModeW(msg.arg1);
                case 6:
                    VolumeDialogController.this.onSetExitConditionW((Condition) msg.obj);
                case 7:
                    volumeDialogController = VolumeDialogController.this;
                    i = msg.arg1;
                    if (msg.arg2 == 0) {
                        z = false;
                    }
                    volumeDialogController.onSetStreamMuteW(i, z);
                case 8:
                    VolumeDialogController.this.mCallbacks.onLayoutDirectionChanged(msg.arg1);
                case 9:
                    VolumeDialogController.this.mCallbacks.onConfigurationChanged();
                case 10:
                    VolumeDialogController.this.onSetStreamVolumeW(msg.arg1, msg.arg2);
                case 11:
                    VolumeDialogController.this.onSetActiveStreamW(msg.arg1);
                case 12:
                    volumeDialogController = VolumeDialogController.this;
                    if (msg.arg1 == 0) {
                        z = false;
                    }
                    volumeDialogController.onNotifyVisibleW(z);
                case 13:
                    VolumeDialogController.this.onUserActivityW();
                case 14:
                    VolumeDialogController.this.onShowSafetyWarningW(msg.arg1);
                default:
            }
        }
    }

    static {
        TAG = Util.logTag(VolumeDialogController.class);
        STREAMS = new int[]{4, 6, 8, 3, 5, 2, 1, 7, 9, 0};
    }

    public VolumeDialogController(Context context, ComponentName component) {
        boolean z;
        this.mReceiver = new Receiver();
        this.mVolumeController = new VC();
        this.mCallbacks = new C0578C();
        this.mState = new State();
        this.mMediaSessionsCallbacksW = new MediaSessionsCallbacks();
        this.mShowDndTile = true;
        this.mContext = context.getApplicationContext();
        Events.writeEvent(this.mContext, 5, new Object[0]);
        this.mComponent = component;
        this.mWorkerThread = new HandlerThread(VolumeDialogController.class.getSimpleName());
        this.mWorkerThread.start();
        this.mWorker = new C0579W(this.mWorkerThread.getLooper());
        this.mMediaSessions = createMediaSessions(this.mContext, this.mWorkerThread.getLooper(), this.mMediaSessionsCallbacksW);
        this.mAudio = (AudioManager) this.mContext.getSystemService("audio");
        this.mNoMan = (NotificationManager) this.mContext.getSystemService("notification");
        this.mObserver = new SettingObserver(this.mWorker);
        this.mObserver.init();
        this.mReceiver.init();
        this.mStreamTitles = this.mContext.getResources().getStringArray(2131230941);
        this.mVibrator = (Vibrator) this.mContext.getSystemService("vibrator");
        if (this.mVibrator == null || !this.mVibrator.hasVibrator()) {
            z = false;
        } else {
            z = true;
        }
        this.mHasVibrator = z;
    }

    public AudioManager getAudioManager() {
        return this.mAudio;
    }

    public ZenModeConfig getZenModeConfig() {
        return this.mNoMan.getZenModeConfig();
    }

    public void dismiss() {
        this.mCallbacks.onDismissRequested(2);
    }

    public void register() {
        try {
            this.mAudio.setVolumeController(this.mVolumeController);
            setVolumePolicy(this.mVolumePolicy);
            showDndTile(this.mShowDndTile);
            try {
                this.mMediaSessions.init();
            } catch (SecurityException e) {
                Log.w(TAG, "No access to media sessions", e);
            }
        } catch (SecurityException e2) {
            Log.w(TAG, "Unable to set the volume controller", e2);
        }
    }

    public void setVolumePolicy(VolumePolicy policy) {
        this.mVolumePolicy = policy;
        if (this.mVolumePolicy != null) {
            try {
                this.mAudio.setVolumePolicy(this.mVolumePolicy);
            } catch (NoSuchMethodError e) {
                Log.w(TAG, "No volume policy api");
            }
        }
    }

    protected MediaSessions createMediaSessions(Context context, Looper looper, com.android.systemui.volume.MediaSessions.Callbacks callbacks) {
        return new MediaSessions(context, looper, callbacks);
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        pw.println(VolumeDialogController.class.getSimpleName() + " state:");
        pw.print("  mEnabled: ");
        pw.println(this.mEnabled);
        pw.print("  mDestroyed: ");
        pw.println(this.mDestroyed);
        pw.print("  mVolumePolicy: ");
        pw.println(this.mVolumePolicy);
        pw.print("  mState: ");
        pw.println(this.mState.toString(4));
        pw.print("  mShowDndTile: ");
        pw.println(this.mShowDndTile);
        pw.print("  mHasVibrator: ");
        pw.println(this.mHasVibrator);
        pw.print("  mRemoteStreams: ");
        pw.println(this.mMediaSessionsCallbacksW.mRemoteStreams.values());
        pw.println();
        this.mMediaSessions.dump(pw);
    }

    public void addCallback(Callbacks callback, Handler handler) {
        this.mCallbacks.add(callback, handler);
    }

    public void removeCallback(Callbacks callback) {
        this.mCallbacks.remove(callback);
    }

    public void getState() {
        if (!this.mDestroyed) {
            this.mWorker.sendEmptyMessage(3);
        }
    }

    public void notifyVisible(boolean visible) {
        if (!this.mDestroyed) {
            this.mWorker.obtainMessage(12, visible ? 1 : 0, 0).sendToTarget();
        }
    }

    public void userActivity() {
        if (!this.mDestroyed) {
            this.mWorker.removeMessages(13);
            this.mWorker.sendEmptyMessage(13);
        }
    }

    public void setRingerMode(int value, boolean external) {
        if (!this.mDestroyed) {
            this.mWorker.obtainMessage(4, value, external ? 1 : 0).sendToTarget();
        }
    }

    public void setStreamVolume(int stream, int level) {
        if (!this.mDestroyed) {
            this.mWorker.obtainMessage(10, stream, level).sendToTarget();
        }
    }

    public void setActiveStream(int stream) {
        if (!this.mDestroyed) {
            this.mWorker.obtainMessage(11, stream, 0).sendToTarget();
        }
    }

    public void vibrate() {
        if (this.mHasVibrator) {
            this.mVibrator.vibrate(50);
        }
    }

    public boolean hasVibrator() {
        return this.mHasVibrator;
    }

    private void onNotifyVisibleW(boolean visible) {
        if (!this.mDestroyed) {
            this.mAudio.notifyVolumeControllerVisible(this.mVolumeController, visible);
            if (!visible && updateActiveStreamW(-1)) {
                this.mCallbacks.onStateChanged(this.mState);
            }
        }
    }

    protected void onUserActivityW() {
    }

    private void onShowSafetyWarningW(int flags) {
        this.mCallbacks.onShowSafetyWarning(flags);
    }

    private boolean checkRoutedToBluetoothW(int stream) {
        if (stream != 3) {
            return false;
        }
        return false | updateStreamRoutedToBluetoothW(stream, (this.mAudio.getDevicesForStream(3) & 896) != 0);
    }

    private void onVolumeChangedW(int stream, int flags) {
        boolean showUI;
        boolean showVibrateHint;
        boolean showSilentHint;
        int i;
        if ((flags & 1) != 0) {
            showUI = true;
        } else {
            showUI = false;
        }
        boolean fromKey;
        if ((flags & 4096) != 0) {
            fromKey = true;
        } else {
            fromKey = false;
        }
        if ((flags & 2048) != 0) {
            showVibrateHint = true;
        } else {
            showVibrateHint = false;
        }
        if ((flags & 128) != 0) {
            showSilentHint = true;
        } else {
            showSilentHint = false;
        }
        boolean changed = false;
        if (showUI) {
            changed = false | updateActiveStreamW(stream);
        }
        changed |= updateStreamLevelW(stream, this.mAudio.getLastAudibleStreamVolume(stream));
        if (showUI) {
            i = 3;
        } else {
            i = stream;
        }
        changed |= checkRoutedToBluetoothW(i);
        if (changed) {
            this.mCallbacks.onStateChanged(this.mState);
        }
        if (showUI) {
            this.mCallbacks.onShowRequested(1);
        }
        if (showVibrateHint) {
            this.mCallbacks.onShowVibrateHint();
        }
        if (showSilentHint) {
            this.mCallbacks.onShowSilentHint();
        }
        if (changed && fromKey) {
            Events.writeEvent(this.mContext, 4, Integer.valueOf(stream), Integer.valueOf(lastAudibleStreamVolume));
        }
    }

    private boolean updateActiveStreamW(int activeStream) {
        if (activeStream == this.mState.activeStream) {
            return false;
        }
        this.mState.activeStream = activeStream;
        Events.writeEvent(this.mContext, 2, Integer.valueOf(activeStream));
        if (C0543D.BUG) {
            Log.d(TAG, "updateActiveStreamW " + activeStream);
        }
        int s = activeStream < 100 ? activeStream : -1;
        if (C0543D.BUG) {
            Log.d(TAG, "forceVolumeControlStream " + s);
        }
        this.mAudio.forceVolumeControlStream(s);
        return true;
    }

    private StreamState streamStateW(int stream) {
        StreamState ss = (StreamState) this.mState.states.get(stream);
        if (ss != null) {
            return ss;
        }
        ss = new StreamState();
        this.mState.states.put(stream, ss);
        return ss;
    }

    private void onGetStateW() {
        for (int stream : STREAMS) {
            updateStreamLevelW(stream, this.mAudio.getLastAudibleStreamVolume(stream));
            streamStateW(stream).levelMin = this.mAudio.getStreamMinVolume(stream);
            streamStateW(stream).levelMax = this.mAudio.getStreamMaxVolume(stream);
            updateStreamMuteW(stream, this.mAudio.isStreamMute(stream));
            StreamState ss = streamStateW(stream);
            ss.muteSupported = this.mAudio.isStreamAffectedByMute(stream);
            ss.name = this.mStreamTitles[stream];
            checkRoutedToBluetoothW(stream);
        }
        updateRingerModeExternalW(this.mAudio.getRingerMode());
        updateZenModeW();
        updateEffectsSuppressorW(this.mNoMan.getEffectsSuppressor());
        updateZenModeConfigW();
        this.mCallbacks.onStateChanged(this.mState);
    }

    private boolean updateStreamRoutedToBluetoothW(int stream, boolean routedToBluetooth) {
        StreamState ss = streamStateW(stream);
        if (ss.routedToBluetooth == routedToBluetooth) {
            return false;
        }
        ss.routedToBluetooth = routedToBluetooth;
        if (C0543D.BUG) {
            Log.d(TAG, "updateStreamRoutedToBluetoothW stream=" + stream + " routedToBluetooth=" + routedToBluetooth);
        }
        return true;
    }

    private boolean updateStreamLevelW(int stream, int level) {
        StreamState ss = streamStateW(stream);
        if (ss.level == level) {
            return false;
        }
        ss.level = level;
        if (isLogWorthy(stream)) {
            Events.writeEvent(this.mContext, 10, Integer.valueOf(stream), Integer.valueOf(level));
        }
        return true;
    }

    private static boolean isLogWorthy(int stream) {
        switch (stream) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
            case C0065R.styleable.NumPadKey_textView /*1*/:
            case 2:
            case 3:
            case 4:
            case 6:
                return true;
            default:
                return false;
        }
    }

    private boolean updateStreamMuteW(int stream, boolean muted) {
        StreamState ss = streamStateW(stream);
        if (ss.muted == muted) {
            return false;
        }
        ss.muted = muted;
        if (isLogWorthy(stream)) {
            Events.writeEvent(this.mContext, 15, Integer.valueOf(stream), Boolean.valueOf(muted));
        }
        if (muted && isRinger(stream)) {
            updateRingerModeInternalW(this.mAudio.getRingerModeInternal());
        }
        return true;
    }

    private static boolean isRinger(int stream) {
        return stream == 2 || stream == 5;
    }

    private boolean updateZenModeConfigW() {
        ZenModeConfig zenModeConfig = getZenModeConfig();
        if (Objects.equals(this.mState.zenModeConfig, zenModeConfig)) {
            return false;
        }
        this.mState.zenModeConfig = zenModeConfig;
        return true;
    }

    private boolean updateEffectsSuppressorW(ComponentName effectsSuppressor) {
        if (Objects.equals(this.mState.effectsSuppressor, effectsSuppressor)) {
            return false;
        }
        this.mState.effectsSuppressor = effectsSuppressor;
        this.mState.effectsSuppressorName = getApplicationName(this.mContext, this.mState.effectsSuppressor);
        Events.writeEvent(this.mContext, 14, this.mState.effectsSuppressor, this.mState.effectsSuppressorName);
        return true;
    }

    private static String getApplicationName(Context context, ComponentName component) {
        if (component == null) {
            return null;
        }
        PackageManager pm = context.getPackageManager();
        String pkg = component.getPackageName();
        try {
            String rt = Objects.toString(pm.getApplicationInfo(pkg, 0).loadLabel(pm), "").trim();
            if (rt.length() > 0) {
                return rt;
            }
        } catch (NameNotFoundException e) {
        }
        return pkg;
    }

    private boolean updateZenModeW() {
        int zen = Global.getInt(this.mContext.getContentResolver(), "zen_mode", 0);
        if (this.mState.zenMode == zen) {
            return false;
        }
        this.mState.zenMode = zen;
        Events.writeEvent(this.mContext, 13, Integer.valueOf(zen));
        return true;
    }

    private boolean updateRingerModeExternalW(int rm) {
        if (rm == this.mState.ringerModeExternal) {
            return false;
        }
        this.mState.ringerModeExternal = rm;
        Events.writeEvent(this.mContext, 12, Integer.valueOf(rm));
        return true;
    }

    private boolean updateRingerModeInternalW(int rm) {
        if (rm == this.mState.ringerModeInternal) {
            return false;
        }
        this.mState.ringerModeInternal = rm;
        Events.writeEvent(this.mContext, 11, Integer.valueOf(rm));
        return true;
    }

    private void onSetRingerModeW(int mode, boolean external) {
        if (external) {
            this.mAudio.setRingerMode(mode);
        } else {
            this.mAudio.setRingerModeInternal(mode);
        }
    }

    private void onSetStreamMuteW(int stream, boolean mute) {
        this.mAudio.adjustStreamVolume(stream, mute ? -100 : 100, 0);
    }

    private void onSetStreamVolumeW(int stream, int level) {
        if (C0543D.BUG) {
            Log.d(TAG, "onSetStreamVolume " + stream + " level=" + level);
        }
        if (stream >= 100) {
            this.mMediaSessionsCallbacksW.setStreamVolume(stream, level);
        } else {
            this.mAudio.setStreamVolume(stream, level, 0);
        }
    }

    private void onSetActiveStreamW(int stream) {
        if (updateActiveStreamW(stream)) {
            this.mCallbacks.onStateChanged(this.mState);
        }
    }

    private void onSetExitConditionW(Condition condition) {
        this.mNoMan.setZenMode(this.mState.zenMode, condition != null ? condition.id : null, TAG);
    }

    private void onSetZenModeW(int mode) {
        if (C0543D.BUG) {
            Log.d(TAG, "onSetZenModeW " + mode);
        }
        this.mNoMan.setZenMode(mode, null, TAG);
    }

    private void onDismissRequestedW(int reason) {
        this.mCallbacks.onDismissRequested(reason);
    }

    public void showDndTile(boolean visible) {
        if (C0543D.BUG) {
            Log.d(TAG, "showDndTile");
        }
        DndTile.setVisible(this.mContext, visible);
    }
}
