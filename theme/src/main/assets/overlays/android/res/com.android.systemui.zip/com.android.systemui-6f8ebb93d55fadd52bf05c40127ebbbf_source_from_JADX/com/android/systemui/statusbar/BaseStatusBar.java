package com.android.systemui.statusbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.app.ActivityManager;
import android.app.ActivityManager.RecentTaskInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.ActivityManagerNative;
import android.app.INotificationManager;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.app.TaskStackBuilder;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.UserInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.ThemeConfig;
import android.database.ContentObserver;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.os.UserManager;
import android.provider.Settings.Global;
import android.provider.Settings.Secure;
import android.service.dreams.IDreamManager;
import android.service.dreams.IDreamManager.Stub;
import android.service.notification.NotificationListenerService;
import android.service.notification.NotificationListenerService.RankingMap;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.Log;
import android.util.Slog;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.view.Display;
import android.view.IWindowManager;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.WindowManagerGlobal;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.AnimationUtils;
import android.widget.DateTimeView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RemoteViews;
import android.widget.RemoteViews.OnClickHandler;
import android.widget.TextView;
import android.widget.Toast;
import com.android.internal.logging.MetricsLogger;
import com.android.internal.statusbar.IStatusBarService;
import com.android.internal.statusbar.StatusBarIcon;
import com.android.internal.statusbar.StatusBarIconList;
import com.android.internal.util.NotificationColorUtil;
import com.android.internal.widget.LockPatternUtils;
import com.android.keyguard.KeyguardHostView.OnDismissAction;
import com.android.keyguard.KeyguardUpdateMonitor;
import com.android.systemui.DejankUtils;
import com.android.systemui.RecentsComponent;
import com.android.systemui.RecentsComponent.Callbacks;
import com.android.systemui.SwipeHelper.LongPressListener;
import com.android.systemui.SystemUI;
import com.android.systemui.assist.AssistManager;
import com.android.systemui.recents.Recents;
import com.android.systemui.statusbar.ActivatableNotificationView.OnActivatedListener;
import com.android.systemui.statusbar.ExpandableNotificationRow.ExpansionLogger;
import com.android.systemui.statusbar.NotificationData.Entry;
import com.android.systemui.statusbar.NotificationData.Environment;
import com.android.systemui.statusbar.phone.NavigationBarView;
import com.android.systemui.statusbar.phone.NotificationGroupManager;
import com.android.systemui.statusbar.phone.StatusBarKeyguardViewManager;
import com.android.systemui.statusbar.policy.HeadsUpManager;
import com.android.systemui.statusbar.policy.PreviewInflater;
import com.android.systemui.statusbar.stack.NotificationStackScrollLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public abstract class BaseStatusBar extends SystemUI implements Callbacks, OnActivatedListener, CommandQueue.Callbacks, ExpansionLogger, Environment {
    public static final boolean DEBUG;
    public static final boolean ENABLE_CHILD_NOTIFICATIONS;
    protected AccessibilityManager mAccessibilityManager;
    private ActivityManager mActivityManager;
    private final BroadcastReceiver mAllUsersReceiver;
    protected AssistManager mAssistManager;
    protected IStatusBarService mBarService;
    protected boolean mBouncerShowing;
    private final BroadcastReceiver mBroadcastReceiver;
    protected CommandQueue mCommandQueue;
    protected final SparseArray<UserInfo> mCurrentProfiles;
    protected ThemeConfig mCurrentTheme;
    protected int mCurrentUserId;
    protected boolean mDeviceInteractive;
    protected DevicePolicyManager mDevicePolicyManager;
    private boolean mDeviceProvisioned;
    protected boolean mDisableNotificationAlerts;
    protected DismissView mDismissView;
    protected Display mDisplay;
    protected IDreamManager mDreamManager;
    protected EmptyShadeView mEmptyShadeView;
    private TimeInterpolator mFastOutLinearIn;
    private float mFontScale;
    protected NotificationGroupManager mGroupManager;
    protected C0297H mHandler;
    protected HeadsUpManager mHeadsUpManager;
    protected boolean mHeadsUpTicker;
    protected NotificationOverflowContainer mKeyguardIconOverflowContainer;
    protected int mLayoutDirection;
    private TimeInterpolator mLinearOutSlowIn;
    private Locale mLocale;
    private boolean mLockscreenPublicMode;
    private final ContentObserver mLockscreenSettingsObserver;
    protected NavigationBarView mNavigationBarView;
    protected INotificationManager mNoMan;
    private NotificationClicker mNotificationClicker;
    private NotificationColorUtil mNotificationColorUtil;
    protected NotificationData mNotificationData;
    private NotificationGuts mNotificationGutsExposed;
    private final NotificationListenerService mNotificationListener;
    private OnClickHandler mOnClickHandler;
    PowerManager mPowerManager;
    private RecentsComponent mRecents;
    protected OnTouchListener mRecentsPreloadOnTouchListener;
    protected int mRowMaxHeight;
    protected int mRowMinHeight;
    protected final ContentObserver mSettingsObserver;
    protected boolean mShowLockscreenNotifications;
    protected SettingConfirmationSnackbarView mSnackbarView;
    protected NotificationStackScrollLayout mStackScroller;
    protected int mState;
    protected StatusBarKeyguardViewManager mStatusBarKeyguardViewManager;
    protected boolean mUseHeadsUp;
    protected boolean mUseNavBar;
    protected boolean mUseSwapKey;
    private UserManager mUserManager;
    private final SparseBooleanArray mUsersAllowingPrivateNotifications;
    protected boolean mVisible;
    private boolean mVisibleToUser;
    protected WindowManager mWindowManager;
    protected IWindowManager mWindowManagerService;
    protected int mZenMode;

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.10 */
    class AnonymousClass10 implements OnClickListener {
        final /* synthetic */ PendingIntent val$contentIntent;

        AnonymousClass10(PendingIntent pendingIntent) {
            this.val$contentIntent = pendingIntent;
        }

        public void onClick(View v) {
            if (this.val$contentIntent == null) {
                String text = BaseStatusBar.this.mContext.getResources().getString(2131361927);
                BaseStatusBar.this.animateCollapsePanels(0);
                Toast.makeText(BaseStatusBar.this.mContext, text, 0).show();
                return;
            }
            BaseStatusBar.this.launchFloating(this.val$contentIntent);
            BaseStatusBar.this.animateCollapsePanels(0);
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.11 */
    class AnonymousClass11 implements OnClickListener {
        final /* synthetic */ Intent val$appSettingsLaunchIntent;
        final /* synthetic */ int val$appUidF;
        final /* synthetic */ StatusBarNotification val$sbn;

        AnonymousClass11(Intent intent, StatusBarNotification statusBarNotification, int i) {
            this.val$appSettingsLaunchIntent = intent;
            this.val$sbn = statusBarNotification;
            this.val$appUidF = i;
        }

        public void onClick(View v) {
            MetricsLogger.action(BaseStatusBar.this.mContext, 206);
            BaseStatusBar.this.startAppOwnNotificationSettingsActivity(this.val$appSettingsLaunchIntent, this.val$sbn.getId(), this.val$sbn.getTag(), this.val$appUidF);
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.13 */
    class AnonymousClass13 extends AnimatorListenerAdapter {
        final /* synthetic */ NotificationGuts val$v;

        AnonymousClass13(NotificationGuts notificationGuts) {
            this.val$v = notificationGuts;
        }

        public void onAnimationEnd(Animator animation) {
            super.onAnimationEnd(animation);
            this.val$v.setVisibility(8);
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.15 */
    class AnonymousClass15 implements OnDismissAction {
        final /* synthetic */ boolean val$afterKeyguardGone;
        final /* synthetic */ PendingIntent val$intent;
        final /* synthetic */ boolean val$keyguardShowing;

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.15.1 */
        class C02811 extends Thread {
            C02811() {
            }

            public void run() {
                try {
                    if (AnonymousClass15.this.val$keyguardShowing && !AnonymousClass15.this.val$afterKeyguardGone) {
                        ActivityManagerNative.getDefault().keyguardWaitingForActivityDrawn();
                    }
                    ActivityManagerNative.getDefault().resumeAppSwitches();
                } catch (RemoteException e) {
                }
                try {
                    AnonymousClass15.this.val$intent.send();
                } catch (CanceledException e2) {
                    Log.w("StatusBar", "Sending intent failed: " + e2);
                }
                if (AnonymousClass15.this.val$intent.isActivity()) {
                    BaseStatusBar.this.mAssistManager.hideAssist();
                    BaseStatusBar baseStatusBar = BaseStatusBar.this;
                    boolean z = AnonymousClass15.this.val$keyguardShowing && !AnonymousClass15.this.val$afterKeyguardGone;
                    baseStatusBar.overrideActivityPendingAppTransition(z);
                }
            }
        }

        AnonymousClass15(boolean z, boolean z2, PendingIntent pendingIntent) {
            this.val$keyguardShowing = z;
            this.val$afterKeyguardGone = z2;
            this.val$intent = pendingIntent;
        }

        public boolean onDismiss() {
            new C02811().start();
            BaseStatusBar.this.animateCollapsePanels(2, true, true);
            BaseStatusBar.this.visibilityChanged(false);
            return true;
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.1 */
    class C02821 extends ContentObserver {
        C02821(Handler x0) {
            super(x0);
        }

        public void onChange(boolean selfChange) {
            boolean provisioned;
            if (Global.getInt(BaseStatusBar.this.mContext.getContentResolver(), "device_provisioned", 0) != 0) {
                provisioned = true;
            } else {
                provisioned = false;
            }
            if (provisioned != BaseStatusBar.this.mDeviceProvisioned) {
                BaseStatusBar.this.mDeviceProvisioned = provisioned;
                BaseStatusBar.this.updateNotifications();
            }
            BaseStatusBar.this.setZenMode(Global.getInt(BaseStatusBar.this.mContext.getContentResolver(), "zen_mode", 0));
            BaseStatusBar.this.updateLockscreenNotificationSetting();
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.2 */
    class C02832 extends ContentObserver {
        C02832(Handler x0) {
            super(x0);
        }

        public void onChange(boolean selfChange) {
            BaseStatusBar.this.mUsersAllowingPrivateNotifications.clear();
            BaseStatusBar.this.updateNotifications();
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.3 */
    class C02853 extends OnClickHandler {

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.3.1 */
        class C02841 implements OnDismissAction {
            final /* synthetic */ boolean val$afterKeyguardGone;
            final /* synthetic */ Intent val$fillInIntent;
            final /* synthetic */ boolean val$keyguardShowing;
            final /* synthetic */ PendingIntent val$pendingIntent;
            final /* synthetic */ View val$view;

            C02841(boolean z, boolean z2, View view, PendingIntent pendingIntent, Intent intent) {
                this.val$keyguardShowing = z;
                this.val$afterKeyguardGone = z2;
                this.val$view = view;
                this.val$pendingIntent = pendingIntent;
                this.val$fillInIntent = intent;
            }

            public boolean onDismiss() {
                if (this.val$keyguardShowing && !this.val$afterKeyguardGone) {
                    try {
                        ActivityManagerNative.getDefault().keyguardWaitingForActivityDrawn();
                        ActivityManagerNative.getDefault().resumeAppSwitches();
                    } catch (RemoteException e) {
                    }
                }
                boolean handled = C02853.this.superOnClickHandler(this.val$view, this.val$pendingIntent, this.val$fillInIntent);
                BaseStatusBar baseStatusBar = BaseStatusBar.this;
                boolean z = this.val$keyguardShowing && !this.val$afterKeyguardGone;
                baseStatusBar.overrideActivityPendingAppTransition(z);
                if (handled) {
                    BaseStatusBar.this.animateCollapsePanels(2, true);
                    BaseStatusBar.this.visibilityChanged(false);
                    BaseStatusBar.this.mAssistManager.hideAssist();
                }
                return handled;
            }
        }

        C02853() {
        }

        public boolean onClickHandler(View view, PendingIntent pendingIntent, Intent fillInIntent) {
            if (BaseStatusBar.DEBUG) {
                Log.v("StatusBar", "Notification click handler invoked for intent: " + pendingIntent);
            }
            logActionClick(view);
            try {
                ActivityManagerNative.getDefault().resumeAppSwitches();
            } catch (RemoteException e) {
            }
            if (!pendingIntent.isActivity()) {
                return super.onClickHandler(view, pendingIntent, fillInIntent);
            }
            boolean keyguardShowing = BaseStatusBar.this.mStatusBarKeyguardViewManager.isShowing();
            boolean afterKeyguardGone = PreviewInflater.wouldLaunchResolverActivity(BaseStatusBar.this.mContext, pendingIntent.getIntent(), BaseStatusBar.this.mCurrentUserId);
            BaseStatusBar.this.dismissKeyguardThenExecute(new C02841(keyguardShowing, afterKeyguardGone, view, pendingIntent, fillInIntent), afterKeyguardGone);
            return true;
        }

        private void logActionClick(View view) {
            ViewParent parent = view.getParent();
            String key = getNotificationKeyForParent(parent);
            if (key == null) {
                Log.w("StatusBar", "Couldn't determine notification for click.");
                return;
            }
            int index = -1;
            if (view.getId() == 16909161 && parent != null && (parent instanceof ViewGroup)) {
                index = ((ViewGroup) parent).indexOfChild(view);
            }
            Log.d("StatusBar", "Clicked on button " + index + " for " + key);
            try {
                BaseStatusBar.this.mBarService.onNotificationActionClick(key, index);
            } catch (RemoteException e) {
            }
        }

        private String getNotificationKeyForParent(ViewParent parent) {
            while (parent != null) {
                if (parent instanceof ExpandableNotificationRow) {
                    return ((ExpandableNotificationRow) parent).getStatusBarNotification().getKey();
                }
                parent = parent.getParent();
            }
            return null;
        }

        private boolean superOnClickHandler(View view, PendingIntent pendingIntent, Intent fillInIntent) {
            return super.onClickHandler(view, pendingIntent, fillInIntent);
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.4 */
    class C02864 extends BroadcastReceiver {
        C02864() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.USER_SWITCHED".equals(action)) {
                BaseStatusBar.this.mCurrentUserId = intent.getIntExtra("android.intent.extra.user_handle", -1);
                BaseStatusBar.this.updateCurrentProfilesCache();
                Log.v("StatusBar", "userId " + BaseStatusBar.this.mCurrentUserId + " is in the house");
                BaseStatusBar.this.updateLockscreenNotificationSetting();
                BaseStatusBar.this.userSwitched(BaseStatusBar.this.mCurrentUserId);
            } else if ("android.intent.action.USER_ADDED".equals(action)) {
                BaseStatusBar.this.updateCurrentProfilesCache();
            } else if ("android.intent.action.USER_PRESENT".equals(action)) {
                List<RecentTaskInfo> recentTask = null;
                try {
                    recentTask = ActivityManagerNative.getDefault().getRecentTasks(1, 5, BaseStatusBar.this.mCurrentUserId);
                } catch (RemoteException e) {
                }
                if (recentTask != null && recentTask.size() > 0) {
                    UserInfo user = BaseStatusBar.this.mUserManager.getUserInfo(((RecentTaskInfo) recentTask.get(0)).userId);
                    if (user != null && user.isManagedProfile()) {
                        Toast toast = Toast.makeText(BaseStatusBar.this.mContext, 2131362332, 0);
                        TextView text = (TextView) toast.getView().findViewById(16908299);
                        text.setCompoundDrawablesRelativeWithIntrinsicBounds(2130837871, 0, 0, 0);
                        text.setCompoundDrawablePadding(BaseStatusBar.this.mContext.getResources().getDimensionPixelSize(2131296467));
                        toast.show();
                    }
                }
            } else if ("com.android.systemui.statusbar.banner_action_cancel".equals(action) || "com.android.systemui.statusbar.banner_action_setup".equals(action)) {
                ((NotificationManager) BaseStatusBar.this.mContext.getSystemService("notification")).cancel(2131755034);
                Secure.putInt(BaseStatusBar.this.mContext.getContentResolver(), "show_note_about_notification_hiding", 0);
                if ("com.android.systemui.statusbar.banner_action_setup".equals(action)) {
                    BaseStatusBar.this.animateCollapsePanels(2, true);
                    BaseStatusBar.this.mContext.startActivity(new Intent("android.settings.ACTION_APP_NOTIFICATION_REDACTION").addFlags(268435456));
                }
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.5 */
    class C02875 extends BroadcastReceiver {
        C02875() {
        }

        public void onReceive(Context context, Intent intent) {
            if ("android.app.action.DEVICE_POLICY_MANAGER_STATE_CHANGED".equals(intent.getAction()) && BaseStatusBar.this.isCurrentProfile(getSendingUserId())) {
                BaseStatusBar.this.mUsersAllowingPrivateNotifications.clear();
                BaseStatusBar.this.updateLockscreenNotificationSetting();
                BaseStatusBar.this.updateNotifications();
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.6 */
    class C02926 extends NotificationListenerService {

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.6.1 */
        class C02881 implements Runnable {
            final /* synthetic */ RankingMap val$currentRanking;
            final /* synthetic */ StatusBarNotification[] val$notifications;

            C02881(StatusBarNotification[] statusBarNotificationArr, RankingMap rankingMap) {
                this.val$notifications = statusBarNotificationArr;
                this.val$currentRanking = rankingMap;
            }

            public void run() {
                for (StatusBarNotification sbn : this.val$notifications) {
                    BaseStatusBar.this.addNotification(sbn, this.val$currentRanking, null);
                }
            }
        }

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.6.2 */
        class C02892 implements Runnable {
            final /* synthetic */ RankingMap val$rankingMap;
            final /* synthetic */ StatusBarNotification val$sbn;

            C02892(StatusBarNotification statusBarNotification, RankingMap rankingMap) {
                this.val$sbn = statusBarNotification;
                this.val$rankingMap = rankingMap;
            }

            public void run() {
                String key = this.val$sbn.getKey();
                boolean isUpdate = BaseStatusBar.this.mNotificationData.get(key) != null;
                if (!BaseStatusBar.ENABLE_CHILD_NOTIFICATIONS && BaseStatusBar.this.mGroupManager.isChildInGroupWithSummary(this.val$sbn)) {
                    if (BaseStatusBar.DEBUG) {
                        Log.d("StatusBar", "Ignoring group child due to existing summary: " + this.val$sbn);
                    }
                    if (isUpdate) {
                        BaseStatusBar.this.removeNotification(key, this.val$rankingMap);
                    } else {
                        BaseStatusBar.this.mNotificationData.updateRanking(this.val$rankingMap);
                    }
                } else if (isUpdate) {
                    BaseStatusBar.this.updateNotification(this.val$sbn, this.val$rankingMap);
                } else {
                    BaseStatusBar.this.addNotification(this.val$sbn, this.val$rankingMap, null);
                }
            }
        }

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.6.3 */
        class C02903 implements Runnable {
            final /* synthetic */ String val$key;
            final /* synthetic */ RankingMap val$rankingMap;

            C02903(String str, RankingMap rankingMap) {
                this.val$key = str;
                this.val$rankingMap = rankingMap;
            }

            public void run() {
                BaseStatusBar.this.removeNotification(this.val$key, this.val$rankingMap);
            }
        }

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.6.4 */
        class C02914 implements Runnable {
            final /* synthetic */ RankingMap val$rankingMap;

            C02914(RankingMap rankingMap) {
                this.val$rankingMap = rankingMap;
            }

            public void run() {
                BaseStatusBar.this.updateNotificationRanking(this.val$rankingMap);
            }
        }

        C02926() {
        }

        public void onListenerConnected() {
            if (BaseStatusBar.DEBUG) {
                Log.d("StatusBar", "onListenerConnected");
            }
            StatusBarNotification[] notifications = getActiveNotifications();
            if (notifications == null) {
                Log.w("StatusBar", "onListenerConnected unable to get active notifications.");
                return;
            }
            BaseStatusBar.this.mHandler.post(new C02881(notifications, getCurrentRanking()));
        }

        public void onNotificationPosted(StatusBarNotification sbn, RankingMap rankingMap) {
            if (BaseStatusBar.DEBUG) {
                Log.d("StatusBar", "onNotificationPosted: " + sbn);
            }
            if (sbn != null) {
                BaseStatusBar.this.mHandler.post(new C02892(sbn, rankingMap));
            }
        }

        public void onNotificationRemoved(StatusBarNotification sbn, RankingMap rankingMap) {
            if (BaseStatusBar.DEBUG) {
                Log.d("StatusBar", "onNotificationRemoved: " + sbn);
            }
            if (sbn != null) {
                BaseStatusBar.this.mHandler.post(new C02903(sbn.getKey(), rankingMap));
            }
        }

        public void onNotificationRankingUpdate(RankingMap rankingMap) {
            if (BaseStatusBar.DEBUG) {
                Log.d("StatusBar", "onRankingUpdate");
            }
            if (rankingMap != null) {
                BaseStatusBar.this.mHandler.post(new C02914(rankingMap));
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.7 */
    class C02937 implements OnClickListener {
        final /* synthetic */ int val$_id;
        final /* synthetic */ String val$_pkg;
        final /* synthetic */ String val$_tag;
        final /* synthetic */ int val$_userId;

        C02937(String str, String str2, int i, int i2) {
            this.val$_pkg = str;
            this.val$_tag = str2;
            this.val$_id = i;
            this.val$_userId = i2;
        }

        public void onClick(View v) {
            v.announceForAccessibility(BaseStatusBar.this.mContext.getString(2131362096));
            try {
                BaseStatusBar.this.mBarService.onNotificationClear(this.val$_pkg, this.val$_tag, this.val$_id, this.val$_userId);
            } catch (RemoteException e) {
            }
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.8 */
    class C02958 implements OnDismissAction {
        final /* synthetic */ int val$appUid;
        final /* synthetic */ Intent val$intent;
        final /* synthetic */ boolean val$keyguardShowing;

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.8.1 */
        class C02941 implements Runnable {
            C02941() {
            }

            public void run() {
                try {
                    if (C02958.this.val$keyguardShowing) {
                        ActivityManagerNative.getDefault().keyguardWaitingForActivityDrawn();
                    }
                    TaskStackBuilder.create(BaseStatusBar.this.mContext).addNextIntentWithParentStack(C02958.this.val$intent).startActivities(null, new UserHandle(UserHandle.getUserId(C02958.this.val$appUid)));
                    BaseStatusBar.this.overrideActivityPendingAppTransition(C02958.this.val$keyguardShowing);
                } catch (RemoteException e) {
                }
            }
        }

        C02958(boolean z, Intent intent, int i) {
            this.val$keyguardShowing = z;
            this.val$intent = intent;
            this.val$appUid = i;
        }

        public boolean onDismiss() {
            AsyncTask.execute(new C02941());
            BaseStatusBar.this.animateCollapsePanels(2, true);
            return true;
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.9 */
    class C02969 implements OnClickListener {
        final /* synthetic */ int val$appUidF;
        final /* synthetic */ String val$pkg;

        C02969(String str, int i) {
            this.val$pkg = str;
            this.val$appUidF = i;
        }

        public void onClick(View v) {
            MetricsLogger.action(BaseStatusBar.this.mContext, 205);
            BaseStatusBar.this.startAppNotificationSettingsActivity(this.val$pkg, this.val$appUidF);
        }
    }

    /* renamed from: com.android.systemui.statusbar.BaseStatusBar.H */
    protected class C0297H extends Handler {
        protected C0297H() {
        }

        public void handleMessage(Message m) {
            boolean z = true;
            switch (m.what) {
                case 1019:
                    BaseStatusBar baseStatusBar = BaseStatusBar.this;
                    if (m.arg1 <= 0) {
                        z = false;
                    }
                    baseStatusBar.showRecents(z);
                case 1020:
                    BaseStatusBar baseStatusBar2 = BaseStatusBar.this;
                    boolean z2 = m.arg1 > 0;
                    if (m.arg2 <= 0) {
                        z = false;
                    }
                    baseStatusBar2.hideRecents(z2, z);
                case 1021:
                    BaseStatusBar.this.toggleRecents();
                case 1022:
                    BaseStatusBar.this.preloadRecents();
                case 1023:
                    BaseStatusBar.this.cancelPreloadingRecents();
                case 1024:
                    BaseStatusBar.this.showRecentsNextAffiliatedTask();
                case 1025:
                    BaseStatusBar.this.showRecentsPreviousAffiliatedTask();
                default:
            }
        }
    }

    private final class NotificationClicker implements OnClickListener {

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.NotificationClicker.1 */
        class C02981 implements Runnable {
            final /* synthetic */ PendingIntent val$intent;
            final /* synthetic */ ExpandableNotificationRow val$row;
            final /* synthetic */ StatusBarNotification val$sbn;
            final /* synthetic */ View val$v;

            C02981(View view, StatusBarNotification statusBarNotification, PendingIntent pendingIntent, ExpandableNotificationRow expandableNotificationRow) {
                this.val$v = view;
                this.val$sbn = statusBarNotification;
                this.val$intent = pendingIntent;
                this.val$row = expandableNotificationRow;
            }

            public void run() {
                if (BaseStatusBar.this.FloatingHeadsup()) {
                    HeadsUpManager headsUpManager = BaseStatusBar.this.mHeadsUpManager;
                    if (HeadsUpManager.isClickedHeadsUpNotification(this.val$v)) {
                        boolean floating = true;
                        try {
                            floating = BaseStatusBar.this.mNoMan.getPackageFloating(this.val$sbn.getPackageName(), this.val$sbn.getUid());
                        } catch (RemoteException e) {
                        }
                        if (!floating || BaseStatusBar.this.isUserOnLauncher()) {
                            Toast.makeText(BaseStatusBar.this.mContext, BaseStatusBar.this.mContext.getResources().getString(2131361930), 1).show();
                        } else {
                            BaseStatusBar.this.launchFloating(this.val$intent);
                        }
                    }
                }
                this.val$row.setJustClicked(false);
            }
        }

        /* renamed from: com.android.systemui.statusbar.BaseStatusBar.NotificationClicker.2 */
        class C03002 implements OnDismissAction {
            final /* synthetic */ boolean val$afterKeyguardGone;
            final /* synthetic */ PendingIntent val$intent;
            final /* synthetic */ boolean val$keyguardShowing;
            final /* synthetic */ String val$notificationKey;
            final /* synthetic */ ExpandableNotificationRow val$row;

            /* renamed from: com.android.systemui.statusbar.BaseStatusBar.NotificationClicker.2.1 */
            class C02991 extends Thread {
                C02991() {
                }

                public void run() {
                    try {
                        if (C03002.this.val$keyguardShowing && !C03002.this.val$afterKeyguardGone) {
                            ActivityManagerNative.getDefault().keyguardWaitingForActivityDrawn();
                        }
                        ActivityManagerNative.getDefault().resumeAppSwitches();
                    } catch (RemoteException e) {
                    }
                    if (C03002.this.val$intent != null) {
                        try {
                            C03002.this.val$intent.send();
                        } catch (CanceledException e2) {
                            Log.w("StatusBar", "Sending contentIntent failed: " + e2);
                        }
                        if (C03002.this.val$intent.isActivity()) {
                            BaseStatusBar.this.mAssistManager.hideAssist();
                            BaseStatusBar baseStatusBar = BaseStatusBar.this;
                            boolean z = C03002.this.val$keyguardShowing && !C03002.this.val$afterKeyguardGone;
                            baseStatusBar.overrideActivityPendingAppTransition(z);
                        }
                    }
                    try {
                        BaseStatusBar.this.mBarService.onNotificationClick(C03002.this.val$notificationKey);
                    } catch (RemoteException e3) {
                    }
                }
            }

            C03002(String str, ExpandableNotificationRow expandableNotificationRow, boolean z, boolean z2, PendingIntent pendingIntent) {
                this.val$notificationKey = str;
                this.val$row = expandableNotificationRow;
                this.val$keyguardShowing = z;
                this.val$afterKeyguardGone = z2;
                this.val$intent = pendingIntent;
            }

            public boolean onDismiss() {
                if (BaseStatusBar.this.mHeadsUpManager != null && BaseStatusBar.this.mHeadsUpManager.isHeadsUp(this.val$notificationKey)) {
                    HeadsUpManager.setIsClickedNotification(this.val$row, true);
                    BaseStatusBar.this.mHeadsUpManager.releaseImmediately(this.val$notificationKey);
                }
                new C02991().start();
                BaseStatusBar.this.animateCollapsePanels(2, true, true);
                BaseStatusBar.this.visibilityChanged(false);
                return true;
            }
        }

        private NotificationClicker() {
        }

        public void onClick(View v) {
            boolean afterKeyguardGone = true;
            if (v instanceof ExpandableNotificationRow) {
                ExpandableNotificationRow row = (ExpandableNotificationRow) v;
                StatusBarNotification sbn = row.getStatusBarNotification();
                if (sbn == null) {
                    Log.e("StatusBar", "NotificationClicker called on an unclickable notification,");
                    return;
                }
                PendingIntent intent = sbn.getNotification().contentIntent;
                String notificationKey = sbn.getKey();
                row.setJustClicked(true);
                DejankUtils.postAfterTraversal(new C02981(v, sbn, intent, row));
                Log.d("StatusBar", "Clicked on content of " + notificationKey);
                boolean keyguardShowing = BaseStatusBar.this.mStatusBarKeyguardViewManager.isShowing();
                if (!(intent.isActivity() && PreviewInflater.wouldLaunchResolverActivity(BaseStatusBar.this.mContext, intent.getIntent(), BaseStatusBar.this.mCurrentUserId))) {
                    afterKeyguardGone = false;
                }
                BaseStatusBar.this.dismissKeyguardThenExecute(new C03002(notificationKey, row, keyguardShowing, afterKeyguardGone, intent), afterKeyguardGone);
                return;
            }
            Log.e("StatusBar", "NotificationClicker called on a view that is not a notification row.");
        }

        public void register(ExpandableNotificationRow row, StatusBarNotification sbn) {
            if (sbn.getNotification().contentIntent != null) {
                row.setOnClickListener(this);
            } else {
                row.setOnClickListener(null);
            }
        }
    }

    public abstract void addNotification(StatusBarNotification statusBarNotification, RankingMap rankingMap, Entry entry);

    protected abstract void createAndAddWindows();

    protected abstract int getMaxKeyguardNotifications();

    protected abstract View getStatusBarView();

    protected abstract boolean isPanelFullyCollapsed();

    protected abstract boolean isSnoozedPackage(StatusBarNotification statusBarNotification);

    public abstract void maybeEscalateHeadsUp();

    protected abstract void refreshLayout(int i);

    public abstract void removeNotification(String str, RankingMap rankingMap);

    protected abstract void setAreThereNotifications();

    protected abstract void setHeadsUpUser(int i);

    protected abstract void updateHeadsUp(String str, Entry entry, boolean z, boolean z2);

    protected abstract void updateNotificationRanking(RankingMap rankingMap);

    protected abstract void updateNotifications();

    public BaseStatusBar() {
        this.mHandler = createHandler();
        this.mGroupManager = new NotificationGroupManager();
        this.mCurrentUserId = 0;
        this.mCurrentProfiles = new SparseArray();
        this.mLayoutDirection = -1;
        this.mNavigationBarView = null;
        this.mSnackbarView = null;
        this.mUseHeadsUp = false;
        this.mHeadsUpTicker = false;
        this.mDisableNotificationAlerts = false;
        this.mUseNavBar = false;
        this.mUseSwapKey = false;
        this.mLockscreenPublicMode = false;
        this.mUsersAllowingPrivateNotifications = new SparseBooleanArray();
        this.mDeviceProvisioned = false;
        this.mNotificationClicker = new NotificationClicker();
        this.mSettingsObserver = new C02821(this.mHandler);
        this.mLockscreenSettingsObserver = new C02832(this.mHandler);
        this.mOnClickHandler = new C02853();
        this.mBroadcastReceiver = new C02864();
        this.mAllUsersReceiver = new C02875();
        this.mNotificationListener = new C02926();
        this.mRecentsPreloadOnTouchListener = new OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction() & 255;
                if (action == 0) {
                    BaseStatusBar.this.preloadRecents();
                } else if (action == 3) {
                    BaseStatusBar.this.cancelPreloadingRecents();
                } else if (action == 1 && !v.isPressed()) {
                    BaseStatusBar.this.cancelPreloadingRecents();
                }
                return false;
            }
        };
    }

    static {
        boolean z = false;
        DEBUG = Log.isLoggable("StatusBar", 3);
        if (Build.IS_DEBUGGABLE && SystemProperties.getBoolean("debug.child_notifs", false)) {
            z = true;
        }
        ENABLE_CHILD_NOTIFICATIONS = z;
    }

    public boolean isDeviceProvisioned() {
        return this.mDeviceProvisioned;
    }

    private void updateCurrentProfilesCache() {
        synchronized (this.mCurrentProfiles) {
            this.mCurrentProfiles.clear();
            if (this.mUserManager != null) {
                for (UserInfo user : this.mUserManager.getProfiles(this.mCurrentUserId)) {
                    this.mCurrentProfiles.put(user.id, user);
                }
            }
        }
    }

    public void start() {
        this.mWindowManager = (WindowManager) this.mContext.getSystemService("window");
        this.mWindowManagerService = WindowManagerGlobal.getWindowManagerService();
        this.mDisplay = this.mWindowManager.getDefaultDisplay();
        this.mDevicePolicyManager = (DevicePolicyManager) this.mContext.getSystemService("device_policy");
        this.mNotificationColorUtil = NotificationColorUtil.getInstance(this.mContext);
        this.mNotificationData = new NotificationData(this);
        this.mAccessibilityManager = (AccessibilityManager) this.mContext.getSystemService("accessibility");
        this.mActivityManager = (ActivityManager) this.mContext.getSystemService("activity");
        this.mDreamManager = Stub.asInterface(ServiceManager.checkService("dreams"));
        this.mPowerManager = (PowerManager) this.mContext.getSystemService("power");
        this.mNoMan = INotificationManager.Stub.asInterface(ServiceManager.getService("notification"));
        this.mContext.getContentResolver().registerContentObserver(Global.getUriFor("device_provisioned"), true, this.mSettingsObserver);
        this.mContext.getContentResolver().registerContentObserver(Global.getUriFor("zen_mode"), false, this.mSettingsObserver);
        this.mContext.getContentResolver().registerContentObserver(Secure.getUriFor("lock_screen_show_notifications"), false, this.mSettingsObserver, -1);
        this.mContext.getContentResolver().registerContentObserver(Secure.getUriFor("lock_screen_allow_private_notifications"), true, this.mLockscreenSettingsObserver, -1);
        this.mBarService = IStatusBarService.Stub.asInterface(ServiceManager.getService("statusbar"));
        this.mRecents = (RecentsComponent) getComponent(Recents.class);
        this.mRecents.setCallback(this);
        Configuration currentConfig = this.mContext.getResources().getConfiguration();
        this.mLocale = currentConfig.locale;
        this.mLayoutDirection = TextUtils.getLayoutDirectionFromLocale(this.mLocale);
        this.mFontScale = currentConfig.fontScale;
        this.mUserManager = (UserManager) this.mContext.getSystemService("user");
        this.mLinearOutSlowIn = AnimationUtils.loadInterpolator(this.mContext, 17563662);
        this.mFastOutLinearIn = AnimationUtils.loadInterpolator(this.mContext, 17563663);
        StatusBarIconList iconList = new StatusBarIconList();
        this.mCommandQueue = new CommandQueue(this, iconList);
        int[] switches = new int[8];
        ArrayList<IBinder> binders = new ArrayList();
        try {
            this.mBarService.registerStatusBar(this.mCommandQueue, iconList, switches, binders);
        } catch (RemoteException e) {
        }
        createAndAddWindows();
        this.mSettingsObserver.onChange(false);
        disable(switches[0], switches[6], false);
        setSystemUiVisibility(switches[1], -1);
        topAppWindowChanged(switches[2] != 0);
        setImeWindowStatus((IBinder) binders.get(0), switches[3], switches[4], switches[5] != 0);
        int N = iconList.size();
        int viewIndex = 0;
        for (int i = 0; i < N; i++) {
            StatusBarIcon icon = iconList.getIcon(i);
            if (icon != null) {
                addIcon(iconList.getSlot(i), i, viewIndex, icon);
                viewIndex++;
            }
        }
        try {
            this.mNotificationListener.registerAsSystemService(this.mContext, new ComponentName(this.mContext.getPackageName(), getClass().getCanonicalName()), -1);
        } catch (RemoteException e2) {
            Log.e("StatusBar", "Unable to register notification listener", e2);
        }
        if (DEBUG) {
            Log.d("StatusBar", String.format("init: icons=%d disabled=0x%08x lights=0x%08x menu=0x%08x imeButton=0x%08x", new Object[]{Integer.valueOf(iconList.size()), Integer.valueOf(switches[0]), Integer.valueOf(switches[1]), Integer.valueOf(switches[2]), Integer.valueOf(switches[3])}));
        }
        this.mCurrentUserId = ActivityManager.getCurrentUser();
        setHeadsUpUser(this.mCurrentUserId);
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.intent.action.USER_SWITCHED");
        filter.addAction("android.intent.action.USER_ADDED");
        filter.addAction("android.intent.action.USER_PRESENT");
        filter.addAction("com.android.systemui.statusbar.banner_action_cancel");
        filter.addAction("com.android.systemui.statusbar.banner_action_setup");
        this.mContext.registerReceiver(this.mBroadcastReceiver, filter);
        IntentFilter allUsersFilter = new IntentFilter();
        allUsersFilter.addAction("android.app.action.DEVICE_POLICY_MANAGER_STATE_CHANGED");
        this.mContext.registerReceiverAsUser(this.mAllUsersReceiver, UserHandle.ALL, allUsersFilter, null, null);
        updateCurrentProfilesCache();
    }

    protected void notifyUserAboutHiddenNotifications() {
        if (Secure.getInt(this.mContext.getContentResolver(), "show_note_about_notification_hiding", 1) != 0) {
            Log.d("StatusBar", "user hasn't seen notification about hidden notifications");
            if (new LockPatternUtils(this.mContext).isSecure(KeyguardUpdateMonitor.getCurrentUser())) {
                Log.d("StatusBar", "disabling lockecreen notifications and alerting the user");
                Secure.putInt(this.mContext.getContentResolver(), "lock_screen_show_notifications", 0);
                Secure.putInt(this.mContext.getContentResolver(), "lock_screen_allow_private_notifications", 0);
                String packageName = this.mContext.getPackageName();
                PendingIntent cancelIntent = PendingIntent.getBroadcast(this.mContext, 0, new Intent("com.android.systemui.statusbar.banner_action_cancel").setPackage(packageName), 268435456);
                PendingIntent setupIntent = PendingIntent.getBroadcast(this.mContext, 0, new Intent("com.android.systemui.statusbar.banner_action_setup").setPackage(packageName), 268435456);
                Resources res = this.mContext.getResources();
                ((NotificationManager) this.mContext.getSystemService("notification")).notify(2131755034, new Builder(this.mContext).setSmallIcon(2130837541).setContentTitle(this.mContext.getString(2131362309)).setContentText(this.mContext.getString(2131362310)).setPriority(1).setOngoing(true).setColor(this.mContext.getColor(17170521)).setContentIntent(setupIntent).addAction(2130837560, this.mContext.getString(2131362311), cancelIntent).addAction(2130837697, this.mContext.getString(2131362312), setupIntent).build());
                return;
            }
            Log.d("StatusBar", "insecure lockscreen, skipping notification");
            Secure.putInt(this.mContext.getContentResolver(), "show_note_about_notification_hiding", 0);
        }
    }

    public void userSwitched(int newUserId) {
        setHeadsUpUser(newUserId);
    }

    public boolean isNotificationForCurrentProfiles(StatusBarNotification n) {
        int thisUserId = this.mCurrentUserId;
        int notificationUserId = n.getUserId();
        if (DEBUG) {
        }
        return isCurrentProfile(notificationUserId);
    }

    protected void setNotificationShown(StatusBarNotification n) {
        setNotificationsShown(new String[]{n.getKey()});
    }

    protected void setNotificationsShown(String[] keys) {
        try {
            this.mNotificationListener.setNotificationsShown(keys);
        } catch (RuntimeException e) {
            Log.d("StatusBar", "failed setNotificationsShown: ", e);
        }
    }

    protected boolean isCurrentProfile(int userId) {
        boolean z;
        synchronized (this.mCurrentProfiles) {
            if (userId != -1) {
                if (this.mCurrentProfiles.get(userId) == null) {
                    z = false;
                }
            }
            z = true;
        }
        return z;
    }

    public String getCurrentMediaNotificationKey() {
        return null;
    }

    public NotificationGroupManager getGroupManager() {
        return this.mGroupManager;
    }

    protected void dismissKeyguardThenExecute(OnDismissAction action, boolean afterKeyguardGone) {
        action.onDismiss();
    }

    protected void onConfigurationChanged(Configuration newConfig) {
        Locale locale = this.mContext.getResources().getConfiguration().locale;
        int ld = TextUtils.getLayoutDirectionFromLocale(locale);
        float fontScale = newConfig.fontScale;
        if (!locale.equals(this.mLocale) || ld != this.mLayoutDirection || fontScale != this.mFontScale) {
            if (DEBUG) {
                Log.v("StatusBar", String.format("config changed locale/LD: %s (%d) -> %s (%d)", new Object[]{this.mLocale, Integer.valueOf(this.mLayoutDirection), locale, Integer.valueOf(ld)}));
            }
            this.mLocale = locale;
            this.mLayoutDirection = ld;
            refreshLayout(ld);
        }
    }

    protected View updateNotificationVetoButton(View row, StatusBarNotification n) {
        View vetoButton = row.findViewById(2131755312);
        if (n.isClearable()) {
            vetoButton.setOnClickListener(new C02937(n.getPackageName(), n.getTag(), n.getId(), n.getUserId()));
            vetoButton.setVisibility(0);
        } else {
            vetoButton.setVisibility(8);
        }
        vetoButton.setImportantForAccessibility(2);
        return vetoButton;
    }

    protected void applyColorsAndBackgrounds(StatusBarNotification sbn, Entry entry) {
        boolean z = true;
        if (entry.getContentView().getId() == 16909165) {
            int color = sbn.getNotification().color;
            if (isMediaNotification(entry)) {
                ExpandableNotificationRow expandableNotificationRow = entry.row;
                if (color == 0) {
                    color = this.mContext.getColor(2131427389);
                }
                expandableNotificationRow.setTintColor(color);
            }
        } else if (entry.targetSdk >= 9 && entry.targetSdk < 21) {
            entry.row.setShowingLegacyBackground(true);
            entry.legacy = true;
        }
        if (entry.icon != null) {
            StatusBarIconView statusBarIconView = entry.icon;
            if (entry.targetSdk >= 21) {
                z = false;
            }
            statusBarIconView.setTag(2131755036, Boolean.valueOf(z));
        }
    }

    public boolean isMediaNotification(Entry entry) {
        return (entry.getExpandedContentView() == null || entry.getExpandedContentView().findViewById(16909170) == null) ? false : true;
    }

    private void startAppOwnNotificationSettingsActivity(Intent intent, int notificationId, String notificationTag, int appUid) {
        intent.putExtra("notification_id", notificationId);
        intent.putExtra("notification_tag", notificationTag);
        startNotificationGutsIntent(intent, appUid);
    }

    public String getForegroundPackageName() {
        return ((RunningTaskInfo) this.mActivityManager.getRunningTasks(1).get(0)).topActivity.getPackageName();
    }

    public boolean isUserOnLauncher() {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        return getForegroundPackageName().equals(this.mContext.getPackageManager().resolveActivity(intent, 65536).activityInfo.packageName);
    }

    private void launchFloating(PendingIntent pIntent) {
        Intent overlay = new Intent();
        overlay.addFlags(45056);
        try {
            ActivityManagerNative.getDefault().resumeAppSwitches();
        } catch (RemoteException e) {
        }
        try {
            pIntent.send(this.mContext, 0, overlay);
        } catch (CanceledException e2) {
            Slog.w("StatusBar", "Sending contentIntent failed: " + e2);
        }
    }

    private void startAppNotificationSettingsActivity(String packageName, int appUid) {
        Intent intent = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
        intent.putExtra("app_package", packageName);
        intent.putExtra("app_uid", appUid);
        startNotificationGutsIntent(intent, appUid);
    }

    private void startNotificationGutsIntent(Intent intent, int appUid) {
        dismissKeyguardThenExecute(new C02958(this.mStatusBarKeyguardViewManager.isShowing(), intent, appUid), false);
    }

    private boolean isKeyguardShowing() {
        return this.mStatusBarKeyguardViewManager.isShowing();
    }

    private void bindGuts(ExpandableNotificationRow row) {
        row.inflateGuts();
        StatusBarNotification sbn = row.getStatusBarNotification();
        PackageManager pmUser = getPackageManagerForUser(sbn.getUser().getIdentifier());
        row.setTag(sbn.getPackageName());
        View guts = row.getGuts();
        PendingIntent contentIntent = sbn.getNotification().contentIntent;
        String pkg = sbn.getPackageName();
        String appname = pkg;
        Drawable pkgicon = null;
        int appUid = -1;
        try {
            ApplicationInfo info = pmUser.getApplicationInfo(pkg, 8704);
            if (info != null) {
                appname = String.valueOf(pmUser.getApplicationLabel(info));
                pkgicon = pmUser.getApplicationIcon(info);
                appUid = info.uid;
            }
        } catch (NameNotFoundException e) {
            pkgicon = pmUser.getDefaultActivityIcon();
        }
        ((ImageView) row.findViewById(16908294)).setImageDrawable(pkgicon);
        ((DateTimeView) row.findViewById(2131755191)).setTime(sbn.getPostTime());
        ((TextView) row.findViewById(2131755190)).setText(appname);
        View floatButton = guts.findViewById(2131755193);
        View settingsButton = guts.findViewById(2131755195);
        View appSettingsButton = guts.findViewById(2131755194);
        if (appUid >= 0) {
            int appUidF = appUid;
            settingsButton.setOnClickListener(new C02969(pkg, appUidF));
            if (isKeyguardShowing()) {
                floatButton.setVisibility(8);
            } else {
                floatButton.setVisibility(0);
            }
            floatButton.setOnClickListener(new AnonymousClass10(contentIntent));
            Intent appSettingsQueryIntent = new Intent("android.intent.action.MAIN").addCategory("android.intent.category.NOTIFICATION_PREFERENCES").setPackage(pkg);
            List<ResolveInfo> infos = pmUser.queryIntentActivities(appSettingsQueryIntent, 0);
            if (infos.size() > 0) {
                appSettingsButton.setVisibility(0);
                appSettingsButton.setContentDescription(this.mContext.getResources().getString(2131362157, new Object[]{appname}));
                appSettingsButton.setOnClickListener(new AnonymousClass11(new Intent(appSettingsQueryIntent).setClassName(pkg, ((ResolveInfo) infos.get(0)).activityInfo.name), sbn, appUidF));
                return;
            }
            appSettingsButton.setVisibility(8);
            return;
        }
        settingsButton.setVisibility(8);
        floatButton.setVisibility(8);
        appSettingsButton.setVisibility(8);
    }

    protected LongPressListener getNotificationLongClicker() {
        return new LongPressListener() {
            public boolean onLongPress(View v, int x, int y) {
                BaseStatusBar.this.dismissPopups();
                if (!(v instanceof ExpandableNotificationRow)) {
                    return false;
                }
                if (v.getWindowToken() == null) {
                    Log.e("StatusBar", "Trying to show notification guts, but not attached to window");
                    return false;
                }
                ExpandableNotificationRow row = (ExpandableNotificationRow) v;
                BaseStatusBar.this.bindGuts(row);
                NotificationGuts guts = row.getGuts();
                if (guts == null) {
                    return false;
                }
                if (guts.getVisibility() == 0) {
                    Log.e("StatusBar", "Trying to show notification guts, but already visible");
                    return false;
                }
                MetricsLogger.action(BaseStatusBar.this.mContext, 204);
                guts.setVisibility(0);
                Animator a = ViewAnimationUtils.createCircularReveal(guts, x, y, 0.0f, (float) Math.hypot((double) Math.max(guts.getWidth() - x, x), (double) Math.max(guts.getActualHeight() - y, y)));
                a.setDuration(400);
                a.setInterpolator(BaseStatusBar.this.mLinearOutSlowIn);
                a.start();
                BaseStatusBar.this.mNotificationGutsExposed = guts;
                return true;
            }
        };
    }

    public void dismissPopups() {
        if (this.mNotificationGutsExposed != null) {
            NotificationGuts v = this.mNotificationGutsExposed;
            this.mNotificationGutsExposed = null;
            if (v.getWindowToken() != null) {
                int x = (v.getLeft() + v.getRight()) / 2;
                Animator a = ViewAnimationUtils.createCircularReveal(v, x, v.getTop() + (v.getActualHeight() / 2), (float) x, 0.0f);
                a.setDuration(200);
                a.setInterpolator(this.mFastOutLinearIn);
                a.addListener(new AnonymousClass13(v));
                a.start();
            }
        }
    }

    public void showRecentApps(boolean triggeredFromAltTab) {
        int i;
        this.mHandler.removeMessages(1019);
        C0297H c0297h = this.mHandler;
        if (triggeredFromAltTab) {
            i = 1;
        } else {
            i = 0;
        }
        c0297h.obtainMessage(1019, i, 0).sendToTarget();
    }

    public void hideRecentApps(boolean triggeredFromAltTab, boolean triggeredFromHomeKey) {
        int i;
        int i2 = 1;
        this.mHandler.removeMessages(1020);
        C0297H c0297h = this.mHandler;
        if (triggeredFromAltTab) {
            i = 1;
        } else {
            i = 0;
        }
        if (!triggeredFromHomeKey) {
            i2 = 0;
        }
        c0297h.obtainMessage(1020, i, i2).sendToTarget();
    }

    public void toggleRecentApps() {
        toggleRecents();
    }

    public void preloadRecentApps() {
        this.mHandler.removeMessages(1022);
        this.mHandler.sendEmptyMessage(1022);
    }

    public void cancelPreloadRecentApps() {
        this.mHandler.removeMessages(1023);
        this.mHandler.sendEmptyMessage(1023);
    }

    public void showNextAffiliatedTask() {
        this.mHandler.removeMessages(1024);
        this.mHandler.sendEmptyMessage(1024);
    }

    public void showPreviousAffiliatedTask() {
        this.mHandler.removeMessages(1025);
        this.mHandler.sendEmptyMessage(1025);
    }

    protected C0297H createHandler() {
        return new C0297H();
    }

    static void sendCloseSystemWindows(Context context, String reason) {
        if (ActivityManagerNative.isSystemReady()) {
            try {
                ActivityManagerNative.getDefault().closeSystemDialogs(reason);
            } catch (RemoteException e) {
            }
        }
    }

    protected void showRecents(boolean triggeredFromAltTab) {
        if (this.mRecents != null) {
            sendCloseSystemWindows(this.mContext, "recentapps");
            this.mRecents.showRecents(triggeredFromAltTab, getStatusBarView());
        }
    }

    protected void hideRecents(boolean triggeredFromAltTab, boolean triggeredFromHomeKey) {
        if (this.mRecents != null) {
            this.mRecents.hideRecents(triggeredFromAltTab, triggeredFromHomeKey);
        }
    }

    protected void toggleRecents() {
        if (this.mRecents != null) {
            sendCloseSystemWindows(this.mContext, "recentapps");
            this.mRecents.toggleRecents(this.mDisplay, this.mLayoutDirection, getStatusBarView());
        }
    }

    protected void preloadRecents() {
        if (this.mRecents != null) {
            this.mRecents.preloadRecents();
        }
    }

    protected void cancelPreloadingRecents() {
        if (this.mRecents != null) {
            this.mRecents.cancelPreloadingRecents();
        }
    }

    protected void showRecentsNextAffiliatedTask() {
        if (this.mRecents != null) {
            this.mRecents.showNextAffiliatedTask();
        }
    }

    protected void showRecentsPreviousAffiliatedTask() {
        if (this.mRecents != null) {
            this.mRecents.showPrevAffiliatedTask();
        }
    }

    public void onVisibilityChanged(boolean visible) {
    }

    public void setLockscreenPublicMode(boolean publicMode) {
        this.mLockscreenPublicMode = publicMode;
    }

    public boolean isLockscreenPublicMode() {
        return this.mLockscreenPublicMode;
    }

    public boolean userAllowsPrivateNotificationsInPublic(int userHandle) {
        if (userHandle == -1) {
            return true;
        }
        if (this.mUsersAllowingPrivateNotifications.indexOfKey(userHandle) >= 0) {
            return this.mUsersAllowingPrivateNotifications.get(userHandle);
        }
        boolean allowedByUser;
        boolean allowed;
        if (Secure.getIntForUser(this.mContext.getContentResolver(), "lock_screen_allow_private_notifications", 0, userHandle) != 0) {
            allowedByUser = true;
        } else {
            allowedByUser = false;
        }
        boolean allowedByDpm;
        if ((this.mDevicePolicyManager.getKeyguardDisabledFeatures(null, userHandle) & 8) == 0) {
            allowedByDpm = true;
        } else {
            allowedByDpm = false;
        }
        if (allowedByUser && allowedByDpm) {
            allowed = true;
        } else {
            allowed = false;
        }
        this.mUsersAllowingPrivateNotifications.append(userHandle, allowed);
        return allowed;
    }

    public boolean shouldHideSensitiveContents(int userid) {
        return isLockscreenPublicMode() && !userAllowsPrivateNotificationsInPublic(userid);
    }

    protected void workAroundBadLayerDrawableOpacity(View v) {
    }

    protected boolean inflateViews(Entry entry, ViewGroup parent) {
        StatusBarNotification sbn = entry.notification;
        String themePackageName = this.mCurrentTheme != null ? this.mCurrentTheme.getOverlayPkgNameForApp(sbn.getPackageName()) : null;
        boolean inflated = inflateViews(entry, parent, true);
        if (inflated || themePackageName == null || "system".equals(themePackageName)) {
            return inflated;
        }
        Log.w("StatusBar", "Couldn't expand themed RemoteViews, trying unthemed for: " + sbn);
        return inflateViews(entry, this.mStackScroller, false);
    }

    protected boolean inflateViews(Entry entry, ViewGroup parent, boolean isThemeable) {
        PackageManager pmUser = getPackageManagerForUser(entry.notification.getUser().getIdentifier());
        int maxHeight = this.mRowMaxHeight;
        StatusBarNotification sbn = entry.notification;
        RemoteViews contentView = sbn.getNotification().contentView;
        RemoteViews bigContentView = sbn.getNotification().bigContentView;
        RemoteViews headsUpContentView = sbn.getNotification().headsUpContentView;
        if (contentView == null) {
            return false;
        }
        View row;
        if (DEBUG) {
            Log.v("StatusBar", "publicNotification: " + sbn.getNotification().publicVersion);
        }
        Notification publicNotification = sbn.getNotification().publicVersion;
        boolean hasUserChangedExpansion = false;
        boolean userExpanded = false;
        boolean userLocked = false;
        if (entry.row != null) {
            row = entry.row;
            hasUserChangedExpansion = row.hasUserChangedExpansion();
            userExpanded = row.isUserExpanded();
            userLocked = row.isUserLocked();
            entry.reset();
            if (hasUserChangedExpansion) {
                row.setUserExpanded(userExpanded);
            }
        } else {
            ExpandableNotificationRow row2 = (ExpandableNotificationRow) ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(2130968648, parent, false);
            row2.setExpansionLogger(this, entry.notification.getKey());
            row2.setGroupManager(this.mGroupManager);
        }
        workAroundBadLayerDrawableOpacity(row);
        updateNotificationVetoButton(row, sbn).setContentDescription(this.mContext.getString(2131362084));
        NotificationContentView contentContainer = row.getPrivateLayout();
        ViewGroup contentContainerPublic = row.getPublicLayout();
        row.setDescendantFocusability(393216);
        this.mNotificationClicker.register(row, sbn);
        View bigContentViewLocal = null;
        View headsUpContentViewLocal = null;
        String themePackageName = (!isThemeable || this.mCurrentTheme == null) ? "system" : this.mCurrentTheme.getOverlayPkgNameForApp(sbn.getPackageName());
        String statusBarThemePackageName = (!isThemeable || this.mCurrentTheme == null) ? "system" : this.mCurrentTheme.getOverlayForStatusBar();
        try {
            String inflationThemePackageName;
            View contentViewLocal = contentView.apply(sbn.getPackageContext(this.mContext), contentContainer, this.mOnClickHandler, statusBarThemePackageName);
            if (themePackageName == null || TextUtils.equals(themePackageName, statusBarThemePackageName) || contentViewLocal.getId() == 16909165) {
                inflationThemePackageName = statusBarThemePackageName;
            } else {
                inflationThemePackageName = themePackageName;
                contentViewLocal = contentView.apply(sbn.getPackageContext(this.mContext), contentContainer, this.mOnClickHandler, inflationThemePackageName);
            }
            if (bigContentView != null) {
                bigContentViewLocal = bigContentView.apply(sbn.getPackageContext(this.mContext), contentContainer, this.mOnClickHandler, inflationThemePackageName);
            }
            if (headsUpContentView != null) {
                headsUpContentViewLocal = headsUpContentView.apply(sbn.getPackageContext(this.mContext), contentContainer, this.mOnClickHandler, inflationThemePackageName);
            }
            if (contentViewLocal != null) {
                contentViewLocal.setIsRootNamespace(true);
                contentContainer.setContractedChild(contentViewLocal);
            }
            if (bigContentViewLocal != null) {
                bigContentViewLocal.setIsRootNamespace(true);
                contentContainer.setExpandedChild(bigContentViewLocal);
            }
            if (headsUpContentViewLocal != null) {
                headsUpContentViewLocal.setIsRootNamespace(true);
                contentContainer.setHeadsUpChild(headsUpContentViewLocal);
            }
            View publicViewLocal = null;
            if (publicNotification != null) {
                try {
                    publicViewLocal = publicNotification.contentView.apply(sbn.getPackageContext(this.mContext), contentContainerPublic, this.mOnClickHandler);
                    if (publicViewLocal != null) {
                        publicViewLocal.setIsRootNamespace(true);
                        contentContainerPublic.setContractedChild(publicViewLocal);
                    }
                } catch (Throwable e) {
                    Log.e("StatusBar", "couldn't inflate public view for notification " + (sbn.getPackageName() + "/0x" + Integer.toHexString(sbn.getId())), e);
                    publicViewLocal = null;
                }
            }
            try {
                entry.targetSdk = pmUser.getApplicationInfo(sbn.getPackageName(), 0).targetSdkVersion;
            } catch (Throwable ex) {
                Log.e("StatusBar", "Failed looking up ApplicationInfo for " + sbn.getPackageName(), ex);
            }
            if (publicViewLocal == null) {
                Context layoutContext;
                if (isThemeable) {
                    layoutContext = this.mContext;
                } else {
                    layoutContext = maybeGetThemedContext(this.mContext, "system");
                }
                publicViewLocal = LayoutInflater.from(layoutContext).inflate(2130968610, contentContainerPublic, false);
                publicViewLocal.setIsRootNamespace(true);
                TextView title = (TextView) publicViewLocal.findViewById(2131755199);
                try {
                    title.setText(pmUser.getApplicationLabel(pmUser.getApplicationInfo(entry.notification.getPackageName(), 0)));
                } catch (NameNotFoundException e2) {
                    title.setText(entry.notification.getPackageName());
                }
                ImageView icon = (ImageView) publicViewLocal.findViewById(2131755197);
                ImageView profileBadge = (ImageView) publicViewLocal.findViewById(2131755200);
                Drawable iconDrawable = StatusBarIconView.getIcon(this.mContext, new StatusBarIcon(entry.notification.getUser(), entry.notification.getPackageName(), entry.notification.getNotification().getSmallIcon(), entry.notification.getNotification().iconLevel, entry.notification.getNotification().number, entry.notification.getNotification().tickerText));
                icon.setImageDrawable(iconDrawable);
                if (entry.targetSdk >= 21 || this.mNotificationColorUtil.isGrayscaleIcon(iconDrawable)) {
                    icon.setBackgroundResource(17302758);
                    int padding = this.mContext.getResources().getDimensionPixelSize(17104993);
                    icon.setPadding(padding, padding, padding, padding);
                    if (sbn.getNotification().color != 0) {
                        icon.getBackground().setColorFilter(sbn.getNotification().color, Mode.SRC_ATOP);
                    }
                }
                if (profileBadge != null) {
                    Drawable profileDrawable = this.mContext.getPackageManager().getUserBadgeForDensity(entry.notification.getUser(), 0);
                    if (profileDrawable != null) {
                        profileBadge.setImageDrawable(profileDrawable);
                        profileBadge.setVisibility(0);
                    } else {
                        profileBadge.setVisibility(8);
                    }
                }
                View privateTime = contentViewLocal.findViewById(16908428);
                DateTimeView time = (DateTimeView) publicViewLocal.findViewById(2131755198);
                if (privateTime != null && privateTime.getVisibility() == 0) {
                    time.setVisibility(0);
                    time.setTime(entry.notification.getNotification().when);
                }
                TextView text = (TextView) publicViewLocal.findViewById(2131755201);
                if (text != null) {
                    text.setText(2131362284);
                    text.setTextAppearance(this.mContext, 2131492912);
                }
                title.setPadding(0, Builder.calculateTopPadding(this.mContext, false, this.mContext.getResources().getConfiguration().fontScale), 0, 0);
                contentContainerPublic.setContractedChild(publicViewLocal);
                entry.autoRedacted = true;
            }
            entry.row = row;
            entry.row.setHeightRange(this.mRowMinHeight, maxHeight);
            entry.row.setOnActivatedListener(this);
            entry.row.setExpandable(bigContentViewLocal != null);
            applyColorsAndBackgrounds(sbn, entry);
            if (hasUserChangedExpansion) {
                row.setUserExpanded(userExpanded);
            }
            row.setUserLocked(userLocked);
            row.setStatusBarNotification(entry.notification);
            return true;
        } catch (Throwable e3) {
            Log.e("StatusBar", "couldn't inflate view for notification " + (sbn.getPackageName() + "/0x" + Integer.toHexString(sbn.getId())), e3);
            return false;
        }
    }

    public void startPendingIntentDismissingKeyguard(PendingIntent intent) {
        if (isDeviceProvisioned()) {
            boolean keyguardShowing = this.mStatusBarKeyguardViewManager.isShowing();
            boolean afterKeyguardGone = intent.isActivity() && PreviewInflater.wouldLaunchResolverActivity(this.mContext, intent.getIntent(), this.mCurrentUserId);
            dismissKeyguardThenExecute(new AnonymousClass15(keyguardShowing, afterKeyguardGone, intent), afterKeyguardGone);
        }
    }

    public void animateCollapsePanels(int flags, boolean force) {
    }

    public void animateCollapsePanels(int flags, boolean force, boolean delayed) {
    }

    public void overrideActivityPendingAppTransition(boolean keyguardShowing) {
        if (keyguardShowing) {
            try {
                this.mWindowManagerService.overridePendingAppTransition(null, 0, 0, null);
            } catch (RemoteException e) {
                Log.w("StatusBar", "Error overriding app transition: " + e);
            }
        }
    }

    protected void visibilityChanged(boolean visible) {
        if (this.mVisible != visible) {
            this.mVisible = visible;
            if (!visible) {
                dismissPopups();
            }
        }
        updateVisibleToUser();
    }

    protected void updateVisibleToUser() {
        boolean oldVisibleToUser = this.mVisibleToUser;
        boolean z = this.mVisible && this.mDeviceInteractive;
        this.mVisibleToUser = z;
        if (oldVisibleToUser != this.mVisibleToUser) {
            handleVisibleToUserChanged(this.mVisibleToUser);
        }
    }

    protected void handleVisibleToUserChanged(boolean visibleToUser) {
        boolean clearNotificationEffects = true;
        if (visibleToUser) {
            try {
                boolean pinnedHeadsUp = this.mHeadsUpManager.hasPinnedHeadsUp();
                if (!(this.mShowLockscreenNotifications && this.mState == 1) && (pinnedHeadsUp || !(this.mState == 0 || this.mState == 2))) {
                    clearNotificationEffects = false;
                }
                int notificationLoad = this.mNotificationData.getActiveNotifications().size();
                if (pinnedHeadsUp && isPanelFullyCollapsed()) {
                    notificationLoad = 1;
                } else {
                    MetricsLogger.histogram(this.mContext, "note_load", notificationLoad);
                }
                this.mBarService.onPanelRevealed(clearNotificationEffects, notificationLoad);
                return;
            } catch (RemoteException e) {
                return;
            }
        }
        this.mBarService.onPanelHidden();
    }

    public void clearNotificationEffects() {
        try {
            this.mBarService.clearNotificationEffects();
        } catch (RemoteException e) {
        }
    }

    void handleNotificationError(StatusBarNotification n, String message) {
        removeNotification(n.getKey(), null);
        try {
            this.mBarService.onNotificationError(n.getPackageName(), n.getTag(), n.getId(), n.getUid(), n.getInitialPid(), message, n.getUserId());
        } catch (RemoteException e) {
        }
    }

    protected StatusBarNotification removeNotificationViews(String key, RankingMap ranking) {
        Entry entry = this.mNotificationData.remove(key, ranking);
        if (entry == null) {
            Log.w("StatusBar", "removeNotification for unknown key: " + key);
            return null;
        }
        updateNotifications();
        return entry.notification;
    }

    protected Entry createNotificationViews(StatusBarNotification sbn) {
        if (DEBUG) {
            Log.d("StatusBar", "createNotificationViews(notification=" + sbn);
        }
        StatusBarIconView iconView = createIcon(sbn);
        if (iconView == null) {
            return null;
        }
        Entry entry = new Entry(sbn, iconView);
        if (inflateViews(entry, this.mStackScroller)) {
            return entry;
        }
        handleNotificationError(sbn, "Couldn't expand RemoteViews for: " + sbn);
        return null;
    }

    protected StatusBarIconView createIcon(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        StatusBarIconView iconView = new StatusBarIconView(this.mContext, sbn.getPackageName() + "/0x" + Integer.toHexString(sbn.getId()), n);
        iconView.setScaleType(ScaleType.CENTER_INSIDE);
        Icon smallIcon = n.getSmallIcon();
        if (smallIcon == null) {
            handleNotificationError(sbn, "No small icon in notification from " + sbn.getPackageName());
            return null;
        }
        StatusBarIcon ic = new StatusBarIcon(sbn.getUser(), sbn.getPackageName(), smallIcon, n.iconLevel, n.number, n.tickerText);
        if (iconView.set(ic)) {
            return iconView;
        }
        handleNotificationError(sbn, "Couldn't create icon: " + ic);
        return null;
    }

    protected void addNotificationViews(Entry entry, RankingMap ranking) {
        if (entry != null) {
            this.mNotificationData.add(entry, ranking);
            updateNotifications();
        }
    }

    protected void updateRowStates() {
        int maxKeyguardNotifications = getMaxKeyguardNotifications();
        this.mKeyguardIconOverflowContainer.getIconsView().removeAllViews();
        ArrayList<Entry> activeNotifications = this.mNotificationData.getActiveNotifications();
        int N = activeNotifications.size();
        int visibleNotifications = 0;
        boolean onKeyguard = this.mState == 1;
        int i = 0;
        while (i < N) {
            Entry entry = (Entry) activeNotifications.get(i);
            if (onKeyguard) {
                entry.row.setExpansionDisabled(true);
            } else {
                entry.row.setExpansionDisabled(false);
                if (!entry.row.isUserLocked()) {
                    entry.row.setSystemExpanded(i == 0);
                }
            }
            boolean isInvisibleChild = !this.mGroupManager.isVisible(entry.notification);
            boolean showOnKeyguard = shouldShowOnKeyguard(entry.notification);
            if ((!isLockscreenPublicMode() || this.mShowLockscreenNotifications) && (!onKeyguard || (visibleNotifications < maxKeyguardNotifications && showOnKeyguard && !isInvisibleChild))) {
                boolean wasGone = entry.row.getVisibility() == 8;
                entry.row.setVisibility(0);
                if (!isInvisibleChild) {
                    if (wasGone) {
                        this.mStackScroller.generateAddAnimation(entry.row, true);
                    }
                    visibleNotifications++;
                }
            } else {
                entry.row.setVisibility(8);
                if (onKeyguard && showOnKeyguard && !isInvisibleChild) {
                    this.mKeyguardIconOverflowContainer.getIconsView().addNotification(entry);
                }
            }
            i++;
        }
        NotificationStackScrollLayout notificationStackScrollLayout = this.mStackScroller;
        boolean z = onKeyguard && this.mKeyguardIconOverflowContainer.getIconsView().getChildCount() > 0;
        notificationStackScrollLayout.updateOverflowContainerVisibility(z);
        this.mStackScroller.changeViewPosition(this.mDismissView, this.mStackScroller.getChildCount() - 1);
        this.mStackScroller.changeViewPosition(this.mEmptyShadeView, this.mStackScroller.getChildCount() - 2);
        this.mStackScroller.changeViewPosition(this.mKeyguardIconOverflowContainer, this.mStackScroller.getChildCount() - 3);
    }

    private boolean FloatingHeadsup() {
        return Secure.getIntForUser(this.mContext.getContentResolver(), "floating_headsup", 0, -2) != 0;
    }

    private boolean shouldShowOnKeyguard(StatusBarNotification sbn) {
        return this.mShowLockscreenNotifications && !this.mNotificationData.isAmbient(sbn.getKey());
    }

    protected void setZenMode(int mode) {
        if (isDeviceProvisioned()) {
            this.mZenMode = mode;
            updateNotifications();
        }
    }

    protected void setShowLockscreenNotifications(boolean show) {
        this.mShowLockscreenNotifications = show;
    }

    private void updateLockscreenNotificationSetting() {
        boolean show;
        boolean z = true;
        if (Secure.getIntForUser(this.mContext.getContentResolver(), "lock_screen_show_notifications", 1, this.mCurrentUserId) != 0) {
            show = true;
        } else {
            show = false;
        }
        boolean allowedByDpm;
        if ((this.mDevicePolicyManager.getKeyguardDisabledFeatures(null, this.mCurrentUserId) & 4) == 0) {
            allowedByDpm = true;
        } else {
            allowedByDpm = false;
        }
        if (!(show && allowedByDpm)) {
            z = false;
        }
        setShowLockscreenNotifications(z);
    }

    public void updateNotification(StatusBarNotification notification, RankingMap ranking) {
        if (DEBUG) {
            Log.d("StatusBar", "updateNotification(" + notification + ")");
        }
        String key = notification.getKey();
        Entry entry = this.mNotificationData.get(key);
        if (entry != null) {
            StatusBarIcon ic;
            Notification n = notification.getNotification();
            if (DEBUG) {
                logUpdate(entry, n);
            }
            boolean applyInPlace = shouldApplyInPlace(entry, n);
            boolean shouldInterrupt = shouldInterrupt(entry, notification);
            boolean alertAgain = alertAgain(entry, n);
            StatusBarNotification oldNotification = entry.notification;
            entry.notification = notification;
            this.mGroupManager.onEntryUpdated(entry, oldNotification);
            boolean updateSuccessful = false;
            if (applyInPlace) {
                if (DEBUG) {
                    Log.d("StatusBar", "reusing notification for key: " + key);
                }
                try {
                    if (entry.icon != null) {
                        ic = new StatusBarIcon(notification.getUser(), notification.getPackageName(), n.getSmallIcon(), n.iconLevel, n.number, n.tickerText);
                        entry.icon.setNotification(n);
                        if (!entry.icon.set(ic)) {
                            handleNotificationError(notification, "Couldn't update icon: " + ic);
                            return;
                        }
                    }
                    updateNotificationViews(entry, notification);
                    updateSuccessful = true;
                } catch (RuntimeException e) {
                    Log.w("StatusBar", "Couldn't reapply views for package " + n.contentView.getPackage(), e);
                }
            }
            if (!updateSuccessful) {
                if (DEBUG) {
                    Log.d("StatusBar", "not reusing notification for key: " + key);
                }
                ic = new StatusBarIcon(notification.getUser(), notification.getPackageName(), n.getSmallIcon(), n.iconLevel, n.number, n.tickerText);
                entry.icon.setNotification(n);
                entry.icon.set(ic);
                inflateViews(entry, this.mStackScroller);
            }
            updateHeadsUp(key, entry, shouldInterrupt, alertAgain);
            this.mNotificationData.updateRanking(ranking);
            updateNotifications();
            updateNotificationVetoButton(entry.row, notification);
            if (DEBUG) {
                Log.d("StatusBar", "notification is " + (isNotificationForCurrentProfiles(notification) ? "" : "not ") + "for you");
            }
            setAreThereNotifications();
        }
    }

    private void logUpdate(Entry oldEntry, Notification n) {
        StatusBarNotification oldNotification = oldEntry.notification;
        Log.d("StatusBar", "old notification: when=" + oldNotification.getNotification().when + " ongoing=" + oldNotification.isOngoing() + " expanded=" + oldEntry.getContentView() + " contentView=" + oldNotification.getNotification().contentView + " bigContentView=" + oldNotification.getNotification().bigContentView + " publicView=" + oldNotification.getNotification().publicVersion + " rowParent=" + oldEntry.row.getParent());
        Log.d("StatusBar", "new notification: when=" + n.when + " ongoing=" + oldNotification.isOngoing() + " contentView=" + n.contentView + " bigContentView=" + n.bigContentView + " publicView=" + n.publicVersion);
    }

    private boolean shouldApplyInPlace(Entry entry, Notification n) {
        StatusBarNotification oldNotification = entry.notification;
        RemoteViews oldContentView = oldNotification.getNotification().contentView;
        RemoteViews contentView = n.contentView;
        RemoteViews oldBigContentView = oldNotification.getNotification().bigContentView;
        RemoteViews bigContentView = n.bigContentView;
        RemoteViews oldHeadsUpContentView = oldNotification.getNotification().headsUpContentView;
        RemoteViews headsUpContentView = n.headsUpContentView;
        Notification oldPublicNotification = oldNotification.getNotification().publicVersion;
        RemoteViews oldPublicContentView = oldPublicNotification != null ? oldPublicNotification.contentView : null;
        Notification publicNotification = n.publicVersion;
        RemoteViews publicContentView = publicNotification != null ? publicNotification.contentView : null;
        boolean contentsUnchanged = (entry.getContentView() == null || contentView.getPackage() == null || oldContentView.getPackage() == null || !oldContentView.getPackage().equals(contentView.getPackage()) || oldContentView.getLayoutId() != contentView.getLayoutId()) ? false : true;
        boolean bigContentsUnchanged = (entry.getExpandedContentView() == null && bigContentView == null) || !(entry.getExpandedContentView() == null || bigContentView == null || bigContentView.getPackage() == null || oldBigContentView.getPackage() == null || !oldBigContentView.getPackage().equals(bigContentView.getPackage()) || oldBigContentView.getLayoutId() != bigContentView.getLayoutId());
        boolean headsUpContentsUnchanged = (oldHeadsUpContentView == null && headsUpContentView == null) || !(oldHeadsUpContentView == null || headsUpContentView == null || headsUpContentView.getPackage() == null || oldHeadsUpContentView.getPackage() == null || !oldHeadsUpContentView.getPackage().equals(headsUpContentView.getPackage()) || oldHeadsUpContentView.getLayoutId() != headsUpContentView.getLayoutId());
        boolean publicUnchanged = (oldPublicContentView == null && publicContentView == null) || !(oldPublicContentView == null || publicContentView == null || publicContentView.getPackage() == null || oldPublicContentView.getPackage() == null || !oldPublicContentView.getPackage().equals(publicContentView.getPackage()) || oldPublicContentView.getLayoutId() != publicContentView.getLayoutId());
        if (contentsUnchanged && bigContentsUnchanged && headsUpContentsUnchanged && publicUnchanged) {
            return true;
        }
        return false;
    }

    private void updateNotificationViews(Entry entry, StatusBarNotification notification) {
        RemoteViews contentView = notification.getNotification().contentView;
        RemoteViews bigContentView = notification.getNotification().bigContentView;
        RemoteViews headsUpContentView = notification.getNotification().headsUpContentView;
        Notification publicVersion = notification.getNotification().publicVersion;
        RemoteViews publicContentView = publicVersion != null ? publicVersion.contentView : null;
        contentView.reapply(this.mContext, entry.getContentView(), this.mOnClickHandler);
        if (!(bigContentView == null || entry.getExpandedContentView() == null)) {
            bigContentView.reapply(notification.getPackageContext(this.mContext), entry.getExpandedContentView(), this.mOnClickHandler);
        }
        View headsUpChild = entry.getHeadsUpContentView();
        if (!(headsUpContentView == null || headsUpChild == null)) {
            headsUpContentView.reapply(notification.getPackageContext(this.mContext), headsUpChild, this.mOnClickHandler);
        }
        if (!(publicContentView == null || entry.getPublicContentView() == null)) {
            publicContentView.reapply(notification.getPackageContext(this.mContext), entry.getPublicContentView(), this.mOnClickHandler);
        }
        this.mNotificationClicker.register(entry.row, notification);
        entry.row.setStatusBarNotification(notification);
        entry.row.notifyContentUpdated();
        entry.row.resetHeight();
    }

    protected void notifyHeadsUpScreenOff() {
        maybeEscalateHeadsUp();
    }

    private boolean alertAgain(Entry oldEntry, Notification newNotification) {
        return oldEntry == null || !oldEntry.hasInterrupted() || (newNotification.flags & 8) == 0;
    }

    protected boolean shouldInterrupt(Entry entry) {
        return shouldInterrupt(entry, entry.notification);
    }

    protected boolean shouldInterrupt(Entry entry, StatusBarNotification sbn) {
        if (this.mNotificationData.shouldFilterOut(sbn)) {
            if (DEBUG) {
                Log.d("StatusBar", "Skipping HUN check for " + sbn.getKey() + " since it's filtered out.");
            }
            return false;
        } else if (isSnoozedPackage(sbn)) {
            return false;
        } else {
            Notification notification = sbn.getNotification();
            boolean isNoisy = ((notification.defaults & 1) == 0 && (notification.defaults & 2) == 0 && notification.sound == null && notification.vibrate == null) ? false : true;
            boolean isHighPriority = sbn.getScore() >= 10;
            boolean isFullscreen = notification.fullScreenIntent != null;
            boolean hasTicker = this.mHeadsUpTicker && !TextUtils.isEmpty(notification.tickerText);
            boolean isAllowed = notification.extras.getInt("headsup", 1) != 0;
            boolean accessibilityForcesLaunch = isFullscreen && this.mAccessibilityManager.isTouchExplorationEnabled();
            boolean interrupt = (isFullscreen || (isHighPriority && (isNoisy || hasTicker))) && isAllowed && !accessibilityForcesLaunch && !entry.hasJustLaunchedFullScreenIntent() && this.mPowerManager.isScreenOn() && ((!this.mStatusBarKeyguardViewManager.isShowing() || this.mStatusBarKeyguardViewManager.isOccluded()) && !this.mStatusBarKeyguardViewManager.isInputRestricted());
            if (interrupt) {
                try {
                    if (!this.mDreamManager.isDreaming()) {
                        interrupt = true;
                        if (DEBUG) {
                            return interrupt;
                        }
                        Log.d("StatusBar", "interrupt: " + interrupt);
                        return interrupt;
                    }
                } catch (RemoteException e) {
                    Log.d("StatusBar", "failed to query dream manager", e);
                }
            }
            interrupt = false;
            if (DEBUG) {
                return interrupt;
            }
            Log.d("StatusBar", "interrupt: " + interrupt);
            return interrupt;
        }
    }

    public void setInteracting(int barWindow, boolean interacting) {
    }

    public void setBouncerShowing(boolean bouncerShowing) {
        this.mBouncerShowing = bouncerShowing;
    }

    public boolean isBouncerShowing() {
        return this.mBouncerShowing;
    }

    public void destroy() {
        this.mContext.unregisterReceiver(this.mBroadcastReceiver);
        try {
            this.mNotificationListener.unregisterAsSystemService();
        } catch (RemoteException e) {
        }
    }

    protected PackageManager getPackageManagerForUser(int userId) {
        Context contextForUser = this.mContext;
        if (userId >= 0) {
            try {
                contextForUser = this.mContext.createPackageContextAsUser(this.mContext.getPackageName(), 4, new UserHandle(userId));
            } catch (NameNotFoundException e) {
            }
        }
        return contextForUser.getPackageManager();
    }

    public void logNotificationExpansion(String key, boolean userAction, boolean expanded) {
        try {
            this.mBarService.onNotificationExpansionChanged(key, userAction, expanded);
        } catch (RemoteException e) {
        }
    }

    public boolean isKeyguardSecure() {
        if (this.mStatusBarKeyguardViewManager != null) {
            return this.mStatusBarKeyguardViewManager.isSecure();
        }
        Slog.w("StatusBar", "isKeyguardSecure() called before startKeyguard(), returning false", new Throwable());
        return false;
    }

    public void showAssistDisclosure() {
        if (this.mAssistManager != null) {
            this.mAssistManager.showDisclosure();
        }
    }

    public void startAssist(Bundle args) {
        if (this.mAssistManager != null) {
            this.mAssistManager.startAssist(args);
        }
    }

    private Context maybeGetThemedContext(Context context, String themePkg) {
        Context themedContext;
        try {
            themedContext = context.createApplicationContext(context.getPackageManager().getApplicationInfo(context.getPackageName(), 0), themePkg, 0);
        } catch (NameNotFoundException e) {
            themedContext = null;
        }
        if (themedContext == null) {
            return context;
        }
        return themedContext;
    }
}
