package com.android.systemui.qs.tiles;

import android.content.Context;
import android.content.Intent;
import com.android.internal.logging.MetricsLogger;
import com.android.systemui.qs.QSTile;
import com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile$com.android.systemui.qs.QSTile.AnimationIcon;
import com.android.systemui.qs.QSTile.BooleanState;
import com.android.systemui.qs.QSTile.Host;
import com.android.systemui.statusbar.policy.RotationLockController;
import com.android.systemui.statusbar.policy.RotationLockController.RotationLockControllerCallback;

public class RotationLockTile extends QSTile<BooleanState> {
    private static final Intent DISPLAY_SETTINGS;
    private final AnimationIcon mAutoToLandscape;
    private final AnimationIcon mAutoToPortrait;
    private final RotationLockControllerCallback mCallback;
    private final RotationLockController mController;
    private final AnimationIcon mLandscapeToAuto;
    private final AnimationIcon mPortraitToAuto;

    /* renamed from: com.android.systemui.qs.tiles.RotationLockTile.1 */
    class C01981 implements RotationLockControllerCallback {
        C01981() {
        }

        public void onRotationLockStateChanged(boolean rotationLocked, boolean affordanceVisible) {
            RotationLockTile.this.refreshState(rotationLocked ? UserBoolean.BACKGROUND_TRUE : UserBoolean.BACKGROUND_FALSE);
        }
    }

    static {
        DISPLAY_SETTINGS = new Intent("android.settings.DISPLAY_SETTINGS");
    }

    public RotationLockTile(Host host) {
        super(host, "rotation");
        this.mPortraitToAuto = new AnimationIcon(2130837611);
        this.mAutoToPortrait = new AnimationIcon(2130837609);
        this.mLandscapeToAuto = new AnimationIcon(2130837597);
        this.mAutoToLandscape = new AnimationIcon(2130837595);
        this.mCallback = new C01981();
        this.mController = host.getRotationLockController();
    }

    protected BooleanState newTileState() {
        return new BooleanState();
    }

    public void setListening(boolean listening) {
        if (this.mController != null) {
            if (listening) {
                this.mController.addRotationLockControllerCallback(this.mCallback);
            } else {
                this.mController.removeRotationLockControllerCallback(this.mCallback);
            }
        }
    }

    protected void handleToggleClick() {
        if (this.mController != null) {
            boolean z;
            boolean newState;
            Context context = this.mContext;
            int metricsCategory = getMetricsCategory();
            if (((BooleanState) this.mState).value) {
                z = false;
            } else {
                z = true;
            }
            MetricsLogger.action(context, metricsCategory, z);
            if (((BooleanState) this.mState).value) {
                newState = false;
            } else {
                newState = true;
            }
            this.mController.setRotationLocked(newState);
            refreshState(newState ? UserBoolean.USER_TRUE : UserBoolean.USER_FALSE);
        }
    }

    protected void handleDetailClick() {
        handleToggleClick();
    }

    protected void handleUpdateState(BooleanState state, Object arg) {
        if (this.mController != null) {
            boolean rotationLocked = arg != null ? ((UserBoolean) arg).value : this.mController.isRotationLocked();
            boolean userInitiated = arg != null ? ((UserBoolean) arg).userInitiated : false;
            state.visible = this.mController.isRotationLockAffordanceVisible();
            if (state.value != rotationLocked || state.contentDescription == null) {
                AnimationIcon icon;
                state.value = rotationLocked;
                boolean portrait = isCurrentOrientationLockPortrait();
                if (rotationLocked) {
                    state.label = this.mContext.getString(portrait ? 2131362178 : 2131362179);
                    icon = portrait ? this.mAutoToPortrait : this.mAutoToLandscape;
                } else {
                    state.label = this.mContext.getString(2131362176);
                    icon = portrait ? this.mPortraitToAuto : this.mLandscapeToAuto;
                }
                icon.setAllowAnimation(userInitiated);
                state.icon = icon;
                state.contentDescription = getAccessibilityString(rotationLocked, 2131362160, 2131362159, 2131362158);
            }
        }
    }

    private boolean isCurrentOrientationLockPortrait() {
        int lockOrientation = this.mController.getRotationLockOrientation();
        if (lockOrientation == 0) {
            if (this.mContext.getResources().getConfiguration().orientation != 2) {
                return true;
            }
            return false;
        } else if (lockOrientation == 2) {
            return false;
        } else {
            return true;
        }
    }

    public int getMetricsCategory() {
        return 123;
    }

    private String getAccessibilityString(boolean locked, int idWhenPortrait, int idWhenLandscape, int idWhenOff) {
        int stringID;
        if (!locked) {
            stringID = idWhenOff;
        } else if (isCurrentOrientationLockPortrait()) {
            stringID = idWhenPortrait;
        } else {
            stringID = idWhenLandscape;
        }
        return this.mContext.getString(stringID);
    }

    protected String composeChangeAnnouncement() {
        return getAccessibilityString(((BooleanState) this.mState).value, 2131362163, 2131362162, 2131362161);
    }
}
