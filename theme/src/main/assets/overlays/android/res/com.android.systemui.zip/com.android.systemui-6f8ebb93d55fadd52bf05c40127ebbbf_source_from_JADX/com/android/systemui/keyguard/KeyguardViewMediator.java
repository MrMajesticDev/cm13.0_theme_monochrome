package com.android.systemui.keyguard;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManagerNative;
import android.app.AlarmManager;
import android.app.IActivityManager;
import android.app.PendingIntent;
import android.app.SearchManager;
import android.app.StatusBarManager;
import android.app.trust.TrustManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.UserInfo;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.RemoteException;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.os.UserManager;
import android.provider.Settings.Global;
import android.provider.Settings.Secure;
import android.provider.Settings.System;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.EventLog;
import android.util.Log;
import android.util.Slog;
import android.view.IWindowManager;
import android.view.ViewGroup;
import android.view.WindowManagerGlobal;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.android.internal.policy.IKeyguardDrawnCallback;
import com.android.internal.policy.IKeyguardExitCallback;
import com.android.internal.policy.IKeyguardStateCallback;
import com.android.internal.telephony.IccCardConstants.State;
import com.android.internal.widget.LockPatternUtils;
import com.android.keyguard.C0065R;
import com.android.keyguard.KeyguardDisplayManager;
import com.android.keyguard.KeyguardUpdateMonitor;
import com.android.keyguard.KeyguardUpdateMonitorCallback;
import com.android.keyguard.ViewMediatorCallback;
import com.android.systemui.SystemUI;
import com.android.systemui.statusbar.phone.FingerprintUnlockController;
import com.android.systemui.statusbar.phone.PhoneStatusBar;
import com.android.systemui.statusbar.phone.ScrimController;
import com.android.systemui.statusbar.phone.StatusBarKeyguardViewManager;
import com.android.systemui.statusbar.phone.StatusBarWindowManager;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;

public class KeyguardViewMediator extends SystemUI {
    private static final Intent USER_PRESENT_INTENT;
    private AlarmManager mAlarmManager;
    private AudioManager mAudioManager;
    private boolean mBootCompleted;
    private boolean mBootSendUserPresent;
    private final BroadcastReceiver mBroadcastReceiver;
    private int mDelayedShowingSequence;
    private boolean mDeviceInteractive;
    private IKeyguardDrawnCallback mDrawnCallback;
    private IKeyguardExitCallback mExitSecureCallback;
    private boolean mExternallyEnabled;
    private boolean mGoingToSleep;
    private Handler mHandler;
    private Animation mHideAnimation;
    private boolean mHideAnimationRun;
    private boolean mHiding;
    private boolean mInputRestricted;
    private KeyguardDisplayManager mKeyguardDisplayManager;
    private boolean mKeyguardDonePending;
    private final Runnable mKeyguardGoingAwayRunnable;
    private final ArrayList<IKeyguardStateCallback> mKeyguardStateCallbacks;
    private LockPatternUtils mLockPatternUtils;
    private int mLockSoundId;
    private int mLockSoundStreamId;
    private float mLockSoundVolume;
    private SoundPool mLockSounds;
    private boolean mNeedToReshowWhenReenabled;
    private boolean mOccluded;
    private PowerManager mPM;
    private boolean mPendingLock;
    private boolean mPendingReset;
    private String mPhoneState;
    private SearchManager mSearchManager;
    private WakeLock mShowKeyguardWakeLock;
    private boolean mShowing;
    private StatusBarKeyguardViewManager mStatusBarKeyguardViewManager;
    private StatusBarManager mStatusBarManager;
    private boolean mSwitchingUser;
    private boolean mSystemReady;
    private TrustManager mTrustManager;
    private int mTrustedSoundId;
    private int mUiSoundsStreamType;
    private int mUnlockSoundId;
    KeyguardUpdateMonitorCallback mUpdateCallback;
    private KeyguardUpdateMonitor mUpdateMonitor;
    ViewMediatorCallback mViewMediatorCallback;
    private IWindowManager mWM;
    private boolean mWaitingUntilKeyguardVisible;
    private boolean mWakeAndUnlocking;

    /* renamed from: com.android.systemui.keyguard.KeyguardViewMediator.1 */
    class C01331 extends KeyguardUpdateMonitorCallback {
        C01331() {
        }

        public void onUserSwitching(int userId) {
            synchronized (KeyguardViewMediator.this) {
                KeyguardViewMediator.this.mSwitchingUser = true;
                KeyguardViewMediator.this.resetKeyguardDonePendingLocked();
                KeyguardViewMediator.this.resetStateLocked();
                KeyguardViewMediator.this.adjustStatusBarLocked();
            }
        }

        public void onUserSwitchComplete(int userId) {
            KeyguardViewMediator.this.mSwitchingUser = false;
            if (userId != 0) {
                UserInfo info = UserManager.get(KeyguardViewMediator.this.mContext).getUserInfo(userId);
                if (info != null && info.isGuest()) {
                    KeyguardViewMediator.this.dismiss();
                }
            }
        }

        public void onUserInfoChanged(int userId) {
        }

        public void onPhoneStateChanged(int phoneState) {
            synchronized (KeyguardViewMediator.this) {
                if (phoneState == 0) {
                    if (!KeyguardViewMediator.this.mDeviceInteractive && KeyguardViewMediator.this.mExternallyEnabled) {
                        KeyguardViewMediator.this.doKeyguardLocked(null);
                    }
                }
            }
        }

        public void onClockVisibilityChanged() {
            KeyguardViewMediator.this.adjustStatusBarLocked();
        }

        public void onDeviceProvisioned() {
            KeyguardViewMediator.this.sendUserPresentBroadcast();
        }

        public void onSimStateChanged(int subId, int slotId, State simState) {
            int size = KeyguardViewMediator.this.mKeyguardStateCallbacks.size();
            boolean simPinSecure = KeyguardViewMediator.this.mUpdateMonitor.isSimPinSecure();
            for (int i = size - 1; i >= 0; i--) {
                try {
                    ((IKeyguardStateCallback) KeyguardViewMediator.this.mKeyguardStateCallbacks.get(i)).onSimSecureStateChanged(simPinSecure);
                } catch (RemoteException e) {
                    Slog.w("KeyguardViewMediator", "Failed to call onSimSecureStateChanged", e);
                    if (e instanceof DeadObjectException) {
                        KeyguardViewMediator.this.mKeyguardStateCallbacks.remove(i);
                    }
                }
            }
            switch (C01386.$SwitchMap$com$android$internal$telephony$IccCardConstants$State[simState.ordinal()]) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                case 2:
                    synchronized (this) {
                        if (KeyguardViewMediator.this.shouldWaitForProvisioning()) {
                            if (KeyguardViewMediator.this.mShowing) {
                                KeyguardViewMediator.this.resetStateLocked();
                                break;
                            }
                            KeyguardViewMediator.this.doKeyguardLocked(null);
                        }
                        break;
                    }
                case 3:
                case 4:
                    synchronized (this) {
                        if (KeyguardViewMediator.this.mShowing) {
                            KeyguardViewMediator.this.resetStateLocked();
                            break;
                        }
                        KeyguardViewMediator.this.doKeyguardLocked(null);
                        break;
                    }
                case 5:
                    synchronized (this) {
                        if (KeyguardViewMediator.this.mShowing) {
                            KeyguardViewMediator.this.resetStateLocked();
                            break;
                        }
                        KeyguardViewMediator.this.doKeyguardLocked(null);
                        break;
                    }
                case 6:
                    synchronized (this) {
                        if (KeyguardViewMediator.this.mShowing) {
                            KeyguardViewMediator.this.resetStateLocked();
                        }
                        break;
                    }
                default:
            }
        }
    }

    /* renamed from: com.android.systemui.keyguard.KeyguardViewMediator.2 */
    class C01342 implements ViewMediatorCallback {
        C01342() {
        }

        public void userActivity() {
            KeyguardViewMediator.this.userActivity();
        }

        public void keyguardDone(boolean strongAuth) {
            if (!KeyguardViewMediator.this.mKeyguardDonePending) {
                KeyguardViewMediator.this.keyguardDone(true);
            }
            if (strongAuth) {
                KeyguardViewMediator.this.mUpdateMonitor.reportSuccessfulStrongAuthUnlockAttempt();
            }
        }

        public void keyguardDoneDrawing() {
            KeyguardViewMediator.this.mHandler.sendEmptyMessage(10);
        }

        public void setNeedsInput(boolean needsInput) {
            KeyguardViewMediator.this.mStatusBarKeyguardViewManager.setNeedsInput(needsInput);
        }

        public void keyguardDonePending(boolean strongAuth) {
            KeyguardViewMediator.this.mKeyguardDonePending = true;
            KeyguardViewMediator.this.mHideAnimationRun = true;
            KeyguardViewMediator.this.mStatusBarKeyguardViewManager.startPreHideAnimation(null);
            KeyguardViewMediator.this.mHandler.sendEmptyMessageDelayed(20, 3000);
            if (strongAuth) {
                KeyguardViewMediator.this.mUpdateMonitor.reportSuccessfulStrongAuthUnlockAttempt();
            }
        }

        public void keyguardGone() {
            KeyguardViewMediator.this.mKeyguardDisplayManager.hide();
        }

        public void readyForKeyguardDone() {
            if (KeyguardViewMediator.this.mKeyguardDonePending) {
                KeyguardViewMediator.this.keyguardDone(true);
            }
        }

        public void resetKeyguard() {
            KeyguardViewMediator.this.resetStateLocked();
        }

        public void playTrustedSound() {
            KeyguardViewMediator.this.playTrustedSound();
        }

        public boolean isInputRestricted() {
            return KeyguardViewMediator.this.isInputRestricted();
        }

        public boolean isScreenOn() {
            return KeyguardViewMediator.this.mDeviceInteractive;
        }

        public int getBouncerPromptReason() {
            int currentUser = ActivityManager.getCurrentUser();
            if ((KeyguardViewMediator.this.mUpdateMonitor.getUserTrustIsManaged(currentUser) || KeyguardViewMediator.this.mUpdateMonitor.isUnlockWithFingerprintPossible(currentUser)) && !KeyguardViewMediator.this.mUpdateMonitor.getStrongAuthTracker().hasUserAuthenticatedSinceBoot()) {
                return 1;
            }
            if (KeyguardViewMediator.this.mUpdateMonitor.isUnlockWithFingerprintPossible(currentUser) && KeyguardViewMediator.this.mUpdateMonitor.hasFingerprintUnlockTimedOut(currentUser)) {
                return 2;
            }
            return 0;
        }
    }

    /* renamed from: com.android.systemui.keyguard.KeyguardViewMediator.3 */
    class C01353 extends BroadcastReceiver {
        C01353() {
        }

        public void onReceive(Context context, Intent intent) {
            if ("com.android.internal.policy.impl.PhoneWindowManager.DELAYED_KEYGUARD".equals(intent.getAction())) {
                int sequence = intent.getIntExtra("seq", 0);
                synchronized (KeyguardViewMediator.this) {
                    if (KeyguardViewMediator.this.mDelayedShowingSequence == sequence) {
                        KeyguardViewMediator.this.doKeyguardLocked(null);
                    }
                }
            } else if ("com.android.keyguard.action.DISMISS_KEYGUARD_SECURELY".equals(intent.getAction())) {
                synchronized (KeyguardViewMediator.this) {
                    KeyguardViewMediator.this.dismiss();
                }
            }
        }
    }

    /* renamed from: com.android.systemui.keyguard.KeyguardViewMediator.4 */
    class C01364 extends Handler {
        C01364(Looper x0, Callback x1, boolean x2) {
            super(x0, x1, x2);
        }

        public void handleMessage(Message msg) {
            boolean z = true;
            KeyguardViewMediator keyguardViewMediator;
            switch (msg.what) {
                case 2:
                    KeyguardViewMediator.this.handleShow((Bundle) msg.obj);
                    return;
                case 3:
                    KeyguardViewMediator.this.handleHide();
                    return;
                case 4:
                    KeyguardViewMediator.this.handleReset();
                    return;
                case 5:
                    KeyguardViewMediator.this.handleVerifyUnlock();
                    return;
                case 6:
                    KeyguardViewMediator.this.handleNotifyFinishedGoingToSleep();
                    return;
                case 7:
                    KeyguardViewMediator.this.handleNotifyScreenTurningOn((IKeyguardDrawnCallback) msg.obj);
                    return;
                case 9:
                    keyguardViewMediator = KeyguardViewMediator.this;
                    if (msg.arg1 == 0) {
                        z = false;
                    }
                    keyguardViewMediator.handleKeyguardDone(z);
                    return;
                case 10:
                    KeyguardViewMediator.this.handleKeyguardDoneDrawing();
                    return;
                case 12:
                    keyguardViewMediator = KeyguardViewMediator.this;
                    if (msg.arg1 == 0) {
                        z = false;
                    }
                    keyguardViewMediator.handleSetOccluded(z);
                    return;
                case 13:
                    synchronized (KeyguardViewMediator.this) {
                        KeyguardViewMediator.this.doKeyguardLocked((Bundle) msg.obj);
                        break;
                    }
                    return;
                case 17:
                    KeyguardViewMediator.this.handleDismiss();
                    return;
                case 18:
                    StartKeyguardExitAnimParams params = msg.obj;
                    KeyguardViewMediator.this.handleStartKeyguardExitAnimation(params.startTime, params.fadeoutDuration);
                    return;
                case 19:
                    break;
                case 20:
                    Log.w("KeyguardViewMediator", "Timeout while waiting for activity drawn!");
                    break;
                case 21:
                    KeyguardViewMediator.this.handleNotifyStartedWakingUp();
                    return;
                case 22:
                    KeyguardViewMediator.this.handleNotifyScreenTurnedOn();
                    return;
                case 23:
                    KeyguardViewMediator.this.handleNotifyScreenTurnedOff();
                    return;
                case 24:
                    KeyguardViewMediator.this.handleNotifyStartedGoingToSleep();
                    return;
                default:
                    return;
            }
            KeyguardViewMediator.this.handleOnActivityDrawn();
        }
    }

    /* renamed from: com.android.systemui.keyguard.KeyguardViewMediator.5 */
    class C01375 implements Runnable {
        C01375() {
        }

        public void run() {
            try {
                KeyguardViewMediator.this.mStatusBarKeyguardViewManager.keyguardGoingAway();
                IActivityManager iActivityManager = ActivityManagerNative.getDefault();
                boolean z = KeyguardViewMediator.this.mStatusBarKeyguardViewManager.shouldDisableWindowAnimationsForUnlock() || KeyguardViewMediator.this.mWakeAndUnlocking;
                iActivityManager.keyguardGoingAway(z, KeyguardViewMediator.this.mStatusBarKeyguardViewManager.isGoingToNotificationShade());
            } catch (RemoteException e) {
                Log.e("KeyguardViewMediator", "Error while calling WindowManager", e);
            }
        }
    }

    /* renamed from: com.android.systemui.keyguard.KeyguardViewMediator.6 */
    static /* synthetic */ class C01386 {
        static final /* synthetic */ int[] $SwitchMap$com$android$internal$telephony$IccCardConstants$State;

        static {
            $SwitchMap$com$android$internal$telephony$IccCardConstants$State = new int[State.values().length];
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.NOT_READY.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.ABSENT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.PIN_REQUIRED.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.PUK_REQUIRED.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.PERM_DISABLED.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$android$internal$telephony$IccCardConstants$State[State.READY.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
        }
    }

    private static class StartKeyguardExitAnimParams {
        long fadeoutDuration;
        long startTime;

        private StartKeyguardExitAnimParams(long startTime, long fadeoutDuration) {
            this.startTime = startTime;
            this.fadeoutDuration = fadeoutDuration;
        }
    }

    public KeyguardViewMediator() {
        this.mExternallyEnabled = true;
        this.mNeedToReshowWhenReenabled = false;
        this.mOccluded = false;
        this.mPhoneState = TelephonyManager.EXTRA_STATE_IDLE;
        this.mWaitingUntilKeyguardVisible = false;
        this.mKeyguardDonePending = false;
        this.mHideAnimationRun = false;
        this.mKeyguardStateCallbacks = new ArrayList();
        this.mUpdateCallback = new C01331();
        this.mViewMediatorCallback = new C01342();
        this.mBroadcastReceiver = new C01353();
        this.mHandler = new C01364(Looper.myLooper(), null, true);
        this.mKeyguardGoingAwayRunnable = new C01375();
    }

    static {
        USER_PRESENT_INTENT = new Intent("android.intent.action.USER_PRESENT").addFlags(603979776);
    }

    public void userActivity() {
        this.mPM.userActivity(SystemClock.uptimeMillis(), false);
    }

    private void setupLocked() {
        boolean z;
        this.mPM = (PowerManager) this.mContext.getSystemService("power");
        this.mWM = WindowManagerGlobal.getWindowManagerService();
        this.mTrustManager = (TrustManager) this.mContext.getSystemService("trust");
        this.mShowKeyguardWakeLock = this.mPM.newWakeLock(1, "show keyguard");
        this.mShowKeyguardWakeLock.setReferenceCounted(false);
        this.mContext.registerReceiver(this.mBroadcastReceiver, new IntentFilter("com.android.internal.policy.impl.PhoneWindowManager.DELAYED_KEYGUARD"));
        this.mContext.registerReceiver(this.mBroadcastReceiver, new IntentFilter("com.android.keyguard.action.DISMISS_KEYGUARD_SECURELY"), "android.permission.CONTROL_KEYGUARD", null);
        this.mKeyguardDisplayManager = new KeyguardDisplayManager(this.mContext);
        this.mAlarmManager = (AlarmManager) this.mContext.getSystemService("alarm");
        this.mUpdateMonitor = KeyguardUpdateMonitor.getInstance(this.mContext);
        this.mLockPatternUtils = new LockPatternUtils(this.mContext);
        KeyguardUpdateMonitor.setCurrentUser(ActivityManager.getCurrentUser());
        if (shouldWaitForProvisioning() || this.mLockPatternUtils.isLockScreenDisabled(KeyguardUpdateMonitor.getCurrentUser())) {
            z = false;
        } else {
            z = true;
        }
        setShowingLocked(z);
        updateInputRestrictedLocked();
        this.mTrustManager.reportKeyguardShowingChanged();
        this.mStatusBarKeyguardViewManager = new StatusBarKeyguardViewManager(this.mContext, this.mViewMediatorCallback, this.mLockPatternUtils);
        ContentResolver cr = this.mContext.getContentResolver();
        this.mDeviceInteractive = this.mPM.isInteractive();
        this.mLockSounds = new SoundPool(1, 1, 0);
        String soundPath = Global.getString(cr, "lock_sound");
        if (soundPath != null) {
            this.mLockSoundId = this.mLockSounds.load(soundPath, 1);
        }
        if (soundPath == null || this.mLockSoundId == 0) {
            Log.w("KeyguardViewMediator", "failed to load lock sound from " + soundPath);
        }
        soundPath = Global.getString(cr, "unlock_sound");
        if (soundPath != null) {
            this.mUnlockSoundId = this.mLockSounds.load(soundPath, 1);
        }
        if (soundPath == null || this.mUnlockSoundId == 0) {
            Log.w("KeyguardViewMediator", "failed to load unlock sound from " + soundPath);
        }
        soundPath = Global.getString(cr, "trusted_sound");
        if (soundPath != null) {
            this.mTrustedSoundId = this.mLockSounds.load(soundPath, 1);
        }
        if (soundPath == null || this.mTrustedSoundId == 0) {
            Log.w("KeyguardViewMediator", "failed to load trusted sound from " + soundPath);
        }
        this.mLockSoundVolume = (float) Math.pow(10.0d, (double) (((float) this.mContext.getResources().getInteger(17694725)) / 20.0f));
        this.mHideAnimation = AnimationUtils.loadAnimation(this.mContext, 17432626);
    }

    public void start() {
        synchronized (this) {
            setupLocked();
        }
        putComponent(KeyguardViewMediator.class, this);
    }

    public void onSystemReady() {
        this.mSearchManager = (SearchManager) this.mContext.getSystemService("search");
        synchronized (this) {
            this.mSystemReady = true;
            doKeyguardLocked(null);
            this.mUpdateMonitor.registerCallback(this.mUpdateCallback);
        }
        maybeSendUserPresentBroadcast();
    }

    public void onStartedGoingToSleep(int why) {
        boolean lockImmediately = false;
        synchronized (this) {
            this.mDeviceInteractive = false;
            this.mGoingToSleep = true;
            int currentUser = KeyguardUpdateMonitor.getCurrentUser();
            if (this.mLockPatternUtils.getPowerButtonInstantlyLocks(currentUser) || !this.mLockPatternUtils.isSecure(currentUser)) {
                lockImmediately = true;
            }
            long timeout = getLockTimeout();
            if (this.mExitSecureCallback != null) {
                try {
                    this.mExitSecureCallback.onKeyguardExitResult(false);
                } catch (RemoteException e) {
                    Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(false)", e);
                }
                this.mExitSecureCallback = null;
                if (!this.mExternallyEnabled) {
                    hideLocked();
                }
            } else if (this.mShowing) {
                this.mPendingReset = true;
            } else if ((why == 3 && timeout > 0) || (why == 2 && !lockImmediately)) {
                doKeyguardLaterLocked(timeout);
            } else if (!this.mLockPatternUtils.isLockScreenDisabled(currentUser)) {
                this.mPendingLock = true;
            }
            if (this.mPendingLock) {
                playSounds(true);
            }
        }
        KeyguardUpdateMonitor.getInstance(this.mContext).dispatchStartedGoingToSleep(why);
        notifyStartedGoingToSleep();
    }

    public void onFinishedGoingToSleep(int why) {
        synchronized (this) {
            this.mDeviceInteractive = false;
            this.mGoingToSleep = false;
            resetKeyguardDonePendingLocked();
            this.mHideAnimationRun = false;
            notifyFinishedGoingToSleep();
            if (this.mPendingReset) {
                resetStateLocked();
                this.mPendingReset = false;
            }
            if (this.mPendingLock) {
                doKeyguardLocked(null);
                this.mPendingLock = false;
            }
        }
        KeyguardUpdateMonitor.getInstance(this.mContext).dispatchFinishedGoingToSleep(why);
    }

    private long getLockTimeout() {
        ContentResolver cr = this.mContext.getContentResolver();
        long displayTimeout = (long) System.getInt(cr, "screen_off_timeout", 30000);
        long lockAfterTimeout = (long) Secure.getInt(cr, "lock_screen_lock_after_timeout", 5000);
        long policyTimeout = this.mLockPatternUtils.getDevicePolicyManager().getMaximumTimeToLock(null, KeyguardUpdateMonitor.getCurrentUser());
        if (policyTimeout > 0) {
            return Math.min(policyTimeout - Math.max(displayTimeout, 0), lockAfterTimeout);
        }
        return lockAfterTimeout;
    }

    private void doKeyguardLaterLocked() {
        long timeout = getLockTimeout();
        if (timeout == 0) {
            doKeyguardLocked(null);
        } else {
            doKeyguardLaterLocked(timeout);
        }
    }

    private void doKeyguardLaterLocked(long timeout) {
        long when = SystemClock.elapsedRealtime() + timeout;
        Intent intent = new Intent("com.android.internal.policy.impl.PhoneWindowManager.DELAYED_KEYGUARD");
        intent.putExtra("seq", this.mDelayedShowingSequence);
        this.mAlarmManager.set(2, when, PendingIntent.getBroadcast(this.mContext, 0, intent, 268435456));
    }

    private void cancelDoKeyguardLaterLocked() {
        this.mDelayedShowingSequence++;
    }

    public void onStartedWakingUp() {
        synchronized (this) {
            this.mDeviceInteractive = true;
            cancelDoKeyguardLaterLocked();
            notifyStartedWakingUp();
        }
        KeyguardUpdateMonitor.getInstance(this.mContext).dispatchStartedWakingUp();
        maybeSendUserPresentBroadcast();
    }

    public void onScreenTurningOn(IKeyguardDrawnCallback callback) {
        notifyScreenOn(callback);
    }

    public void onScreenTurnedOn() {
        notifyScreenTurnedOn();
        this.mUpdateMonitor.dispatchScreenTurnedOn();
    }

    public void onScreenTurnedOff() {
        notifyScreenTurnedOff();
        this.mUpdateMonitor.dispatchScreenTurnedOff();
    }

    private void maybeSendUserPresentBroadcast() {
        if (this.mSystemReady && this.mLockPatternUtils.isLockScreenDisabled(KeyguardUpdateMonitor.getCurrentUser())) {
            sendUserPresentBroadcast();
        }
    }

    public void onDreamingStarted() {
        synchronized (this) {
            if (this.mDeviceInteractive && this.mLockPatternUtils.isSecure(KeyguardUpdateMonitor.getCurrentUser())) {
                doKeyguardLaterLocked();
            }
        }
    }

    public void onDreamingStopped() {
        synchronized (this) {
            if (this.mDeviceInteractive) {
                cancelDoKeyguardLaterLocked();
            }
        }
    }

    public void setKeyguardEnabled(boolean enabled) {
        synchronized (this) {
            this.mExternallyEnabled = enabled;
            if (enabled || !this.mShowing) {
                if (enabled) {
                    if (this.mNeedToReshowWhenReenabled) {
                        this.mNeedToReshowWhenReenabled = false;
                        updateInputRestrictedLocked();
                        if (this.mExitSecureCallback != null) {
                            try {
                                this.mExitSecureCallback.onKeyguardExitResult(false);
                            } catch (RemoteException e) {
                                Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(false)", e);
                            }
                            this.mExitSecureCallback = null;
                            resetStateLocked();
                        } else {
                            showLocked(null);
                            this.mWaitingUntilKeyguardVisible = true;
                            this.mHandler.sendEmptyMessageDelayed(10, 2000);
                            while (this.mWaitingUntilKeyguardVisible) {
                                try {
                                    wait();
                                } catch (InterruptedException e2) {
                                    Thread.currentThread().interrupt();
                                }
                            }
                        }
                    }
                }
            } else if (this.mExitSecureCallback != null) {
                return;
            } else {
                this.mNeedToReshowWhenReenabled = true;
                updateInputRestrictedLocked();
                hideLocked();
            }
        }
    }

    public void verifyUnlock(IKeyguardExitCallback callback) {
        synchronized (this) {
            if (shouldWaitForProvisioning()) {
                try {
                    callback.onKeyguardExitResult(false);
                } catch (RemoteException e) {
                    Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(false)", e);
                }
            } else if (this.mExternallyEnabled) {
                Log.w("KeyguardViewMediator", "verifyUnlock called when not externally disabled");
                try {
                    callback.onKeyguardExitResult(false);
                } catch (RemoteException e2) {
                    Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(false)", e2);
                }
            } else if (this.mExitSecureCallback != null) {
                try {
                    callback.onKeyguardExitResult(false);
                } catch (RemoteException e22) {
                    Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(false)", e22);
                }
            } else if (isSecure()) {
                try {
                    callback.onKeyguardExitResult(false);
                } catch (RemoteException e222) {
                    Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(false)", e222);
                }
            } else {
                this.mExternallyEnabled = true;
                this.mNeedToReshowWhenReenabled = false;
                updateInputRestricted();
                try {
                    callback.onKeyguardExitResult(true);
                } catch (RemoteException e2222) {
                    Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(false)", e2222);
                }
            }
        }
    }

    public boolean isShowingAndNotOccluded() {
        return this.mShowing && !this.mOccluded;
    }

    public void setOccluded(boolean isOccluded) {
        int i;
        this.mHandler.removeMessages(12);
        Handler handler = this.mHandler;
        if (isOccluded) {
            i = 1;
        } else {
            i = 0;
        }
        this.mHandler.sendMessage(handler.obtainMessage(12, i, 0));
    }

    private void handleSetOccluded(boolean isOccluded) {
        synchronized (this) {
            if (this.mHiding && isOccluded) {
                startKeyguardExitAnimation(0, 0);
            }
            if (this.mOccluded != isOccluded) {
                this.mOccluded = isOccluded;
                this.mStatusBarKeyguardViewManager.setOccluded(isOccluded);
                updateActivityLockScreenState();
                adjustStatusBarLocked();
            }
        }
    }

    public void doKeyguardTimeout(Bundle options) {
        this.mHandler.removeMessages(13);
        this.mHandler.sendMessage(this.mHandler.obtainMessage(13, options));
    }

    public boolean isInputRestricted() {
        return this.mShowing || this.mNeedToReshowWhenReenabled;
    }

    private void updateInputRestricted() {
        synchronized (this) {
            updateInputRestrictedLocked();
        }
    }

    private void updateInputRestrictedLocked() {
        boolean inputRestricted = isInputRestricted();
        if (this.mInputRestricted != inputRestricted) {
            this.mInputRestricted = inputRestricted;
            for (int i = this.mKeyguardStateCallbacks.size() - 1; i >= 0; i--) {
                try {
                    ((IKeyguardStateCallback) this.mKeyguardStateCallbacks.get(i)).onInputRestrictedStateChanged(inputRestricted);
                } catch (RemoteException e) {
                    Slog.w("KeyguardViewMediator", "Failed to call onDeviceProvisioned", e);
                    if (e instanceof DeadObjectException) {
                        this.mKeyguardStateCallbacks.remove(i);
                    }
                }
            }
        }
    }

    private void doKeyguardLocked(Bundle options) {
        if (!this.mExternallyEnabled) {
            return;
        }
        if (this.mStatusBarKeyguardViewManager.isShowing()) {
            resetStateLocked();
            return;
        }
        boolean lockedOrMissing;
        boolean requireSim;
        if (SystemProperties.getBoolean("keyguard.no_require_sim", false)) {
            requireSim = false;
        } else {
            requireSim = true;
        }
        boolean absent = SubscriptionManager.isValidSubscriptionId(this.mUpdateMonitor.getNextSubIdForState(State.ABSENT));
        boolean disabled = SubscriptionManager.isValidSubscriptionId(this.mUpdateMonitor.getNextSubIdForState(State.PERM_DISABLED));
        if (this.mUpdateMonitor.isSimPinSecure() || ((absent || disabled) && requireSim)) {
            lockedOrMissing = true;
        } else {
            lockedOrMissing = false;
        }
        if (!lockedOrMissing && shouldWaitForProvisioning()) {
            return;
        }
        if (this.mLockPatternUtils.isLockScreenDisabled(KeyguardUpdateMonitor.getCurrentUser()) && !lockedOrMissing) {
            return;
        }
        if (this.mLockPatternUtils.checkVoldPassword(KeyguardUpdateMonitor.getCurrentUser())) {
            setShowingLocked(false);
            hideLocked();
            this.mUpdateMonitor.reportSuccessfulStrongAuthUnlockAttempt();
            return;
        }
        showLocked(options);
    }

    private boolean shouldWaitForProvisioning() {
        return (this.mUpdateMonitor.isDeviceProvisioned() || isSecure()) ? false : true;
    }

    public void handleDismiss() {
        if (this.mShowing && !this.mOccluded) {
            this.mStatusBarKeyguardViewManager.dismiss();
        }
    }

    public void dismiss() {
        this.mHandler.sendEmptyMessage(17);
    }

    private void resetStateLocked() {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(4));
    }

    private void notifyStartedGoingToSleep() {
        this.mHandler.sendEmptyMessage(24);
    }

    private void notifyFinishedGoingToSleep() {
        this.mHandler.sendEmptyMessage(6);
    }

    private void notifyStartedWakingUp() {
        this.mHandler.sendEmptyMessage(21);
    }

    private void notifyScreenOn(IKeyguardDrawnCallback callback) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(7, callback));
    }

    private void notifyScreenTurnedOn() {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(22));
    }

    private void notifyScreenTurnedOff() {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(23));
    }

    private void showLocked(Bundle options) {
        this.mShowKeyguardWakeLock.acquire();
        this.mHandler.sendMessage(this.mHandler.obtainMessage(2, options));
    }

    private void hideLocked() {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(3));
    }

    public boolean isSecure() {
        return this.mLockPatternUtils.isSecure(KeyguardUpdateMonitor.getCurrentUser()) || KeyguardUpdateMonitor.getInstance(this.mContext).isSimPinSecure();
    }

    public void setCurrentUser(int newUserId) {
        KeyguardUpdateMonitor.setCurrentUser(newUserId);
    }

    public void keyguardDone(boolean authenticated) {
        EventLog.writeEvent(70000, 2);
        this.mHandler.sendMessage(this.mHandler.obtainMessage(9, Integer.valueOf(authenticated ? 1 : 0)));
    }

    private void handleKeyguardDone(boolean authenticated) {
        synchronized (this) {
            resetKeyguardDonePendingLocked();
        }
        if (authenticated) {
            this.mUpdateMonitor.clearFailedUnlockAttempts();
        }
        this.mUpdateMonitor.clearFingerprintRecognized();
        if (this.mGoingToSleep) {
            Log.i("KeyguardViewMediator", "Device is going to sleep, aborting keyguardDone");
            return;
        }
        if (this.mExitSecureCallback != null) {
            try {
                this.mExitSecureCallback.onKeyguardExitResult(authenticated);
            } catch (RemoteException e) {
                Slog.w("KeyguardViewMediator", "Failed to call onKeyguardExitResult(" + authenticated + ")", e);
            }
            this.mExitSecureCallback = null;
            if (authenticated) {
                this.mExternallyEnabled = true;
                this.mNeedToReshowWhenReenabled = false;
                updateInputRestricted();
            }
        }
        handleHide();
    }

    private void sendUserPresentBroadcast() {
        synchronized (this) {
            if (this.mBootCompleted) {
                for (UserInfo ui : ((UserManager) this.mContext.getSystemService("user")).getProfiles(new UserHandle(KeyguardUpdateMonitor.getCurrentUser()).getIdentifier())) {
                    this.mContext.sendBroadcastAsUser(USER_PRESENT_INTENT, ui.getUserHandle());
                }
            } else {
                this.mBootSendUserPresent = true;
            }
        }
    }

    private void handleKeyguardDoneDrawing() {
        synchronized (this) {
            if (this.mWaitingUntilKeyguardVisible) {
                this.mWaitingUntilKeyguardVisible = false;
                notifyAll();
                this.mHandler.removeMessages(10);
            }
        }
    }

    private void playSounds(boolean locked) {
        playSound(locked ? this.mLockSoundId : this.mUnlockSoundId);
    }

    private void playSound(int soundId) {
        if (soundId != 0 && System.getInt(this.mContext.getContentResolver(), "lockscreen_sounds_enabled", 1) == 1) {
            this.mLockSounds.stop(this.mLockSoundStreamId);
            if (this.mAudioManager == null) {
                this.mAudioManager = (AudioManager) this.mContext.getSystemService("audio");
                if (this.mAudioManager != null) {
                    this.mUiSoundsStreamType = this.mAudioManager.getUiSoundsStreamType();
                } else {
                    return;
                }
            }
            if (!this.mAudioManager.isStreamMute(this.mUiSoundsStreamType)) {
                this.mLockSoundStreamId = this.mLockSounds.play(soundId, this.mLockSoundVolume, this.mLockSoundVolume, 1, 0, 1.0f);
            }
        }
    }

    private void playTrustedSound() {
        playSound(this.mTrustedSoundId);
    }

    private void updateActivityLockScreenState() {
        try {
            IActivityManager iActivityManager = ActivityManagerNative.getDefault();
            boolean z = this.mShowing && !this.mOccluded;
            iActivityManager.setLockScreenShown(z);
        } catch (RemoteException e) {
        }
    }

    private void handleShow(Bundle options) {
        synchronized (this) {
            if (this.mSystemReady) {
                setShowingLocked(true);
                this.mStatusBarKeyguardViewManager.show(options);
                this.mHiding = false;
                this.mWakeAndUnlocking = false;
                resetKeyguardDonePendingLocked();
                this.mHideAnimationRun = false;
                updateActivityLockScreenState();
                adjustStatusBarLocked();
                userActivity();
                this.mShowKeyguardWakeLock.release();
                this.mKeyguardDisplayManager.show();
                return;
            }
        }
    }

    private void handleHide() {
        synchronized (this) {
            this.mHiding = true;
            if (!this.mShowing || this.mOccluded) {
                handleStartKeyguardExitAnimation(SystemClock.uptimeMillis() + this.mHideAnimation.getStartOffset(), this.mHideAnimation.getDuration());
            } else if (this.mHideAnimationRun) {
                this.mKeyguardGoingAwayRunnable.run();
            } else {
                this.mStatusBarKeyguardViewManager.startPreHideAnimation(this.mKeyguardGoingAwayRunnable);
            }
        }
    }

    private void handleOnActivityDrawn() {
        if (this.mKeyguardDonePending) {
            this.mStatusBarKeyguardViewManager.onActivityDrawn();
        }
    }

    private void handleStartKeyguardExitAnimation(long startTime, long fadeoutDuration) {
        synchronized (this) {
            if (this.mHiding) {
                this.mHiding = false;
                if (this.mWakeAndUnlocking && this.mDrawnCallback != null) {
                    this.mStatusBarKeyguardViewManager.getViewRootImpl().setReportNextDraw();
                    notifyDrawn(this.mDrawnCallback);
                }
                if (TelephonyManager.EXTRA_STATE_IDLE.equals(this.mPhoneState) && this.mShowing && this.mDeviceInteractive) {
                    playSounds(false);
                }
                setShowingLocked(false);
                this.mStatusBarKeyguardViewManager.hide(startTime, fadeoutDuration);
                resetKeyguardDonePendingLocked();
                this.mHideAnimationRun = false;
                updateActivityLockScreenState();
                adjustStatusBarLocked();
                sendUserPresentBroadcast();
                return;
            }
        }
    }

    private void adjustStatusBarLocked() {
        if (this.mStatusBarManager == null) {
            this.mStatusBarManager = (StatusBarManager) this.mContext.getSystemService("statusbar");
        }
        if (this.mStatusBarManager == null) {
            Log.w("KeyguardViewMediator", "Could not get status bar manager");
            return;
        }
        int flags = 0;
        if (this.mShowing) {
            flags = (0 | 16777216) | 33554432;
        }
        if (isShowingAndNotOccluded()) {
            flags |= 2097152;
        }
        if (!(this.mContext instanceof Activity)) {
            this.mStatusBarManager.disable(flags);
        }
    }

    private void handleReset() {
        synchronized (this) {
            this.mStatusBarKeyguardViewManager.reset();
        }
    }

    private void handleVerifyUnlock() {
        synchronized (this) {
            setShowingLocked(true);
            this.mStatusBarKeyguardViewManager.verifyUnlock();
            updateActivityLockScreenState();
        }
    }

    private void handleNotifyStartedGoingToSleep() {
        synchronized (this) {
            this.mStatusBarKeyguardViewManager.onStartedGoingToSleep();
        }
    }

    private void handleNotifyFinishedGoingToSleep() {
        synchronized (this) {
            this.mStatusBarKeyguardViewManager.onFinishedGoingToSleep();
        }
    }

    private void handleNotifyStartedWakingUp() {
        synchronized (this) {
            this.mStatusBarKeyguardViewManager.onStartedWakingUp();
        }
    }

    private void handleNotifyScreenTurningOn(IKeyguardDrawnCallback callback) {
        synchronized (this) {
            this.mStatusBarKeyguardViewManager.onScreenTurningOn();
            if (callback != null) {
                if (this.mWakeAndUnlocking) {
                    this.mDrawnCallback = callback;
                } else {
                    notifyDrawn(callback);
                }
            }
        }
    }

    private void handleNotifyScreenTurnedOn() {
        synchronized (this) {
            this.mStatusBarKeyguardViewManager.onScreenTurnedOn();
        }
    }

    private void handleNotifyScreenTurnedOff() {
        synchronized (this) {
            this.mStatusBarKeyguardViewManager.onScreenTurnedOff();
            this.mWakeAndUnlocking = false;
        }
    }

    private void notifyDrawn(IKeyguardDrawnCallback callback) {
        try {
            callback.onDrawn();
        } catch (RemoteException e) {
            Slog.w("KeyguardViewMediator", "Exception calling onDrawn():", e);
        }
    }

    private void resetKeyguardDonePendingLocked() {
        this.mKeyguardDonePending = false;
        this.mHandler.removeMessages(20);
    }

    public void onBootCompleted() {
        this.mUpdateMonitor.dispatchBootCompleted();
        synchronized (this) {
            this.mBootCompleted = true;
            if (this.mBootSendUserPresent) {
                sendUserPresentBroadcast();
            }
        }
    }

    public void onWakeAndUnlocking() {
        this.mWakeAndUnlocking = true;
        keyguardDone(true);
    }

    public StatusBarKeyguardViewManager registerStatusBar(PhoneStatusBar phoneStatusBar, ViewGroup container, StatusBarWindowManager statusBarWindowManager, ScrimController scrimController, FingerprintUnlockController fingerprintUnlockController) {
        this.mStatusBarKeyguardViewManager.registerStatusBar(phoneStatusBar, container, statusBarWindowManager, scrimController, fingerprintUnlockController);
        return this.mStatusBarKeyguardViewManager;
    }

    public void startKeyguardExitAnimation(long startTime, long fadeoutDuration) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(18, new StartKeyguardExitAnimParams(fadeoutDuration, null)));
    }

    public void onActivityDrawn() {
        this.mHandler.sendEmptyMessage(19);
    }

    public ViewMediatorCallback getViewMediatorCallback() {
        return this.mViewMediatorCallback;
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        pw.print("  mSystemReady: ");
        pw.println(this.mSystemReady);
        pw.print("  mBootCompleted: ");
        pw.println(this.mBootCompleted);
        pw.print("  mBootSendUserPresent: ");
        pw.println(this.mBootSendUserPresent);
        pw.print("  mExternallyEnabled: ");
        pw.println(this.mExternallyEnabled);
        pw.print("  mNeedToReshowWhenReenabled: ");
        pw.println(this.mNeedToReshowWhenReenabled);
        pw.print("  mShowing: ");
        pw.println(this.mShowing);
        pw.print("  mInputRestricted: ");
        pw.println(this.mInputRestricted);
        pw.print("  mOccluded: ");
        pw.println(this.mOccluded);
        pw.print("  mDelayedShowingSequence: ");
        pw.println(this.mDelayedShowingSequence);
        pw.print("  mExitSecureCallback: ");
        pw.println(this.mExitSecureCallback);
        pw.print("  mDeviceInteractive: ");
        pw.println(this.mDeviceInteractive);
        pw.print("  mGoingToSleep: ");
        pw.println(this.mGoingToSleep);
        pw.print("  mHiding: ");
        pw.println(this.mHiding);
        pw.print("  mWaitingUntilKeyguardVisible: ");
        pw.println(this.mWaitingUntilKeyguardVisible);
        pw.print("  mKeyguardDonePending: ");
        pw.println(this.mKeyguardDonePending);
        pw.print("  mHideAnimationRun: ");
        pw.println(this.mHideAnimationRun);
        pw.print("  mPendingReset: ");
        pw.println(this.mPendingReset);
        pw.print("  mPendingLock: ");
        pw.println(this.mPendingLock);
        pw.print("  mWakeAndUnlocking: ");
        pw.println(this.mWakeAndUnlocking);
        pw.print("  mDrawnCallback: ");
        pw.println(this.mDrawnCallback);
    }

    private void setShowingLocked(boolean showing) {
        if (showing != this.mShowing) {
            this.mShowing = showing;
            for (int i = this.mKeyguardStateCallbacks.size() - 1; i >= 0; i--) {
                try {
                    ((IKeyguardStateCallback) this.mKeyguardStateCallbacks.get(i)).onShowingStateChanged(showing);
                } catch (RemoteException e) {
                    Slog.w("KeyguardViewMediator", "Failed to call onShowingStateChanged", e);
                    if (e instanceof DeadObjectException) {
                        this.mKeyguardStateCallbacks.remove(i);
                    }
                }
            }
            updateInputRestrictedLocked();
            this.mTrustManager.reportKeyguardShowingChanged();
        }
    }

    public void addStateMonitorCallback(IKeyguardStateCallback callback) {
        synchronized (this) {
            this.mKeyguardStateCallbacks.add(callback);
            try {
                callback.onSimSecureStateChanged(this.mUpdateMonitor.isSimPinSecure());
                callback.onShowingStateChanged(this.mShowing);
                callback.onInputRestrictedStateChanged(this.mInputRestricted);
            } catch (RemoteException e) {
                Slog.w("KeyguardViewMediator", "Failed to call onShowingStateChanged or onSimSecureStateChanged or onInputRestrictedStateChanged", e);
            }
        }
    }
}
