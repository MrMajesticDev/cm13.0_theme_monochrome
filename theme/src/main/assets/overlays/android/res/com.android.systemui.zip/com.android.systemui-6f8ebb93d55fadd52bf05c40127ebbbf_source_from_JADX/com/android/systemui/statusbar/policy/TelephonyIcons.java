package com.android.systemui.statusbar.policy;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.util.Log;
import android.util.SparseArray;
import com.android.keyguard.C0065R;

class TelephonyIcons {
    static final MobileIconGroup CARRIER_NETWORK_CHANGE;
    static final int[][] DATA_1X;
    static final int[][] DATA_3G;
    static final int[][] DATA_4G;
    static final int[][] DATA_4G_PLUS;
    static final int[][] DATA_E;
    static final int[][] DATA_G;
    static final int[][] DATA_H;
    static final int[][] DATA_LTE;
    static final MobileIconGroup f24E;
    static final MobileIconGroup FOUR_G;
    static final MobileIconGroup FOUR_G_LTE;
    static final MobileIconGroup FOUR_G_PLUS;
    static final MobileIconGroup f25G;
    static final MobileIconGroup f26H;
    static final MobileIconGroup H_PLUS;
    static final MobileIconGroup LTE;
    static final MobileIconGroup LTE_PLUS;
    static final MobileIconGroup ONE_X;
    static final int[][] QS_TELEPHONY_CARRIER_NETWORK_CHANGE;
    static final int[][] QS_TELEPHONY_SIGNAL_STRENGTH;
    static final MobileIconGroup ROAMING;
    static final int[][] TELEPHONY_CARRIER_NETWORK_CHANGE;
    static final int[][] TELEPHONY_SIGNAL_STRENGTH;
    static final int[][] TELEPHONY_SIGNAL_STRENGTH_ROAMING;
    static final int[][] TELEPHONY_SIGNAL_STRENGTH_ROAMING_R;
    static final MobileIconGroup THREE_G;
    static final MobileIconGroup THREE_G_PLUS;
    static final MobileIconGroup UNKNOWN;
    static final MobileIconGroup WFC;
    private static boolean isInitiated;
    static String[] mDataActivityArray;
    static String[] mDataTypeArray;
    static String[] mDataTypeDescriptionArray;
    static String[] mDataTypeGenerationArray;
    static String[] mDataTypeGenerationDescArray;
    private static Resources mRes;
    static int[] mSelectedDataActivityIndex;
    static String[] mSelectedDataTypeDesc;
    static int[] mSelectedDataTypeIcon;
    static int[] mSelectedQSDataTypeIcon;
    static int[] mSelectedSignalStreagthIndex;
    static String[] mSignalNullArray;
    static String[] mSignalStrengthArray;
    static String[] mSignalStrengthDesc;
    static String[] mSignalStrengthRoamingArray;
    static SparseArray<Integer> mStacked2SingleIconLookup;

    static {
        TELEPHONY_SIGNAL_STRENGTH = new int[][]{new int[]{2130837916, 2130837956, 2130837996, 2130838040, 2130838080}, new int[]{2130837941, 2130837981, 2130838021, 2130838065, 2130838105}};
        QS_TELEPHONY_SIGNAL_STRENGTH = new int[][]{new int[]{2130837646, 2130837647, 2130837649, 2130837651, 2130837654}, new int[]{2130837662, 2130837663, 2130837664, 2130837666, 2130837667}};
        TELEPHONY_SIGNAL_STRENGTH_ROAMING = new int[][]{new int[]{2130837916, 2130837956, 2130837996, 2130838040, 2130838080}, new int[]{2130837941, 2130837981, 2130838021, 2130838065, 2130838105}};
        TELEPHONY_SIGNAL_STRENGTH_ROAMING_R = new int[][]{new int[]{2130837936, 2130837976, 2130838016, 2130838060, 2130838100}, new int[]{2130837935, 2130837975, 2130838015, 2130838059, 2130838099}};
        TELEPHONY_CARRIER_NETWORK_CHANGE = new int[][]{new int[]{2130838125, 2130838125, 2130838125, 2130838125, 2130838125}, new int[]{2130838125, 2130838125, 2130838125, 2130838125, 2130838125}};
        QS_TELEPHONY_CARRIER_NETWORK_CHANGE = new int[][]{new int[]{2130837659, 2130837659, 2130837659, 2130837659, 2130837659}, new int[]{2130837659, 2130837659, 2130837659, 2130837659, 2130837659}};
        DATA_G = new int[][]{new int[]{2130837835, 2130837835, 2130837835, 2130837835}, new int[]{2130837835, 2130837835, 2130837835, 2130837835}};
        DATA_3G = new int[][]{new int[]{2130837829, 2130837829, 2130837829, 2130837829}, new int[]{2130837829, 2130837829, 2130837829, 2130837829}};
        DATA_E = new int[][]{new int[]{2130837834, 2130837834, 2130837834, 2130837834}, new int[]{2130837834, 2130837834, 2130837834, 2130837834}};
        DATA_H = new int[][]{new int[]{2130837836, 2130837836, 2130837836, 2130837836}, new int[]{2130837836, 2130837836, 2130837836, 2130837836}};
        DATA_1X = new int[][]{new int[]{2130837828, 2130837828, 2130837828, 2130837828}, new int[]{2130837828, 2130837828, 2130837828, 2130837828}};
        DATA_4G = new int[][]{new int[]{2130837831, 2130837831, 2130837831, 2130837831}, new int[]{2130837831, 2130837831, 2130837831, 2130837831}};
        DATA_4G_PLUS = new int[][]{new int[]{2130837833, 2130837833, 2130837833, 2130837833}, new int[]{2130837833, 2130837833, 2130837833, 2130837833}};
        DATA_LTE = new int[][]{new int[]{2130837838, 2130837838, 2130837838, 2130837838}, new int[]{2130837838, 2130837838, 2130837838, 2130837838}};
        isInitiated = false;
        CARRIER_NETWORK_CHANGE = new MobileIconGroup("CARRIER_NETWORK_CHANGE", TELEPHONY_CARRIER_NETWORK_CHANGE, QS_TELEPHONY_CARRIER_NETWORK_CHANGE, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838125, 2130837659, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362080, 0, false, 0);
        THREE_G = new MobileIconGroup("3G", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362063, 2130837829, true, 2130837652);
        THREE_G_PLUS = new MobileIconGroup("3G+", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362064, 2130837830, true, 2130837653);
        WFC = new MobileIconGroup("WFC", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 0, 0, false, 0);
        UNKNOWN = new MobileIconGroup("Unknown", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 0, 0, false, 0);
        f24E = new MobileIconGroup("E", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362074, 2130837834, false, 2130837661);
        ONE_X = new MobileIconGroup("1X", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362072, 2130837828, true, 2130837648);
        f25G = new MobileIconGroup("G", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362060, 2130837835, false, 2130837669);
        f26H = new MobileIconGroup("H", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362065, 2130837836, false, 2130837670);
        H_PLUS = new MobileIconGroup("H+", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362066, 2130837837, false, 2130837671);
        FOUR_G = new MobileIconGroup("4G", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362067, 2130837831, true, 2130837655);
        FOUR_G_LTE = new MobileIconGroup("4GLTE", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362068, 2130837832, true, 2130837656);
        FOUR_G_PLUS = new MobileIconGroup("4G+", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362069, 2130837833, true, 2130837657);
        LTE = new MobileIconGroup("LTE", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362070, 2130837838, true, 2130837674);
        LTE_PLUS = new MobileIconGroup("LTE+", TELEPHONY_SIGNAL_STRENGTH, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362071, 2130837839, true, 2130837675);
        ROAMING = new MobileIconGroup("Roaming", TELEPHONY_SIGNAL_STRENGTH_ROAMING, QS_TELEPHONY_SIGNAL_STRENGTH, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH, 0, 0, 2130838134, 2130837676, AccessibilityContentDescriptions.PHONE_SIGNAL_STRENGTH[0], 2131362073, 2130837840, false, 2130837678);
    }

    static void readIconsFromXml(Context context) {
        if (isInitiated) {
            log("TelephonyIcons", "readIconsFromXml, already read!");
            return;
        }
        mRes = context.getResources();
        try {
            mDataTypeArray = mRes.getStringArray(2131230725);
            mDataTypeDescriptionArray = mRes.getStringArray(2131230730);
            mDataTypeGenerationArray = mRes.getStringArray(2131230729);
            mDataTypeGenerationDescArray = mRes.getStringArray(2131230731);
            mDataActivityArray = mRes.getStringArray(2131230732);
            mSignalStrengthArray = mRes.getStringArray(2131230766);
            mSignalStrengthRoamingArray = mRes.getStringArray(2131230767);
            mSignalNullArray = mRes.getStringArray(2131230829);
            mSignalStrengthDesc = mRes.getStringArray(2131230828);
            initStacked2SingleIconLookup();
            if (mSelectedDataTypeIcon == null && mDataTypeArray.length != 0) {
                mSelectedDataTypeIcon = new int[mDataTypeArray.length];
            }
            if (mSelectedQSDataTypeIcon == null && mDataTypeArray.length != 0) {
                mSelectedQSDataTypeIcon = new int[mDataTypeArray.length];
            }
            if (mSelectedDataTypeDesc == null && mDataTypeArray.length != 0) {
                mSelectedDataTypeDesc = new String[mDataTypeArray.length];
            }
            if (mSelectedDataActivityIndex == null && mDataActivityArray.length != 0) {
                mSelectedDataActivityIndex = new int[mDataActivityArray.length];
            }
            if (mSelectedSignalStreagthIndex == null && mSignalStrengthArray.length != 0) {
                mSelectedSignalStreagthIndex = new int[mSignalStrengthArray.length];
            }
            isInitiated = true;
        } catch (NotFoundException e) {
            isInitiated = false;
            log("TelephonyIcons", "readIconsFromXml, exception happened: " + e);
        }
    }

    static void initStacked2SingleIconLookup() {
        mStacked2SingleIconLookup = new SparseArray();
        TypedArray stackedIcons = mRes.obtainTypedArray(2131230939);
        TypedArray singleIcons = mRes.obtainTypedArray(2131230940);
        mStacked2SingleIconLookup.clear();
        int i = 0;
        while (i < stackedIcons.length() && i < singleIcons.length()) {
            mStacked2SingleIconLookup.put(stackedIcons.getResourceId(i, 0), Integer.valueOf(singleIcons.getResourceId(i, 0)));
            i++;
        }
        stackedIcons.recycle();
        singleIcons.recycle();
        log("TelephonyIcons", "initStacked2SingleIconLookup: size=" + mStacked2SingleIconLookup.size());
    }

    static int getSignalNullIcon(int slot) {
        if (mSignalNullArray == null) {
            return 0;
        }
        String resName = mSignalNullArray[slot];
        log("TelephonyIcons", "null signal icon name: " + resName);
        return mRes.getIdentifier(resName, null, "com.android.systemui");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void updateDataType(int r9, int r10, boolean r11, boolean r12, boolean r13, int r14) {
        /*
        r3 = "TelephonyIcons";
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r5 = "updateDataType ";
        r4 = r4.append(r5);
        r5 = "slot=%d, type=%d, inetCondition=%d";
        r6 = 3;
        r6 = new java.lang.Object[r6];
        r7 = 0;
        r8 = java.lang.Integer.valueOf(r9);
        r6[r7] = r8;
        r7 = 1;
        r8 = java.lang.Integer.valueOf(r10);
        r6[r7] = r8;
        r7 = 2;
        r8 = java.lang.Integer.valueOf(r14);
        r6[r7] = r8;
        r5 = java.lang.String.format(r5, r6);
        r4 = r4.append(r5);
        r5 = " showAtLeast3G=";
        r4 = r4.append(r5);
        r5 = java.lang.String.valueOf(r11);
        r4 = r4.append(r5);
        r5 = " show4GforLte=";
        r4 = r4.append(r5);
        r5 = java.lang.String.valueOf(r12);
        r4 = r4.append(r5);
        r5 = " hspaDistinguishable=";
        r4 = r4.append(r5);
        r5 = java.lang.String.valueOf(r13);
        r4 = r4.append(r5);
        r4 = r4.toString();
        log(r3, r4);
        r3 = mDataTypeArray;
        r2 = r3[r9];
        r3 = mRes;
        r4 = 0;
        r5 = "com.android.systemui";
        r1 = r3.getIdentifier(r2, r4, r5);
        r3 = mRes;
        r0 = r3.getStringArray(r1);
        r3 = "TelephonyIcons";
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r5 = "data type item name: ";
        r4 = r4.append(r5);
        r4 = r4.append(r2);
        r5 = " id:";
        r4 = r4.append(r5);
        r4 = r4.append(r1);
        r4 = r4.toString();
        log(r3, r4);
        switch(r10) {
            case 0: goto L_0x00f1;
            case 1: goto L_0x033f;
            case 2: goto L_0x011a;
            case 3: goto L_0x0146;
            case 4: goto L_0x024a;
            case 5: goto L_0x02a4;
            case 6: goto L_0x02a4;
            case 7: goto L_0x0277;
            case 8: goto L_0x0171;
            case 9: goto L_0x0171;
            case 10: goto L_0x0171;
            case 11: goto L_0x0098;
            case 12: goto L_0x02a4;
            case 13: goto L_0x02ce;
            case 14: goto L_0x02a4;
            case 15: goto L_0x01cb;
            case 16: goto L_0x033f;
            case 17: goto L_0x0146;
            case 18: goto L_0x0098;
            case 19: goto L_0x02ce;
            default: goto L_0x0098;
        };
    L_0x0098:
        r3 = mSelectedDataActivityIndex;
        r4 = 0;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = 0;
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 0;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = "";
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 0;
        r3[r9] = r4;
    L_0x00b2:
        r3 = "TelephonyIcons";
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r5 = "updateDataType ";
        r4 = r4.append(r5);
        r5 = "mSelectedDataTypeIcon[%d]=%d, mSelectedDataActivityIndex=%d";
        r6 = 3;
        r6 = new java.lang.Object[r6];
        r7 = 0;
        r8 = java.lang.Integer.valueOf(r9);
        r6[r7] = r8;
        r7 = 1;
        r8 = mSelectedDataTypeIcon;
        r8 = r8[r9];
        r8 = java.lang.Integer.valueOf(r8);
        r6[r7] = r8;
        r7 = 2;
        r8 = mSelectedDataActivityIndex;
        r8 = r8[r9];
        r8 = java.lang.Integer.valueOf(r8);
        r6[r7] = r8;
        r5 = java.lang.String.format(r5, r6);
        r4 = r4.append(r5);
        r4 = r4.toString();
        log(r3, r4);
        return;
    L_0x00f1:
        if (r11 != 0) goto L_0x011a;
    L_0x00f3:
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 0;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedDataActivityIndex;
        r4 = 0;
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 0;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x011a:
        if (r11 != 0) goto L_0x0146;
    L_0x011c:
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837661; // 0x7f02009d float:1.7280282E38 double:1.052773685E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedDataActivityIndex;
        r4 = 2;
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 1;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x0146:
        r3 = mSelectedDataActivityIndex;
        r4 = 4;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837652; // 0x7f020094 float:1.7280264E38 double:1.0527736807E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 8;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x0171:
        if (r13 == 0) goto L_0x019d;
    L_0x0173:
        r3 = mSelectedDataActivityIndex;
        r4 = 6;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837670; // 0x7f0200a6 float:1.72803E38 double:1.0527736896E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 4;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x019d:
        r3 = mSelectedDataActivityIndex;
        r4 = 4;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = mDataTypeGenerationArray;
        r6 = 0;
        r5 = r5[r6];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837652; // 0x7f020094 float:1.7280264E38 double:1.0527736807E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeGenerationDescArray;
        r5 = 0;
        r4 = r4[r5];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 2;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x01cb:
        if (r13 == 0) goto L_0x01f7;
    L_0x01cd:
        r3 = mSelectedDataActivityIndex;
        r4 = 7;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837670; // 0x7f0200a6 float:1.72803E38 double:1.0527736896E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 5;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x01f7:
        r3 = mSelectedDataActivityIndex;
        r4 = 4;
        r3[r9] = r4;
        r3 = mRes;
        r4 = 2131558434; // 0x7f0d0022 float:1.8742184E38 double:1.0531297943E-314;
        r3 = r3.getBoolean(r4);
        if (r3 == 0) goto L_0x0230;
    L_0x0207:
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = mDataTypeGenerationArray;
        r6 = 3;
        r5 = r5[r6];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837655; // 0x7f020097 float:1.728027E38 double:1.052773682E-314;
        r3[r9] = r4;
    L_0x0220:
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeGenerationDescArray;
        r5 = 0;
        r4 = r4[r5];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 2;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x0230:
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = mDataTypeGenerationArray;
        r6 = 0;
        r5 = r5[r6];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837652; // 0x7f020094 float:1.7280264E38 double:1.0527736807E-314;
        r3[r9] = r4;
        goto L_0x0220;
    L_0x024a:
        if (r11 != 0) goto L_0x0277;
    L_0x024c:
        r3 = mSelectedDataActivityIndex;
        r4 = 8;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837648; // 0x7f020090 float:1.7280256E38 double:1.0527736787E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 7;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x0277:
        if (r11 != 0) goto L_0x02a4;
    L_0x0279:
        r3 = mSelectedDataActivityIndex;
        r4 = 8;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837648; // 0x7f020090 float:1.7280256E38 double:1.0527736787E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 6;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x02a4:
        r3 = mSelectedDataActivityIndex;
        r4 = 4;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837652; // 0x7f020094 float:1.7280264E38 double:1.0527736807E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 2;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x02ce:
        if (r12 == 0) goto L_0x0314;
    L_0x02d0:
        r3 = mSelectedDataActivityIndex;
        r4 = 5;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = mDataTypeGenerationArray;
        r6 = 1;
        r5 = r5[r6];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = 19;
        if (r10 != r3) goto L_0x02fd;
    L_0x02eb:
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = mDataTypeGenerationArray;
        r6 = 2;
        r5 = r5[r6];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
    L_0x02fd:
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837655; // 0x7f020097 float:1.728027E38 double:1.052773682E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeGenerationDescArray;
        r5 = 1;
        r4 = r4[r5];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 3;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x0314:
        r3 = mSelectedDataActivityIndex;
        r4 = 9;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837674; // 0x7f0200aa float:1.7280309E38 double:1.0527736916E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 3;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x033f:
        if (r11 != 0) goto L_0x036b;
    L_0x0341:
        r3 = mSelectedDataActivityIndex;
        r4 = 1;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = r0[r10];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837669; // 0x7f0200a5 float:1.7280299E38 double:1.052773689E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeDescriptionArray;
        r4 = r4[r10];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 0;
        r3[r9] = r4;
        goto L_0x00b2;
    L_0x036b:
        r3 = mSelectedDataActivityIndex;
        r4 = 4;
        r3[r9] = r4;
        r3 = mSelectedDataTypeIcon;
        r4 = mRes;
        r5 = mDataTypeGenerationArray;
        r6 = 0;
        r5 = r5[r6];
        r6 = 0;
        r7 = "com.android.systemui";
        r4 = r4.getIdentifier(r5, r6, r7);
        r3[r9] = r4;
        r3 = mSelectedQSDataTypeIcon;
        r4 = 2130837652; // 0x7f020094 float:1.7280264E38 double:1.0527736807E-314;
        r3[r9] = r4;
        r3 = mSelectedDataTypeDesc;
        r4 = mDataTypeGenerationDescArray;
        r5 = 0;
        r4 = r4[r5];
        r3[r9] = r4;
        r3 = mSelectedSignalStreagthIndex;
        r4 = 2;
        r3[r9] = r4;
        goto L_0x00b2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.systemui.statusbar.policy.TelephonyIcons.updateDataType(int, int, boolean, boolean, boolean, int):void");
    }

    static int getQSDataTypeIcon(int slot) {
        return mSelectedQSDataTypeIcon[slot];
    }

    static int getDataTypeIcon(int slot) {
        log("TelephonyIcons", "getDataTypeIcon " + String.format("sub=%d", new Object[]{Integer.valueOf(slot)}));
        return mSelectedDataTypeIcon[slot];
    }

    static int getDataTypeDesc(int slot) {
        return mRes.getIdentifier(mSelectedDataTypeDesc[slot], null, "com.android.systemui");
    }

    static int getDataActivity(int slot, int activity) {
        log("TelephonyIcons", String.format("getDataActivity, slot=%d, activity=%d", new Object[]{Integer.valueOf(slot), Integer.valueOf(activity)}));
        return mRes.getIdentifier(mRes.getStringArray(mRes.getIdentifier(mRes.getStringArray(mRes.getIdentifier(mDataActivityArray[slot], null, "com.android.systemui"))[mSelectedDataActivityIndex[slot]], null, "com.android.systemui"))[activity], null, "com.android.systemui");
    }

    static int getSignalStrengthIcon(int slot, int inet, int level, boolean roaming) {
        log("TelephonyIcons", "getSignalStrengthIcon: " + String.format("slot=%d, inetCondition=%d, level=%d, roaming=%b", new Object[]{Integer.valueOf(slot), Integer.valueOf(inet), Integer.valueOf(level), Boolean.valueOf(roaming)}));
        log("TelephonyIcons", String.format("signalStrengthArray.length=%d", new Object[]{Integer.valueOf(mRes.getStringArray(mRes.getIdentifier(!roaming ? mSignalStrengthArray[slot] : mSignalStrengthRoamingArray[slot], null, "com.android.systemui")).length)}));
        log("TelephonyIcons", String.format("selectedTypeArray.length=%d", new Object[]{Integer.valueOf(mRes.getStringArray(mRes.getIdentifier(signalStrengthArray[mSelectedSignalStreagthIndex[slot]], null, "com.android.systemui")).length)}));
        log("TelephonyIcons", String.format("inetArray.length=%d", new Object[]{Integer.valueOf(mRes.getStringArray(mRes.getIdentifier(mRes.getStringArray(mRes.getIdentifier(signalStrengthArray[mSelectedSignalStreagthIndex[slot]], null, "com.android.systemui"))[inet], null, "com.android.systemui")).length)}));
        return mRes.getIdentifier(mRes.getStringArray(mRes.getIdentifier(mRes.getStringArray(mRes.getIdentifier(signalStrengthArray[mSelectedSignalStreagthIndex[slot]], null, "com.android.systemui"))[inet], null, "com.android.systemui"))[level], null, "com.android.systemui");
    }

    static int convertMobileStrengthIcon(int stackedIcon) {
        if (mStacked2SingleIconLookup != null && mStacked2SingleIconLookup.indexOfKey(stackedIcon) >= 0) {
            return ((Integer) mStacked2SingleIconLookup.get(stackedIcon)).intValue();
        }
        return stackedIcon;
    }

    static int getStackedVoiceIcon(int level) {
        switch (level) {
            case C0065R.styleable.NumPadKey_digit /*0*/:
                return 2130837917;
            case C0065R.styleable.NumPadKey_textView /*1*/:
                return 2130837957;
            case 2:
                return 2130837997;
            case 3:
                return 2130838041;
            case 4:
                return 2130838081;
            default:
                return 0;
        }
    }

    static int getRoamingSignalIconId(int level, int inet) {
        return TELEPHONY_SIGNAL_STRENGTH_ROAMING_R[inet][level];
    }

    static int[] getSignalStrengthDes(int slot) {
        int[] resId = new int[5];
        for (int i = 0; i < 5; i++) {
            resId[i] = mRes.getIdentifier(mSignalStrengthDesc[i], null, "com.android.systemui");
        }
        return resId;
    }

    private static void log(String tag, String str) {
        Log.d(tag, str);
    }
}
