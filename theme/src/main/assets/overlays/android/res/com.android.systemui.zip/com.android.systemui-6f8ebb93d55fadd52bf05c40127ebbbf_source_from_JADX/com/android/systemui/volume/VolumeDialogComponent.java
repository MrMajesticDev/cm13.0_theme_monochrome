package com.android.systemui.volume;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.VolumePolicy;
import android.os.Bundle;
import android.os.Handler;
import com.android.systemui.SystemUI;
import com.android.systemui.keyguard.KeyguardViewMediator;
import com.android.systemui.qs.tiles.DndTile;
import com.android.systemui.statusbar.phone.PhoneStatusBar;
import com.android.systemui.statusbar.policy.ZenModeController;
import com.android.systemui.volume.VolumeDialog.Callback;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class VolumeDialogComponent implements VolumeComponent {
    private final Context mContext;
    private final VolumeDialogController mController;
    private VolumeDialog mDialog;
    private final SystemUI mSysui;
    private final Callback mVolumeDialogCallback;
    private final VolumePolicy mVolumePolicy;
    private final ZenModeController mZenModeController;

    /* renamed from: com.android.systemui.volume.VolumeDialogComponent.1 */
    class C05661 extends VolumeDialogController {
        C05661(Context x0, ComponentName x1) {
            super(x0, x1);
        }

        protected void onUserActivityW() {
            VolumeDialogComponent.this.sendUserActivity();
        }
    }

    /* renamed from: com.android.systemui.volume.VolumeDialogComponent.2 */
    class C05672 implements Callback {
        C05672() {
        }

        public void onSettingsClicked() {
            VolumeDialogComponent.this.startSettings(new Intent("android.settings.NOTIFICATION_SETTINGS"));
        }
    }

    public VolumeDialogComponent(SystemUI sysui, Context context, Handler handler, ZenModeController zen) {
        this.mVolumePolicy = new VolumePolicy(true, true, true, 400);
        this.mVolumeDialogCallback = new C05672();
        this.mSysui = sysui;
        this.mContext = context;
        this.mController = new C05661(context, null);
        this.mZenModeController = zen;
        this.mDialog = new VolumeDialog(context, 2020, this.mController, zen, this.mVolumeDialogCallback);
        applyConfiguration();
    }

    private void sendUserActivity() {
        KeyguardViewMediator kvm = (KeyguardViewMediator) this.mSysui.getComponent(KeyguardViewMediator.class);
        if (kvm != null) {
            kvm.userActivity();
        }
    }

    private void applyConfiguration() {
        this.mDialog.setStreamImportant(4, true);
        this.mDialog.setStreamImportant(1, false);
        this.mDialog.setShowHeaders(false);
        this.mDialog.setAutomute(true);
        this.mDialog.setSilentMode(false);
        this.mController.setVolumePolicy(this.mVolumePolicy);
        this.mController.showDndTile(true);
    }

    public ZenModeController getZenController() {
        return this.mZenModeController;
    }

    public void onConfigurationChanged(Configuration newConfig) {
    }

    public void dismissNow() {
        this.mController.dismiss();
    }

    public void dispatchDemoCommand(String command, Bundle args) {
    }

    public void register() {
        this.mController.register();
        DndTile.setCombinedIcon(this.mContext, true);
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        this.mController.dump(fd, pw, args);
        this.mDialog.dump(pw);
    }

    private void startSettings(Intent intent) {
        ((PhoneStatusBar) this.mSysui.getComponent(PhoneStatusBar.class)).startActivityDismissingKeyguard(intent, true, true);
    }

    public void recreateDialog() {
        if (this.mDialog != null) {
            this.mDialog.cleanup();
        }
        this.mDialog = new VolumeDialog(this.mContext, 2020, this.mController, this.mZenModeController, this.mVolumeDialogCallback);
        applyConfiguration();
    }
}
