package com.android.systemui.statusbar.phone;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewPropertyAnimator;
import android.view.animation.AccelerateInterpolator;
import com.android.internal.statusbar.IStatusBarService;
import com.android.internal.statusbar.IStatusBarService.Stub;

public final class NavigationBarTransitions extends BarTransitions {
    private final IStatusBarService mBarService;
    private boolean mLightsOut;
    private final OnTouchListener mLightsOutListener;
    private final NavigationBarView mView;

    /* renamed from: com.android.systemui.statusbar.phone.NavigationBarTransitions.1 */
    class C03801 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$lowLights;

        C03801(View view) {
            this.val$lowLights = view;
        }

        public void onAnimationEnd(Animator _a) {
            this.val$lowLights.setVisibility(8);
        }
    }

    /* renamed from: com.android.systemui.statusbar.phone.NavigationBarTransitions.2 */
    class C03812 implements OnTouchListener {
        C03812() {
        }

        public boolean onTouch(View v, MotionEvent ev) {
            if (ev.getAction() == 0) {
                NavigationBarTransitions.this.applyLightsOut(false, false, false);
                try {
                    NavigationBarTransitions.this.mBarService.setSystemUiVisibility(0, 1, "LightsOutListener");
                } catch (RemoteException e) {
                }
            }
            return false;
        }
    }

    public NavigationBarTransitions(NavigationBarView view) {
        super(view, 2130837771, 2131427332, 2131427333, 2131427334, 17170522);
        this.mLightsOutListener = new C03812();
        this.mView = view;
        this.mBarService = Stub.asInterface(ServiceManager.getService("statusbar"));
    }

    public void init() {
        applyModeBackground(-1, getMode(), false);
        applyMode(getMode(), false, true);
    }

    protected void onTransition(int oldMode, int newMode, boolean animate) {
        super.onTransition(oldMode, newMode, animate);
        applyMode(newMode, animate, false);
    }

    private void applyMode(int mode, boolean animate, boolean force) {
        applyLightsOut(isLightsOut(mode), animate, force);
    }

    private void applyLightsOut(boolean lightsOut, boolean animate, boolean force) {
        int i = 0;
        float lowLightsAlpha = 1.0f;
        if (force || lightsOut != this.mLightsOut) {
            float navButtonsAlpha;
            this.mLightsOut = lightsOut;
            View navButtons = this.mView.getCurrentView().findViewById(2131755175);
            View lowLights = this.mView.getCurrentView().findViewById(2131755183);
            navButtons.animate().cancel();
            lowLights.animate().cancel();
            if (lightsOut) {
                navButtonsAlpha = 0.0f;
            } else {
                navButtonsAlpha = 1.0f;
            }
            if (!lightsOut) {
                lowLightsAlpha = 0.0f;
            }
            if (animate) {
                AnimatorListener animatorListener;
                int duration = lightsOut ? 750 : 250;
                navButtons.animate().alpha(navButtonsAlpha).setDuration((long) duration).start();
                lowLights.setOnTouchListener(this.mLightsOutListener);
                if (lowLights.getVisibility() == 8) {
                    lowLights.setAlpha(0.0f);
                    lowLights.setVisibility(0);
                }
                ViewPropertyAnimator interpolator = lowLights.animate().alpha(lowLightsAlpha).setDuration((long) duration).setInterpolator(new AccelerateInterpolator(2.0f));
                if (lightsOut) {
                    animatorListener = null;
                } else {
                    animatorListener = new C03801(lowLights);
                }
                interpolator.setListener(animatorListener).start();
                return;
            }
            navButtons.setAlpha(navButtonsAlpha);
            lowLights.setAlpha(lowLightsAlpha);
            if (!lightsOut) {
                i = 8;
            }
            lowLights.setVisibility(i);
        }
    }
}
