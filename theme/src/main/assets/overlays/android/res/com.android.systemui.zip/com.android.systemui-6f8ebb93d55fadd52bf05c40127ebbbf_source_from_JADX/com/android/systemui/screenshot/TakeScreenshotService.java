package com.android.systemui.screenshot;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import com.android.keyguard.C0065R;

public class TakeScreenshotService extends Service {
    private static GlobalScreenshot mScreenshot;
    private Handler mHandler;

    /* renamed from: com.android.systemui.screenshot.TakeScreenshotService.1 */
    class C02651 extends Handler {

        /* renamed from: com.android.systemui.screenshot.TakeScreenshotService.1.1 */
        class C02641 implements Runnable {
            final /* synthetic */ Messenger val$callback;

            C02641(Messenger messenger) {
                this.val$callback = messenger;
            }

            public void run() {
                try {
                    this.val$callback.send(Message.obtain(null, 1));
                } catch (RemoteException e) {
                }
            }
        }

        C02651() {
        }

        public void handleMessage(Message msg) {
            boolean z = true;
            switch (msg.what) {
                case C0065R.styleable.NumPadKey_textView /*1*/:
                    Messenger callback = msg.replyTo;
                    if (TakeScreenshotService.mScreenshot == null) {
                        TakeScreenshotService.mScreenshot = new GlobalScreenshot(TakeScreenshotService.this);
                    }
                    GlobalScreenshot access$000 = TakeScreenshotService.mScreenshot;
                    Runnable c02641 = new C02641(callback);
                    boolean z2 = msg.arg1 > 0;
                    if (msg.arg2 <= 0) {
                        z = false;
                    }
                    access$000.takeScreenshot(c02641, z2, z);
                default:
            }
        }
    }

    public TakeScreenshotService() {
        this.mHandler = new C02651();
    }

    public IBinder onBind(Intent intent) {
        return new Messenger(this.mHandler).getBinder();
    }
}
