package com.android.systemui.volume;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnGenericMotionListener;
import android.view.View.OnTouchListener;

public class Interaction {

    public interface Callback {
        void onInteraction();
    }

    /* renamed from: com.android.systemui.volume.Interaction.1 */
    static class C05441 implements OnTouchListener {
        final /* synthetic */ Callback val$callback;

        C05441(Callback callback) {
            this.val$callback = callback;
        }

        public boolean onTouch(View v, MotionEvent event) {
            this.val$callback.onInteraction();
            return false;
        }
    }

    /* renamed from: com.android.systemui.volume.Interaction.2 */
    static class C05452 implements OnGenericMotionListener {
        final /* synthetic */ Callback val$callback;

        C05452(Callback callback) {
            this.val$callback = callback;
        }

        public boolean onGenericMotion(View v, MotionEvent event) {
            this.val$callback.onInteraction();
            return false;
        }
    }

    public static void register(View v, Callback callback) {
        v.setOnTouchListener(new C05441(callback));
        v.setOnGenericMotionListener(new C05452(callback));
    }
}
