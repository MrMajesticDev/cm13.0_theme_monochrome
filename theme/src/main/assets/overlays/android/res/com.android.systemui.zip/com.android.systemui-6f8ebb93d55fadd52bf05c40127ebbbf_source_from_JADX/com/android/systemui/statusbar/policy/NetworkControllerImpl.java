package com.android.systemui.statusbar.policy;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings.Global;
import android.telephony.ServiceState;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.SubscriptionManager.OnSubscriptionsChangedListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.MathUtils;
import android.widget.TextView;
import com.android.systemui.DemoMode;
import com.android.systemui.statusbar.policy.MobileDataControllerImpl.Callback;
import com.android.systemui.statusbar.policy.NetworkController.AccessPointController;
import com.android.systemui.statusbar.policy.NetworkController.IconState;
import com.android.systemui.statusbar.policy.NetworkController.MobileDataController;
import com.android.systemui.statusbar.policy.NetworkController.SignalCallback;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class NetworkControllerImpl extends BroadcastReceiver implements DemoMode, NetworkController {
    static final boolean CHATTY;
    static final boolean DEBUG;
    private final AccessPointControllerImpl mAccessPoints;
    private boolean mAirplaneMode;
    private final CallbackHandler mCallbackHandler;
    private Config mConfig;
    private final BitSet mConnectedTransports;
    private final ConnectivityManager mConnectivityManager;
    private final Context mContext;
    private List<SubscriptionInfo> mCurrentSubscriptions;
    private int mCurrentUserId;
    private MobileSignalController mDefaultSignalController;
    private boolean mDemoInetCondition;
    private boolean mDemoMode;
    private WifiState mDemoWifiState;
    private int mEmergencySource;
    final EthernetSignalController mEthernetSignalController;
    private final boolean mHasMobileDataFeature;
    private boolean mHasNoSims;
    private boolean mInetCondition;
    private boolean mIsEmergency;
    ServiceState mLastServiceState;
    boolean mListening;
    private Locale mLocale;
    private final MobileDataControllerImpl mMobileDataController;
    final Map<Integer, MobileSignalController> mMobileSignalControllers;
    private TextView mNetWorkNameLabelView;
    private final TelephonyManager mPhone;
    private final Handler mReceiverHandler;
    private final Runnable mRegisterListeners;
    private final SubscriptionDefaults mSubDefaults;
    private OnSubscriptionsChangedListener mSubscriptionListener;
    private final SubscriptionManager mSubscriptionManager;
    private final BitSet mValidatedTransports;
    private final WifiManager mWifiManager;
    final WifiSignalController mWifiSignalController;

    public interface EmergencyListener {
        void setEmergencyCallsOnly(boolean z);
    }

    /* renamed from: com.android.systemui.statusbar.policy.NetworkControllerImpl.1 */
    class C04851 implements Callback {
        C04851() {
        }

        public void onMobileDataEnabled(boolean enabled) {
            NetworkControllerImpl.this.mCallbackHandler.setMobileDataEnabled(enabled);
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.NetworkControllerImpl.2 */
    class C04862 extends AsyncTask<Void, Void, Void> {
        final /* synthetic */ boolean val$enabled;

        C04862(boolean z) {
            this.val$enabled = z;
        }

        protected Void doInBackground(Void... args) {
            int wifiApState = NetworkControllerImpl.this.mWifiManager.getWifiApState();
            if (this.val$enabled && (wifiApState == 12 || wifiApState == 13)) {
                NetworkControllerImpl.this.mWifiManager.setWifiApEnabled(null, false);
            }
            NetworkControllerImpl.this.mWifiManager.setWifiEnabled(this.val$enabled);
            return null;
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.NetworkControllerImpl.3 */
    class C04873 implements Runnable {
        C04873() {
        }

        public void run() {
            NetworkControllerImpl.this.handleConfigurationChanged();
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.NetworkControllerImpl.4 */
    class C04884 implements Comparator<SubscriptionInfo> {
        C04884() {
        }

        public int compare(SubscriptionInfo lhs, SubscriptionInfo rhs) {
            return lhs.getSimSlotIndex() == rhs.getSimSlotIndex() ? lhs.getSubscriptionId() - rhs.getSubscriptionId() : lhs.getSimSlotIndex() - rhs.getSimSlotIndex();
        }
    }

    /* renamed from: com.android.systemui.statusbar.policy.NetworkControllerImpl.5 */
    class C04895 implements Runnable {
        C04895() {
        }

        public void run() {
            NetworkControllerImpl.this.registerListeners();
        }
    }

    static class Config {
        boolean alwaysShowCdmaRssi;
        boolean hspaDataDistinguishable;
        boolean readIconsFromXml;
        boolean show4gForLte;
        boolean showAtLeast3G;
        boolean showLocale;
        boolean showRat;
        boolean showRsrpSignalLevelforLTE;

        Config() {
            this.showAtLeast3G = false;
            this.alwaysShowCdmaRssi = false;
            this.show4gForLte = false;
        }

        static Config readConfig(Context context) {
            Config config = new Config();
            Resources res = context.getResources();
            config.showAtLeast3G = res.getBoolean(2131558408);
            config.alwaysShowCdmaRssi = res.getBoolean(17956964);
            config.show4gForLte = res.getBoolean(2131558414);
            config.hspaDataDistinguishable = res.getBoolean(2131558405);
            config.readIconsFromXml = res.getBoolean(2131558419);
            config.showRsrpSignalLevelforLTE = res.getBoolean(2131558415);
            config.showLocale = res.getBoolean(17957034);
            config.showRat = res.getBoolean(17957035);
            return config;
        }
    }

    private class SubListener extends OnSubscriptionsChangedListener {
        private SubListener() {
        }

        public void onSubscriptionsChanged() {
            NetworkControllerImpl.this.updateMobileControllers();
        }
    }

    public static class SubscriptionDefaults {
        public int getDefaultVoiceSubId() {
            return SubscriptionManager.getDefaultVoiceSubId();
        }

        public int getDefaultDataSubId() {
            return SubscriptionManager.getDefaultDataSubId();
        }
    }

    static {
        DEBUG = Log.isLoggable("NetworkController", 3);
        CHATTY = Log.isLoggable("NetworkControllerChat", 3);
    }

    public NetworkControllerImpl(Context context, Looper bgLooper) {
        this(context, (ConnectivityManager) context.getSystemService("connectivity"), (TelephonyManager) context.getSystemService("phone"), (WifiManager) context.getSystemService("wifi"), SubscriptionManager.from(context), Config.readConfig(context), bgLooper, new CallbackHandler(), new AccessPointControllerImpl(context, bgLooper), new MobileDataControllerImpl(context), new SubscriptionDefaults());
        this.mReceiverHandler.post(this.mRegisterListeners);
    }

    NetworkControllerImpl(Context context, ConnectivityManager connectivityManager, TelephonyManager telephonyManager, WifiManager wifiManager, SubscriptionManager subManager, Config config, Looper bgLooper, CallbackHandler callbackHandler, AccessPointControllerImpl accessPointController, MobileDataControllerImpl mobileDataController, SubscriptionDefaults defaultsHandler) {
        this.mMobileSignalControllers = new HashMap();
        this.mConnectedTransports = new BitSet();
        this.mValidatedTransports = new BitSet();
        this.mAirplaneMode = false;
        this.mLocale = null;
        this.mCurrentSubscriptions = new ArrayList();
        this.mRegisterListeners = new C04895();
        this.mContext = context;
        this.mConfig = config;
        this.mReceiverHandler = new Handler(bgLooper);
        this.mCallbackHandler = callbackHandler;
        this.mSubscriptionManager = subManager;
        this.mSubDefaults = defaultsHandler;
        this.mConnectivityManager = connectivityManager;
        this.mHasMobileDataFeature = this.mConnectivityManager.isNetworkSupported(0);
        this.mPhone = telephonyManager;
        this.mWifiManager = wifiManager;
        this.mLocale = this.mContext.getResources().getConfiguration().locale;
        this.mAccessPoints = accessPointController;
        this.mMobileDataController = mobileDataController;
        this.mMobileDataController.setNetworkController(this);
        this.mMobileDataController.setCallback(new C04851());
        this.mWifiSignalController = new WifiSignalController(this.mContext, this.mHasMobileDataFeature, this.mCallbackHandler, this);
        this.mEthernetSignalController = new EthernetSignalController(this.mContext, this.mCallbackHandler, this);
        updateAirplaneMode(true);
    }

    private void registerListeners() {
        for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
            mobileSignalController.registerListener();
        }
        if (this.mSubscriptionListener == null) {
            this.mSubscriptionListener = new SubListener();
        }
        this.mSubscriptionManager.addOnSubscriptionsChangedListener(this.mSubscriptionListener);
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.net.wifi.RSSI_CHANGED");
        filter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        filter.addAction("android.net.wifi.STATE_CHANGE");
        filter.addAction("android.intent.action.SIM_STATE_CHANGED");
        filter.addAction("android.intent.action.ACTION_DEFAULT_DATA_SUBSCRIPTION_CHANGED");
        filter.addAction("android.intent.action.ACTION_DEFAULT_VOICE_SUBSCRIPTION_CHANGED");
        filter.addAction("android.intent.action.SERVICE_STATE");
        filter.addAction("android.provider.Telephony.SPN_STRINGS_UPDATED");
        filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        filter.addAction("android.net.conn.INET_CONDITION_ACTION");
        filter.addAction("android.intent.action.LOCALE_CHANGED");
        filter.addAction("android.intent.action.AIRPLANE_MODE");
        this.mContext.registerReceiver(this, filter, null, this.mReceiverHandler);
        this.mListening = true;
        updateMobileControllers();
    }

    private void unregisterListeners() {
        this.mListening = false;
        for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
            mobileSignalController.unregisterListener();
        }
        this.mSubscriptionManager.removeOnSubscriptionsChangedListener(this.mSubscriptionListener);
        this.mContext.unregisterReceiver(this);
    }

    public AccessPointController getAccessPointController() {
        return this.mAccessPoints;
    }

    public MobileDataController getMobileDataController() {
        return this.mMobileDataController;
    }

    public void addEmergencyListener(EmergencyListener listener) {
        this.mCallbackHandler.setListening(listener, true);
        this.mCallbackHandler.setEmergencyCallsOnly(isEmergencyOnly());
    }

    public void removeEmergencyListener(EmergencyListener listener) {
        this.mCallbackHandler.setListening(listener, false);
    }

    public boolean hasMobileDataFeature() {
        return this.mHasMobileDataFeature;
    }

    public boolean hasVoiceCallingFeature() {
        return this.mPhone.getPhoneType() != 0;
    }

    private MobileSignalController getDataController() {
        int dataSubId = this.mSubDefaults.getDefaultDataSubId();
        if (!SubscriptionManager.isValidSubscriptionId(dataSubId)) {
            if (DEBUG) {
                Log.e("NetworkController", "No data sim selected");
            }
            return this.mDefaultSignalController;
        } else if (this.mMobileSignalControllers.containsKey(Integer.valueOf(dataSubId))) {
            return (MobileSignalController) this.mMobileSignalControllers.get(Integer.valueOf(dataSubId));
        } else {
            if (DEBUG) {
                Log.e("NetworkController", "Cannot find controller for data sub: " + dataSubId);
            }
            return this.mDefaultSignalController;
        }
    }

    public String getMobileDataNetworkName() {
        MobileSignalController controller = getDataController();
        return controller != null ? ((MobileState) controller.getState()).networkNameData : "";
    }

    public boolean isEmergencyOnly() {
        if (this.mMobileSignalControllers.size() == 0) {
            this.mEmergencySource = 0;
            if (this.mLastServiceState == null || !this.mLastServiceState.isEmergencyOnly()) {
                return false;
            }
            return true;
        }
        int voiceSubId = this.mSubDefaults.getDefaultVoiceSubId();
        if (!SubscriptionManager.isValidSubscriptionId(voiceSubId)) {
            for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
                if (!((MobileState) mobileSignalController.getState()).isEmergency) {
                    this.mEmergencySource = mobileSignalController.mSubscriptionInfo.getSubscriptionId() + 100;
                    if (DEBUG) {
                        Log.d("NetworkController", "Found emergency " + mobileSignalController.mTag);
                    }
                    return false;
                }
            }
        }
        if (this.mMobileSignalControllers.containsKey(Integer.valueOf(voiceSubId))) {
            this.mEmergencySource = voiceSubId + 200;
            if (DEBUG) {
                Log.d("NetworkController", "Getting emergency from " + voiceSubId);
            }
            return ((MobileState) ((MobileSignalController) this.mMobileSignalControllers.get(Integer.valueOf(voiceSubId))).getState()).isEmergency;
        }
        if (DEBUG) {
            Log.e("NetworkController", "Cannot find controller for voice sub: " + voiceSubId);
        }
        this.mEmergencySource = voiceSubId + 300;
        return true;
    }

    void recalculateEmergency() {
        this.mIsEmergency = isEmergencyOnly();
        this.mCallbackHandler.setEmergencyCallsOnly(this.mIsEmergency);
    }

    public void addSignalCallback(SignalCallback cb) {
        this.mCallbackHandler.setListening(cb, true);
        this.mCallbackHandler.setSubs(this.mCurrentSubscriptions);
        this.mCallbackHandler.setIsAirplaneMode(new IconState(this.mAirplaneMode, 2130837822, 2131362078, this.mContext));
        this.mCallbackHandler.setNoSims(this.mHasNoSims);
        this.mWifiSignalController.notifyListeners();
        this.mEthernetSignalController.notifyListeners();
        for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
            mobileSignalController.notifyListeners();
        }
    }

    public void removeSignalCallback(SignalCallback cb) {
        this.mCallbackHandler.setListening(cb, false);
    }

    public void setWifiEnabled(boolean enabled) {
        new C04862(enabled).execute(new Void[0]);
    }

    public void onReceive(Context context, Intent intent) {
        if (CHATTY) {
            Log.d("NetworkController", "onReceive: intent=" + intent);
        }
        String action = intent.getAction();
        if (action.equals("android.net.conn.CONNECTIVITY_CHANGE") || action.equals("android.net.conn.INET_CONDITION_ACTION")) {
            updateConnectivity();
        } else if (action.equals("android.intent.action.AIRPLANE_MODE")) {
            refreshLocale();
            updateAirplaneMode(false);
        } else if (action.equals("android.intent.action.ACTION_DEFAULT_VOICE_SUBSCRIPTION_CHANGED")) {
            recalculateEmergency();
        } else if (action.equals("android.intent.action.ACTION_DEFAULT_DATA_SUBSCRIPTION_CHANGED")) {
            for (MobileSignalController controller : this.mMobileSignalControllers.values()) {
                controller.handleBroadcast(intent);
            }
        } else if (action.equals("android.intent.action.SIM_STATE_CHANGED")) {
            updateMobileControllers();
        } else if (action.equals("android.intent.action.LOCALE_CHANGED")) {
            for (MobileSignalController controller2 : this.mMobileSignalControllers.values()) {
                controller2.handleBroadcast(intent);
            }
        } else if (action.equals("android.intent.action.SERVICE_STATE")) {
            this.mLastServiceState = ServiceState.newFromBundle(intent.getExtras());
            if (this.mMobileSignalControllers.size() == 0) {
                recalculateEmergency();
            }
        } else {
            int subId = intent.getIntExtra("subscription", -1);
            if (!SubscriptionManager.isValidSubscriptionId(subId)) {
                this.mWifiSignalController.handleBroadcast(intent);
            } else if (this.mMobileSignalControllers.containsKey(Integer.valueOf(subId))) {
                ((MobileSignalController) this.mMobileSignalControllers.get(Integer.valueOf(subId))).handleBroadcast(intent);
            } else {
                updateMobileControllers();
            }
        }
    }

    public void onConfigurationChanged() {
        this.mConfig = Config.readConfig(this.mContext);
        this.mReceiverHandler.post(new C04873());
    }

    void handleConfigurationChanged() {
        for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
            mobileSignalController.setConfiguration(this.mConfig);
        }
        refreshLocale();
    }

    private void updateMobileControllers() {
        if (this.mListening) {
            doUpdateMobileControllers();
        }
    }

    void doUpdateMobileControllers() {
        List<SubscriptionInfo> subscriptions = this.mSubscriptionManager.getActiveSubscriptionInfoList();
        if (subscriptions == null) {
            subscriptions = Collections.emptyList();
        }
        if (hasCorrectMobileControllers(subscriptions)) {
            updateNoSims();
            return;
        }
        setCurrentSubscriptions(subscriptions);
        updateNoSims();
        recalculateEmergency();
    }

    protected void updateNoSims() {
        boolean hasNoSims = this.mHasMobileDataFeature && this.mMobileSignalControllers.size() == 0;
        if (hasNoSims != this.mHasNoSims) {
            this.mHasNoSims = hasNoSims;
            this.mCallbackHandler.setNoSims(this.mHasNoSims);
        }
    }

    void setCurrentSubscriptions(List<SubscriptionInfo> subscriptions) {
        Collections.sort(subscriptions, new C04884());
        this.mCurrentSubscriptions = subscriptions;
        HashMap<Integer, MobileSignalController> cachedControllers = new HashMap(this.mMobileSignalControllers);
        this.mMobileSignalControllers.clear();
        int num = subscriptions.size();
        for (int i = 0; i < num; i++) {
            int subId = ((SubscriptionInfo) subscriptions.get(i)).getSubscriptionId();
            if (cachedControllers.containsKey(Integer.valueOf(subId))) {
                this.mMobileSignalControllers.put(Integer.valueOf(subId), cachedControllers.remove(Integer.valueOf(subId)));
            } else {
                MobileSignalController controller = new MobileSignalController(this.mContext, this.mConfig, this.mHasMobileDataFeature, this.mPhone, this.mCallbackHandler, this, (SubscriptionInfo) subscriptions.get(i), this.mSubDefaults, this.mReceiverHandler.getLooper());
                this.mMobileSignalControllers.put(Integer.valueOf(subId), controller);
                if (((SubscriptionInfo) subscriptions.get(i)).getSimSlotIndex() == 0) {
                    this.mDefaultSignalController = controller;
                }
                if (this.mListening) {
                    controller.registerListener();
                }
            }
        }
        if (this.mListening) {
            for (Integer key : cachedControllers.keySet()) {
                if (cachedControllers.get(key) == this.mDefaultSignalController) {
                    this.mDefaultSignalController = null;
                }
                ((MobileSignalController) cachedControllers.get(key)).unregisterListener();
            }
        }
        this.mCallbackHandler.setSubs(subscriptions);
        notifyAllListeners();
        pushConnectivityToSignals();
        updateAirplaneMode(true);
    }

    boolean hasCorrectMobileControllers(List<SubscriptionInfo> allSubscriptions) {
        if (allSubscriptions.size() != this.mMobileSignalControllers.size()) {
            return false;
        }
        for (SubscriptionInfo info : allSubscriptions) {
            if (!this.mMobileSignalControllers.containsKey(Integer.valueOf(info.getSubscriptionId()))) {
                return false;
            }
        }
        return true;
    }

    private void updateAirplaneMode(boolean force) {
        boolean airplaneMode = true;
        if (Global.getInt(this.mContext.getContentResolver(), "airplane_mode_on", 0) != 1) {
            airplaneMode = false;
        }
        if (airplaneMode != this.mAirplaneMode || force) {
            this.mAirplaneMode = airplaneMode;
            for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
                mobileSignalController.setAirplaneMode(this.mAirplaneMode);
            }
            notifyListeners();
        }
    }

    private void refreshLocale() {
        Locale current = this.mContext.getResources().getConfiguration().locale;
        if (!current.equals(this.mLocale)) {
            this.mLocale = current;
            notifyAllListeners();
        }
    }

    private void notifyAllListeners() {
        notifyListeners();
        for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
            mobileSignalController.notifyListeners();
        }
        this.mWifiSignalController.notifyListeners();
        this.mEthernetSignalController.notifyListeners();
    }

    private void notifyListeners() {
        this.mCallbackHandler.setIsAirplaneMode(new IconState(this.mAirplaneMode, 2130837822, 2131362078, this.mContext));
        this.mCallbackHandler.setNoSims(this.mHasNoSims);
    }

    private void updateConnectivity() {
        this.mConnectedTransports.clear();
        this.mValidatedTransports.clear();
        for (NetworkCapabilities nc : this.mConnectivityManager.getDefaultNetworkCapabilitiesForUser(this.mCurrentUserId)) {
            for (int transportType : nc.getTransportTypes()) {
                this.mConnectedTransports.set(transportType);
                if (nc.hasCapability(16)) {
                    this.mValidatedTransports.set(transportType);
                }
            }
        }
        if (CHATTY) {
            Log.d("NetworkController", "updateConnectivity: mConnectedTransports=" + this.mConnectedTransports);
            Log.d("NetworkController", "updateConnectivity: mValidatedTransports=" + this.mValidatedTransports);
        }
        this.mInetCondition = !this.mValidatedTransports.isEmpty();
        pushConnectivityToSignals();
    }

    private void pushConnectivityToSignals() {
        for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
            mobileSignalController.updateConnectivity(this.mConnectedTransports, this.mValidatedTransports);
        }
        this.mWifiSignalController.updateConnectivity(this.mConnectedTransports, this.mValidatedTransports);
        this.mEthernetSignalController.updateConnectivity(this.mConnectedTransports, this.mValidatedTransports);
    }

    private void setTextViewVisibility(TextView v) {
        String networkName = getMobileDataNetworkName();
        if (networkName.equals(this.mContext.getString(17040004)) || networkName.equals(this.mContext.getString(17040028))) {
            v.setVisibility(8);
        } else {
            v.setVisibility(0);
        }
    }

    public void addNetworkLabelView(TextView v) {
        if (v != null) {
            this.mNetWorkNameLabelView = v;
            this.mNetWorkNameLabelView.setText(getMobileDataNetworkName());
            setTextViewVisibility(this.mNetWorkNameLabelView);
        }
    }

    public void removeNetworkLabelView() {
        if (this.mNetWorkNameLabelView != null) {
            this.mNetWorkNameLabelView = null;
        }
    }

    public void updateNetworkLabelView() {
        if (this.mNetWorkNameLabelView != null) {
            this.mNetWorkNameLabelView.setText(getMobileDataNetworkName());
            setTextViewVisibility(this.mNetWorkNameLabelView);
        }
    }

    public void dump(FileDescriptor fd, PrintWriter pw, String[] args) {
        pw.println("NetworkController state:");
        pw.println("  - telephony ------");
        pw.print("  hasVoiceCallingFeature()=");
        pw.println(hasVoiceCallingFeature());
        pw.println("  - connectivity ------");
        pw.print("  mConnectedTransports=");
        pw.println(this.mConnectedTransports);
        pw.print("  mValidatedTransports=");
        pw.println(this.mValidatedTransports);
        pw.print("  mInetCondition=");
        pw.println(this.mInetCondition);
        pw.print("  mAirplaneMode=");
        pw.println(this.mAirplaneMode);
        pw.print("  mLocale=");
        pw.println(this.mLocale);
        pw.print("  mLastServiceState=");
        pw.println(this.mLastServiceState);
        pw.print("  mIsEmergency=");
        pw.println(this.mIsEmergency);
        pw.print("  mEmergencySource=");
        pw.println(emergencyToString(this.mEmergencySource));
        for (MobileSignalController mobileSignalController : this.mMobileSignalControllers.values()) {
            mobileSignalController.dump(pw);
        }
        this.mWifiSignalController.dump(pw);
        this.mEthernetSignalController.dump(pw);
        this.mAccessPoints.dump(pw);
    }

    private static final String emergencyToString(int emergencySource) {
        if (emergencySource > 300) {
            return "NO_SUB(" + (emergencySource - 300) + ")";
        }
        if (emergencySource > 200) {
            return "VOICE_CONTROLLER(" + (emergencySource - 200) + ")";
        }
        if (emergencySource > 100) {
            return "FIRST_CONTROLLER(" + (emergencySource - 100) + ")";
        }
        if (emergencySource == 0) {
            return "NO_CONTROLLERS";
        }
        return "UNKNOWN_SOURCE";
    }

    public void dispatchDemoCommand(String command, Bundle args) {
        MobileSignalController controller;
        if (!this.mDemoMode) {
            if (command.equals("enter")) {
                if (DEBUG) {
                    Log.d("NetworkController", "Entering demo mode");
                }
                unregisterListeners();
                this.mDemoMode = true;
                this.mDemoInetCondition = this.mInetCondition;
                this.mDemoWifiState = (WifiState) this.mWifiSignalController.getState();
                return;
            }
        }
        if (this.mDemoMode) {
            if (command.equals("exit")) {
                if (DEBUG) {
                    Log.d("NetworkController", "Exiting demo mode");
                }
                this.mDemoMode = false;
                updateMobileControllers();
                for (MobileSignalController controller2 : this.mMobileSignalControllers.values()) {
                    controller2.resetLastState();
                }
                this.mWifiSignalController.resetLastState();
                this.mReceiverHandler.post(this.mRegisterListeners);
                notifyAllListeners();
                return;
            }
        }
        if (this.mDemoMode) {
            if (command.equals("network")) {
                boolean show;
                String level;
                List<SubscriptionInfo> subs;
                String airplane = args.getString("airplane");
                if (airplane != null) {
                    this.mCallbackHandler.setIsAirplaneMode(new IconState(airplane.equals("show"), 2130837822, 2131362078, this.mContext));
                }
                String fully = args.getString("fully");
                if (fully != null) {
                    this.mDemoInetCondition = Boolean.parseBoolean(fully);
                    BitSet connected = new BitSet();
                    if (this.mDemoInetCondition) {
                        connected.set(this.mWifiSignalController.mTransportType);
                    }
                    this.mWifiSignalController.updateConnectivity(connected, connected);
                    for (MobileSignalController controller22 : this.mMobileSignalControllers.values()) {
                        if (this.mDemoInetCondition) {
                            connected.set(controller22.mTransportType);
                        }
                        controller22.updateConnectivity(connected, connected);
                    }
                }
                String wifi = args.getString("wifi");
                if (wifi != null) {
                    show = wifi.equals("show");
                    level = args.getString("level");
                    if (level != null) {
                        this.mDemoWifiState.level = level.equals("null") ? -1 : Math.min(Integer.parseInt(level), WifiIcons.WIFI_LEVEL_COUNT - 1);
                        this.mDemoWifiState.connected = this.mDemoWifiState.level >= 0;
                    }
                    this.mDemoWifiState.enabled = show;
                    this.mWifiSignalController.notifyListeners();
                }
                String sims = args.getString("sims");
                if (sims != null) {
                    int num = MathUtils.constrain(Integer.parseInt(sims), 1, 8);
                    subs = new ArrayList();
                    if (num != this.mMobileSignalControllers.size()) {
                        this.mMobileSignalControllers.clear();
                        int start = this.mSubscriptionManager.getActiveSubscriptionInfoCountMax();
                        for (int i = start; i < start + num; i++) {
                            subs.add(addSignalController(i, i));
                        }
                        this.mCallbackHandler.setSubs(subs);
                    }
                }
                String nosim = args.getString("nosim");
                if (nosim != null) {
                    this.mHasNoSims = nosim.equals("show");
                    this.mCallbackHandler.setNoSims(this.mHasNoSims);
                }
                String mobile = args.getString("mobile");
                if (mobile != null) {
                    show = mobile.equals("show");
                    String datatype = args.getString("datatype");
                    String slotString = args.getString("slot");
                    int slot = MathUtils.constrain(TextUtils.isEmpty(slotString) ? 0 : Integer.parseInt(slotString), 0, 8);
                    subs = new ArrayList();
                    while (true) {
                        if (this.mMobileSignalControllers.size() > slot) {
                            break;
                        }
                        int nextSlot = this.mMobileSignalControllers.size();
                        subs.add(addSignalController(nextSlot, nextSlot));
                    }
                    if (!subs.isEmpty()) {
                        this.mCallbackHandler.setSubs(subs);
                    }
                    controller22 = ((MobileSignalController[]) this.mMobileSignalControllers.values().toArray(new MobileSignalController[0]))[slot];
                    ((MobileState) controller22.getState()).dataSim = datatype != null;
                    if (datatype != null) {
                        IconGroup iconGroup;
                        MobileState mobileState = (MobileState) controller22.getState();
                        if (datatype.equals("1x")) {
                            iconGroup = TelephonyIcons.ONE_X;
                        } else {
                            if (datatype.equals("3g")) {
                                iconGroup = TelephonyIcons.THREE_G;
                            } else {
                                if (datatype.equals("4g")) {
                                    iconGroup = TelephonyIcons.FOUR_G;
                                } else {
                                    if (datatype.equals("4g+")) {
                                        iconGroup = TelephonyIcons.FOUR_G_PLUS;
                                    } else {
                                        if (datatype.equals("e")) {
                                            iconGroup = TelephonyIcons.f24E;
                                        } else {
                                            if (datatype.equals("g")) {
                                                iconGroup = TelephonyIcons.f25G;
                                            } else {
                                                if (datatype.equals("h")) {
                                                    iconGroup = TelephonyIcons.f26H;
                                                } else {
                                                    if (datatype.equals("lte")) {
                                                        iconGroup = TelephonyIcons.LTE;
                                                    } else {
                                                        iconGroup = datatype.equals("roam") ? TelephonyIcons.ROAMING : TelephonyIcons.UNKNOWN;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        mobileState.iconGroup = iconGroup;
                    }
                    int[][] icons = TelephonyIcons.TELEPHONY_SIGNAL_STRENGTH;
                    level = args.getString("level");
                    if (level != null) {
                        ((MobileState) controller22.getState()).level = level.equals("null") ? -1 : Math.min(Integer.parseInt(level), icons[0].length - 1);
                        ((MobileState) controller22.getState()).connected = ((MobileState) controller22.getState()).level >= 0;
                    }
                    ((MobileState) controller22.getState()).enabled = show;
                    controller22.notifyListeners();
                }
                String carrierNetworkChange = args.getString("carriernetworkchange");
                if (carrierNetworkChange != null) {
                    show = carrierNetworkChange.equals("show");
                    for (MobileSignalController controller222 : this.mMobileSignalControllers.values()) {
                        controller222.setCarrierNetworkChangeMode(show);
                    }
                }
            }
        }
    }

    private SubscriptionInfo addSignalController(int id, int simSlotIndex) {
        SubscriptionInfo info = new SubscriptionInfo(id, "", simSlotIndex, "", "", 0, 0, "", 0, null, 0, 0, "");
        this.mMobileSignalControllers.put(Integer.valueOf(id), new MobileSignalController(this.mContext, this.mConfig, this.mHasMobileDataFeature, this.mPhone, this.mCallbackHandler, this, info, this.mSubDefaults, this.mReceiverHandler.getLooper()));
        return info;
    }
}
